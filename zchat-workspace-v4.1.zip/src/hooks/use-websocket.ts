'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

interface UseWebSocketOptions {
  onMessage?: (data: unknown) => void;
  onOpen?: () => void;
  onClose?: () => void;
}

export function useWebSocket(sessionId: string | null, options?: UseWebSocketOptions) {
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttempts = useRef(0);

  const connect = useCallback(() => {
    if (!sessionId) return;
    if (typeof window === 'undefined') return;

    const token = getSessionToken();
    if (!token) return;

    const wsUrl = `ws://${window.location.hostname}:3001?sessionId=${sessionId}&token=${token}`;

    try {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setIsConnected(true);
        reconnectAttempts.current = 0;
        options?.onOpen?.();
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data) as unknown;
          options?.onMessage?.(data);
        } catch {
          // skip non-JSON
        }
      };

      ws.onclose = () => {
        setIsConnected(false);
        options?.onClose?.();
        // Reconnect with exponential backoff (max 30s)
        if (sessionId && reconnectAttempts.current < 10) {
          const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000);
          reconnectTimerRef.current = setTimeout(() => {
            reconnectAttempts.current++;
            connect();
          }, delay);
        }
      };

      ws.onerror = () => {
        ws.close();
      };
    } catch {
      // WebSocket not available
    }
  }, [sessionId, options]);

  useEffect(() => {
    connect();
    return () => {
      if (reconnectTimerRef.current) clearTimeout(reconnectTimerRef.current);
      wsRef.current?.close();
      wsRef.current = null;
    };
  }, [connect]);

  const send = useCallback((message: unknown) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message));
    }
  }, []);

  return { isConnected, send };
}

function getSessionToken(): string | null {
  if (typeof window === 'undefined') return null;
  // The token is stored by the auth layer after login.
  // For MVP, we read from localStorage.
  return localStorage.getItem('zchat-ws-token');
}
