'use client';

import { useCallback, useRef, useState } from 'react';

interface UseSseOptions {
  onMessage?: (data: unknown) => void;
  onError?: (err: Event) => void;
  onClose?: () => void;
}

export function useSse() {
  const [isConnected, setIsConnected] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  const connect = useCallback(async (
    url: string,
    body: unknown,
    options?: UseSseOptions,
  ) => {
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      setIsConnected(true);

      const reader = response.body?.getReader();
      if (!reader) throw new Error('No response body');

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') {
              options?.onClose?.();
              return;
            }
            try {
              options?.onMessage?.(JSON.parse(data));
            } catch {
              // skip non-JSON
            }
          }
        }
      }

      options?.onClose?.();
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') return;
      throw err;
    } finally {
      setIsConnected(false);
    }
  }, []);

  const disconnect = useCallback(() => {
    abortControllerRef.current?.abort();
    abortControllerRef.current = null;
    setIsConnected(false);
  }, []);

  return { isConnected, connect, disconnect };
}
