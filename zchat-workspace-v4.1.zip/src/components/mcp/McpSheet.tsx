'use client';

import { useEffect, useState } from 'react';
import { Sheet } from '@/components/ui/Sheet';
import { Button } from '@/components/ui/Button';
import { Loader2, FlaskConical, Check } from 'lucide-react';

interface McpServer {
  id: string;
  name: string;
  transport: string;
  command: string | null;
  enabled: boolean;
  toolsCache: Array<{ name: string; description: string }>;
}

interface McpSheetProps {
  open: boolean;
  onClose: () => void;
}

export function McpSheet({ open, onClose }: McpSheetProps) {
  const [servers, setServers] = useState<McpServer[]>([]);
  const [loading, setLoading] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);

  useEffect(() => {
    if (open) loadServers();
  }, [open]);

  async function loadServers() {
    setLoading(true);
    try {
      const res = await fetch('/api/mcp/servers');
      if (!res.ok) return;
      const data = await res.json() as { data: McpServer[] };
      setServers(data.data);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  async function testServer(serverId: string) {
    setTestingId(serverId);
    try {
      await fetch(`/api/mcp/servers/${serverId}/test`, { method: 'POST' });
      loadServers();
    } catch {
      // ignore
    } finally {
      setTestingId(null);
    }
  }

  return (
    <Sheet open={open} onClose={onClose} title="MCP Servers" description="Model Context Protocol. Add Filesystem + Memory servers for tool access." width="md">
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-5 w-5 animate-spin text-zinc-500" />
        </div>
      ) : servers.length === 0 ? (
        <div className="py-8 text-center text-sm text-zinc-500">
          No MCP servers configured. Add one to enable tool access.
        </div>
      ) : (
        <div className="space-y-3">
          {servers.map((server) => (
            <div key={server.id} className="rounded-lg border border-zinc-800 bg-zinc-950 p-4">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-sm font-medium text-zinc-100">{server.name}</h3>
                  <p className="text-xs text-zinc-500">{server.transport} · {server.command ?? 'no command'}</p>
                </div>
                <Button size="sm" variant="outline" onClick={() => testServer(server.id)} disabled={testingId === server.id}>
                  {testingId === server.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <FlaskConical className="h-3 w-3" />}
                  Test
                </Button>
              </div>
              {server.toolsCache.length > 0 && (
                <div className="mt-3 space-y-1">
                  <p className="text-xs text-zinc-600">{server.toolsCache.length} tools discovered:</p>
                  <div className="flex flex-wrap gap-1">
                    {server.toolsCache.slice(0, 8).map((tool) => (
                      <span key={tool.name} className="flex items-center gap-1 rounded bg-zinc-900 px-1.5 py-0.5 text-xs text-zinc-400">
                        <Check className="h-2.5 w-2.5 text-green-400" />
                        {tool.name}
                      </span>
                    ))}
                    {server.toolsCache.length > 8 && (
                      <span className="text-xs text-zinc-600">+{server.toolsCache.length - 8} more</span>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </Sheet>
  );
}
