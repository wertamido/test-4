'use client';

import { useEffect, useState } from 'react';
import { Sheet } from '@/components/ui/Sheet';
import { Button } from '@/components/ui/Button';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle2, XCircle, Loader2, Key, Power } from 'lucide-react';
import type { ProviderRecord } from '@/types';

interface ProvidersSheetProps {
  open: boolean;
  onClose: () => void;
}

export function ProvidersSheet({ open, onClose }: ProvidersSheetProps) {
  const [providers, setProviders] = useState<ProviderRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, { matched: boolean; claimed: string } | null>>({});
  const { toast, error: showError } = useToast();

  useEffect(() => {
    if (open) loadProviders();
  }, [open]);

  async function loadProviders() {
    setLoading(true);
    try {
      const res = await fetch('/api/providers');
      if (!res.ok) throw new Error('Failed to load providers');
      const data = await res.json() as { data: ProviderRecord[] };
      setProviders(data.data);
    } catch (err) {
      showError('Failed to load providers', err instanceof Error ? err.message : undefined);
    } finally {
      setLoading(false);
    }
  }

  async function toggleProvider(providerId: string, enabled: boolean) {
    try {
      const res = await fetch(`/api/providers/${providerId}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ enabled }),
      });
      if (!res.ok) throw new Error('Failed to update provider');
      toast(enabled ? 'Provider enabled' : 'Provider disabled');
      loadProviders();
    } catch (err) {
      showError('Failed to update provider', err instanceof Error ? err.message : undefined);
    }
  }

  async function testProvider(providerId: string) {
    setTestingId(providerId);
    setTestResults((prev) => ({ ...prev, [providerId]: null }));
    try {
      const res = await fetch(`/api/providers/${providerId}/test`, { method: 'POST' });
      const data = await res.json() as { data?: { matched: boolean; claimedModel: string }; error?: { message: string } };
      if (data.data) {
        setTestResults((prev) => ({
          ...prev,
          [providerId]: { matched: data.data!.matched, claimed: data.data!.claimedModel },
        }));
      } else if (data.error) {
        showError('Provider test failed', data.error.message);
      }
    } catch (err) {
      showError('Provider test failed', err instanceof Error ? err.message : undefined);
    } finally {
      setTestingId(null);
    }
  }

  return (
    <Sheet open={open} onClose={onClose} title="Providers" description="Configure LLM providers. Z.ai is enabled by default — 100% deactivatable." width="lg">
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-5 w-5 animate-spin text-zinc-500" />
        </div>
      ) : (
        <div className="space-y-3">
          {providers.map((provider) => (
            <div key={provider.id} className="rounded-lg border border-zinc-800 bg-zinc-950 p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div>
                    <h3 className="text-sm font-medium text-zinc-100">{provider.name}</h3>
                    <p className="text-xs text-zinc-500">
                      {provider.kind} {provider.isLocal && '(local)'} {provider.models.length > 0 && `· ${provider.models.length} models`}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => testProvider(provider.id)}
                    disabled={testingId === provider.id}
                  >
                    {testingId === provider.id ? <Loader2 className="h-3 w-3 animate-spin" /> : null}
                    Test
                  </Button>
                  <Button
                    size="sm"
                    variant={provider.enabled ? 'default' : 'outline'}
                    onClick={() => toggleProvider(provider.id, !provider.enabled)}
                  >
                    <Power className="h-3 w-3" />
                    {provider.enabled ? 'Enabled' : 'Disabled'}
                  </Button>
                </div>
              </div>

              {testResults[provider.id] !== undefined && testResults[provider.id] !== null && (
                <div className="mt-3 flex items-center gap-2 rounded-md border border-zinc-800 bg-black px-3 py-2 text-xs">
                  {testResults[provider.id]!.matched ? (
                    <CheckCircle2 className="h-4 w-4 text-green-400" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-400" />
                  )}
                  <span className="text-zinc-300">
                    Claimed: <code className="text-zinc-100">{testResults[provider.id]!.claimed}</code>
                    {!testResults[provider.id]!.matched && ' (model mismatch)'}
                  </span>
                </div>
              )}

              {!provider.apiKey && !provider.isLocal && (
                <div className="mt-2 flex items-center gap-1.5 text-xs text-yellow-500/80">
                  <Key className="h-3 w-3" />
                  API key required to enable
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </Sheet>
  );
}
