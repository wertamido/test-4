'use client';

import { useEffect, useState } from 'react';
import { Sheet } from '@/components/ui/Sheet';
import { Loader2 } from 'lucide-react';
import type { AgentTemplateRecord } from '@/types';

interface AgentsSheetProps {
  open: boolean;
  onClose: () => void;
}

export function AgentsSheet({ open, onClose }: AgentsSheetProps) {
  const [agents, setAgents] = useState<AgentTemplateRecord[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) loadAgents();
  }, [open]);

  async function loadAgents() {
    setLoading(true);
    try {
      const res = await fetch('/api/agents');
      if (!res.ok) return;
      const data = await res.json() as { data: AgentTemplateRecord[] };
      setAgents(data.data);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  const orchestrators = agents.filter((a) => a.category === 'orchestrator');
  const workers = agents.filter((a) => a.category === 'worker');

  return (
    <Sheet open={open} onClose={onClose} title="Agent Templates" description="10 built-in agents. 3 orchestrators + 7 workers. Each preserves model identity." width="lg">
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-5 w-5 animate-spin text-zinc-500" />
        </div>
      ) : (
        <div className="space-y-6">
          <div>
            <h3 className="mb-2 text-xs font-medium uppercase tracking-wider text-zinc-600">Orchestrators ({orchestrators.length})</h3>
            <div className="space-y-2">
              {orchestrators.map((agent) => (
                <AgentCard key={agent.id} agent={agent} />
              ))}
            </div>
          </div>
          <div>
            <h3 className="mb-2 text-xs font-medium uppercase tracking-wider text-zinc-600">Workers ({workers.length})</h3>
            <div className="space-y-2">
              {workers.map((agent) => (
                <AgentCard key={agent.id} agent={agent} />
              ))}
            </div>
          </div>
        </div>
      )}
    </Sheet>
  );
}

function AgentCard({ agent }: { agent: AgentTemplateRecord }) {
  return (
    <div className="rounded-md border border-zinc-800 bg-zinc-950 p-3">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-sm font-medium text-zinc-100">{agent.name}</h4>
          <p className="text-xs text-zinc-500">{agent.description}</p>
        </div>
        <div className="flex items-center gap-2 text-xs text-zinc-600">
          <span>{agent.preferredModel ?? 'default'}</span>
          {agent.canSpawnAgents && <span className="rounded bg-zinc-900 px-1.5 py-0.5">spawns: {agent.maxSubAgents}</span>}
        </div>
      </div>
    </div>
  );
}
