'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/Button';
import { Loader2, Play, GitBranch, ListTodo, Network } from 'lucide-react';

interface OrchestrationViewProps {
  sessionId: string;
}

interface OrchestrationResult {
  orchestrationId: string;
  status: string;
  finalResult: string | null;
  tasksCreated: number;
  tasksCompleted: number;
  tasksFailed: number;
  durationMs: number;
}

export function OrchestrationView({ sessionId }: OrchestrationViewProps) {
  const [goal, setGoal] = useState('');
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<OrchestrationResult | null>(null);

  async function startOrchestration() {
    if (!goal.trim()) return;
    setRunning(true);
    setResult(null);

    try {
      const res = await fetch('/api/orchestrate', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ sessionId, goal, mode: 'auto' }),
      });
      if (!res.ok) throw new Error('Orchestration failed');
      const data = await res.json() as { data: OrchestrationResult };
      setResult(data.data);
    } catch {
      // ignore
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-zinc-800 p-4">
        <div className="mx-auto max-w-3xl space-y-3">
          <div className="flex items-center gap-2">
            <Network className="h-5 w-5 text-zinc-300" />
            <h2 className="text-lg font-semibold text-zinc-100">Orchestration</h2>
          </div>
          <p className="text-sm text-zinc-500">
            Submit a goal. The lead agent will decompose it into tasks, spawn sub-agents, and merge results.
          </p>
          <div className="flex gap-2">
            <textarea
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              placeholder="e.g., Build a REST API for a blog with auth, posts, comments, and tests"
              rows={3}
              className="flex-1 rounded-md border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm text-zinc-100 placeholder-zinc-600 focus:outline-none"
              disabled={running}
            />
            <Button onClick={startOrchestration} disabled={running || !goal.trim()}>
              {running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
              Run
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="mx-auto max-w-3xl space-y-4">
          {running && (
            <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-6 text-center">
              <Loader2 className="mx-auto h-6 w-6 animate-spin text-zinc-400" />
              <p className="mt-2 text-sm text-zinc-400">Orchestrating... This may take 5-15 minutes.</p>
            </div>
          )}

          {result && (
            <>
              <div className="grid grid-cols-4 gap-3">
                <StatCard icon={ListTodo} label="Tasks" value={result.tasksCreated} />
                <StatCard icon={GitBranch} label="Completed" value={result.tasksCompleted} color="text-green-400" />
                <StatCard icon={GitBranch} label="Failed" value={result.tasksFailed} color={result.tasksFailed > 0 ? 'text-red-400' : 'text-zinc-400'} />
                <StatCard icon={Play} label="Duration" value={`${(result.durationMs / 1000).toFixed(1)}s`} />
              </div>

              {result.finalResult && (
                <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                  <h3 className="mb-2 text-sm font-medium text-zinc-100">Final Deliverable</h3>
                  <pre className="whitespace-pre-wrap text-sm text-zinc-300">{result.finalResult}</pre>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color = 'text-zinc-100' }: {
  icon: typeof ListTodo;
  label: string;
  value: string | number;
  color?: string;
}) {
  return (
    <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-3">
      <div className="flex items-center gap-1.5 text-xs text-zinc-500">
        <Icon className="h-3 w-3" />
        {label}
      </div>
      <p className={`mt-1 text-lg font-semibold ${color}`}>{value}</p>
    </div>
  );
}
