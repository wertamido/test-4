'use client';

import { X, Terminal } from 'lucide-react';

interface GettingStartedProps {
  onCreateSession: () => void;
}

export function GettingStarted({ onCreateSession }: GettingStartedProps) {
  return (
    <div className="flex items-center gap-3 border-b border-zinc-800 bg-zinc-950 px-4 py-2 text-sm text-zinc-400">
      <Terminal className="h-4 w-4 text-zinc-500" />
      <span>Welcome to Z-Chat Workspace. Create your first session to get started.</span>
      <button
        onClick={onCreateSession}
        className="ml-auto rounded-md border border-zinc-700 px-3 py-1 text-xs text-zinc-200 hover:bg-zinc-800"
      >
        New Session
      </button>
    </div>
  );
}
