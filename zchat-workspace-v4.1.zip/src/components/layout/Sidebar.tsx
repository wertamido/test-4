'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, MessageSquare, Pin, Terminal, Settings, Cpu, Bot, Plug, Github, Search } from 'lucide-react';
import { useChatStore, useSettingsStore } from '@/store/chat';
import type { SessionRecord } from '@/types';

export function Sidebar() {
  const router = useRouter();
  const { sessions, activeSessionId, sidebarOpen, setSessions } = useChatStore();
  const setActiveSheet = useSettingsStore((s) => s.setActiveSheet);

  useEffect(() => {
    loadSessions().then(setSessions);
  }, [setSessions]);

  async function handleNewSession() {
    try {
      const res = await fetch('/api/sessions', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ title: 'New session' }),
      });
      if (!res.ok) return;
      const data = await res.json() as { data: SessionRecord };
      router.push(`/chat/${data.data.id}`);
    } catch {
      // ignore
    }
  }

  if (!sidebarOpen) return null;

  return (
    <aside className="flex w-64 flex-col border-r border-zinc-800 bg-zinc-950">
      {/* Logo */}
      <div className="flex items-center gap-2 border-b border-zinc-800 px-4 py-3">
        <div className="flex h-8 w-8 items-center justify-center rounded-md border border-zinc-700 bg-black">
          <Terminal className="h-4 w-4 text-zinc-100" />
        </div>
        <span className="text-sm font-semibold text-zinc-100">Z-Chat</span>
      </div>

      {/* New session */}
      <div className="p-2">
        <button
          onClick={handleNewSession}
          className="flex w-full items-center gap-2 rounded-md border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm text-zinc-200 hover:bg-zinc-800"
        >
          <Plus className="h-4 w-4" />
          New Session
        </button>
      </div>

      {/* Sessions list */}
      <div className="flex-1 overflow-y-auto px-2">
        <div className="mb-1 px-2 text-xs font-medium uppercase tracking-wider text-zinc-600">
          Sessions
        </div>
        {sessions.length === 0 ? (
          <p className="px-2 py-4 text-xs text-zinc-600">No sessions yet</p>
        ) : (
          <div className="space-y-0.5">
            {sessions.map((session) => (
              <button
                key={session.id}
                onClick={() => router.push(`/chat/${session.id}`)}
                className={`flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm transition-colors ${
                  activeSessionId === session.id
                    ? 'bg-zinc-800 text-zinc-100'
                    : 'text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200'
                }`}
              >
                {session.pinned && <Pin className="h-3 w-3 flex-shrink-0 text-zinc-500" />}
                <MessageSquare className="h-3 w-3 flex-shrink-0" />
                <span className="truncate">{session.title}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Bottom nav */}
      <div className="border-t border-zinc-800 p-2">
        <div className="space-y-0.5">
          <NavButton icon={Cpu} label="Providers" onClick={() => setActiveSheet('providers')} />
          <NavButton icon={Search} label="Skills" onClick={() => setActiveSheet('skills')} />
          <NavButton icon={Bot} label="Agents" onClick={() => setActiveSheet('agents')} />
          <NavButton icon={Plug} label="MCP Servers" onClick={() => setActiveSheet('mcp')} />
          <NavButton icon={Github} label="GitHub Repos" onClick={() => setActiveSheet('github')} />
          <NavButton icon={Settings} label="Settings" onClick={() => setActiveSheet('settings')} />
        </div>
      </div>
    </aside>
  );
}

function NavButton({ icon: Icon, label, onClick }: { icon: typeof Cpu; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-sm text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200"
    >
      <Icon className="h-4 w-4" />
      {label}
    </button>
  );
}

async function loadSessions(): Promise<SessionRecord[]> {
  try {
    const res = await fetch('/api/sessions');
    if (!res.ok) return [];
    const data = await res.json() as { data: SessionRecord[] };
    return data.data;
  } catch {
    return [];
  }
}
