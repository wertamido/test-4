'use client';

/**
 * React Error Boundary — Client-Side Crash Safety
 *
 * Blueprint v4.1 §5 (System Architecture), §22 Phase 0 Step 0.5, §12 (Mistake #12)
 *
 * Design goals:
 *  - Catches every render-time error in its subtree — NEVER shows a white screen
 *  - Black/zinc themed fallback with Lucide icons (no emojis, no violet)
 *  - "Try Again" resets internal state and re-renders the subtree
 *  - "Reload Page" calls window.location.reload() for hard recovery
 *  - `resetKey` prop: when it changes, the boundary auto-recovers — useful so a
 *    route change clears stale errors without user action
 *  - `onError` callback for telemetry hooks (Sentry, custom log shipper, etc.)
 *  - Logs errors as JSON-structured lines via console.error — pino-parseable.
 *    Task 0.6 will swap this for a real pino logger; the JSON shape is already
 *    pino-compatible (`level`, `time`, `msg`, `err` fields).
 *  - Strictly typed: explicit `Props` + `State` interfaces, no `any`
 *
 * Why a class component? React's error boundary API (getDerivedStateFromError,
 * componentDidCatch) is only available on class components. There is no hook
 * equivalent as of React 19.
 *
 * Usage:
 *   <ErrorBoundary resetKey={pathname}>
 *     <MyPage />
 *   </ErrorBoundary>
 *
 *   // Custom fallback:
 *   <ErrorBoundary fallback={<MyErrorUI />}>
 *     <MyPage />
 *   </ErrorBoundary>
 */

import React from 'react';
import { AlertTriangle, RefreshCw, RotateCcw } from 'lucide-react';

// ─── Types ─────────────────────────────────────────────────────────────────

export interface ErrorBoundaryProps {
  /** The subtree to render when no error is active. */
  children: React.ReactNode;
  /**
   * Optional custom fallback. When provided, replaces the default fallback UI
   * entirely. The custom fallback receives no props — callers that need
   * "Try Again" / "Reload" buttons in their custom UI should use the
   * `renderFallback` prop instead.
   */
  fallback?: React.ReactNode;
  /**
   * Optional render-prop fallback. Receives the error + a reset callback so
   * custom UIs can render their own recovery buttons. Takes precedence over
   * the static `fallback` prop.
   */
  renderFallback?: (error: Error, reset: () => void) => React.ReactNode;
  /**
   * Telemetry hook. Fires once per caught error (NOT once per render of the
   * fallback). Use this to ship the error to Sentry / Logflare / etc.
   */
  onError?: (error: Error, info: React.ErrorInfo) => void;
  /**
   * When this value changes, the boundary auto-resets. Pass `pathname` from
   * `usePathname()` (Next.js App Router) so navigating to a new route clears
   * stale errors without user action.
   */
  resetKey?: string | number;
}

export interface ErrorBoundaryState {
  error: Error | null;
}

// ─── JSON-structured logging (pino-compatible shape) ───────────────────────
//
// Emits a single JSON line per error. pino's logfmt parser will accept this
// as-is once Task 0.6 swaps console.error for logger.error. The `err` field
// follows pino's standard error serialization convention.

interface ErrorLogPayload {
  level: 'error';
  time: number;
  msg: string;
  err: {
    type: string;
    message: string;
    stack: string | undefined;
    componentStack: string | undefined;
  };
  boundary: {
    resetKey: string | number | undefined;
  };
}

function logErrorToConsole(error: Error, info: React.ErrorInfo, resetKey: string | number | undefined): void {
  const payload: ErrorLogPayload = {
    level: 'error',
    time: Date.now(),
    msg: `ErrorBoundary caught: ${error.message}`,
    err: {
      type: error.name,
      message: error.message,
      stack: error.stack,
      componentStack: info.componentStack ?? undefined,
    },
    boundary: { resetKey },
  };
  // console.error is the safest dev-time channel; pino will replace this in 0.6.
  // Using console.error (not console.log) so browser devtools highlight it.
  // eslint-disable-next-line no-console
  console.error(JSON.stringify(payload));
}

// ─── Default fallback UI (black/zinc, Lucide icons, no emojis) ─────────────

interface DefaultFallbackProps {
  error: Error;
  onReset: () => void;
  onReload: () => void;
}

function DefaultFallback({ error, onReset, onReload }: DefaultFallbackProps): React.ReactElement {
  const isDev = process.env.NODE_ENV !== 'production';

  return (
    <div
      role="alert"
      className="flex min-h-[400px] w-full flex-col items-center justify-center gap-6 bg-black p-8 text-zinc-200"
    >
      <div className="flex items-center gap-3 text-zinc-100">
        <AlertTriangle className="h-6 w-6 text-zinc-400" aria-hidden="true" />
        <h2 className="text-lg font-semibold tracking-tight">Something went wrong</h2>
      </div>

      <p className="max-w-md text-center text-sm text-zinc-400">
        {error.message || 'An unexpected error occurred while rendering this view.'}
      </p>

      {isDev && error.stack ? (
        <pre className="max-h-48 w-full max-w-2xl overflow-auto rounded-md border border-zinc-800 bg-zinc-950 p-4 text-xs text-zinc-500">
          <code>{error.stack}</code>
        </pre>
      ) : null}

      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onReset}
          className="inline-flex items-center gap-2 rounded-md border border-zinc-700 bg-zinc-900 px-4 py-2 text-sm font-medium text-zinc-100 transition-colors hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-zinc-600 focus:ring-offset-2 focus:ring-offset-black"
        >
          <RotateCcw className="h-4 w-4" aria-hidden="true" />
          Try Again
        </button>
        <button
          type="button"
          onClick={onReload}
          className="inline-flex items-center gap-2 rounded-md border border-zinc-700 bg-zinc-900 px-4 py-2 text-sm font-medium text-zinc-100 transition-colors hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-zinc-600 focus:ring-offset-2 focus:ring-offset-black"
        >
          <RefreshCw className="h-4 w-4" aria-hidden="true" />
          Reload Page
        </button>
      </div>
    </div>
  );
}

// ─── ErrorBoundary class component ─────────────────────────────────────────

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  public constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { error: null };
  }

  public static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { error };
  }

  public componentDidCatch(error: Error, info: React.ErrorInfo): void {
    logErrorToConsole(error, info, this.props.resetKey);
    this.props.onError?.(error, info);
  }

  // componentDidUpdate is the standard React pattern for reacting to prop
  // changes that should reset internal state. We compare prevProps.resetKey
  // against the current one — if it changed AND we're in an error state,
  // clear the error so the subtree re-renders.
  public componentDidUpdate(prevProps: ErrorBoundaryProps): void {
    if (
      this.state.error !== null &&
      prevProps.resetKey !== this.props.resetKey
    ) {
      this.setState({ error: null });
    }
  }

  private readonly handleReset = (): void => {
    this.setState({ error: null });
  };

  private readonly handleReload = (): void => {
    if (typeof window !== 'undefined') {
      window.location.reload();
    }
  };

  public render(): React.ReactNode {
    const { error } = this.state;
    const { children, fallback, renderFallback } = this.props;

    if (error === null) {
      return children;
    }

    if (renderFallback) {
      return renderFallback(error, this.handleReset);
    }
    if (fallback !== undefined) {
      return fallback;
    }
    return (
      <DefaultFallback
        error={error}
        onReset={this.handleReset}
        onReload={this.handleReload}
      />
    );
  }
}

export default ErrorBoundary;
