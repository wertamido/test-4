'use client';

import { useChatStore } from '@/store/chat';
import { PanelLeft, Activity, Network } from 'lucide-react';

export function Header() {
  const { toggleSidebar, sessions, activeSessionId } = useChatStore();
  const activeSession = sessions.find((s) => s.id === activeSessionId);

  return (
    <header className="flex h-12 items-center justify-between border-b border-zinc-800 bg-black px-4">
      <div className="flex items-center gap-3">
        <button
          onClick={toggleSidebar}
          className="rounded-md p-1 text-zinc-400 hover:bg-zinc-900 hover:text-zinc-100"
        >
          <PanelLeft className="h-4 w-4" />
        </button>
        {activeSession && (
          <span className="text-sm font-medium text-zinc-300">{activeSession.title}</span>
        )}
      </div>

      <div className="flex items-center gap-2">
        {activeSession && (
          <>
            <StatusBadge status={activeSession.status} />
            <button className="rounded-md p-1.5 text-zinc-400 hover:bg-zinc-900 hover:text-zinc-100" title="View orchestration">
              <Network className="h-4 w-4" />
            </button>
          </>
        )}
        <div className="flex items-center gap-1 rounded-md border border-zinc-800 bg-zinc-950 px-2 py-1 text-xs text-zinc-500">
          <Activity className="h-3 w-3" />
          <span>v4.1</span>
        </div>
      </div>
    </header>
  );
}

function StatusBadge({ status }: { status: string }) {
  const colorMap: Record<string, string> = {
    idle: 'text-zinc-500 bg-zinc-900',
    planning: 'text-blue-400 bg-blue-950',
    executing: 'text-yellow-400 bg-yellow-950',
    verifying: 'text-purple-400 bg-purple-950',
    done: 'text-green-400 bg-green-950',
    error: 'text-red-400 bg-red-950',
  };

  return (
    <span className={`rounded px-2 py-0.5 text-xs font-medium ${colorMap[status] ?? colorMap.idle}`}>
      {status}
    </span>
  );
}
