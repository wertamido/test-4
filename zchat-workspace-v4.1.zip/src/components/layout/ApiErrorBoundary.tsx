/**
 * API Route Handler Error Boundary — Server-Side Crash Safety
 *
 * Blueprint v4.1 §5 (System Architecture), §22 Phase 0 Step 0.5, §24 (Security)
 *
 * Design goals:
 *  - Wrap any Next.js 16 App Router route handler with `withApiErrorHandler`
 *    so thrown errors are mapped to typed HTTP responses — never an unhandled
 *    500 with a stack trace leak.
 *  - DbError         → 500 (server-side infra failure)
 *  - AuthError       → 401 (unauthenticated) — NOTE: some auth failures
 *    (e.g., forbidden vs unauthenticated) could map to 403; the v4.1 schema
 *    uses a single 401 for all AuthError codes per §24. Future work can split.
 *  - ValidationError → 400 (client input error) with per-field `issues`
 *  - Unknown Error   → 500 with generic message ("Internal server error") —
 *    NEVER leaks internals in production. Dev mode includes the stack trace.
 *  - ApiResponse<T> discriminated union: success has `data`, failure has `error`
 *  - `buildApiResponse()` helper exposed for tests + non-handler code paths
 *
 * Usage:
 *   export const POST = withApiErrorHandler(async (req) => {
 *     const body = validate(createSessionSchema, await req.json());
 *     return await createSession(body);
 *   });
 *
 *   // With input validation chained:
 *   export const POST = withApiErrorHandler(
 *     withValidatedBody(createSessionSchema, async (body) => createSession(body))
 *   );
 */

import { DbError, isDbError } from '@/lib/db';
import { AuthError, isAuthError } from '@/lib/auth';
import {
  ValidationError,
  isValidationError,
  type ValidationIssue,
} from '@/lib/validation/schemas';

// ─── Types ─────────────────────────────────────────────────────────────────

export interface ApiSuccessBody<T> {
  data: T;
}

export interface ApiErrorBody {
  error: {
    code: string;
    message: string;
    issues?: ReadonlyArray<ValidationIssue>;
    stack?: string;
  };
}

/**
 * Discriminated union. `success` carries `data`; `failure` carries `error`.
 * Use `body.data` / `body.error` after narrowing on the `success` flag.
 */
export type ApiResponse<T> =
  | { success: true; status: number; body: ApiSuccessBody<T> }
  | { success: false; status: number; body: ApiErrorBody };

export type ApiHandler<T> = (req: Request) => Promise<T>;

// ─── Error → HTTP status mapping ───────────────────────────────────────────
//
// Centralized so the tests can assert against a single source of truth.
// Mirrors the DbError / AuthError / ValidationError code unions exactly.

export interface ErrorMapping {
  readonly status: number;
  readonly code: string;
  readonly message: string;
}

function mapDbError(error: DbError): ErrorMapping {
  // All DbError codes currently map to 500 — they represent server-side infra
  // failures (DB unreachable, query failed, transaction failed). If a future
  // code represents a client-side issue (e.g., unique-constraint violation),
  // add a 409 branch here.
  return {
    status: 500,
    code: error.code,
    message: 'Database operation failed.',
  };
}

function mapAuthError(error: AuthError): ErrorMapping {
  // Per Blueprint §24, all AuthError codes → 401. If we later split
  // FORBIDDEN vs UNAUTHENTICATED, add a 403 branch here.
  void error; // referenced for type-narrowing symmetry with mapDbError
  return {
    status: 401,
    code: error.code,
    message: 'Authentication required.',
  };
}

function mapValidationError(error: ValidationError): ErrorMapping {
  return {
    status: 400,
    code: error.code,
    message: 'Request validation failed.',
  };
}

function mapUnknownError(error: unknown): ErrorMapping {
  return {
    status: 500,
    code: 'INTERNAL_ERROR',
    message: 'Internal server error.',
  };
}

// ─── buildApiResponse — pure, testable ─────────────────────────────────────
//
// Takes any thrown value and produces a typed ApiResponse<never> (failure).
// Exposed publicly so tests + non-handler code paths can reuse the mapping
// without spinning up a fake Request.

export function buildApiResponse(error: unknown): ApiResponse<never> {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDbError(error)) {
    const m = mapDbError(error);
    const body: ApiErrorBody = {
      error: {
        code: m.code,
        message: m.message,
        ...(isDev && error.stack ? { stack: error.stack } : {}),
      },
    };
    return { success: false, status: m.status, body };
  }

  if (isAuthError(error)) {
    const m = mapAuthError(error);
    const body: ApiErrorBody = {
      error: {
        code: m.code,
        message: m.message,
        ...(isDev && error.stack ? { stack: error.stack } : {}),
      },
    };
    return { success: false, status: m.status, body };
  }

  if (isValidationError(error)) {
    const m = mapValidationError(error);
    const body: ApiErrorBody = {
      error: {
        code: m.code,
        message: m.message,
        ...(error.issues.length > 0 ? { issues: error.issues } : {}),
        ...(isDev && error.stack ? { stack: error.stack } : {}),
      },
    };
    return { success: false, status: m.status, body };
  }

  const m = mapUnknownError(error);
  const stack =
    isDev && error instanceof Error && typeof error.stack === 'string'
      ? error.stack
      : undefined;
  const body: ApiErrorBody = {
    error: {
      code: m.code,
      message: m.message,
      ...(stack ? { stack } : {}),
    },
  };
  return { success: false, status: m.status, body };
}

// ─── Response construction ─────────────────────────────────────────────────

function apiResponseToResponse(result: ApiResponse<unknown>): Response {
  return new Response(JSON.stringify(result.body), {
    status: result.status,
    headers: { 'content-type': 'application/json; charset=utf-8' },
  });
}

// ─── withApiErrorHandler — the HOF ─────────────────────────────────────────
//
// Wraps an async route handler. On success, returns 200 with `{ data }`.
// On thrown error, returns the mapped status + body via buildApiResponse.
//
// The handler accepts the standard Next.js route handler args:
//   (req: Request, context?: { params: Promise<Record<string, string>> })

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function withApiErrorHandler<T>(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  handler: (req: Request, context?: any) => Promise<T>,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
): (req: Request, context?: any) => Promise<Response> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return async (req: Request, context?: any): Promise<Response> => {
    try {
      const data: T = await handler(req, context);
      const result: ApiResponse<T> = {
        success: true,
        status: 200,
        body: { data },
      };
      return apiResponseToResponse(result);
    } catch (error) {
      const result = buildApiResponse(error);
      return apiResponseToResponse(result);
    }
  };
}

// ─── Bonus: withValidatedBody — chain validate + handler ───────────────────
//
// Cuts down boilerplate in route handlers. The body is parsed + validated
// before the handler runs; on validation failure, ValidationError is thrown
// (which withApiErrorHandler then maps to 400).
//
// Usage:
//   export const POST = withApiErrorHandler(
//     withValidatedBody(createSessionSchema, async (body, req) => createSession(body))
//   );

import type { ZodSchema } from 'zod';
import { validate } from '@/lib/validation/schemas';

export function withValidatedBody<S>(
  schema: ZodSchema<S>,
  handler: (body: S, req: Request) => Promise<unknown>,
): ApiHandler<unknown> {
  return async (req: Request): Promise<unknown> => {
    let rawBody: unknown;
    try {
      rawBody = await req.json();
    } catch (err) {
      // Malformed JSON — synthesize a ValidationError so it maps to 400.
      throw new ValidationError(
        'VALIDATION_FAILED',
        'Request body is not valid JSON.',
        err,
        [
          {
            path: '(root)',
            message: 'Request body is not valid JSON.',
            code: 'invalid_json',
          },
        ],
      );
    }
    const body = validate(schema, rawBody);
    return handler(body, req);
  };
}

export default withApiErrorHandler;
