'use client';

import { useState } from 'react';
import { Sheet } from '@/components/ui/Sheet';
import { Button } from '@/components/ui/Button';
import { Search, Loader2, Plus, Star, GitBranch } from 'lucide-react';

interface GithubRepo {
  id: number;
  fullName: string;
  description: string | null;
  url: string;
  stars: number;
  language: string | null;
  owner: string;
}

interface GithubSheetProps {
  open: boolean;
  onClose: () => void;
}

export function GithubSheet({ open, onClose }: GithubSheetProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<GithubRepo[]>([]);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState<number | null>(null);
  const [imported, setImported] = useState<Set<number>>(new Set());

  async function handleSearch() {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/github/search?q=${encodeURIComponent(query)}`);
      if (!res.ok) return;
      const data = await res.json() as { data: GithubRepo[] };
      setResults(data.data);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  async function handleImport(repo: GithubRepo) {
    setImporting(repo.id);
    try {
      await fetch('/api/github/import', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(repo),
      });
      setImported((prev) => new Set(prev).add(repo.id));
    } catch {
      // ignore
    } finally {
      setImporting(null);
    }
  }

  return (
    <Sheet open={open} onClose={onClose} title="GitHub Repos" description="Search, import, and pin repos for context injection. Max 3 pinned." width="lg">
      <div className="space-y-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="Search GitHub repos..."
              className="w-full rounded-md border border-zinc-800 bg-zinc-950 pl-10 pr-3 py-2 text-sm text-zinc-100 placeholder-zinc-600"
            />
          </div>
          <Button onClick={handleSearch} disabled={loading || !query.trim()}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            Search
          </Button>
        </div>

        <div className="space-y-2">
          {results.map((repo) => (
            <div key={repo.id} className="rounded-lg border border-zinc-800 bg-zinc-950 p-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <GitBranch className="h-3.5 w-3.5 text-zinc-500" />
                    <a href={repo.url} target="_blank" rel="noopener noreferrer" className="text-sm font-medium text-zinc-100 hover:underline">
                      {repo.fullName}
                    </a>
                  </div>
                  {repo.description && <p className="mt-1 text-xs text-zinc-500">{repo.description}</p>}
                  <div className="mt-1.5 flex items-center gap-3 text-xs text-zinc-600">
                    <span className="flex items-center gap-1">
                      <Star className="h-3 w-3" />
                      {repo.stars.toLocaleString()}
                    </span>
                    {repo.language && <span>{repo.language}</span>}
                  </div>
                </div>
                <Button
                  size="sm"
                  variant={imported.has(repo.id) ? 'default' : 'outline'}
                  onClick={() => handleImport(repo)}
                  disabled={importing === repo.id || imported.has(repo.id)}
                >
                  {importing === repo.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <Plus className="h-3 w-3" />}
                  {imported.has(repo.id) ? 'Imported' : 'Import'}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Sheet>
  );
}
