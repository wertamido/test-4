'use client';

import { useToastStore } from '@/hooks/use-toast';
import { X, AlertCircle, CheckCircle, Info } from 'lucide-react';

export function Toaster() {
  const { toasts, removeToast } = useToastStore();

  return (
    <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={`flex items-start gap-3 rounded-lg border p-4 shadow-lg min-w-[300px] max-w-[400px] animate-slide-up ${
            toast.variant === 'error'
              ? 'border-red-800 bg-red-950/50 text-red-100'
              : toast.variant === 'success'
              ? 'border-green-800 bg-green-950/50 text-green-100'
              : 'border-zinc-800 bg-zinc-900 text-zinc-100'
          }`}
        >
          {toast.variant === 'error' && <AlertCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />}
          {toast.variant === 'success' && <CheckCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />}
          {toast.variant === 'default' && <Info className="h-5 w-5 flex-shrink-0 mt-0.5" />}
          <div className="flex-1">
            <p className="text-sm font-medium">{toast.title}</p>
            {toast.description && <p className="text-xs mt-1 opacity-80">{toast.description}</p>}
          </div>
          <button
            onClick={() => removeToast(toast.id)}
            className="text-current opacity-50 hover:opacity-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ))}
    </div>
  );
}
