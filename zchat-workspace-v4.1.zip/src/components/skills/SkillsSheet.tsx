'use client';

import { useEffect, useState } from 'react';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import type { SkillRecord } from '@/types';

interface SkillsSheetProps {
  open: boolean;
  onClose: () => void;
}

const STRENGTH_LABELS: Record<number, { label: string; color: string }> = {
  1: { label: 'Light', color: 'text-zinc-400 bg-zinc-900' },
  2: { label: 'Medium', color: 'text-blue-400 bg-blue-950' },
  3: { label: 'Strict', color: 'text-red-400 bg-red-950' },
};

export function SkillsSheet({ open, onClose }: SkillsSheetProps) {
  const [skills, setSkills] = useState<SkillRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast, error: showError } = useToast();

  useEffect(() => {
    if (open) loadSkills();
  }, [open]);

  async function loadSkills() {
    setLoading(true);
    try {
      const res = await fetch('/api/skills');
      if (!res.ok) throw new Error('Failed to load skills');
      const data = await res.json() as { data: SkillRecord[] };
      setSkills(data.data);
    } catch (err) {
      showError('Failed to load skills', err instanceof Error ? err.message : undefined);
    } finally {
      setLoading(false);
    }
  }

  async function toggleSkill(skillId: string, enabled: boolean) {
    try {
      await fetch(`/api/skills/${skillId}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ enabled }),
      });
      toast(enabled ? 'Skill enabled' : 'Skill disabled');
      loadSkills();
    } catch (err) {
      showError('Failed to update skill', err instanceof Error ? err.message : undefined);
    }
  }

  // Group by category
  const categories = skills.reduce<Record<string, SkillRecord[]>>((acc, skill) => {
    (acc[skill.category] ??= []).push(skill);
    return acc;
  }, {});

  return (
    <Sheet open={open} onClose={onClose} title="Skills" description="42 professional prompts across 10 categories. Strict skills override all." width="lg">
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-5 w-5 animate-spin text-zinc-500" />
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(categories).map(([category, categorySkills]) => (
            <div key={category}>
              <h3 className="mb-2 text-xs font-medium uppercase tracking-wider text-zinc-600">{category} ({categorySkills.length})</h3>
              <div className="space-y-2">
                {categorySkills.map((skill) => (
                  <div key={skill.id} className="flex items-start justify-between rounded-md border border-zinc-800 bg-zinc-950 p-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-medium text-zinc-100">{skill.name}</h4>
                        <span className={`rounded px-1.5 py-0.5 text-xs ${STRENGTH_LABELS[skill.strength]?.color}`}>
                          {STRENGTH_LABELS[skill.strength]?.label}
                        </span>
                      </div>
                      <p className="mt-0.5 text-xs text-zinc-500">{skill.description}</p>
                    </div>
                    <button
                      onClick={() => toggleSkill(skill.id, !skill.enabled)}
                      className={`ml-3 rounded-md border px-2 py-1 text-xs ${
                        skill.enabled
                          ? 'border-zinc-100 bg-zinc-100 text-black'
                          : 'border-zinc-700 text-zinc-400 hover:bg-zinc-800'
                      }`}
                    >
                      {skill.enabled ? 'On' : 'Off'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </Sheet>
  );
}
