'use client';

import { User, Bot } from 'lucide-react';
import { CodeBlock } from './CodeBlock';
import type { MessageRecord } from '@/types';

interface MessageBubbleProps {
  message: MessageRecord;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === 'user';

  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
      <div className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-md border ${
        isUser
          ? 'border-zinc-700 bg-zinc-900'
          : 'border-zinc-800 bg-zinc-950'
      }`}>
        {isUser ? <User className="h-4 w-4 text-zinc-300" /> : <Bot className="h-4 w-4 text-zinc-100" />}
      </div>

      <div className={`flex flex-col gap-1 ${isUser ? 'items-end' : 'items-start'} max-w-[85%]`}>
        <div className={`rounded-lg px-4 py-2 text-sm ${
          isUser
            ? 'bg-zinc-100 text-black'
            : 'bg-zinc-900 text-zinc-100 border border-zinc-800'
        }`}>
          <MessageContent content={message.content} />
        </div>

        {(message.tokens > 0 || message.model) && (
          <div className="flex items-center gap-2 text-xs text-zinc-600">
            {message.model && <span>{message.model}</span>}
            {message.tokens > 0 && <span>{message.tokens} tokens</span>}
            {message.costUsd > 0 && <span>${message.costUsd.toFixed(4)}</span>}
          </div>
        )}
      </div>
    </div>
  );
}

function MessageContent({ content }: { content: string }) {
  // Split by code fences (```lang\n...\n```)
  const parts = content.split(/(```[\s\S]*?```)/g);

  return (
    <div className="space-y-2">
      {parts.map((part, i) => {
        if (part.startsWith('```')) {
          const match = part.match(/```(\w*)\n([\s\S]*?)```/);
          if (match) {
            return <CodeBlock key={i} language={match[1] ?? 'text'} code={match[2] ?? ''} />;
          }
        }
        return <p key={i} className="whitespace-pre-wrap">{part}</p>;
      })}
    </div>
  );
}
