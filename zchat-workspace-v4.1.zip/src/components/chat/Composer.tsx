'use client';

import { useState, useRef, useEffect } from 'react';
import { useChatStore } from '@/store/chat';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/Button';
import { Send, Square, Loader2 } from 'lucide-react';
import type { MessageRecord } from '@/types';

interface ComposerProps {
  sessionId: string;
}

export function Composer({ sessionId }: ComposerProps) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { addMessage, setIsStreaming, setStreamingContent } = useChatStore();
  const { error: showError } = useToast();

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  async function handleSend() {
    const content = input.trim();
    if (!content || loading) return;

    setInput('');
    setLoading(true);
    setIsStreaming(true);
    setStreamingContent('');

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ sessionId, content }),
        signal: controller.signal,
      });

      if (!res.ok) {
        const errData = await res.json() as { error?: { message?: string } };
        throw new Error(errData.error?.message ?? 'Chat request failed');
      }

      const reader = res.body?.getReader();
      if (!reader) throw new Error('No response body');

      const decoder = new TextDecoder();
      let buffer = '';
      let assistantContent = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const data = line.slice(6);
          if (data === '[DONE]') continue;

          try {
            const event = JSON.parse(data) as { type: string; message?: MessageRecord; content?: string };
            if (event.type === 'user_message_saved' && event.message) {
              addMessage(event.message);
            } else if (event.type === 'token' && event.content) {
              assistantContent += event.content;
              setStreamingContent(assistantContent);
            } else if (event.type === 'assistant_message_saved' && event.message) {
              addMessage(event.message);
              setStreamingContent('');
            }
          } catch {
            // skip
          }
        }
      }
    } catch (err) {
      if (err instanceof Error && err.name !== 'AbortError') {
        showError('Failed to send message', err.message);
      }
    } finally {
      setLoading(false);
      setIsStreaming(false);
      setStreamingContent('');
      abortRef.current = null;
    }
  }

  function handleStop() {
    abortRef.current?.abort();
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (true) { // sendOnEnter is the default; settings will be wired from the settings store in a future iteration
        handleSend();
      }
    }
  }

  return (
    <div className="border-t border-zinc-800 bg-black p-4">
      <div className="mx-auto max-w-3xl">
        <div className="flex items-end gap-2 rounded-lg border border-zinc-800 bg-zinc-950 p-2">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type a message... (Enter to send, Shift+Enter for newline)"
            rows={1}
            className="flex-1 resize-none bg-transparent px-2 py-1.5 text-sm text-zinc-100 placeholder-zinc-600 focus:outline-none"
            disabled={loading}
          />
          {loading ? (
            <Button size="icon" variant="destructive" onClick={handleStop} title="Stop generating">
              <Square className="h-4 w-4" />
            </Button>
          ) : (
            <Button size="icon" onClick={handleSend} disabled={!input.trim()} title="Send message">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          )}
        </div>
        <p className="mt-1.5 text-center text-xs text-zinc-600">
          Z-Chat Workspace v4.1 — Multi-Agent Orchestration Platform
        </p>
      </div>
    </div>
  );
}
