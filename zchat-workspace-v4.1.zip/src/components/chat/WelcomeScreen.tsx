'use client';

import { Terminal, Zap, Bot, GitBranch, Plug } from 'lucide-react';

interface WelcomeScreenProps {
  onNewSession?: () => void;
}

export function WelcomeScreen({ onNewSession }: WelcomeScreenProps) {
  return (
    <div className="flex h-full items-center justify-center p-8">
      <div className="max-w-2xl text-center space-y-6">
        <div className="flex justify-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-xl border border-zinc-800 bg-zinc-950">
            <Terminal className="h-8 w-8 text-zinc-100" />
          </div>
        </div>

        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-zinc-100">Z-Chat Workspace</h1>
          <p className="text-zinc-400">
            Multi-Agent AI Orchestration Platform — Plan, Execute, Verify, Ship.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-4">
          <FeatureCard
            icon={Zap}
            title="13-Phase Reasoning"
            description="GOAL → THINK → PLAN → EXECUTE → BUILD → TEST → ANALYSE → FIX → AUDIT → VALIDATE → PREVIEW → COMPARISON → DECIDE"
          />
          <FeatureCard
            icon={Bot}
            title="10 Agent Templates"
            description="Hermes, Odysseus, OpenClaw + 7 specialists. Multi-LLM, sub-agent spawning, shared memory."
          />
          <FeatureCard
            icon={GitBranch}
            title="GitHub Integration"
            description="Search, import, pin up to 3 repos. README context injection with citation rules."
          />
          <FeatureCard
            icon={Plug}
            title="MCP Integration"
            description="Filesystem + Memory presets. Custom servers via JSON-RPC. 14+ tools per server."
          />
        </div>

        {onNewSession && (
          <button
            onClick={onNewSession}
            className="mt-4 inline-flex items-center gap-2 rounded-md bg-zinc-100 px-6 py-2.5 text-sm font-medium text-black hover:bg-zinc-200"
          >
            Start a new session
          </button>
        )}
      </div>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, description }: { icon: typeof Zap; title: string; description: string }) {
  return (
    <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4 text-left">
      <div className="flex items-center gap-2 mb-2">
        <Icon className="h-4 w-4 text-zinc-300" />
        <h3 className="text-sm font-medium text-zinc-100">{title}</h3>
      </div>
      <p className="text-xs text-zinc-500 leading-relaxed">{description}</p>
    </div>
  );
}
