'use client';

import { useChatStore } from '@/store/chat';
import { MessageBubble } from './MessageBubble';
import { WelcomeScreen } from './WelcomeScreen';
import { Loader2 } from 'lucide-react';

interface ChatAreaProps {
  sessionId: string;
}

export function ChatArea({ sessionId }: ChatAreaProps) {
  const { messages, streamingContent, isStreaming } = useChatStore();

  if (messages.length === 0 && !isStreaming) {
    return <WelcomeScreen />;
  }

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="mx-auto max-w-3xl px-4 py-6 space-y-6">
        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} />
        ))}

        {isStreaming && (
          <div className="flex items-center gap-2 text-sm text-zinc-500">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span>Generating...</span>
            {streamingContent && (
              <span className="ml-2 text-zinc-300">{streamingContent.slice(-200)}</span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
