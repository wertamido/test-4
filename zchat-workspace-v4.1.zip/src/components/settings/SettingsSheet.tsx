'use client';

import { useEffect, useState } from 'react';
import { Sheet } from '@/components/ui/Sheet';
import { Button } from '@/components/ui/Button';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Save } from 'lucide-react';
import type { WorkspaceSettings } from '@/types';

interface SettingsSheetProps {
  open: boolean;
  onClose: () => void;
}

export function SettingsSheet({ open, onClose }: SettingsSheetProps) {
  const [settings, setSettings] = useState<WorkspaceSettings | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast, error: showError } = useToast();

  useEffect(() => {
    if (open) loadSettings();
  }, [open]);

  async function loadSettings() {
    setLoading(true);
    try {
      const res = await fetch('/api/settings');
      if (!res.ok) throw new Error('Failed to load settings');
      const data = await res.json() as { data: WorkspaceSettings };
      setSettings(data.data);
    } catch (err) {
      showError('Failed to load settings', err instanceof Error ? err.message : undefined);
    } finally {
      setLoading(false);
    }
  }

  async function saveSettings() {
    if (!settings) return;
    setSaving(true);
    try {
      const res = await fetch('/api/settings', {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(settings),
      });
      if (!res.ok) throw new Error('Failed to save settings');
      toast('Settings saved');
    } catch (err) {
      showError('Failed to save settings', err instanceof Error ? err.message : undefined);
    } finally {
      setSaving(false);
    }
  }

  function update<K extends keyof WorkspaceSettings>(key: K, value: WorkspaceSettings[K]) {
    setSettings((prev) => prev ? { ...prev, [key]: value } : prev);
  }

  return (
    <Sheet open={open} onClose={onClose} title="Settings" description="Workspace preferences. Black/zinc theme only." width="md">
      {loading || !settings ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-5 w-5 animate-spin text-zinc-500" />
        </div>
      ) : (
        <div className="space-y-6">
          {/* Density */}
          <div>
            <label className="text-sm font-medium text-zinc-300">Density</label>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {(['compact', 'comfortable', 'spacious'] as const).map((d) => (
                <button
                  key={d}
                  onClick={() => update('density', d)}
                  className={`rounded-md border px-3 py-2 text-sm capitalize ${
                    settings.density === d
                      ? 'border-zinc-100 bg-zinc-100 text-black'
                      : 'border-zinc-700 text-zinc-400 hover:bg-zinc-800'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>

          {/* Default temperature */}
          <div>
            <label className="text-sm font-medium text-zinc-300">
              Default Temperature: {settings.defaultTemperature.toFixed(1)}
            </label>
            <input
              type="range"
              min="0"
              max="2"
              step="0.1"
              value={settings.defaultTemperature}
              onChange={(e) => update('defaultTemperature', Number(e.target.value))}
              className="mt-2 w-full accent-zinc-100"
            />
          </div>

          {/* Default max tokens */}
          <div>
            <label className="text-sm font-medium text-zinc-300">Default Max Tokens</label>
            <input
              type="number"
              min="1"
              max="128000"
              value={settings.defaultMaxTokens}
              onChange={(e) => update('defaultMaxTokens', Number(e.target.value))}
              className="mt-1 w-full rounded-md border border-zinc-800 bg-zinc-950 px-3 py-1.5 text-sm text-zinc-100"
            />
          </div>

          {/* Toggles */}
          <div className="space-y-3">
            <Toggle
              label="Send on Enter"
              description="Press Enter to send, Shift+Enter for newline"
              checked={settings.sendOnEnter}
              onChange={(v) => update('sendOnEnter', v)}
            />
            <Toggle
              label="Show token count"
              description="Display token usage under each message"
              checked={settings.showTokenCount}
              onChange={(v) => update('showTokenCount', v)}
            />
            <Toggle
              label="Streaming enabled"
              description="Stream responses token-by-token via SSE"
              checked={settings.streamingEnabled}
              onChange={(v) => update('streamingEnabled', v)}
            />
          </div>

          {/* Save */}
          <div className="flex justify-end border-t border-zinc-800 pt-4">
            <Button onClick={saveSettings} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Save Settings
            </Button>
          </div>
        </div>
      )}
    </Sheet>
  );
}

function Toggle({ label, description, checked, onChange }: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-zinc-200">{label}</p>
        <p className="text-xs text-zinc-500">{description}</p>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`relative h-6 w-11 rounded-full transition-colors ${
          checked ? 'bg-zinc-100' : 'bg-zinc-700'
        }`}
      >
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-black transition-transform ${
          checked ? 'translate-x-5' : 'translate-x-0.5'
        }`} />
      </button>
    </div>
  );
}
