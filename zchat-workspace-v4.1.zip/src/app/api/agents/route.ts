import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { db } from '@/lib/db';

export const GET = withApiErrorHandler(async () => {
  const agents = await db.agentTemplate.findMany({ orderBy: [{ category: 'asc' }, { name: 'asc' }] });
  return agents.map((a) => ({
    ...a,
    tools: JSON.parse(a.tools) as string[],
    mcpTools: JSON.parse(a.mcpTools) as string[],
  }));
});
