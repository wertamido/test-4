import { withApiErrorHandler, withValidatedBody } from '@/components/layout/ApiErrorBoundary';
import { getServerSession } from 'next-auth';
import { getAuthOptions } from '@/lib/auth';
import { createSession, listSessions } from '@/lib/sessions/repository';
import { validate } from '@/lib/validation/schemas';
import { z } from 'zod';

const createSchema = z.object({
  title: z.string().min(1).max(200),
  goal: z.string().max(10000).optional(),
  providerId: z.string().optional(),
  model: z.string().optional(),
});

export const GET = withApiErrorHandler(async () => {
  const session = await getServerSession(getAuthOptions());
  if (!session?.user?.workspaceId) {
    throw new Error('Unauthorized');
  }
  const result = await listSessions({ workspaceId: session.user.workspaceId, limit: 100 });
  return result.items;
});

export const POST = withApiErrorHandler(
  withValidatedBody(createSchema, async (body) => {
    const session = await getServerSession(getAuthOptions());
    if (!session?.user?.workspaceId) {
      throw new Error('Unauthorized');
    }
    return createSession({
      workspaceId: session.user.workspaceId,
      title: body.title,
      goal: body.goal,
      providerId: body.providerId,
      model: body.model,
    });
  }),
);
