import { withApiErrorHandler, withValidatedBody } from '@/components/layout/ApiErrorBoundary';
import { getServerSession } from 'next-auth';
import { getAuthOptions } from '@/lib/auth';
import { getSession, updateSession, deleteSession, pinSession } from '@/lib/sessions/repository';
import { validate } from '@/lib/validation/schemas';
import { z } from 'zod';

const updateSchema = z.object({
  title: z.string().min(1).max(200).optional(),
  goal: z.string().max(10000).optional(),
  status: z.enum(['idle', 'planning', 'executing', 'verifying', 'done', 'error']).optional(),
  pinned: z.boolean().optional(),
  providerId: z.string().nullable().optional(),
  model: z.string().optional(),
  agentId: z.string().nullable().optional(),
  skillIds: z.array(z.string()).optional(),
  repoIds: z.array(z.string()).max(3).optional(),
  mcpServerIds: z.array(z.string()).optional(),
});

export const GET = withApiErrorHandler(async (_req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const { id } = await params;
  const session = await getServerSession(getAuthOptions());
  if (!session?.user?.workspaceId) throw new Error('Unauthorized');
  return getSession(id, session.user.workspaceId);
});

export const PATCH = withApiErrorHandler(async (req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const { id } = await params;
  const session = await getServerSession(getAuthOptions());
  if (!session?.user?.workspaceId) throw new Error('Unauthorized');
  const body = validate(updateSchema, await req.json());
  return updateSession(id, session.user.workspaceId, body);
});

export const DELETE = withApiErrorHandler(async (_req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const { id } = await params;
  const session = await getServerSession(getAuthOptions());
  if (!session?.user?.workspaceId) throw new Error('Unauthorized');
  await deleteSession(id, session.user.workspaceId);
  return { deleted: true };
});
