import { withApiErrorHandler, withValidatedBody } from '@/components/layout/ApiErrorBoundary';
import { getServerSession } from 'next-auth';
import { getAuthOptions } from '@/lib/auth';
import { getMessages } from '@/lib/chat/messages';

export const GET = withApiErrorHandler(async (_req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const { id } = await params;
  const session = await getServerSession(getAuthOptions());
  if (!session?.user?.workspaceId) throw new Error('Unauthorized');
  const messages = await getMessages(id, session.user.workspaceId, { limit: 200 });
  return messages;
});
