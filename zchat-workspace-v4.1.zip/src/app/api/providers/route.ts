import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { db } from '@/lib/db';

export const GET = withApiErrorHandler(async () => {
  const providers = await db.provider.findMany({
    where: { workspaceId: null },
    orderBy: { name: 'asc' },
  });
  return providers.map((p) => ({
    ...p,
    models: JSON.parse(p.models) as string[],
    apiKey: p.apiKey ? '[redacted]' : null,
  }));
});
