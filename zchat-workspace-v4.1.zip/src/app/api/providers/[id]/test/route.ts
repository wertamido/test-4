import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { db } from '@/lib/db';
import { verifyProviderModel } from '@/lib/providers/verify';

export const POST = withApiErrorHandler(async (_req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const { id } = await params;

  const row = await db.provider.findUnique({ where: { id } });
  if (!row) throw new Error(`Provider ${id} not found`);

  // Use the first model from the provider's models list, or a default
  const models = JSON.parse(row.models) as string[];
  const model = models[0] ?? 'glm-4.6';

  const result = await verifyProviderModel(
    {
      id: row.id,
      name: row.name,
      kind: row.kind as 'openai' | 'anthropic' | 'zai' | 'custom',
      baseUrl: row.baseUrl,
      apiKey: row.apiKey,
      enabled: row.enabled,
      isLocal: row.isLocal,
    },
    model,
  );

  return result;
});
