import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { db } from '@/lib/db';
import { validate } from '@/lib/validation/schemas';
import { z } from 'zod';

const updateSchema = z.object({
  enabled: z.boolean().optional(),
  apiKey: z.string().max(500).optional(),
  models: z.array(z.string()).max(100).optional(),
});

export const PATCH = withApiErrorHandler(async (req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const { id } = await params;
  const body = validate(updateSchema, await req.json());

  // Check: cannot disable the last enabled provider
  if (body.enabled === false) {
    const enabledCount = await db.provider.count({ where: { enabled: true, workspaceId: null } });
    if (enabledCount <= 1) {
      throw new Error('Cannot disable the last enabled provider');
    }
  }

  const data: Record<string, unknown> = {};
  if (body.enabled !== undefined) data['enabled'] = body.enabled;
  if (body.apiKey !== undefined) data['apiKey'] = body.apiKey;
  if (body.models !== undefined) data['models'] = JSON.stringify(body.models);

  const updated = await db.provider.update({ where: { id }, data });
  return { ...updated, models: JSON.parse(updated.models) as string[], apiKey: updated.apiKey ? '[redacted]' : null };
});
