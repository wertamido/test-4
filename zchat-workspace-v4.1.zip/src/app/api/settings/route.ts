import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { getServerSession } from 'next-auth';
import { getAuthOptions } from '@/lib/auth';
import { getSettings, updateSettings } from '@/lib/settings';

export const GET = withApiErrorHandler(async () => {
  const session = await getServerSession(getAuthOptions());
  if (!session?.user?.workspaceId) throw new Error('Unauthorized');
  return getSettings(session.user.workspaceId);
});

export const PATCH = withApiErrorHandler(async (req: Request) => {
  const session = await getServerSession(getAuthOptions());
  if (!session?.user?.workspaceId) throw new Error('Unauthorized');
  const body = await req.json() as Record<string, unknown>;
  return updateSettings(session.user.workspaceId, body);
});
