import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { db } from '@/lib/db';
import { validate } from '@/lib/validation/schemas';
import { z } from 'zod';

const updateSchema = z.object({
  enabled: z.boolean().optional(),
  strength: z.union([z.literal(1), z.literal(2), z.literal(3)]).optional(),
});

export const PATCH = withApiErrorHandler(async (req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const { id } = await params;
  const body = validate(updateSchema, await req.json());

  const data: Record<string, unknown> = {};
  if (body.enabled !== undefined) data['enabled'] = body.enabled;
  if (body.strength !== undefined) data['strength'] = body.strength;

  return db.skill.update({ where: { id }, data });
});
