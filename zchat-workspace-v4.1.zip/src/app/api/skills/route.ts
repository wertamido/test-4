import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { db } from '@/lib/db';

export const GET = withApiErrorHandler(async () => {
  const skills = await db.skill.findMany({ orderBy: [{ category: 'asc' }, { strength: 'asc' }] });
  return skills;
});
