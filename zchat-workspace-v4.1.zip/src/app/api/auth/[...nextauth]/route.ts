/**
 * Next.js 16 App Router — NextAuth v4 Route Handler
 *
 * Blueprint v4.1 §5 (System Architecture), §24 (Security Model)
 *
 * Exports GET and POST for /api/auth/[...nextauth]/* — NextAuth's required
 * catch-all entrypoint. The handler is constructed once per process by
 * `NextAuth(getAuthOptions())` and reused across requests.
 *
 * The `as Promise<Response>` cast is necessary because NextAuth v4's handler
 * return type is `Promise<NextApiResponse | Response | undefined>` (it
 * supports both Pages and App Router). In App Router mode (which is what we
 * use), the handler always returns a `Response`. We narrow the type so the
 * route handler signature matches Next.js 16's strict `(req: Request) =>
 * Promise<Response>` contract.
 *
 * `getAuthOptions()` is lazy and fails fast with AuthError(AUTH_CONFIG_MISSING)
 * if NEXTAUTH_SECRET is not set. We let that error propagate — Next.js 16
 * will surface it as a 500 with the AuthError message in development.
 */

import NextAuth from 'next-auth';
import { getAuthOptions } from '@/lib/auth';

const handler = NextAuth(getAuthOptions());

export async function GET(request: Request): Promise<Response> {
  return handler(request) as Promise<Response>;
}

export async function POST(request: Request): Promise<Response> {
  return handler(request) as Promise<Response>;
}
