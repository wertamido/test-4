import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { hashPassword } from '@/lib/auth';
import { db } from '@/lib/db';
import { validate } from '@/lib/validation/schemas';
import { z } from 'zod';

const registerSchema = z.object({
  name: z.string().min(1).max(100),
  email: z.string().email(),
  password: z.string().min(8).max(100),
});

export const POST = withApiErrorHandler(async (req: Request) => {
  const body = validate(registerSchema, await req.json());

  const existing = await db.user.findUnique({ where: { email: body.email } });
  if (existing) {
    throw new Error('Email already registered');
  }

  const passwordHash = await hashPassword(body.password);

  const user = await db.user.create({
    data: {
      email: body.email,
      name: body.name,
      passwordHash,
      tier: 'free',
    },
  });

  await db.workspace.create({
    data: {
      userId: user.id,
      name: `${body.name}'s Workspace`,
      settings: '{}',
    },
  });

  return { userId: user.id, email: user.email };
});
