import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { getServerSession } from 'next-auth';
import { getAuthOptions } from '@/lib/auth';
import { exportProject } from '@/lib/export';
import { validate } from '@/lib/validation/schemas';
import { z } from 'zod';

const exportSchema = z.object({
  sessionId: z.string().min(1),
  format: z.enum(['zip', 'tar']),
});

export const POST = withApiErrorHandler(async (req: Request) => {
  const session = await getServerSession(getAuthOptions());
  if (!session?.user?.workspaceId) throw new Error('Unauthorized');

  const body = validate(exportSchema, await req.json());
  const result = await exportProject(body.sessionId, session.user.workspaceId, body.format);

  return new Response(new Uint8Array(result.buffer), {
    headers: {
      'content-type': body.format === 'zip' ? 'application/zip' : 'application/x-tar',
      'content-disposition': `attachment; filename="${result.filename}"`,
    },
  });
}) as unknown as (req: Request) => Promise<Response>;
