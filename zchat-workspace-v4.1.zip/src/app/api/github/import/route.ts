import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { getServerSession } from 'next-auth';
import { getAuthOptions } from '@/lib/auth';
import { importGithubRepo } from '@/lib/github';
import { validate } from '@/lib/validation/schemas';
import { z } from 'zod';

const importSchema = z.object({
  id: z.number(),
  fullName: z.string(),
  description: z.string().nullable(),
  url: z.string().url(),
  stars: z.number(),
  language: z.string().nullable(),
  owner: z.string(),
});

export const POST = withApiErrorHandler(async (req: Request) => {
  const session = await getServerSession(getAuthOptions());
  if (!session?.user?.workspaceId) throw new Error('Unauthorized');
  const body = validate(importSchema, await req.json());
  return importGithubRepo(session.user.workspaceId, body);
});
