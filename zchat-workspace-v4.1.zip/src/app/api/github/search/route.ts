import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { searchGithubRepos } from '@/lib/github';
import { validate } from '@/lib/validation/schemas';
import { z } from 'zod';

const searchSchema = z.object({
  q: z.string().min(1).max(500),
  language: z.string().optional(),
});

export const GET = withApiErrorHandler(async (req: Request) => {
  const url = new URL(req.url);
  const params = Object.fromEntries(url.searchParams.entries());
  const { q, language } = validate(searchSchema, params);
  return searchGithubRepos({ query: q, language });
});
