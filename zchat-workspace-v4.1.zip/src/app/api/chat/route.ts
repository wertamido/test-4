import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { getServerSession } from 'next-auth';
import { getAuthOptions } from '@/lib/auth';
import { streamChat, streamChatToSse } from '@/lib/chat/stream';
import { getSession } from '@/lib/sessions/repository';
import { db } from '@/lib/db';
import { validate } from '@/lib/validation/schemas';
import { z } from 'zod';

const chatSchema = z.object({
  sessionId: z.string().min(1),
  content: z.string().min(1).max(32000),
  skillIds: z.array(z.string()).max(42).optional(),
  repoIds: z.array(z.string()).max(3).optional(),
});

export const POST = withApiErrorHandler(async (req: Request) => {
  const session = await getServerSession(getAuthOptions());
  if (!session?.user?.workspaceId || !session?.user?.id) {
    throw new Error('Unauthorized');
  }

  const body = validate(chatSchema, await req.json());

  // Get the session to find the provider + model
  const sessionRecord = await getSession(body.sessionId, session.user.workspaceId);
  const providerId = sessionRecord.providerId ?? 'zai';
  const model = sessionRecord.model ?? 'glm-4.6';

  // Verify the provider is enabled
  const provider = await db.provider.findUnique({ where: { id: providerId } });
  if (!provider || !provider.enabled) {
    throw new Error(`Provider ${providerId} is not enabled`);
  }

  // Stream the chat
  const stream = streamChat({
    sessionId: body.sessionId,
    workspaceId: session.user.workspaceId,
    userId: session.user.id,
    content: body.content,
    providerId,
    model,
    skillIds: body.skillIds ?? sessionRecord.skillIds,
    repoIds: body.repoIds ?? sessionRecord.repoIds,
  });

  const sseStream = streamChatToSse(stream);

  return new Response(sseStream, {
    headers: {
      'content-type': 'text/event-stream',
      'cache-control': 'no-cache',
      connection: 'keep-alive',
    },
  });
}) as unknown as (req: Request) => Promise<Response>;
