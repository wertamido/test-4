import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { db } from '@/lib/db';

export const GET = withApiErrorHandler(async () => {
  const servers = await db.mcpServer.findMany({
    where: { OR: [{ workspaceId: null }] },
    orderBy: { name: 'asc' },
  });
  return servers.map((s) => ({
    ...s,
    args: JSON.parse(s.args) as string[],
    env: JSON.parse(s.env) as Record<string, string>,
    toolsCache: JSON.parse(s.toolsCache) as unknown[],
  }));
});
