import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { testMcpServer } from '@/lib/mcp';

export const POST = withApiErrorHandler(async (_req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const { id } = await params;
  const tools = await testMcpServer(id);
  return { toolsDiscovered: tools.length, tools };
});
