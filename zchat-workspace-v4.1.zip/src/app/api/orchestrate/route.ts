import { withApiErrorHandler } from '@/components/layout/ApiErrorBoundary';
import { getServerSession } from 'next-auth';
import { getAuthOptions } from '@/lib/auth';
import { orchestrate } from '@/lib/agents/orchestrator';
import { validate } from '@/lib/validation/schemas';
import { z } from 'zod';

const orchestrateSchema = z.object({
  sessionId: z.string().min(1),
  goal: z.string().min(1).max(10000),
  leadAgentId: z.string().default('agent.hermes'),
  providerId: z.string().default('zai'),
  model: z.string().default('glm-4.6'),
  maxDepth: z.number().int().min(0).max(3).default(3),
  maxAgents: z.number().int().min(1).max(20).default(20),
  mode: z.enum(['auto', 'manual']).default('auto'),
});

export const POST = withApiErrorHandler(async (req: Request) => {
  const session = await getServerSession(getAuthOptions());
  if (!session?.user?.workspaceId) throw new Error('Unauthorized');

  const body = validate(orchestrateSchema, await req.json());

  const result = await orchestrate({
    sessionId: body.sessionId,
    workspaceId: session.user.workspaceId,
    goal: body.goal,
    leadAgentId: body.leadAgentId ?? 'agent.hermes',
    providerId: body.providerId ?? 'zai',
    model: body.model ?? 'glm-4.6',
    maxDepth: body.maxDepth ?? 3,
    maxAgents: body.maxAgents ?? 20,
    mode: body.mode ?? 'auto',
  });

  return result;
});
