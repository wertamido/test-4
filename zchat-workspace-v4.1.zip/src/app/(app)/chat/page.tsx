'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ChatArea } from '@/components/chat/ChatArea';
import { Composer } from '@/components/chat/Composer';
import { WelcomeScreen } from '@/components/chat/WelcomeScreen';
import { GettingStarted } from '@/components/onboarding/GettingStarted';
import { useChatStore } from '@/store/chat';
import { useToast } from '@/hooks/use-toast';
import type { SessionRecord } from '@/types';

export default function ChatPage() {
  const router = useRouter();
  const { activeSessionId, setSessions, setActiveSession } = useChatStore();
  const [loading, setLoading] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const { error: showError } = useToast();

  useEffect(() => {
    loadSessions();
  }, []);

  async function loadSessions() {
    try {
      const res = await fetch('/api/sessions');
      if (!res.ok) throw new Error('Failed to load sessions');
      const data = await res.json() as { data: SessionRecord[] };
      setSessions(data.data);
      if (data.data.length === 0) {
        setShowOnboarding(true);
      }
    } catch (err) {
      showError('Failed to load sessions', err instanceof Error ? err.message : undefined);
    } finally {
      setLoading(false);
    }
  }

  async function createSession(title?: string) {
    try {
      const res = await fetch('/api/sessions', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ title: title ?? 'New session' }),
      });
      if (!res.ok) throw new Error('Failed to create session');
      const data = await res.json() as { data: SessionRecord };
      setActiveSession(data.data.id);
      router.push(`/chat/${data.data.id}`);
      setShowOnboarding(false);
    } catch (err) {
      showError('Failed to create session', err instanceof Error ? err.message : undefined);
    }
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-zinc-600 border-t-zinc-100" />
      </div>
    );
  }

  if (!activeSessionId) {
    return (
      <div className="flex h-full flex-col">
        {showOnboarding && <GettingStarted onCreateSession={() => createSession()} />}
        <WelcomeScreen onNewSession={() => createSession()} />
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <ChatArea sessionId={activeSessionId} />
      <Composer sessionId={activeSessionId} />
    </div>
  );
}
