'use client';

import { useEffect } from 'react';
import { useParams } from 'next/navigation';
import { ChatArea } from '@/components/chat/ChatArea';
import { Composer } from '@/components/chat/Composer';
import { useChatStore } from '@/store/chat';

export default function SessionChatPage() {
  const params = useParams<{ sessionId: string }>();
  const sessionId = params.sessionId;
  const { setActiveSession, setMessages } = useChatStore();

  useEffect(() => {
    if (sessionId) {
      setActiveSession(sessionId);
      // Load messages for this session
      loadMessages(sessionId).then((msgs) => setMessages(msgs));
    }
  }, [sessionId, setActiveSession, setMessages]);

  if (!sessionId) return null;

  return (
    <div className="flex h-full flex-col">
      <ChatArea sessionId={sessionId} />
      <Composer sessionId={sessionId} />
    </div>
  );
}

async function loadMessages(sessionId: string) {
  try {
    const res = await fetch(`/api/sessions/${sessionId}/messages`);
    if (!res.ok) return [];
    const data = await res.json() as { data: unknown[] };
    return data.data as never[];
  } catch {
    return [];
  }
}
