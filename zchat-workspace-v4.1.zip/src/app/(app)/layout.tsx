'use client';

import { SessionProvider } from 'next-auth/react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { ProvidersSheet } from '@/components/providers/ProvidersSheet';
import { SkillsSheet } from '@/components/skills/SkillsSheet';
import { AgentsSheet } from '@/components/agents/AgentsSheet';
import { McpSheet } from '@/components/mcp/McpSheet';
import { SettingsSheet } from '@/components/settings/SettingsSheet';
import { GithubSheet } from '@/components/github/GithubSheet';
import { useSettingsStore } from '@/store/chat';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const activeSheet = useSettingsStore((s) => s.activeSheet);
  const setActiveSheet = useSettingsStore((s) => s.setActiveSheet);

  return (
    <SessionProvider>
      <div className="flex h-screen bg-black">
        <Sidebar />
        <div className="flex flex-1 flex-col overflow-hidden">
          <Header />
          <main className="flex-1 overflow-hidden">{children}</main>
        </div>
      </div>

      <ProvidersSheet open={activeSheet === 'providers'} onClose={() => setActiveSheet(null)} />
      <SkillsSheet open={activeSheet === 'skills'} onClose={() => setActiveSheet(null)} />
      <AgentsSheet open={activeSheet === 'agents'} onClose={() => setActiveSheet(null)} />
      <McpSheet open={activeSheet === 'mcp'} onClose={() => setActiveSheet(null)} />
      <SettingsSheet open={activeSheet === 'settings'} onClose={() => setActiveSheet(null)} />
      <GithubSheet open={activeSheet === 'github'} onClose={() => setActiveSheet(null)} />
    </SessionProvider>
  );
}
