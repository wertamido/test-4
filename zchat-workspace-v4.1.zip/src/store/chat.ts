'use client';

import { create } from 'zustand';
import type { SessionRecord, MessageRecord, ProviderRecord, SkillRecord, AgentTemplateRecord, WorkspaceSettings } from '@/types';

interface ChatState {
  sessions: SessionRecord[];
  activeSessionId: string | null;
  messages: MessageRecord[];
  streamingContent: string;
  isStreaming: boolean;
  sidebarOpen: boolean;

  setSessions: (sessions: SessionRecord[]) => void;
  setActiveSession: (id: string | null) => void;
  setMessages: (messages: MessageRecord[]) => void;
  addMessage: (message: MessageRecord) => void;
  setStreamingContent: (content: string) => void;
  setIsStreaming: (streaming: boolean) => void;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  reset: () => void;
}

export const useChatStore = create<ChatState>((set) => ({
  sessions: [],
  activeSessionId: null,
  messages: [],
  streamingContent: '',
  isStreaming: false,
  sidebarOpen: true,

  setSessions: (sessions) => set({ sessions }),
  setActiveSession: (id) => set({ activeSessionId: id, messages: [] }),
  setMessages: (messages) => set({ messages }),
  addMessage: (message) => set((state) => ({ messages: [...state.messages, message] })),
  setStreamingContent: (content) => set({ streamingContent: content }),
  setIsStreaming: (streaming) => set({ isStreaming: streaming }),
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  reset: () => set({ sessions: [], activeSessionId: null, messages: [], streamingContent: '', isStreaming: false }),
}));

interface SettingsState {
  settings: WorkspaceSettings | null;
  providers: ProviderRecord[];
  skills: SkillRecord[];
  agents: AgentTemplateRecord[];
  activeSheet: 'providers' | 'skills' | 'agents' | 'mcp' | 'github' | 'settings' | null;

  setSettings: (s: WorkspaceSettings) => void;
  setProviders: (p: ProviderRecord[]) => void;
  setSkills: (s: SkillRecord[]) => void;
  setAgents: (a: AgentTemplateRecord[]) => void;
  setActiveSheet: (sheet: SettingsState['activeSheet']) => void;
}

export const useSettingsStore = create<SettingsState>((set) => ({
  settings: null,
  providers: [],
  skills: [],
  agents: [],
  activeSheet: null,

  setSettings: (settings) => set({ settings }),
  setProviders: (providers) => set({ providers }),
  setSkills: (skills) => set({ skills }),
  setAgents: (agents) => set({ agents }),
  setActiveSheet: (activeSheet) => set({ activeSheet }),
}));
