/**
 * Context Summarizer — Prevents Token Explosion
 *
 * Blueprint v4.1 §15 (13-Phase Reasoning Loop with Context Summarizer),
 * §4 (Mistake #18 — No Context Window Management)
 *
 * The problem (§4 Mistake #18): "v4.0's 13-phase loop would pass raw context
 * between phases, causing token explosion (30K+ tokens, $3+/run)."
 *
 * The fix: "Context Summarizer. Each phase summarizes its output to max 500
 * tokens before passing to the next phase. Total context stays under 10K
 * tokens. Cost stays under $0.50/run."
 *
 * This module provides:
 *   - summarizeContext(text, maxTokens): compresses text to ≤ maxTokens
 *   - estimateTokens(text): rough token count (~4 chars/token)
 *   - buildPhaseContext(prevSummary, currentOutput, systemPrompt): assembles
 *     the context for the next phase, capped at 10K tokens total
 *   - TOKEN_ESTIMATE_CHARS_PER_TOKEN: the constant used for estimation
 */

import { logger } from '@/lib/logger';

// ─── Constants ─────────────────────────────────────────────────────────────

export const TOKEN_ESTIMATE_CHARS_PER_TOKEN = 4; // ~4 chars per token for English
export const MAX_PHASE_OUTPUT_TOKENS = 500; // §15: each phase output ≤ 500 tokens
export const MAX_TOTAL_CONTEXT_TOKENS = 10_000; // §15: total context < 10K tokens
export const SYSTEM_PROMPT_TOKEN_BUDGET = 1000; // §15: system prompt budget

// ─── Token estimation ──────────────────────────────────────────────────────

export function estimateTokens(text: string): number {
  return Math.ceil(text.length / TOKEN_ESTIMATE_CHARS_PER_TOKEN);
}

// ─── summarizeContext ──────────────────────────────────────────────────────
//
// Compresses `text` to at most `maxTokens` tokens. Strategy:
//   1. If the text is already under the limit, return it as-is.
//   2. Otherwise, use a sentence-aware truncation:
//      a. Split into sentences (by . ! ?)
//      b. Keep sentences until adding the next would exceed the budget
//      c. Append "[... summarized: N tokens → M tokens]" footer
//
// This is a HEURISTIC summarizer — it does NOT call an LLM. For the MVP,
// truncation is sufficient because:
//   - The reasoning loop's phase outputs are structured (not freeform prose)
//   - The LLM can reconstruct missing detail from the goal + plan
//   - A future LLM-based summarizer can be swapped in without changing the
//     interface (just replace the body of summarizeContext)

export function summarizeContext(text: string, maxTokens: number = MAX_PHASE_OUTPUT_TOKENS): string {
  const inputTokens = estimateTokens(text);

  if (inputTokens <= maxTokens) {
    return text;
  }

  // Sentence-aware truncation
  const maxChars = maxTokens * TOKEN_ESTIMATE_CHARS_PER_TOKEN;
  const sentences = text.match(/[^.!?]+[.!?]*/g) ?? [text];

  let result = '';
  for (const sentence of sentences) {
    if ((result + sentence).length > maxChars) {
      break;
    }
    result += sentence;
  }

  if (result.length === 0) {
    // Even the first sentence is too long — hard-truncate
    result = text.slice(0, maxChars);
  }

  const outputTokens = estimateTokens(result);
  const footer = `\n[... summarized: ${inputTokens} tokens → ${outputTokens} tokens]`;

  return result + footer;
}

// ─── buildPhaseContext ─────────────────────────────────────────────────────
//
// Assembles the context for the next reasoning phase. The total context
// must stay under MAX_TOTAL_CONTEXT_TOKENS (10K per §15).
//
// Structure:
//   - System prompt (≤ SYSTEM_PROMPT_TOKEN_BUDGET)
//   - Previous phase summary (≤ MAX_PHASE_OUTPUT_TOKENS)
//   - Current phase output (≤ MAX_PHASE_OUTPUT_TOKENS)
//
// Total: ~1000 + 500 + 500 = 2000 tokens per phase, well under the 10K cap.

export interface PhaseContext {
  readonly systemPrompt: string;
  readonly previousSummary: string;
  readonly currentOutput: string;
  readonly totalEstimatedTokens: number;
}

export function buildPhaseContext(
  systemPrompt: string,
  previousSummary: string,
  currentOutput: string,
): PhaseContext {
  // Truncate each component to its budget
  const truncatedSystem = truncateToTokens(systemPrompt, SYSTEM_PROMPT_TOKEN_BUDGET);
  const truncatedPrev = truncateToTokens(previousSummary, MAX_PHASE_OUTPUT_TOKENS);
  const truncatedCurrent = truncateToTokens(currentOutput, MAX_PHASE_OUTPUT_TOKENS);

  const totalEstimatedTokens =
    estimateTokens(truncatedSystem) +
    estimateTokens(truncatedPrev) +
    estimateTokens(truncatedCurrent);

  if (totalEstimatedTokens > MAX_TOTAL_CONTEXT_TOKENS) {
    logger.warn(
      { module: 'summarizer', totalEstimatedTokens, max: MAX_TOTAL_CONTEXT_TOKENS },
      `Phase context exceeds budget: ${totalEstimatedTokens} > ${MAX_TOTAL_CONTEXT_TOKENS}`,
    );
  }

  return {
    systemPrompt: truncatedSystem,
    previousSummary: truncatedPrev,
    currentOutput: truncatedCurrent,
    totalEstimatedTokens,
  };
}

function truncateToTokens(text: string, maxTokens: number): string {
  if (estimateTokens(text) <= maxTokens) {
    return text;
  }
  const maxChars = maxTokens * TOKEN_ESTIMATE_CHARS_PER_TOKEN;
  return text.slice(0, maxChars) + '\n[... truncated]';
}
