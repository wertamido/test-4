/**
 * 13-Phase Reasoning Loop
 *
 * Blueprint v4.1 §15 (13-Phase Reasoning Loop with Context Summarizer),
 * §22 Phase 3
 *
 * The 13 phases:
 *   1. GOAL         → restate goal + "done" criteria
 *   2. THINK        → free-form reasoning
 *   3. PLAN         → numbered steps, each declares: tool / skill / repo / MCP
 *   4. EXECUTE      → run each step, call declared tools/skills
 *   5. BUILD        → produce the artifact (code / diff / doc / design / data)
 *   6. TEST         → verify artifact against GOAL criteria
 *   7. ANALYSE      → read failures, identify root cause
 *   8. FIX          → patch root cause, re-BUILD, re-TEST (max 3 attempts)
 *   9. AUDIT        → self-review: did I follow the plan?
 *  10. VALIDATE     → cross-check artifact against GOAL criteria
 *  11. PREVIEW      → render frontend, observe output (Puppeteer screenshot)
 *  12. COMPARISON   → search internet for similar apps, benchmark (12 dims)
 *  13. DECIDE       → combine Preview + Comparison + Goal → SHIP | RETRY | SHIP-WITH-CAVEATS
 *
 * Context Summarizer runs after each phase (max 500 tokens per phase output).
 * Total context stays under 10K tokens. Cost stays under $0.50/run.
 *
 * 5 Modes (§15):
 *   - Instant:     no phases, ~2s, $0.001
 *   - Standard:    4 phases (GOAL, THINK, PLAN, EXECUTE), ~10s, $0.01
 *   - Reasoning:   all 13, static preview, ~60s, $0.10
 *   - Deep:        all 13, dynamic preview, ~5-15min, $0.30-0.60
 *   - Autonomous:  deep, background, async, $0.30-0.60
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { runAgent } from '@/lib/agents/runner';
import {
  summarizeContext,
  buildPhaseContext,
  estimateTokens,
  MAX_PHASE_OUTPUT_TOKENS,
} from '@/lib/reasoning/summarizer';
import { type ChatMessage } from '@/lib/providers/types';

// ─── Types ─────────────────────────────────────────────────────────────────

export type ReasoningMode = 'instant' | 'standard' | 'reasoning' | 'deep' | 'autonomous';

export type PhaseName =
  | 'GOAL' | 'THINK' | 'PLAN' | 'EXECUTE' | 'BUILD' | 'TEST'
  | 'ANALYSE' | 'FIX' | 'AUDIT' | 'VALIDATE' | 'PREVIEW'
  | 'COMPARISON' | 'DECIDE';

export interface PhaseResult {
  readonly phase: number;
  readonly phaseName: PhaseName;
  readonly rawOutput: string;
  readonly summary: string;
  readonly tokensUsed: number;
  readonly costUsd: number;
  readonly durationMs: number;
  readonly error?: string;
}

export interface ReasoningResult {
  readonly reasoningRunId: string;
  readonly sessionId: string;
  readonly goal: string;
  readonly mode: ReasoningMode;
  readonly status: 'done' | 'error';
  readonly phases: PhaseResult[];
  readonly finalAnswer: string;
  readonly decision: 'SHIP' | 'RETRY' | 'SHIP-WITH-CAVEATS' | null;
  readonly totalTokens: number;
  readonly totalCostUsd: number;
  readonly durationMs: number;
}

export interface ReasoningParams {
  readonly sessionId: string;
  readonly workspaceId: string;
  readonly goal: string;
  readonly mode: ReasoningMode;
  readonly providerId: string;
  readonly model: string;
  readonly agentTemplateId?: string;
  readonly signal?: AbortSignal;
  readonly onPhaseComplete?: (phase: PhaseResult) => void;
}

// ─── Phase definitions ─────────────────────────────────────────────────────

interface PhaseDef {
  readonly name: PhaseName;
  readonly prompt: string;
}

const ALL_13_PHASES: ReadonlyArray<PhaseDef> = [
  { name: 'GOAL', prompt: 'Restate the goal in your own words. Define clear "done" criteria — what would make this goal complete?' },
  { name: 'THINK', prompt: 'Free-form reasoning about the goal. What are the key challenges? What approaches could work? What are the tradeoffs?' },
  { name: 'PLAN', prompt: 'Create a numbered plan. Each step must declare: which tool to use, which skill applies, which repo to reference, which MCP server is needed. Output as a numbered list.' },
  { name: 'EXECUTE', prompt: 'Execute each step from the plan. Call the declared tools/skills. Report what you did at each step.' },
  { name: 'BUILD', prompt: 'Produce the final artifact (code / diff / doc / design / data). This is the deliverable — make it production-ready.' },
  { name: 'TEST', prompt: 'Verify the artifact against the goal\'s "done" criteria. List specific tests you would run. Identify any failures.' },
  { name: 'ANALYSE', prompt: 'If there are failures, read them carefully. Identify the root cause (not the symptom). State the root cause in one sentence.' },
  { name: 'FIX', prompt: 'Patch the root cause. Re-build and re-test. Maximum 3 fix attempts. If you cannot fix it in 3 attempts, document the blocker.' },
  { name: 'AUDIT', prompt: 'Self-review: did you follow the plan? Did you skip any steps? Did you make assumptions you should have validated? Be honest.' },
  { name: 'VALIDATE', prompt: 'Cross-check the artifact against the original goal criteria. Does it meet every criterion? List any gaps.' },
  { name: 'PREVIEW', prompt: 'If the artifact is a frontend (HTML/CSS/JS), describe how it would render. Note any visual issues. (MVP: no code execution — describe, do not run.)' },
  { name: 'COMPARISON', prompt: 'Search the internet for similar apps/tools. Benchmark against them on 12 dimensions: features, UX, performance, price, docs, community, integrations, security, scalability, support, roadmap, switch cost.' },
  { name: 'DECIDE', prompt: 'Combine the Preview + Comparison + Goal validation. Decide: SHIP (ready), RETRY (re-enter PLAN), or SHIP-WITH-CAVEATS (ready but document the caveats). State your decision and rationale.' },
];

const STANDARD_PHASES: ReadonlyArray<PhaseDef> = [
  ALL_13_PHASES[0]!, // GOAL
  ALL_13_PHASES[1]!, // THINK
  ALL_13_PHASES[2]!, // PLAN
  ALL_13_PHASES[3]!, // EXECUTE
];

function getPhasesForMode(mode: ReasoningMode): ReadonlyArray<PhaseDef> {
  switch (mode) {
    case 'instant': return [];
    case 'standard': return STANDARD_PHASES;
    case 'reasoning':
    case 'deep':
    case 'autonomous':
      return ALL_13_PHASES;
  }
}

// ─── Phase prompt builder ──────────────────────────────────────────────────

function buildPhaseMessage(
  goal: string,
  phase: PhaseDef,
  phaseNumber: number,
  totalPhases: number,
  previousSummary: string,
): string {
  const parts: string[] = [];

  parts.push(`GOAL: ${goal}`);
  parts.push('');
  parts.push(`PHASE ${phaseNumber}/${totalPhases}: ${phase.name}`);
  parts.push(phase.prompt);
  parts.push('');

  if (previousSummary.length > 0) {
    parts.push(`PREVIOUS PHASE SUMMARY:\n${previousSummary}`);
    parts.push('');
  }

  parts.push('Output your response for this phase. Be concise — your output will be summarized to 500 tokens before passing to the next phase.');

  return parts.join('\n');
}

// ─── runReasoningLoop ──────────────────────────────────────────────────────

export async function runReasoningLoop(params: ReasoningParams): Promise<ReasoningResult> {
  const startedAt = Date.now();
  const phases = getPhasesForMode(params.mode);

  logger.info(
    { module: 'reasoning', sessionId: params.sessionId, goal: params.goal, mode: params.mode, phaseCount: phases.length },
    `Reasoning loop starting: mode=${params.mode} phases=${phases.length}`,
  );

  // Create a ReasoningRun record in the DB
  const reasoningRun = await db.reasoningRun.create({
    data: {
      sessionId: params.sessionId,
      goal: params.goal,
      mode: params.mode,
      status: 'running',
      phases: '[]',
    },
  });

  // Instant mode: no phases, just answer directly
  if (params.mode === 'instant' || phases.length === 0) {
    const completion = await runAgent({
      agentTemplateId: params.agentTemplateId ?? 'agent.hermes',
      providerId: params.providerId,
      model: params.model,
      messages: [{ role: 'user', content: params.goal }],
      signal: params.signal,
    });

    const result: ReasoningResult = {
      reasoningRunId: reasoningRun.id,
      sessionId: params.sessionId,
      goal: params.goal,
      mode: params.mode,
      status: 'done',
      phases: [],
      finalAnswer: completion.content,
      decision: null,
      totalTokens: completion.tokensUsed,
      totalCostUsd: completion.costUsd,
      durationMs: Date.now() - startedAt,
    };

    await db.reasoningRun.update({
      where: { id: reasoningRun.id },
      data: {
        status: 'done',
        finalAnswer: completion.content,
        totalTokens: completion.tokensUsed,
        costUsd: completion.costUsd,
        durationMs: result.durationMs,
        finishedAt: new Date(),
      },
    });

    return result;
  }

  // Run each phase
  const phaseResults: PhaseResult[] = [];
  let previousSummary = '';
  let totalTokens = 0;
  let totalCostUsd = 0;

  for (let i = 0; i < phases.length; i++) {
    if (params.signal?.aborted) {
      logger.warn({ module: 'reasoning', phase: i + 1 }, 'Reasoning loop aborted');
      break;
    }

    const phase = phases[i]!;
    const phaseStartedAt = Date.now();
    const phaseMessage = buildPhaseMessage(
      params.goal,
      phase,
      i + 1,
      phases.length,
      previousSummary,
    );

    try {
      const completion = await runAgent({
        agentTemplateId: params.agentTemplateId ?? 'agent.hermes',
        providerId: params.providerId,
        model: params.model,
        messages: [{ role: 'user', content: phaseMessage }],
        signal: params.signal,
      });

      const rawOutput = completion.content;
      const summary = summarizeContext(rawOutput, MAX_PHASE_OUTPUT_TOKENS);

      const phaseResult: PhaseResult = {
        phase: i + 1,
        phaseName: phase.name,
        rawOutput,
        summary,
        tokensUsed: completion.tokensUsed,
        costUsd: completion.costUsd,
        durationMs: Date.now() - phaseStartedAt,
      };

      phaseResults.push(phaseResult);
      previousSummary = summary;
      totalTokens += completion.tokensUsed;
      totalCostUsd += completion.costUsd;

      params.onPhaseComplete?.(phaseResult);

      logger.debug(
        { module: 'reasoning', phase: i + 1, phaseName: phase.name, tokens: completion.tokensUsed, durationMs: phaseResult.durationMs },
        `Phase ${i + 1}/${phases.length} (${phase.name}) complete`,
      );
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      const phaseResult: PhaseResult = {
        phase: i + 1,
        phaseName: phase.name,
        rawOutput: '',
        summary: `[Phase failed: ${errorMsg}]`,
        tokensUsed: 0,
        costUsd: 0,
        durationMs: Date.now() - phaseStartedAt,
        error: errorMsg,
      };
      phaseResults.push(phaseResult);
      previousSummary = phaseResult.summary;

      logger.error(
        { module: 'reasoning', phase: i + 1, err },
        `Phase ${i + 1} (${phase.name}) failed: ${errorMsg}`,
      );
    }
  }

  // Extract the final answer + decision
  const lastPhase = phaseResults[phaseResults.length - 1];
  const finalAnswer = lastPhase?.rawOutput ?? '';
  const decision = extractDecision(finalAnswer);

  const result: ReasoningResult = {
    reasoningRunId: reasoningRun.id,
    sessionId: params.sessionId,
    goal: params.goal,
    mode: params.mode,
    status: 'done',
    phases: phaseResults,
    finalAnswer,
    decision,
    totalTokens,
    totalCostUsd: totalCostUsd,
    durationMs: Date.now() - startedAt,
  };

  // Persist the final result
  await db.reasoningRun.update({
    where: { id: reasoningRun.id },
    data: {
      status: 'done',
      phases: JSON.stringify(phaseResults.map((p) => ({
        phase: p.phase, phaseName: p.phaseName, summary: p.summary,
        tokensUsed: p.tokensUsed, costUsd: p.costUsd, durationMs: p.durationMs, error: p.error,
      }))),
      finalAnswer,
      totalTokens,
      costUsd: totalCostUsd,
      durationMs: result.durationMs,
      finishedAt: new Date(),
    },
  });

  logger.info(
    { module: 'reasoning', sessionId: params.sessionId, reasoningRunId: reasoningRun.id, phaseCount: phaseResults.length, totalTokens, totalCostUsd, durationMs: result.durationMs, decision },
    `Reasoning loop complete: ${params.mode} (${phaseResults.length} phases, ${totalTokens} tokens, $${totalCostUsd.toFixed(4)})`,
  );

  return result;
}

// ─── Decision extraction ───────────────────────────────────────────────────

function extractDecision(finalAnswer: string): 'SHIP' | 'RETRY' | 'SHIP-WITH-CAVEATS' | null {
  const upper = finalAnswer.toUpperCase();
  if (upper.includes('SHIP-WITH-CAVEATS') || upper.includes('SHIP WITH CAVEATS')) {
    return 'SHIP-WITH-CAVEATS';
  }
  if (upper.includes('SHIP')) {
    return 'SHIP';
  }
  if (upper.includes('RETRY')) {
    return 'RETRY';
  }
  return null;
}

// ─── Re-exports ────────────────────────────────────────────────────────────

export { summarizeContext, estimateTokens, buildPhaseContext } from '@/lib/reasoning/summarizer';
