/**
 * Settings — Theme, Density, Generation Params
 *
 * Blueprint v4.1 §22 Phase 1 Step 1.10, §26 (User Decisions — Black/zinc)
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { z } from 'zod';

export const themeSchema = z.enum(['black', 'zinc']);
export type Theme = z.infer<typeof themeSchema>;

export const densitySchema = z.enum(['compact', 'comfortable', 'spacious']);
export type Density = z.infer<typeof densitySchema>;

export const workspaceSettingsSchema = z.object({
  theme: themeSchema.default('black'),
  density: densitySchema.default('comfortable'),
  defaultProviderId: z.string().nullable().default(null),
  defaultModel: z.string().default('glm-4.6'),
  defaultTemperature: z.number().min(0).max(2).default(0.7),
  defaultMaxTokens: z.number().int().min(1).max(128000).default(4096),
  sendOnEnter: z.boolean().default(true),
  showTokenCount: z.boolean().default(true),
  streamingEnabled: z.boolean().default(true),
});

export type WorkspaceSettings = z.infer<typeof workspaceSettingsSchema>;

export const DEFAULT_SETTINGS: WorkspaceSettings = {
  theme: 'black',
  density: 'comfortable',
  defaultProviderId: null,
  defaultModel: 'glm-4.6',
  defaultTemperature: 0.7,
  defaultMaxTokens: 4096,
  sendOnEnter: true,
  showTokenCount: true,
  streamingEnabled: true,
};

export type SettingsErrorCode = 'SETTINGS_INVALID' | 'SETTINGS_UPDATE_FAILED' | 'WORKSPACE_NOT_FOUND';

const SETTINGS_ERROR_BRAND = Symbol('SettingsError');

export class SettingsError extends Error {
  public readonly [SETTINGS_ERROR_BRAND]: true = true;
  public readonly code: SettingsErrorCode;
  public readonly cause: unknown;

  public constructor(code: SettingsErrorCode, message: string, cause?: unknown) {
    super(message);
    this.name = 'SettingsError';
    this.code = code;
    this.cause = cause;
    Object.setPrototypeOf(this, SettingsError.prototype);
  }
}

export function isSettingsError(error: unknown): error is SettingsError {
  return typeof error === 'object' && error !== null && (error as Record<symbol, unknown>)[SETTINGS_ERROR_BRAND] === true;
}

function parseSettings(json: string): WorkspaceSettings {
  try {
    const parsed = JSON.parse(json) as unknown;
    return workspaceSettingsSchema.parse(parsed);
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export async function getSettings(workspaceId: string): Promise<WorkspaceSettings> {
  const workspace = await db.workspace.findUnique({
    where: { id: workspaceId },
    select: { settings: true },
  });

  if (!workspace) {
    throw new SettingsError('WORKSPACE_NOT_FOUND', `Workspace ${workspaceId} not found.`);
  }

  return parseSettings(workspace.settings);
}

export async function updateSettings(
  workspaceId: string,
  updates: Partial<WorkspaceSettings>,
): Promise<WorkspaceSettings> {
  const current = await getSettings(workspaceId);
  const merged = { ...current, ...updates };
  const parsed = workspaceSettingsSchema.safeParse(merged);
  if (!parsed.success) {
    throw new SettingsError(
      'SETTINGS_INVALID',
      `Invalid settings: ${parsed.error.issues.map((i) => i.message).join('; ')}`,
    );
  }

  try {
    await db.workspace.update({
      where: { id: workspaceId },
      data: { settings: JSON.stringify(parsed.data) },
    });
    logger.info({ module: 'settings', workspaceId }, `Settings updated for workspace ${workspaceId}`);
    return parsed.data;
  } catch (err) {
    throw new SettingsError(
      'SETTINGS_UPDATE_FAILED',
      `Failed to update settings: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}

export async function resetSettings(workspaceId: string): Promise<WorkspaceSettings> {
  try {
    await db.workspace.update({
      where: { id: workspaceId },
      data: { settings: JSON.stringify(DEFAULT_SETTINGS) },
    });
    return { ...DEFAULT_SETTINGS };
  } catch (err) {
    throw new SettingsError(
      'SETTINGS_UPDATE_FAILED',
      `Failed to reset settings: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}
