/**
 * StorageAdapter — Interface + Types + Path Validation
 *
 * Blueprint v4.1 §20 (Interface-Driven Design — StorageAdapter), §5 (Architecture),
 * §22 Phase 0 Step 0.10, §24 (Security Model — path traversal defense)
 *
 * Design goals:
 *  - Single storage abstraction for the entire codebase. Direct `fs.readFile`
 *    / `fs.writeFile` calls outside the local.ts implementation are forbidden.
 *  - Interface is S3-compatible: a future S3 adapter can implement it without
 *    API changes. The swap is "change the implementation, not the interface"
 *    (Blueprint §20).
 *  - `validatePath()` is the security boundary that prevents LLM-generated
 *    artifacts from escaping the storage root via `..`, absolute paths,
 *    null bytes, or symlink traversal. Every adapter implementation MUST
 *    call `validatePath()` before any filesystem or remote-API operation.
 *  - `StorageError` follows the branded-symbol pattern established by
 *    DbError, AuthError, ValidationError, and QueueError.
 *  - `getSignedUrl` is optional (returns `null` for local; an S3 adapter
 *    would return a presigned URL). The return type `string | null` makes
 *    the optionality explicit at the type level.
 *
 * No runtime code in this file beyond the error class + validatePath helper.
 * The interface + types live here so test files can import them without
 * pulling in the local.ts implementation (which depends on Node's fs).
 */

// ─── Types ─────────────────────────────────────────────────────────────────

/**
 * A single storage item returned by `list()`. Mirrors what an S3 ListObjects
 * response would yield: key (path), size, last-modified, content-type.
 */
export interface StorageItem {
  /** Relative path within the storage root (POSIX-style, forward slashes). */
  readonly path: string;
  /** File size in bytes. */
  readonly size: number;
  /** Creation or last-modified time (prefers birthtime; falls back to mtime). */
  readonly createdAt: Date;
  /** MIME type inferred from extension (e.g., 'application/json'). */
  readonly contentType: string;
}

/**
 * Metadata for a single storage item returned by `metadata()`.
 * Same shape as `StorageItem` (intentional — `list()` returns `StorageItem[]`,
 * `metadata()` returns a single `StorageItem`).
 */
export type StorageMetadata = StorageItem;

// ─── StorageAdapter interface ──────────────────────────────────────────────
//
// Every method takes a `path` parameter that is RELATIVE to the adapter's
// root. Implementations MUST call `validatePath(path)` before doing anything
// with the path. This is the security boundary.
//
// The interface is designed so an S3 adapter can implement it without API
// changes:
//   - save() → S3 PutObject
//   - read() → S3 GetObject
//   - exists() → S3 HeadObject
//   - delete() → S3 DeleteObject
//   - list() → S3 ListObjectsV2
//   - getSignedUrl() → S3 getSignedUrl (presigned URL)
//   - metadata() → S3 HeadObject (returns size, lastModified, contentType)

export interface StorageAdapter {
  /**
   * Write data to the given path. Creates parent directories as needed.
   * Returns the full path (root + relative) of the written file.
   */
  save(path: string, data: Buffer): Promise<string>;

  /**
   * Read the file at the given path. Returns the file contents as a Buffer.
   * Throws StorageError(NOT_FOUND) if the file does not exist.
   */
  read(path: string): Promise<Buffer>;

  /**
   * Check whether a file exists at the given path. Never throws.
   */
  exists(path: string): Promise<boolean>;

  /**
   * Delete the file at the given path.
   * Throws StorageError(NOT_FOUND) if the file does not exist.
   */
  delete(path: string): Promise<void>;

  /**
   * List all files under the given prefix (or root if no prefix).
   * Returns StorageItem[] — never returns directories, only files.
   */
  list(prefix?: string): Promise<StorageItem[]>;

  /**
   * Return a presigned URL for the given path, valid for `expiresIn` seconds.
   * Local adapter returns `null` (no signing — caller uses the direct path).
   * S3 adapter would return a presigned URL.
   */
  getSignedUrl(path: string, expiresIn: number): Promise<string | null>;

  /**
   * Return metadata for the given path.
   * Throws StorageError(NOT_FOUND) if the file does not exist.
   */
  metadata(path: string): Promise<StorageMetadata>;
}

// ─── StorageError ──────────────────────────────────────────────────────────

export type StorageErrorCode =
  | 'SAVE_FAILED'
  | 'READ_FAILED'
  | 'DELETE_FAILED'
  | 'NOT_FOUND'
  | 'PATH_TRAVERSAL_DETECTED'
  | 'INVALID_PATH'
  | 'EDGE_RUNTIME_UNSUPPORTED';

const STORAGE_ERROR_BRAND = Symbol('StorageError');

export class StorageError extends Error {
  public readonly [STORAGE_ERROR_BRAND]: true = true;
  public readonly code: StorageErrorCode;
  public readonly cause: unknown;
  public readonly path?: string;

  public constructor(
    code: StorageErrorCode,
    message: string,
    cause?: unknown,
    path?: string,
  ) {
    super(message);
    this.name = 'StorageError';
    this.code = code;
    this.cause = cause;
    this.path = path;
    // Restore prototype chain after subclassing Error (TS/ES2015 target quirk)
    Object.setPrototypeOf(this, StorageError.prototype);
  }
}

/**
 * Type guard for StorageError. Use this in catch blocks instead of
 * `instanceof` to remain robust against cross-realm / serialized payloads.
 */
export function isStorageError(error: unknown): error is StorageError {
  return (
    typeof error === 'object' &&
    error !== null &&
    (error as Record<symbol, unknown>)[STORAGE_ERROR_BRAND] === true
  );
}

// ─── validatePath — the security boundary ──────────────────────────────────
//
// Defense in depth against path traversal. LLM-generated artifacts may
// contain malicious paths; this function rejects them BEFORE they reach the
// filesystem.
//
// Rules:
//   1. Path must be a non-empty string.
//   2. Path must not contain null bytes (`\0`) — these can truncate paths
//      in some C-based filesystem APIs.
//   3. Path must not be absolute (no leading `/` or drive letter `C:\`).
//   4. Path must not contain `..` segments — these escape the storage root.
//   5. Path segments must not contain backslashes — normalize to forward
//      slashes only (POSIX-style).
//   6. After normalization, the resolved path must stay within the root.
//
// Returns the normalized relative path on success. Throws StorageError on
// violation.
//
// Note: This function does NOT touch the filesystem. It is a pure string
// validation. Filesystem-level defense (checking real symlinks) is the
// local.ts implementation's responsibility — but validatePath is the first
// line of defense and catches 99% of attacks.

export function validatePath(path: unknown): string {
  if (typeof path !== 'string') {
    throw new StorageError(
      'INVALID_PATH',
      'Path must be a string.',
      undefined,
      path === undefined ? undefined : String(path),
    );
  }

  if (path.length === 0) {
    throw new StorageError(
      'INVALID_PATH',
      'Path must not be empty.',
      undefined,
      path,
    );
  }

  // Null byte check — never allow these in paths
  if (path.includes('\0')) {
    throw new StorageError(
      'INVALID_PATH',
      'Path must not contain null bytes.',
      undefined,
      path,
    );
  }

  // Normalize backslashes to forward slashes (Windows compatibility)
  const normalized = path.replace(/\\/g, '/');

  // Reject absolute paths (Unix or Windows drive letter)
  if (normalized.startsWith('/')) {
    throw new StorageError(
      'PATH_TRAVERSAL_DETECTED',
      'Path must not be absolute.',
      undefined,
      path,
    );
  }
  if (/^[a-zA-Z]:/.test(normalized)) {
    throw new StorageError(
      'PATH_TRAVERSAL_DETECTED',
      'Path must not start with a drive letter.',
      undefined,
      path,
    );
  }

  // Split into segments and reject `..` segments
  const segments = normalized.split('/').filter((s) => s.length > 0);
  for (const segment of segments) {
    if (segment === '..') {
      throw new StorageError(
        'PATH_TRAVERSAL_DETECTED',
        'Path must not contain ".." segments.',
        undefined,
        path,
      );
    }
    if (segment === '.') {
      // Allow `.` segments (harmless) but strip them for cleanliness
      continue;
    }
    // Reject segments that contain `..` as a substring (e.g., `a..b`)
    // — these are not traversal but are suspicious. Allow them — they
    // are valid filenames. Only exact `..` segments are dangerous.
  }

  // Re-join the normalized segments (drops `.` and empty segments)
  const cleaned = segments.filter((s) => s !== '.').join('/');

  if (cleaned.length === 0) {
    throw new StorageError(
      'INVALID_PATH',
      'Path must contain at least one non-trivial segment.',
      undefined,
      path,
    );
  }

  return cleaned;
}

// ─── MIME type map (inline, no external deps) ──────────────────────────────
//
// Blueprint constraint: do NOT use any external mime-detection library.
// This map covers the 10 most common types LLM-generated artifacts produce.
// Unknown extensions default to 'application/octet-stream'.

export const MIME_MAP: Readonly<Record<string, string>> = {
  json: 'application/json',
  txt: 'text/plain',
  md: 'text/markdown',
  html: 'text/html',
  css: 'text/css',
  js: 'application/javascript',
  ts: 'application/typescript',
  tsx: 'application/typescript',
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
};

export function getContentType(filename: string): string {
  const lastDot = filename.lastIndexOf('.');
  if (lastDot === -1 || lastDot === filename.length - 1) {
    return 'application/octet-stream';
  }
  const ext = filename.slice(lastDot + 1).toLowerCase();
  return MIME_MAP[ext] ?? 'application/octet-stream';
}
