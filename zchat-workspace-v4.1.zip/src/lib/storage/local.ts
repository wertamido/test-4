/**
 * Local Filesystem StorageAdapter
 *
 * Blueprint v4.1 §20 (Interface-Driven Design — StorageAdapter), §5 (Architecture),
 * §22 Phase 0 Step 0.10, §24 (Security Model)
 *
 * Design goals:
 *  - The ONLY place in the codebase that imports `node:fs`. Every other
 *    module reads/writes files through this adapter.
 *  - Constructor takes a `rootPath` (default: `process.env.STORAGE_ROOT`
 *    ?? `'./storage'`). All paths are relative to this root.
 *  - Every method calls `validatePath(path)` BEFORE any filesystem operation.
 *    This is the security boundary that prevents LLM-generated artifacts
 *    from escaping the storage root.
 *  - Edge-runtime detection: throws `StorageError(EDGE_RUNTIME_UNSUPPORTED)`
 *    if instantiated in Edge runtime (which has no `fs`).
 *  - `save()` creates parent directories automatically.
 *  - `metadata()` prefers `birthtime` (file creation time), falls back to
 *    `mtime` (some filesystems don't support birthtime).
 *  - Content-type is inferred from extension via the inline `MIME_MAP`
 *    in adapter.ts — no external mime-detection library.
 *  - `getSignedUrl()` returns `null` — local FS has no signing. Callers
 *    that need to expose files to the browser use the direct path (or
 *    a Next.js API route that streams the file).
 *  - Production swap: replace this module with `src/lib/storage/s3.ts`
 *    implementing the same `StorageAdapter` interface. No caller code
 *    changes required.
 *
 * Strictly typed. No `any`.
 */

import { promises as fs } from 'node:fs';
import { join, relative, sep } from 'node:path';
import { isEdgeRuntime } from '@/lib/logger';
import { logger } from '@/lib/logger';
import {
  type StorageAdapter,
  type StorageItem,
  type StorageMetadata,
  StorageError,
  isStorageError,
  validatePath,
  getContentType,
} from '@/lib/storage/adapter';

// ─── Constants ─────────────────────────────────────────────────────────────

const DEFAULT_ROOT = './storage';

// ─── LocalStorageAdapter ───────────────────────────────────────────────────

export class LocalStorageAdapter implements StorageAdapter {
  private readonly rootPath: string;

  public constructor(rootPath?: string) {
    // Edge runtime check — fail fast on instantiation
    if (isEdgeRuntime()) {
      throw new StorageError(
        'EDGE_RUNTIME_UNSUPPORTED',
        'LocalStorageAdapter cannot be used in Edge runtime (no node:fs). Use an S3 adapter instead, or refactor the caller to run in Node.',
      );
    }

    this.rootPath = rootPath ?? process.env.STORAGE_ROOT ?? DEFAULT_ROOT;

    logger.debug(
      { module: 'storage', rootPath: this.rootPath, adapter: 'local' },
      'LocalStorageAdapter initialized',
    );
  }

  // ─── save ──────────────────────────────────────────────────────────────

  public async save(path: string, data: Buffer): Promise<string> {
    const safePath = validatePath(path);
    const fullPath = this.resolve(safePath);

    try {
      // Create parent directories (recursive)
      const lastSlash = fullPath.lastIndexOf(sep);
      if (lastSlash > 0) {
        const dir = fullPath.slice(0, lastSlash);
        await fs.mkdir(dir, { recursive: true });
      }
      await fs.writeFile(fullPath, data);

      logger.debug(
        { module: 'storage', op: 'save', path: safePath, size: data.length },
        `Saved ${data.length} bytes to ${safePath}`,
      );

      return fullPath;
    } catch (err) {
      throw new StorageError(
        'SAVE_FAILED',
        `Failed to save file at ${safePath}: ${err instanceof Error ? err.message : String(err)}`,
        err,
        safePath,
      );
    }
  }

  // ─── read ──────────────────────────────────────────────────────────────

  public async read(path: string): Promise<Buffer> {
    const safePath = validatePath(path);
    const fullPath = this.resolve(safePath);

    try {
      const buffer = await fs.readFile(fullPath);
      logger.debug(
        { module: 'storage', op: 'read', path: safePath, size: buffer.length },
        `Read ${buffer.length} bytes from ${safePath}`,
      );
      return buffer;
    } catch (err) {
      // Node's fs.readFile throws ENOENT for missing files
      if (err instanceof Error && 'code' in err && (err as { code: string }).code === 'ENOENT') {
        throw new StorageError(
          'NOT_FOUND',
          `File not found: ${safePath}`,
          err,
          safePath,
        );
      }
      throw new StorageError(
        'READ_FAILED',
        `Failed to read file at ${safePath}: ${err instanceof Error ? err.message : String(err)}`,
        err,
        safePath,
      );
    }
  }

  // ─── exists ────────────────────────────────────────────────────────────

  public async exists(path: string): Promise<boolean> {
    const safePath = validatePath(path);
    const fullPath = this.resolve(safePath);

    try {
      await fs.access(fullPath);
      return true;
    } catch {
      return false;
    }
  }

  // ─── delete ────────────────────────────────────────────────────────────

  public async delete(path: string): Promise<void> {
    const safePath = validatePath(path);
    const fullPath = this.resolve(safePath);

    try {
      await fs.unlink(fullPath);
      logger.debug(
        { module: 'storage', op: 'delete', path: safePath },
        `Deleted ${safePath}`,
      );
    } catch (err) {
      if (err instanceof Error && 'code' in err && (err as { code: string }).code === 'ENOENT') {
        throw new StorageError(
          'NOT_FOUND',
          `Cannot delete — file not found: ${safePath}`,
          err,
          safePath,
        );
      }
      throw new StorageError(
        'DELETE_FAILED',
        `Failed to delete file at ${safePath}: ${err instanceof Error ? err.message : String(err)}`,
        err,
        safePath,
      );
    }
  }

  // ─── list ──────────────────────────────────────────────────────────────

  public async list(prefix?: string): Promise<StorageItem[]> {
    // Validate prefix if provided
    let safePrefix: string | undefined;
    if (prefix !== undefined && prefix !== '') {
      safePrefix = validatePath(prefix);
    }

    const fullRoot = this.rootPath;
    const items: StorageItem[] = [];

    try {
      // Ensure root exists; if not, return empty list (no items yet)
      try {
        await fs.access(fullRoot);
      } catch {
        return [];
      }

      // Walk the directory tree recursively
      await this.walk(fullRoot, '', safePrefix, items);

      logger.debug(
        { module: 'storage', op: 'list', prefix: safePrefix ?? '(root)', count: items.length },
        `Listed ${items.length} items`,
      );

      return items;
    } catch (err) {
      if (isStorageError(err)) throw err;
      throw new StorageError(
        'READ_FAILED',
        `Failed to list storage${safePrefix ? ` (prefix: ${safePrefix})` : ''}: ${err instanceof Error ? err.message : String(err)}`,
        err,
      );
    }
  }

  // ─── getSignedUrl ──────────────────────────────────────────────────────

  public async getSignedUrl(_path: string, _expiresIn: number): Promise<string | null> {
    // Local FS has no concept of signing. Callers that need to expose files
    // to the browser should serve them through a Next.js API route that
    // streams the file (and applies auth). Returns null so callers know to
    // fall back to the direct path.
    return null;
  }

  // ─── metadata ──────────────────────────────────────────────────────────

  public async metadata(path: string): Promise<StorageMetadata> {
    const safePath = validatePath(path);
    const fullPath = this.resolve(safePath);

    try {
      const stats = await fs.stat(fullPath);

      if (!stats.isFile()) {
        throw new StorageError(
          'NOT_FOUND',
          `Path is not a file: ${safePath}`,
          undefined,
          safePath,
        );
      }

      // Prefer birthtime (creation time); fall back to mtime
      // Some filesystems (ext4 without birthtime support) return 0 for birthtime.
      const birthtime =
        stats.birthtime && stats.birthtime.getTime() > 0
          ? stats.birthtime
          : stats.mtime;

      const filename = safePath.slice(safePath.lastIndexOf('/') + 1);

      return {
        path: safePath,
        size: stats.size,
        createdAt: birthtime,
        contentType: getContentType(filename),
      };
    } catch (err) {
      if (isStorageError(err)) throw err;
      if (err instanceof Error && 'code' in err && (err as { code: string }).code === 'ENOENT') {
        throw new StorageError(
          'NOT_FOUND',
          `File not found: ${safePath}`,
          err,
          safePath,
        );
      }
      throw new StorageError(
        'READ_FAILED',
        `Failed to get metadata for ${safePath}: ${err instanceof Error ? err.message : String(err)}`,
        err,
        safePath,
      );
    }
  }

  // ─── Private helpers ───────────────────────────────────────────────────

  /**
   * Resolve a safe relative path against the root. Returns an absolute
   * filesystem path. The result is guaranteed to be inside `this.rootPath`
   * because `validatePath` already rejected `..`, absolute paths, and null
   * bytes — but we double-check the resolved path is inside the root as
   * defense in depth (catches symlink traversal that `validatePath` cannot
   * detect at the string level).
   */
  private resolve(safePath: string): string {
    const fullPath = join(this.rootPath, safePath);

    // Defense in depth: verify the resolved path is still inside the root.
    // This catches symlink-traversal attacks that `validatePath` cannot
    // detect at the string level.
    const rel = relative(this.rootPath, fullPath);
    if (rel.startsWith('..') || rel === '') {
      // `rel === ''` means fullPath === rootPath, which is also invalid
      // (we never want to read/write the root directory itself as a file)
      throw new StorageError(
        'PATH_TRAVERSAL_DETECTED',
        `Resolved path escapes storage root: ${safePath}`,
        undefined,
        safePath,
      );
    }

    return fullPath;
  }

  /**
   * Recursively walk the directory tree under `fullDir`, collecting files
   * that match `prefix` (if provided) into `items`.
   */
  private async walk(
    fullDir: string,
    relativeDir: string,
    prefix: string | undefined,
    items: StorageItem[],
  ): Promise<void> {
    let entries: import('node:fs').Dirent[];
    try {
      entries = await fs.readdir(fullDir, { withFileTypes: true });
    } catch (err) {
      // If we can't read a subdirectory, log and skip — don't fail the whole list
      logger.warn(
        { module: 'storage', op: 'walk', dir: relativeDir, err },
        `Failed to read directory ${relativeDir}`,
      );
      return;
    }

    for (const entry of entries) {
      const relativePath = relativeDir === '' ? entry.name : `${relativeDir}/${entry.name}`;

      // If a prefix is set, skip entries that don't match
      if (prefix !== undefined && !relativePath.startsWith(prefix)) {
        continue;
      }

      const fullPath = join(fullDir, entry.name);

      if (entry.isDirectory()) {
        // Recurse
        await this.walk(fullPath, relativePath, prefix, items);
      } else if (entry.isFile()) {
        try {
          const stats = await fs.stat(fullPath);
          const birthtime =
            stats.birthtime && stats.birthtime.getTime() > 0
              ? stats.birthtime
              : stats.mtime;
          items.push({
            path: relativePath,
            size: stats.size,
            createdAt: birthtime,
            contentType: getContentType(entry.name),
          });
        } catch (err) {
          // Stat failed — skip this file but continue
          logger.warn(
            { module: 'storage', op: 'walk', file: relativePath, err },
            `Failed to stat ${relativePath}`,
          );
        }
      }
      // Symlinks and other types are skipped — defense in depth
    }
  }
}

// Re-export for convenience so callers can import everything from one module
export { StorageError, isStorageError } from '@/lib/storage/adapter';
export type {
  StorageAdapter,
  StorageItem,
  StorageMetadata,
} from '@/lib/storage/adapter';
