/**
 * MCP (Model Context Protocol) Integration — Client + Presets
 *
 * Blueprint v4.1 §13 (MCP Integration), §22 Phase 1 Step 1.9
 *
 * Two verified-working presets (Blueprint §13):
 *   1. Filesystem — @modelcontextprotocol/server-filesystem (14 tools)
 *   2. Memory — @modelcontextprotocol/server-memory (knowledge graph)
 *
 * How MCP works (Blueprint §13):
 *   1. User adds MCP server (preset or custom npx command)
 *   2. User clicks "Test" → system spawns server, sends JSON-RPC, discovers tools
 *   3. User enables server
 *   4. Agent runner loads ALL enabled MCP tools via getEnabledMcpTools()
 *   5. MCP tools appear in system prompt alongside builtin tools
 *   6. Agent calls MCP tool → executes via subprocess → result returned
 *
 * NOTE on child_process (Blueprint §19):
 *   MCP servers are spawned via child_process.spawn. This is ALLOWED because:
 *   - The spawned process is a known MCP server (not LLM-generated code)
 *   - The server command is configured by the user, not by the LLM
 *   - This is NOT "code execution of LLM-generated content" (which is forbidden)
 *   - The forbidden case (§19) is running LLM-generated code via child_process
 *
 * This module provides:
 *   - McpClient: spawns an MCP server, discovers tools, calls tools
 *   - presets: the two verified presets
 *   - McpError + isMcpError guard
 *   - getEnabledMcpTools: loads all enabled MCP servers + their cached tools
 */

import { spawn, type ChildProcess } from 'node:child_process';
import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

// ─── Types ─────────────────────────────────────────────────────────────────

export type McpTransport = 'stdio' | 'sse';

export interface McpServerRecord {
  readonly id: string;
  readonly workspaceId: string | null;
  readonly name: string;
  readonly transport: McpTransport;
  readonly command: string | null;
  readonly args: string[];
  readonly url: string | null;
  readonly env: Record<string, string>;
  readonly enabled: boolean;
  readonly toolsCache: McpTool[];
}

export interface McpTool {
  readonly name: string;
  readonly description: string;
  readonly inputSchema: Record<string, unknown>;
}

export interface McpToolResult {
  readonly content: string;
  readonly isError: boolean;
}

export type McpErrorCode =
  | 'MCP_SERVER_NOT_FOUND'
  | 'MCP_SPAWN_FAILED'
  | 'MCP_DISCOVER_FAILED'
  | 'MCP_CALL_FAILED'
  | 'MCP_TIMEOUT'
  | 'MCP_NOT_CONFIGURED';

const MCP_ERROR_BRAND = Symbol('McpError');

export class McpError extends Error {
  public readonly [MCP_ERROR_BRAND]: true = true;
  public readonly code: McpErrorCode;
  public readonly cause: unknown;
  public readonly mcpServerId?: string;

  public constructor(code: McpErrorCode, message: string, cause?: unknown, mcpServerId?: string) {
    super(message);
    this.name = 'McpError';
    this.code = code;
    this.cause = cause;
    this.mcpServerId = mcpServerId;
    Object.setPrototypeOf(this, McpError.prototype);
  }
}

export function isMcpError(error: unknown): error is McpError {
  return (
    typeof error === 'object' &&
    error !== null &&
    (error as Record<symbol, unknown>)[MCP_ERROR_BRAND] === true
  );
}

// ─── Presets (Blueprint §13) ───────────────────────────────────────────────

export interface McpPreset {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly transport: McpTransport;
  readonly command: string;
  readonly args: string[];
  readonly docsUrl: string;
}

export const MCP_PRESETS: ReadonlyArray<McpPreset> = [
  {
    id: 'mcp.filesystem',
    name: 'Filesystem',
    description: 'Read/write files on the local filesystem. 14 tools including read_file, write_file, list_directory.',
    transport: 'stdio',
    command: 'npx',
    args: ['-y', '@modelcontextprotocol/server-filesystem', '/home/z/my-project/storage'],
    docsUrl: 'https://github.com/modelcontextprotocol/servers/tree/main/src/filesystem',
  },
  {
    id: 'mcp.memory',
    name: 'Memory',
    description: 'Knowledge graph for persistent memory across sessions. Create entities, relations, observations.',
    transport: 'stdio',
    command: 'npx',
    args: ['-y', '@modelcontextprotocol/server-memory'],
    docsUrl: 'https://github.com/modelcontextprotocol/servers/tree/main/src/memory',
  },
];

// ─── McpClient ─────────────────────────────────────────────────────────────
//
// Spawns an MCP server, communicates via JSON-RPC over stdio, discovers
// tools, and calls tools. The client is designed to be short-lived: spawn
// → discover → call → kill. Long-lived connections would be more efficient
// but add complexity (process management, crash recovery).

export class McpClient {
  private process: ChildProcess | null = null;
  private readonly command: string;
  private readonly args: string[];
  private readonly env: Record<string, string>;
  private buffer: string = '';
  private readonly pendingRequests = new Map<number, {
    resolve: (value: unknown) => void;
    reject: (err: Error) => void;
  }>();
  private nextRequestId = 1;
  private readonly timeoutMs: number;

  public constructor(params: {
    command: string;
    args: string[];
    env?: Record<string, string>;
    timeoutMs?: number;
  }) {
    this.command = params.command;
    this.args = params.args;
    this.env = params.env ?? {};
    this.timeoutMs = params.timeoutMs ?? 30_000;
  }

  // ─── Spawn the MCP server process ─────────────────────────────────────
  public async connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        this.process = spawn(this.command, this.args, {
          stdio: ['pipe', 'pipe', 'pipe'],
          env: { ...process.env, ...this.env },
        });
      } catch (err) {
        reject(new McpError(
          'MCP_SPAWN_FAILED',
          `Failed to spawn MCP server: ${err instanceof Error ? err.message : String(err)}`,
          err,
        ));
        return;
      }

      if (!this.process.stdout || !this.process.stdin) {
        reject(new McpError('MCP_SPAWN_FAILED', 'MCP server spawned without stdio pipes.'));
        return;
      }

      this.process.stdout.on('data', (data: Buffer) => {
        this.buffer += data.toString('utf8');
        this.processBuffer();
      });

      this.process.on('error', (err) => {
        reject(new McpError('MCP_SPAWN_FAILED', `MCP server error: ${err.message}`, err));
      });

      this.process.on('exit', (code) => {
        if (code !== 0 && code !== null) {
          logger.warn({ module: 'mcp', code }, `MCP server exited with code ${code}`);
        }
      });

      // Send initialize request
      this.sendRequest('initialize', {
        protocolVersion: '2024-11-05',
        capabilities: {},
        clientInfo: { name: 'zchat-workspace', version: '4.1.0' },
      })
        .then(() => {
          // Send initialized notification
          this.sendNotification('notifications/initialized', {});
          resolve();
        })
        .catch(reject);
    });
  }

  // ─── Discover tools ───────────────────────────────────────────────────
  public async discoverTools(): Promise<McpTool[]> {
    const result = await this.sendRequest('tools/list', {}) as {
      tools?: Array<{ name: string; description?: string; inputSchema?: Record<string, unknown> }>;
    };

    const tools: McpTool[] = (result.tools ?? []).map((t) => ({
      name: t.name,
      description: t.description ?? '',
      inputSchema: t.inputSchema ?? { type: 'object', properties: {} },
    }));

    logger.info({ module: 'mcp', command: this.command, toolCount: tools.length }, `Discovered ${tools.length} MCP tools`);
    return tools;
  }

  // ─── Call a tool ──────────────────────────────────────────────────────
  public async callTool(name: string, args: Record<string, unknown>): Promise<McpToolResult> {
    try {
      const result = await this.sendRequest('tools/call', { name, arguments: args }) as {
        content?: Array<{ type: string; text?: string }>;
        isError?: boolean;
      };

      const textParts = (result.content ?? [])
        .filter((c) => c.type === 'text' && c.text)
        .map((c) => c.text!);
      const content = textParts.join('\n');

      return {
        content,
        isError: result.isError ?? false,
      };
    } catch (err) {
      throw new McpError(
        'MCP_CALL_FAILED',
        `Failed to call MCP tool ${name}: ${err instanceof Error ? err.message : String(err)}`,
        err,
      );
    }
  }

  // ─── Disconnect ───────────────────────────────────────────────────────
  public disconnect(): void {
    if (this.process) {
      try {
        this.process.stdin?.end();
        this.process.kill('SIGTERM');
      } catch {
        // ignore
      }
      this.process = null;
    }
    for (const [, promise] of this.pendingRequests) {
      promise.reject(new Error('MCP client disconnected'));
    }
    this.pendingRequests.clear();
  }

  // ─── JSON-RPC plumbing ────────────────────────────────────────────────
  private sendRequest(method: string, params: unknown): Promise<unknown> {
    return new Promise((resolve, reject) => {
      if (!this.process || !this.process.stdin) {
        reject(new McpError('MCP_SPAWN_FAILED', 'MCP server not connected.'));
        return;
      }

      const id = this.nextRequestId++;
      const request = { jsonrpc: '2.0', id, method, params };

      const timeout = setTimeout(() => {
        const pending = this.pendingRequests.get(id);
        if (pending) {
          this.pendingRequests.delete(id);
          pending.reject(new McpError('MCP_TIMEOUT', `MCP request ${method} timed out after ${this.timeoutMs}ms.`));
        }
      }, this.timeoutMs);

      this.pendingRequests.set(id, {
        resolve: (value) => {
          clearTimeout(timeout);
          resolve(value);
        },
        reject: (err) => {
          clearTimeout(timeout);
          reject(err);
        },
      });

      const json = JSON.stringify(request) + '\n';
      this.process.stdin.write(json);
    });
  }

  private sendNotification(method: string, params: unknown): void {
    if (!this.process || !this.process.stdin) return;
    const notification = { jsonrpc: '2.0', method, params };
    this.process.stdin.write(JSON.stringify(notification) + '\n');
  }

  private processBuffer(): void {
    let newlineIdx: number;
    while ((newlineIdx = this.buffer.indexOf('\n')) !== -1) {
      const line = this.buffer.slice(0, newlineIdx);
      this.buffer = this.buffer.slice(newlineIdx + 1);

      if (line.trim().length === 0) continue;

      try {
        const message = JSON.parse(line) as { jsonrpc: string; id?: number; result?: unknown; error?: { message: string } };
        if (message.id !== undefined) {
          const pending = this.pendingRequests.get(message.id);
          if (pending) {
            this.pendingRequests.delete(message.id);
            if (message.error) {
              pending.reject(new Error(message.error.message));
            } else {
              pending.resolve(message.result);
            }
          }
        }
      } catch (err) {
        logger.warn({ module: 'mcp', line, err }, `Failed to parse MCP message: ${err instanceof Error ? err.message : String(err)}`);
      }
    }
  }
}

// ─── DB-backed MCP server management ───────────────────────────────────────

function toRecord(row: {
  id: string; workspaceId: string | null; name: string; transport: string;
  command: string | null; args: string; url: string | null; env: string;
  enabled: boolean; toolsCache: string;
}): McpServerRecord {
  let args: string[] = [];
  let env: Record<string, string> = {};
  let toolsCache: McpTool[] = [];
  try { args = JSON.parse(row.args) as string[]; } catch { args = []; }
  try { env = JSON.parse(row.env) as Record<string, string>; } catch { env = {}; }
  try {
    const parsed = JSON.parse(row.toolsCache) as unknown;
    if (Array.isArray(parsed)) toolsCache = parsed as McpTool[];
  } catch { toolsCache = []; }
  return {
    id: row.id,
    workspaceId: row.workspaceId,
    name: row.name,
    transport: row.transport as McpTransport,
    command: row.command,
    args,
    url: row.url,
    env,
    enabled: row.enabled,
    toolsCache,
  };
}

export async function getMcpServer(serverId: string): Promise<McpServerRecord> {
  const row = await db.mcpServer.findUnique({ where: { id: serverId } });
  if (!row) {
    throw new McpError('MCP_SERVER_NOT_FOUND', `MCP server ${serverId} not found.`, undefined, serverId);
  }
  return toRecord(row);
}

export async function getEnabledMcpServers(workspaceId: string): Promise<McpServerRecord[]> {
  const rows = await db.mcpServer.findMany({
    where: {
      OR: [
        { workspaceId, enabled: true },
        { workspaceId: null, enabled: true },
      ],
    },
  });
  return rows.map(toRecord);
}

export async function getEnabledMcpTools(workspaceId: string): Promise<McpTool[]> {
  const servers = await getEnabledMcpServers(workspaceId);
  const allTools: McpTool[] = [];
  for (const server of servers) {
    allTools.push(...server.toolsCache);
  }
  return allTools;
}

// ─── Test an MCP server (discover tools) ───────────────────────────────────

export async function testMcpServer(serverId: string): Promise<McpTool[]> {
  const server = await getMcpServer(serverId);

  if (server.transport !== 'stdio' || !server.command) {
    throw new McpError('MCP_NOT_CONFIGURED', `MCP server ${server.name} is not a stdio server.`, undefined, serverId);
  }

  const client = new McpClient({
    command: server.command,
    args: server.args,
    env: server.env,
    timeoutMs: 15_000,
  });

  try {
    await client.connect();
    const tools = await client.discoverTools();

    // Cache the discovered tools in the DB
    await db.mcpServer.update({
      where: { id: serverId },
      data: { toolsCache: JSON.stringify(tools) },
    });

    return tools;
  } finally {
    client.disconnect();
  }
}
