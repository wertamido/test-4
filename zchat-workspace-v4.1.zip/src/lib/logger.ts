/**
 * pino Logger — Singleton, Redacting, Runtime-Aware
 *
 * Blueprint v4.1 §20 (Technology Stack — pino), §5 (System Architecture — pino logging),
 * §22 Phase 0 Step 0.6, §24 (Security Model — never log API keys)
 *
 * Design goals:
 *  - Single pino instance per process via globalThis (hot-reload safe, same
 *    pattern as src/lib/db.ts)
 *  - Pretty-printing in dev (colorized, human-readable via pino-pretty sync transport)
 *  - JSON-line output in production (parseable by log aggregators: Datadog,
 *    Logflare, CloudWatch, etc.)
 *  - Strict typed wrappers around every log level — no `any`
 *  - Child logger factory: `logger.child({ module, requestId, userId, workspaceId })`
 *  - Redaction of sensitive fields: password, passwordHash, apiKey, secret,
 *    token, authorization, cookie — top-level AND nested paths
 *  - `withRequestContext(req)` extracts a generated requestId (crypto.randomUUID),
 *    url, and redacts auth headers into a child logger
 *  - `logReactError(error, info, resetKey)` — drop-in replacement for the
 *    JSON-line console.error in src/components/layout/ErrorBoundary.tsx
 *    (Integration point: ErrorBoundary.componentDidCatch should call this
 *    instead of console.error once Task 0.7+ ships)
 *  - Runtime-aware: detects Node.js vs Edge runtime and picks an appropriate
 *    destination. Edge runtime lacks `pino-pretty`'s worker-thread transport;
 *    fall back to a plain JSON destination there.
 *
 * The exported `logger` is the only entrypoint other modules should use.
 * Direct `import pino from 'pino'` is forbidden elsewhere.
 */

import pino, { type Logger, type LoggerOptions } from 'pino';
import type { ErrorInfo } from 'react';

// ─── Types ─────────────────────────────────────────────────────────────────

/**
 * Bindings accepted by `logger.child()` and embedded in every log line.
 * Optional fields; callers pass only what they have.
 */
export interface LogContext {
  /** Logical module name: 'auth', 'db', 'queue', 'orchestrator', etc. */
  module?: string;
  /** Per-request UUID for correlating logs across modules. */
  requestId?: string;
  /** Authenticated user ID (cuid). */
  userId?: string;
  /** Workspace ID (cuid) — Blueprint §24: every query scoped to workspaceId. */
  workspaceId?: string;
  /** Session ID (cuid) — for orchestration traceability. */
  sessionId?: string;
  /** Job ID (cuid) — for queue worker logs. */
  jobId?: string;
  /** Agent run ID (cuid) — for orchestration sub-agent logs. */
  agentRunId?: string;
  /** Free-form string label (e.g., 'orchestration', 'reasoning'). */
  tag?: string;
}

/**
 * Strict logger interface — exposes only the methods we want callers to use.
 * Prevents accidental `logger.silent()` calls and keeps the surface small.
 */
export interface AppLogger {
  trace: (objOrMsg: object | string, msg?: string) => void;
  debug: (objOrMsg: object | string, msg?: string) => void;
  info: (objOrMsg: object | string, msg?: string) => void;
  warn: (objOrMsg: object | string, msg?: string) => void;
  error: (objOrMsg: object | string, msg?: string) => void;
  fatal: (objOrMsg: object | string, msg?: string) => void;
  child: (bindings: LogContext) => AppLogger;
  level: string;
}

// ─── Redaction paths ───────────────────────────────────────────────────────
//
// pino's redact option matches dotted paths. `*` is a wildcard for any key
// at that depth. Paths cover both top-level fields and nested objects:
//   - 'password'         — top-level
//   - 'apiKey'           — top-level
//   - 'passwordHash'     — top-level
//   - 'secret'           — top-level
//   - 'token'            — top-level
//   - 'authorization'    — top-level
//   - 'cookie'           — top-level
//   - 'headers.authorization'   — common HTTP header shape
//   - 'headers.cookie'          — common HTTP header shape
//   - 'cookies.*'               — Express/Next parsed cookies object
//   - '*.password'              — any nested object's password field
//   - '*.apiKey'                — any nested object's apiKey field
//   - '*.passwordHash'
//   - '*.secret'
//   - '*.token'
//
// `[Redacted]` is pino's default placeholder; we set it explicitly for clarity.

const REDACT_PATHS: ReadonlyArray<string> = [
  'password',
  'passwordHash',
  'apiKey',
  'secret',
  'token',
  'authorization',
  'cookie',
  'headers.authorization',
  'headers.cookie',
  'cookies.*',
  '*.password',
  '*.passwordHash',
  '*.apiKey',
  '*.secret',
  '*.token',
  '*.authorization',
  '*.cookie',
];

const REDACT_CENSOR = '[Redacted]';

// ─── Runtime detection ─────────────────────────────────────────────────────
//
// Edge runtime (Cloudflare Workers, Vercel Edge) does NOT support:
//   - pino-pretty's worker-thread transport
//   - Node's `stream.PassThrough` in some builds
//   - Some Node built-ins (fs, net) — though crypto.randomUUID is fine
//
// Detection: `process.versions.node` is undefined in Edge runtimes. The
// optional chaining is intentional — `process` itself may be polyfilled
// differently in Edge bundles.

export function isEdgeRuntime(): boolean {
  // Next.js sets `process.env.NEXT_RUNTIME` to 'edge' for edge runtime, and
  // 'nodejs' for Node.js. We also fall back to checking for Node versions.
  if (typeof process !== 'undefined' && process.env?.NEXT_RUNTIME === 'edge') {
    return true;
  }
  if (typeof process !== 'undefined' && typeof process.versions?.node === 'string') {
    return false;
  }
  // No process at all (browser) — treat as edge for safety
  return true;
}

// ─── Logger construction ───────────────────────────────────────────────────

function buildBaseConfig(): LoggerOptions {
  const isProd = process.env.NODE_ENV === 'production';

  const config: LoggerOptions = {
    level: process.env.LOG_LEVEL ?? (isProd ? 'info' : 'debug'),
    redact: {
      paths: [...REDACT_PATHS],
      censor: REDACT_CENSOR,
      remove: false,
    },
    base: {
      service: 'zchat-workspace',
      version: '4.1.0',
    },
    // Always include `time` as epoch ms (pino default) so log aggregators can
    // sort without parsing the message.
    timestamp: pino.stdTimeFunctions.epochTime,
    // Custom error serializer: pino's default already extracts name, message,
    // stack. We extend it to ensure `cause` is preserved (ES2022 Error.cause).
    serializers: {
      err: (value: unknown) => {
        if (value instanceof Error) {
          const base: Record<string, unknown> = {
            type: value.name,
            message: value.message,
            stack: value.stack,
          };
          if (value.cause !== undefined) {
            base.cause =
              value.cause instanceof Error
                ? {
                    type: value.cause.name,
                    message: value.cause.message,
                    stack: value.cause.stack,
                  }
                : value.cause;
          }
          return base;
        }
        return { type: 'unknown', message: String(value) };
      },
    },
  };

  return config;
}

function buildLogger(): Logger {
  const isProd = process.env.NODE_ENV === 'production';
  const isEdge = isEdgeRuntime();

  const config = buildBaseConfig();

  // Edge runtime: skip pino-pretty entirely. Output raw JSON lines to stdout.
  if (isEdge) {
    return pino(config);
  }

  // Node dev: pretty-print to stdout via pino-pretty sync mode (no worker thread).
  // Sync mode keeps logs ordered deterministically — important for tests.
  if (!isProd) {
    return pino({
      ...config,
      transport: {
        target: 'pino-pretty',
        options: {
          colorize: true,
          translateTime: 'SYS:HH:MM:ss.l',
          ignore: 'pid,hostname,service,version',
          singleLine: false,
          messageFormat: '{msg}',
        },
      },
    });
  }

  // Node prod: raw JSON to stdout, one line per log.
  return pino(config);
}

// ─── Singleton via globalThis ──────────────────────────────────────────────
//
// Same pattern as src/lib/db.ts — globalThis stash ensures Next.js dev
// hot-reload reuses the same logger instance. A new logger per reload would
// create new transport worker threads and leak file descriptors.

const globalForLogger = globalThis as unknown as {
  __zchatLogger?: Logger;
};

export const logger: Logger = globalForLogger.__zchatLogger ?? buildLogger();

if (process.env.NODE_ENV !== 'production') {
  globalForLogger.__zchatLogger = logger;
}

// ─── Typed wrappers ────────────────────────────────────────────────────────
//
// pino's Logger interface already has typed level methods, but the call
// signatures allow `any` in some overloads. We expose the same Logger
// directly — pino's own types are strict enough for our needs. The
// `AppLogger` interface above documents the canonical usage shape for
// documentation purposes; callers can import either.

export type { Logger } from 'pino';

// ─── withRequestContext ────────────────────────────────────────────────────
//
// Returns a child logger scoped to a single HTTP request. Generates a
// requestId if the client didn't pass one (X-Request-Id header). Extracts
// the URL but NOT the auth header — auth headers are redacted by pino's
// redact config when logged as part of an object, but we intentionally do
// not include them in the child bindings to avoid accidental leakage.

export interface RequestContextBindings extends LogContext {
  requestId: string;
  url: string;
  method: string;
}

export function withRequestContext(req: Request): Logger & {
  child: (bindings: LogContext) => Logger;
} {
  const requestId =
    req.headers.get('x-request-id') ?? crypto.randomUUID();
  const method = req.method;
  const url = req.url;

  return logger.child({ requestId, method, url });
}

// ─── logReactError — drop-in replacement for ErrorBoundary's console.error ─
//
// INTEGRATION POINT:
//   src/components/layout/ErrorBoundary.tsx currently logs a JSON-structured
//   line via console.error in its logErrorToConsole() helper. Once this
//   logger ships, replace that helper's body with:
//
//     import { logReactError } from '@/lib/logger';
//     logReactError(error, info, this.props.resetKey);
//
//   The pino log shape mirrors the JSON line ErrorBoundary currently emits:
//   { level, time, msg, err: { type, message, stack, componentStack },
//     boundary: { resetKey } }
//
// This function is NOT called yet — ErrorBoundary.tsx is unchanged per the
// task constraint. The integration is a one-line swap in a later task.

export function logReactError(
  error: Error,
  info: ErrorInfo,
  resetKey?: string | number,
): void {
  logger.error(
    {
      err: error,
      componentStack: info.componentStack ?? undefined,
      boundary: { resetKey },
    },
    `ErrorBoundary caught: ${error.message}`,
  );
}

// ─── Convenience: module-tagged child ──────────────────────────────────────

/**
 * Create a module-scoped child logger. Equivalent to `logger.child({ module })`
 * but signals intent at the call site and reduces the chance of typos in
 * the `module` field name.
 *
 * Usage:
 *   import { moduleLogger } from '@/lib/logger';
 *   const log = moduleLogger('auth');
 *   log.info({ userId }, 'user signed in');
 */
export function moduleLogger(module: string): Logger {
  return logger.child({ module });
}

// ─── Re-exports ────────────────────────────────────────────────────────────

export default logger;
