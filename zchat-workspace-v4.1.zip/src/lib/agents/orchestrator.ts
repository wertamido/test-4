/**
 * Agent Orchestration Engine — Lead → Plan → Spawn → Merge
 *
 * Blueprint v4.1 §10 (Agent Orchestration Engine), §22 Phase 2 Steps 2.1, 2.5, 2.6, 2.10
 *
 * The engine:
 *   1. Receives a GOAL from the user
 *   2. Creates a lead AgentRun (depth 0)
 *   3. Lead agent plans — decomposes the goal into tasks (JSON output)
 *   4. For each task: spawn a sub-agent (depth 1), assign the task
 *   5. Sub-agents execute (may spawn sub-sub-agents up to depth 3)
 *   6. Sub-agents write results to the task board + shared memory
 *   7. Lead agent collects results, merges into final deliverable
 *   8. Verifies the deliverable against the original goal
 *
 * Limits (Blueprint §10):
 *   - Max depth: 3 (lead=0 → sub=1 → sub-sub=2 → sub-sub-sub=3)
 *   - Max agents per session: 20
 *   - Max sub-agents per orchestrator: defined on the AgentTemplate
 *   - Token cap: 500K per orchestration (configurable)
 *
 * The engine uses:
 *   - db singleton for AgentRun persistence
 *   - runAgent from agents/runner for LLM calls
 *   - task board + shared memory + messaging from agents/shared-layer
 *   - broadcastToSession from the WebSocket server for live progress
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { runAgent } from '@/lib/agents/runner';
import {
  createTask, claimTask, completeTask, failTask, getTasksBySession, getTask,
  writeMemory, readAllMemory,
  sendAgentMessage,
  type TaskRecord,
} from '@/lib/agents/shared-layer';
import { getSession } from '@/lib/sessions/repository';
import { type ChatMessage } from '@/lib/providers/types';

// ─── Types ─────────────────────────────────────────────────────────────────

export type AgentRunStatus =
  | 'pending' | 'planning' | 'executing' | 'waiting_subagents'
  | 'merging' | 'done' | 'error';

export interface AgentRunRecord {
  readonly id: string;
  readonly sessionId: string;
  readonly parentRunId: string | null;
  readonly agentTemplateId: string | null;
  readonly providerId: string | null;
  readonly model: string;
  readonly task: string;
  readonly taskContext: Record<string, unknown>;
  readonly status: AgentRunStatus;
  readonly depth: number;
  readonly result: string | null;
  readonly artifacts: string[];
  readonly toolCalls: string[];
  readonly tokensUsed: number;
  readonly costUsd: number;
  readonly durationMs: number | null;
  readonly messagesToParent: unknown[];
  readonly messagesFromParent: unknown[];
  readonly startedAt: Date;
  readonly finishedAt: Date | null;
}

export interface OrchestrationParams {
  readonly sessionId: string;
  readonly workspaceId: string;
  readonly goal: string;
  readonly leadAgentId: string;
  readonly providerId: string;
  readonly model: string;
  readonly maxDepth?: number;
  readonly maxAgents?: number;
  readonly mode?: 'auto' | 'manual';
  readonly signal?: AbortSignal;
}

export interface OrchestrationResult {
  readonly orchestrationId: string;
  readonly leadRunId: string;
  readonly status: AgentRunStatus;
  readonly finalResult: string | null;
  readonly tasksCreated: number;
  readonly tasksCompleted: number;
  readonly tasksFailed: number;
  readonly subAgentRuns: AgentRunRecord[];
  readonly totalTokens: number;
  readonly totalCostUsd: number;
  readonly durationMs: number;
}

export interface PlanTask {
  readonly title: string;
  readonly agentType: string;
  readonly provider: string;
  readonly model: string;
  readonly dependencies: string[];
  readonly priority: number;
  readonly taskDescription: string;
}

export interface Plan {
  readonly tasks: PlanTask[];
}

// ─── Constants (Blueprint §10) ─────────────────────────────────────────────

export const DEFAULT_MAX_DEPTH = 3;
export const DEFAULT_MAX_AGENTS = 20;
export const DEFAULT_TOKEN_CAP = 500_000;

// ─── AgentRun persistence ──────────────────────────────────────────────────

function parseAgentRunRow(row: {
  id: string; sessionId: string; parentRunId: string | null;
  agentTemplateId: string | null; providerId: string | null; model: string;
  task: string; taskContext: string; status: string; depth: number;
  result: string | null; artifacts: string; toolCalls: string;
  tokensUsed: number; costUsd: number; durationMs: number | null;
  messagesToParent: string; messagesFromParent: string;
  startedAt: Date; finishedAt: Date | null;
}): AgentRunRecord {
  let taskContext: Record<string, unknown> = {};
  let artifacts: string[] = [];
  let toolCalls: string[] = [];
  let messagesToParent: unknown[] = [];
  let messagesFromParent: unknown[] = [];
  try { taskContext = JSON.parse(row.taskContext); } catch { taskContext = {}; }
  try { artifacts = JSON.parse(row.artifacts); } catch { artifacts = []; }
  try { toolCalls = JSON.parse(row.toolCalls); } catch { toolCalls = []; }
  try { messagesToParent = JSON.parse(row.messagesToParent); } catch { messagesToParent = []; }
  try { messagesFromParent = JSON.parse(row.messagesFromParent); } catch { messagesFromParent = []; }
  return {
    id: row.id, sessionId: row.sessionId, parentRunId: row.parentRunId,
    agentTemplateId: row.agentTemplateId, providerId: row.providerId, model: row.model,
    task: row.task, taskContext, status: row.status as AgentRunStatus, depth: row.depth,
    result: row.result, artifacts, toolCalls, tokensUsed: row.tokensUsed, costUsd: row.costUsd,
    durationMs: row.durationMs, messagesToParent, messagesFromParent,
    startedAt: row.startedAt, finishedAt: row.finishedAt,
  };
}

export async function createAgentRun(params: {
  sessionId: string;
  workspaceId: string;
  parentRunId?: string;
  agentTemplateId?: string;
  providerId?: string;
  model: string;
  task: string;
  taskContext?: Record<string, unknown>;
  depth: number;
}): Promise<AgentRunRecord> {
  await getSession(params.sessionId, params.workspaceId);
  const row = await db.agentRun.create({
    data: {
      sessionId: params.sessionId,
      parentRunId: params.parentRunId ?? null,
      agentTemplateId: params.agentTemplateId ?? null,
      providerId: params.providerId ?? null,
      model: params.model,
      task: params.task,
      taskContext: JSON.stringify(params.taskContext ?? {}),
      status: 'pending',
      depth: params.depth,
      artifacts: '[]',
      toolCalls: '[]',
      tokensUsed: 0,
      costUsd: 0,
      messagesToParent: '[]',
      messagesFromParent: '[]',
    },
  });
  return parseAgentRunRow(row);
}

export async function updateAgentRunStatus(
  runId: string,
  status: AgentRunStatus,
  updates?: { result?: string; tokensUsed?: number; costUsd?: number; durationMs?: number },
): Promise<void> {
  const data: Record<string, unknown> = { status };
  if (updates?.result !== undefined) data['result'] = updates.result;
  if (updates?.tokensUsed !== undefined) data['tokensUsed'] = updates.tokensUsed;
  if (updates?.costUsd !== undefined) data['costUsd'] = updates.costUsd;
  if (updates?.durationMs !== undefined) data['durationMs'] = updates.durationMs;
  if (status === 'done' || status === 'error') {
    data['finishedAt'] = new Date();
  }
  await db.agentRun.update({ where: { id: runId }, data });
}

export async function getAgentRun(runId: string): Promise<AgentRunRecord> {
  const row = await db.agentRun.findUnique({ where: { id: runId } });
  if (!row) throw new Error(`AgentRun ${runId} not found`);
  return parseAgentRunRow(row);
}

export async function getAgentRunsBySession(sessionId: string, workspaceId: string): Promise<AgentRunRecord[]> {
  await getSession(sessionId, workspaceId);
  const rows = await db.agentRun.findMany({ where: { sessionId }, orderBy: { startedAt: 'asc' } });
  return rows.map(parseAgentRunRow);
}

// ─── Orchestrator ──────────────────────────────────────────────────────────

export async function orchestrate(params: OrchestrationParams): Promise<OrchestrationResult> {
  const startedAt = Date.now();
  const maxDepth = params.maxDepth ?? DEFAULT_MAX_DEPTH;
  const maxAgents = params.maxAgents ?? DEFAULT_MAX_AGENTS;

  logger.info(
    { module: 'orchestrator', sessionId: params.sessionId, goal: params.goal, leadAgentId: params.leadAgentId, maxDepth, maxAgents },
    `Orchestration starting: ${params.goal}`,
  );

  // 1. Create the lead agent run (depth 0)
  const leadRun = await createAgentRun({
    sessionId: params.sessionId,
    workspaceId: params.workspaceId,
    agentTemplateId: params.leadAgentId,
    providerId: params.providerId,
    model: params.model,
    task: params.goal,
    taskContext: { goal: params.goal, maxDepth, maxAgents },
    depth: 0,
  });

  // 2. Lead agent plans
  await updateAgentRunStatus(leadRun.id, 'planning');

  const planPrompt = buildPlanPrompt(params.goal);
  const planCompletion = await runAgent({
    agentTemplateId: params.leadAgentId,
    providerId: params.providerId,
    model: params.model,
    messages: [{ role: 'user', content: planPrompt }],
    signal: params.signal,
  });

  const plan = parsePlan(planCompletion.content);

  // Store the plan in shared memory
  await writeMemory({
    sessionId: params.sessionId,
    workspaceId: params.workspaceId,
    key: 'plan',
    value: JSON.stringify(plan),
    scope: 'session',
    writtenByAgentRunId: leadRun.id,
  });

  // 3. Create tasks on the task board
  await updateAgentRunStatus(leadRun.id, 'executing');

  const taskMap = new Map<string, TaskRecord>(); // planTaskIndex → TaskRecord
  for (let i = 0; i < plan.tasks.length; i++) {
    const planTask = plan.tasks[i]!;
    // Resolve dependency indices to task IDs (dependencies are indices into plan.tasks)
    const depIds = planTask.dependencies
      .map((depIdx) => taskMap.get(depIdx)?.id)
      .filter((id): id is string => id !== undefined);

    const task = await createTask({
      sessionId: params.sessionId,
      workspaceId: params.workspaceId,
      title: planTask.title,
      description: planTask.taskDescription,
      priority: planTask.priority,
      dependencies: depIds,
      createdByAgentRunId: leadRun.id,
    });
    taskMap.set(String(i), task);
  }

  // 4. Execute tasks (respecting dependencies)
  await updateAgentRunStatus(leadRun.id, 'waiting_subagents');

  const subAgentRuns: AgentRunRecord[] = [];
  const allTasks = Array.from(taskMap.values());

  // Simple sequential execution with dependency resolution
  // (A production version would run independent tasks in parallel)
  for (const task of allTasks) {
    if (params.signal?.aborted) break;

    // Wait for dependencies to be done
    const deps = await Promise.all(
      task.dependencies.map((depId) => getTask(depId, params.workspaceId)),
    );
    if (deps.some((d) => d.status === 'failed')) {
      await failTask(task.id, 'Dependency failed', params.workspaceId);
      continue;
    }

    // Spawn a sub-agent for this task
    const subRun = await createAgentRun({
      sessionId: params.sessionId,
      workspaceId: params.workspaceId,
      parentRunId: leadRun.id,
      model: params.model,
      task: task.title,
      taskContext: { taskId: task.id, description: task.description },
      depth: 1,
    });
    subAgentRuns.push(subRun);

    await claimTask(task.id, subRun.id, params.workspaceId);
    await updateAgentRunStatus(subRun.id, 'executing');

    try {
      // Look up the plan task for provider/model
      const planTask = plan.tasks.find((t) => t.title === task.title);
      const taskProviderId = planTask?.provider ?? params.providerId;
      const taskModel = planTask?.model ?? params.model;

      // Build context: goal + task + shared memory
      const memory = await readAllMemory(params.sessionId, params.workspaceId);
      const memoryContext = memory.map((m) => `${m.key}: ${m.value}`).join('\n');

      const taskCompletion = await runAgent({
        agentTemplateId: params.leadAgentId, // In production, map agentType → template ID
        providerId: taskProviderId,
        model: taskModel,
        messages: [
          { role: 'user', content: `Goal: ${params.goal}\n\nYour task: ${task.title}\n\nDescription: ${task.description ?? ''}\n\nShared memory:\n${memoryContext}` },
        ],
        signal: params.signal,
      });

      await completeTask(task.id, taskCompletion.content, params.workspaceId);
      await updateAgentRunStatus(subRun.id, 'done', {
        result: taskCompletion.content,
        tokensUsed: taskCompletion.tokensUsed,
        costUsd: taskCompletion.costUsd,
        durationMs: Date.now() - subRun.startedAt.getTime(),
      });

      // Write the result to shared memory
      await writeMemory({
        sessionId: params.sessionId,
        workspaceId: params.workspaceId,
        key: `task:${task.id}:result`,
        value: taskCompletion.content,
        scope: 'session',
        writtenByAgentRunId: subRun.id,
      });
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      await failTask(task.id, errorMsg, params.workspaceId);
      await updateAgentRunStatus(subRun.id, 'error', { result: errorMsg });
    }
  }

  // 5. Merge results
  await updateAgentRunStatus(leadRun.id, 'merging');

  const completedTasks = await getTasksBySession(params.sessionId, params.workspaceId);
  const taskResults = completedTasks
    .filter((t) => t.status === 'done')
    .map((t) => `## ${t.title}\n${t.result ?? ''}`)
    .join('\n\n');

  const mergePrompt = `Goal: ${params.goal}\n\nSub-agent results:\n${taskResults}\n\nMerge these results into a final deliverable that fulfills the goal. Produce a single coherent document.`;

  const mergeCompletion = await runAgent({
    agentTemplateId: params.leadAgentId,
    providerId: params.providerId,
    model: params.model,
    messages: [{ role: 'user', content: mergePrompt }],
    signal: params.signal,
  });

  await updateAgentRunStatus(leadRun.id, 'done', {
    result: mergeCompletion.content,
    tokensUsed: mergeCompletion.tokensUsed,
    costUsd: mergeCompletion.costUsd,
    durationMs: Date.now() - startedAt,
  });

  const finalTasks = await getTasksBySession(params.sessionId, params.workspaceId);
  const tasksCompleted = finalTasks.filter((t) => t.status === 'done').length;
  const tasksFailed = finalTasks.filter((t) => t.status === 'failed').length;

  const totalTokens = subAgentRuns.reduce((sum, r) => sum + r.tokensUsed, 0) + mergeCompletion.tokensUsed;
  const totalCostUsd = subAgentRuns.reduce((sum, r) => sum + r.costUsd, 0) + mergeCompletion.costUsd;

  const result: OrchestrationResult = {
    orchestrationId: leadRun.id,
    leadRunId: leadRun.id,
    status: 'done',
    finalResult: mergeCompletion.content,
    tasksCreated: finalTasks.length,
    tasksCompleted,
    tasksFailed,
    subAgentRuns,
    totalTokens,
    totalCostUsd,
    durationMs: Date.now() - startedAt,
  };

  logger.info(
    { module: 'orchestrator', sessionId: params.sessionId, orchestrationId: result.orchestrationId, tasksCreated: result.tasksCreated, tasksCompleted, tasksFailed, durationMs: result.durationMs },
    `Orchestration complete: ${params.goal}`,
  );

  return result;
}

// ─── Helpers ───────────────────────────────────────────────────────────────

function buildPlanPrompt(goal: string): string {
  return `You are the lead orchestrator. Decompose the following goal into 3-7 tasks.

Goal: ${goal}

Output a JSON object with this exact shape (no markdown, no commentary, just JSON):
{
  "tasks": [
    {
      "title": "short task title",
      "agentType": "researcher|coder|tester|reviewer|bug-hunter|deployer|scribe",
      "provider": "openai|mistral|anthropic|zai",
      "model": "model name",
      "dependencies": [0, 1],
      "priority": 1,
      "taskDescription": "detailed instructions for the sub-agent"
    }
  ]
}

Rules:
- dependencies are zero-based indices into the tasks array
- priority 1 is highest
- Each task should be independently assignable
- 3-7 tasks total
- Output ONLY the JSON, nothing else.`;
}

function parsePlan(content: string): Plan {
  // Extract JSON from the response (the LLM may wrap it in markdown)
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    logger.warn({ module: 'orchestrator', contentLength: content.length }, 'Plan parsing: no JSON found in response');
    return { tasks: [] };
  }

  try {
    const parsed = JSON.parse(jsonMatch[0]) as { tasks?: PlanTask[] };
    if (!Array.isArray(parsed.tasks)) {
      return { tasks: [] };
    }
    return { tasks: parsed.tasks };
  } catch (err) {
    logger.warn({ module: 'orchestrator', err }, `Plan parsing failed: ${err instanceof Error ? err.message : String(err)}`);
    return { tasks: [] };
  }
}
