/**
 * Agent Identity Preservation
 *
 * Blueprint v4.1 §4 (Mistake #7 — Agent Persona Overrode Model Identity),
 * §11 (Agent Templates), §22 Phase 1 Step 1.7
 *
 * The fix (§4): "You are [Agent], powered by [Model]. When asked, state:
 * 'I am [Model], operating as [Agent].'"
 *
 * This module provides:
 *  - verifyAgentIdentity: sends "What model are you?" to an agent, verifies
 *    the response contains BOTH the model name AND the agent name.
 *  - extractIdentityClaims: parses a response to extract the claimed model
 *    and claimed agent name.
 *  - IdentityResult type with matchedModel, matchedAgent, matched fields.
 *
 * Difference from provider verification (Phase 1.2):
 *   Provider verification checks the MODEL only (does the provider serve
 *   the right model?). Agent identity verification checks BOTH the model
 *   AND the agent persona (does the agent correctly identify itself as
 *   "[Model] operating as [Agent]"?).
 */

import { logger } from '@/lib/logger';
import { runAgent, type AgentTemplateRecord } from '@/lib/agents/runner';
import {
  type ProviderConfig,
} from '@/lib/providers/types';

// ─── Types ─────────────────────────────────────────────────────────────────

export interface IdentityResult {
  readonly agentTemplateId: string;
  readonly providerId: string;
  readonly model: string;
  readonly agentName: string;
  readonly claimedModel: string;
  readonly claimedAgent: string;
  readonly expectedModel: string;
  readonly expectedAgent: string;
  readonly matchedModel: boolean;
  readonly matchedAgent: boolean;
  readonly matched: boolean;
  readonly response: string;
  readonly durationMs: number;
}

// ─── Identity extraction ───────────────────────────────────────────────────
//
// The agent's response should contain a phrase like:
//   "I am Mistral Large, operating as Hermes."
//
// We extract:
//   - claimedModel: the text between "I am " and ", operating as"
//   - claimedAgent: the text after "operating as " (trimmed, punctuation stripped)
//
// If the response doesn't match the expected pattern, we fall back to
// best-effort parsing (return the whole response as claimedModel, empty
// string as claimedAgent).

export interface IdentityClaims {
  readonly claimedModel: string;
  readonly claimedAgent: string;
}

export function extractIdentityClaims(response: string): IdentityClaims {
  const trimmed = response.trim();

  // Pattern: "I am <model>, operating as <agent>."
  // Case-insensitive, allows optional period at end.
  const match = trimmed.match(
    /^I am\s+(.+?),\s*operating as\s+(.+?)\.?$/i,
  );

  if (match) {
    return {
      claimedModel: match[1]!.trim(),
      claimedAgent: match[2]!.trim(),
    };
  }

  // Fallback: try to extract just the model from "I am <model>"
  const modelOnly = trimmed.match(/^I am\s+(.+?)\.?$/i);
  if (modelOnly) {
    return {
      claimedModel: modelOnly[1]!.trim(),
      claimedAgent: '',
    };
  }

  // Last resort: return the whole response as claimedModel
  return {
    claimedModel: trimmed.replace(/\.$/, ''),
    claimedAgent: '',
  };
}

// ─── Expected claims extraction ────────────────────────────────────────────
//
// Given an agent template, extract the expected model + agent names from
// the systemPrompt. The prompt should contain a line like:
//   "You are Hermes, powered by Mistral Large from Mistral."
// and:
//   "When asked what model you are, state: 'I am Mistral Large, operating as Hermes.'"
//
// We extract from the second pattern (the identity clause) because it's
// the canonical form.

export function extractExpectedClaims(agent: AgentTemplateRecord): {
  expectedModel: string;
  expectedAgent: string;
} {
  // Look for: "I am <model>, operating as <agent>"
  const match = agent.systemPrompt.match(
    /I am\s+(.+?),\s*operating as\s+(.+?)[\.\s'"]/,
  );

  if (match) {
    return {
      expectedModel: match[1]!.trim(),
      expectedAgent: match[2]!.trim(),
    };
  }

  // Fallback: use the agent name and preferred model
  return {
    expectedModel: agent.preferredModel ?? '',
    expectedAgent: agent.name,
  };
}

// ─── Matching logic ────────────────────────────────────────────────────────

function caseInsensitiveSubstring(haystack: string, needle: string): boolean {
  if (needle.length === 0) return false;
  return haystack.toLowerCase().includes(needle.toLowerCase());
}

// ─── verifyAgentIdentity ───────────────────────────────────────────────────

const IDENTITY_PROMPT =
  'What model are you? Reply with: "I am <model>, operating as <agent>."';

export async function verifyAgentIdentity(params: {
  agent: AgentTemplateRecord;
  providerId: string;
  model: string;
}): Promise<IdentityResult> {
  const { agent, providerId, model } = params;
  const startedAt = Date.now();

  const { expectedModel, expectedAgent } = extractExpectedClaims(agent);

  logger.info(
    {
      module: 'agent-identity',
      agentTemplateId: agent.id,
      agentName: agent.name,
      providerId,
      model,
      expectedModel,
      expectedAgent,
    },
    `Verifying agent identity: ${agent.name}`,
  );

  // Send the identity prompt via the agent runner
  const completion = await runAgent({
    agentTemplateId: agent.id,
    providerId,
    model,
    messages: [{ role: 'user', content: IDENTITY_PROMPT }],
  });

  const response = completion.content;
  const { claimedModel, claimedAgent } = extractIdentityClaims(response);

  // Matching: case-insensitive substring
  // - claimedModel should contain expectedModel (or vice versa)
  // - claimedAgent should contain expectedAgent (or vice versa)
  const matchedModel =
    caseInsensitiveSubstring(claimedModel, expectedModel) ||
    caseInsensitiveSubstring(expectedModel, claimedModel);
  const matchedAgent =
    caseInsensitiveSubstring(claimedAgent, expectedAgent) ||
    caseInsensitiveSubstring(expectedAgent, claimedAgent);
  const matched = matchedModel && matchedAgent;

  const result: IdentityResult = {
    agentTemplateId: agent.id,
    providerId,
    model,
    agentName: agent.name,
    claimedModel,
    claimedAgent,
    expectedModel,
    expectedAgent,
    matchedModel,
    matchedAgent,
    matched,
    response,
    durationMs: Date.now() - startedAt,
  };

  logger.info(
    {
      module: 'agent-identity',
      agentTemplateId: agent.id,
      matched,
      matchedModel,
      matchedAgent,
      claimedModel,
      claimedAgent,
    },
    `Identity verification ${matched ? 'PASSED' : 'FAILED'}: agent=${agent.name} claimed="${claimedModel} / ${claimedAgent}" expected="${expectedModel} / ${expectedAgent}"`,
  );

  return result;
}
