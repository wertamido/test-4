/**
 * Agent Orchestration — Task Board, Shared Memory, Inter-Agent Messaging
 *
 * Blueprint v4.1 §10 (Agent Orchestration Engine), §16 (Shared Layer),
 * §22 Phase 2 Steps 2.2–2.4
 *
 * Three shared-layer services that agents use to coordinate:
 *   1. Task Board — create, claim, complete, depend (§16)
 *   2. Shared Memory — read, write, scope isolation (§16)
 *   3. Inter-Agent Messages — targeted + broadcast (§16)
 *
 * All three are DB-backed (no pending state, §4). Every operation goes
 * through the db singleton.
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { getSession } from '@/lib/sessions/repository';

// ═══════════════════════════════════════════════════════════════════════════
// TASK BOARD
// ═══════════════════════════════════════════════════════════════════════════

export type TaskStatus = 'pending' | 'in_progress' | 'blocked' | 'done' | 'failed';

export interface TaskRecord {
  readonly id: string;
  readonly sessionId: string;
  readonly createdByAgentRunId: string | null;
  readonly assignedToAgentRunId: string | null;
  readonly title: string;
  readonly description: string | null;
  readonly status: TaskStatus;
  readonly priority: number;
  readonly dependencies: string[];
  readonly result: string | null;
  readonly createdAt: Date;
  readonly completedAt: Date | null;
}

export interface CreateTaskInput {
  readonly sessionId: string;
  readonly workspaceId: string;
  readonly title: string;
  readonly description?: string;
  readonly priority?: number;
  readonly dependencies?: string[];
  readonly createdByAgentRunId?: string;
}

function parseTaskRow(row: {
  id: string; sessionId: string; createdByAgentRunId: string | null;
  assignedToAgentRunId: string | null; title: string; description: string | null;
  status: string; priority: number; dependencies: string; result: string | null;
  createdAt: Date; completedAt: Date | null;
}): TaskRecord {
  let deps: string[] = [];
  try { deps = JSON.parse(row.dependencies) as string[]; } catch { deps = []; }
  return {
    id: row.id, sessionId: row.sessionId,
    createdByAgentRunId: row.createdByAgentRunId,
    assignedToAgentRunId: row.assignedToAgentRunId,
    title: row.title, description: row.description,
    status: row.status as TaskStatus, priority: row.priority,
    dependencies: deps, result: row.result,
    createdAt: row.createdAt, completedAt: row.completedAt,
  };
}

export async function createTask(input: CreateTaskInput): Promise<TaskRecord> {
  await getSession(input.sessionId, input.workspaceId);
  const row = await db.task.create({
    data: {
      sessionId: input.sessionId,
      title: input.title,
      description: input.description ?? null,
      status: 'pending',
      priority: input.priority ?? 0,
      dependencies: JSON.stringify(input.dependencies ?? []),
      createdByAgentRunId: input.createdByAgentRunId ?? null,
    },
  });
  logger.info({ module: 'task-board', op: 'create', taskId: row.id, sessionId: input.sessionId }, `Task created: ${input.title}`);
  return parseTaskRow(row);
}

export async function getTask(taskId: string, workspaceId: string): Promise<TaskRecord> {
  const row = await db.task.findUnique({ where: { id: taskId } });
  if (!row) throw new Error(`Task ${taskId} not found`);
  await getSession(row.sessionId, workspaceId); // RBAC
  return parseTaskRow(row);
}

export async function getTasksBySession(sessionId: string, workspaceId: string): Promise<TaskRecord[]> {
  await getSession(sessionId, workspaceId);
  const rows = await db.task.findMany({ where: { sessionId }, orderBy: [{ priority: 'desc' }, { createdAt: 'asc' }] });
  return rows.map(parseTaskRow);
}

export async function claimTask(taskId: string, agentRunId: string, workspaceId: string): Promise<TaskRecord> {
  const task = await getTask(taskId, workspaceId);
  if (task.status !== 'pending') {
    throw new Error(`Task ${taskId} is not claimable (status=${task.status})`);
  }
  // Check dependencies are all done
  for (const depId of task.dependencies) {
    const dep = await getTask(depId, workspaceId);
    if (dep.status !== 'done') {
      throw new Error(`Task ${taskId} dependency ${depId} is not done (status=${dep.status})`);
    }
  }
  const row = await db.task.update({
    where: { id: taskId },
    data: { status: 'in_progress', assignedToAgentRunId: agentRunId },
  });
  logger.info({ module: 'task-board', op: 'claim', taskId, agentRunId }, `Task claimed: ${taskId}`);
  return parseTaskRow(row);
}

export async function completeTask(taskId: string, result: string, workspaceId: string): Promise<TaskRecord> {
  const task = await getTask(taskId, workspaceId);
  const row = await db.task.update({
    where: { id: taskId },
    data: { status: 'done', result, completedAt: new Date() },
  });
  logger.info({ module: 'task-board', op: 'complete', taskId }, `Task completed: ${task.title}`);
  return parseTaskRow(row);
}

export async function failTask(taskId: string, reason: string, workspaceId: string): Promise<TaskRecord> {
  await getTask(taskId, workspaceId);
  const row = await db.task.update({
    where: { id: taskId },
    data: { status: 'failed', result: reason, completedAt: new Date() },
  });
  logger.warn({ module: 'task-board', op: 'fail', taskId, reason }, `Task failed: ${taskId}`);
  return parseTaskRow(row);
}

// ═══════════════════════════════════════════════════════════════════════════
// SHARED MEMORY
// ═══════════════════════════════════════════════════════════════════════════

export type MemoryScope = 'session' | 'workspace' | 'global';

export interface AgentMemoryRecord {
  readonly id: string;
  readonly sessionId: string;
  readonly writtenByAgentRunId: string | null;
  readonly key: string;
  readonly value: string;
  readonly scope: MemoryScope;
  readonly createdAt: Date;
}

export async function writeMemory(params: {
  sessionId: string;
  workspaceId: string;
  key: string;
  value: string;
  scope?: MemoryScope;
  writtenByAgentRunId?: string;
}): Promise<AgentMemoryRecord> {
  await getSession(params.sessionId, params.workspaceId);
  const row = await db.agentMemory.create({
    data: {
      sessionId: params.sessionId,
      writtenByAgentRunId: params.writtenByAgentRunId ?? null,
      key: params.key,
      value: params.value,
      scope: params.scope ?? 'session',
    },
  });
  return {
    id: row.id, sessionId: row.sessionId,
    writtenByAgentRunId: row.writtenByAgentRunId,
    key: row.key, value: row.value,
    scope: row.scope as MemoryScope, createdAt: row.createdAt,
  };
}

export async function readMemory(sessionId: string, workspaceId: string, key: string): Promise<AgentMemoryRecord | null> {
  await getSession(sessionId, workspaceId);
  const row = await db.agentMemory.findFirst({
    where: { sessionId, key },
    orderBy: { createdAt: 'desc' },
  });
  if (!row) return null;
  return {
    id: row.id, sessionId: row.sessionId,
    writtenByAgentRunId: row.writtenByAgentRunId,
    key: row.key, value: row.value,
    scope: row.scope as MemoryScope, createdAt: row.createdAt,
  };
}

export async function readAllMemory(sessionId: string, workspaceId: string): Promise<AgentMemoryRecord[]> {
  await getSession(sessionId, workspaceId);
  const rows = await db.agentMemory.findMany({ where: { sessionId }, orderBy: { createdAt: 'asc' } });
  return rows.map((row) => ({
    id: row.id, sessionId: row.sessionId,
    writtenByAgentRunId: row.writtenByAgentRunId,
    key: row.key, value: row.value,
    scope: row.scope as MemoryScope, createdAt: row.createdAt,
  }));
}

// ═══════════════════════════════════════════════════════════════════════════
// INTER-AGENT MESSAGING
// ═══════════════════════════════════════════════════════════════════════════

export type AgentMessageType = 'task_assignment' | 'task_result' | 'question' | 'finding' | 'handoff';

export interface AgentMessageRecord {
  readonly id: string;
  readonly sessionId: string;
  readonly fromAgentRunId: string | null;
  readonly toAgentRunId: string | null;
  readonly type: AgentMessageType;
  readonly content: string;
  readonly readAt: Date | null;
  readonly createdAt: Date;
}

export async function sendAgentMessage(params: {
  sessionId: string;
  workspaceId: string;
  fromAgentRunId?: string;
  toAgentRunId?: string | null; // null = broadcast
  type: AgentMessageType;
  content: string;
}): Promise<AgentMessageRecord> {
  await getSession(params.sessionId, params.workspaceId);
  const row = await db.agentMessage.create({
    data: {
      sessionId: params.sessionId,
      fromAgentRunId: params.fromAgentRunId ?? null,
      toAgentRunId: params.toAgentRunId ?? null,
      type: params.type,
      content: params.content,
    },
  });
  return {
    id: row.id, sessionId: row.sessionId,
    fromAgentRunId: row.fromAgentRunId, toAgentRunId: row.toAgentRunId,
    type: row.type as AgentMessageType, content: row.content,
    readAt: row.readAt, createdAt: row.createdAt,
  };
}

export async function getAgentMessages(
  sessionId: string,
  workspaceId: string,
  options?: { toAgentRunId?: string; unreadOnly?: boolean },
): Promise<AgentMessageRecord[]> {
  await getSession(sessionId, workspaceId);
  const where: Record<string, unknown> = { sessionId };
  if (options?.toAgentRunId !== undefined) {
    where['toAgentRunId'] = options.toAgentRunId;
  }
  if (options?.unreadOnly) {
    where['readAt'] = null;
  }
  const rows = await db.agentMessage.findMany({ where, orderBy: { createdAt: 'asc' } });
  return rows.map((row) => ({
    id: row.id, sessionId: row.sessionId,
    fromAgentRunId: row.fromAgentRunId, toAgentRunId: row.toAgentRunId,
    type: row.type as AgentMessageType, content: row.content,
    readAt: row.readAt, createdAt: row.createdAt,
  }));
}

export async function markMessageRead(messageId: string): Promise<void> {
  await db.agentMessage.update({ where: { id: messageId }, data: { readAt: new Date() } });
}
