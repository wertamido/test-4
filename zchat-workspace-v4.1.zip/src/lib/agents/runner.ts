/**
 * Single-Agent Runner — Persona Assembly + Execution
 *
 * Blueprint v4.1 §11 (Agent Templates), §10 (Agent Orchestration Engine),
 * §22 Phase 1 Step 1.6, §12 (System Prompt Assembly Order)
 *
 * The runner assembles the system prompt for an agent (persona + skills +
 * identity preservation clause), dispatches to the appropriate provider
 * adapter, and returns the completion. This is the SINGLE-AGENT path —
 * no sub-agent spawning (that's Phase 2 orchestration).
 *
 * System Prompt Assembly Order (Blueprint §12):
 *   1. Base system prompt (or agent persona)
 *   2. Agent persona (if selected) — already in (1) for agent runs
 *   3. Skills sorted ASCENDING (Light → Medium → Strict)
 *   4. Pinned repo context (README) — Phase 1 Step 1.8
 *   5. Conversation history — passed by the caller
 *
 * Identity Preservation (Blueprint §11 Mistake #7):
 *   The agent prompt already contains the identity clause ("When asked what
 *   model you are, state: 'I am [Model], operating as [Name].'"). The runner
 *   does NOT override this — it trusts the agent template's systemPrompt.
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { assembleSkillsPrompt } from '@/lib/skills/registry';
import {
  type ChatCompletion,
  type ChatMessage,
  type ProviderConfig,
  type StreamAdapterParams,
  ProviderError,
} from '@/lib/providers/types';
import { streamOpenAICompatible } from '@/lib/providers/stream-openai';
import { streamZai } from '@/lib/providers/stream-zai';

// ─── Types ─────────────────────────────────────────────────────────────────

export interface AgentTemplateRecord {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly icon: string;
  readonly category: 'orchestrator' | 'worker' | 'specialist';
  readonly systemPrompt: string;
  readonly tools: string[];
  readonly mcpTools: string[];
  readonly preferredProvider: string | null;
  readonly preferredModel: string | null;
  readonly temperature: number;
  readonly canSpawnAgents: boolean;
  readonly maxSubAgents: number;
  readonly builtin: boolean;
  readonly enabled: boolean;
}

export interface RunAgentParams {
  readonly agentTemplateId: string;
  readonly providerId: string;
  readonly model: string;
  readonly messages: ReadonlyArray<ChatMessage>;
  readonly skillIds?: ReadonlyArray<string>;
  readonly temperature?: number;
  readonly signal?: AbortSignal;
  readonly onChunk?: StreamAdapterParams['onChunk'];
}

export type AgentErrorCode =
  | 'AGENT_TEMPLATE_NOT_FOUND'
  | 'AGENT_DISABLED'
  | 'RUN_FAILED';

const AGENT_ERROR_BRAND = Symbol('AgentError');

export class AgentError extends Error {
  public readonly [AGENT_ERROR_BRAND]: true = true;
  public readonly code: AgentErrorCode;
  public readonly cause: unknown;
  public readonly agentTemplateId?: string;

  public constructor(code: AgentErrorCode, message: string, cause?: unknown, agentTemplateId?: string) {
    super(message);
    this.name = 'AgentError';
    this.code = code;
    this.cause = cause;
    this.agentTemplateId = agentTemplateId;
    Object.setPrototypeOf(this, AgentError.prototype);
  }
}

export function isAgentError(error: unknown): error is AgentError {
  return (
    typeof error === 'object' &&
    error !== null &&
    (error as Record<symbol, unknown>)[AGENT_ERROR_BRAND] === true
  );
}

// ─── Agent template lookup ─────────────────────────────────────────────────

async function getAgentTemplate(id: string): Promise<AgentTemplateRecord> {
  const row = await db.agentTemplate.findUnique({ where: { id } });
  if (!row) {
    throw new AgentError(
      'AGENT_TEMPLATE_NOT_FOUND',
      `Agent template ${id} not found.`,
      undefined,
      id,
    );
  }
  let tools: string[] = [];
  let mcpTools: string[] = [];
  try { tools = JSON.parse(row.tools) as string[]; } catch { tools = []; }
  try { mcpTools = JSON.parse(row.mcpTools) as string[]; } catch { mcpTools = []; }
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    icon: row.icon,
    category: row.category as AgentTemplateRecord['category'],
    systemPrompt: row.systemPrompt,
    tools,
    mcpTools,
    preferredProvider: row.preferredProvider,
    preferredModel: row.preferredModel,
    temperature: row.temperature,
    canSpawnAgents: row.canSpawnAgents,
    maxSubAgents: row.maxSubAgents,
    builtin: row.builtin,
    enabled: row.enabled,
  };
}

async function lookupProvider(providerId: string): Promise<ProviderConfig> {
  const row = await db.provider.findUnique({ where: { id: providerId } });
  if (!row) {
    throw new ProviderError(
      'PROVIDER_NOT_CONFIGURED',
      `Provider ${providerId} not found.`,
      undefined,
      providerId,
    );
  }
  return {
    id: row.id,
    name: row.name,
    kind: row.kind as ProviderConfig['kind'],
    baseUrl: row.baseUrl,
    apiKey: row.apiKey,
    enabled: row.enabled,
    isLocal: row.isLocal,
  };
}

// ─── System prompt assembly ────────────────────────────────────────────────
//
// Blueprint §12 assembly order for an agent run:
//   1. Agent persona (the template's systemPrompt — includes identity clause)
//   2. Skills sorted ASCENDING
//   3. (Repo context — Phase 1 Step 1.8)
//   4. (Conversation history — passed by caller as messages)

export async function assembleAgentSystemPrompt(
  agent: AgentTemplateRecord,
  skillIds: ReadonlyArray<string>,
): Promise<string> {
  const parts: string[] = [];

  // 1. Agent persona (includes identity preservation clause per §11)
  parts.push(agent.systemPrompt);

  // 2. Skills
  const skillsPrompt = await assembleSkillsPrompt(skillIds);
  if (skillsPrompt.length > 0) {
    parts.push(skillsPrompt);
  }

  return parts.join('\n\n');
}

// ─── runAgent ──────────────────────────────────────────────────────────────

export async function runAgent(params: RunAgentParams): Promise<ChatCompletion> {
  const { agentTemplateId, providerId, model, messages, skillIds, temperature, signal, onChunk } = params;

  logger.info(
    { module: 'agent-runner', agentTemplateId, providerId, model, messageCount: messages.length },
    `Running agent: ${agentTemplateId} via ${providerId}/${model}`,
  );

  // 1. Load agent template
  const agent = await getAgentTemplate(agentTemplateId);
  if (!agent.enabled) {
    throw new AgentError(
      'AGENT_DISABLED',
      `Agent template ${agent.name} (${agent.id}) is disabled.`,
      undefined,
      agent.id,
    );
  }

  // 2. Assemble system prompt (persona + skills)
  const systemPrompt = await assembleAgentSystemPrompt(agent, skillIds ?? []);

  // 3. Prepend the system prompt to the messages
  const fullMessages: ChatMessage[] = [
    { role: 'system', content: systemPrompt },
    ...messages,
  ];

  // 4. Look up provider
  const provider = await lookupProvider(providerId);

  // 5. Dispatch to the adapter
  const adapterParams: StreamAdapterParams = {
    provider,
    model,
    messages: fullMessages,
    temperature: temperature ?? agent.temperature,
    signal,
    onChunk,
  };

  try {
    let completion: ChatCompletion;
    if (provider.kind === 'zai') {
      completion = await streamZai(adapterParams);
    } else if (provider.kind === 'openai') {
      completion = await streamOpenAICompatible(adapterParams);
    } else {
      throw new ProviderError(
        'PROVIDER_NOT_CONFIGURED',
        `Provider kind '${provider.kind}' not supported for agent runs.`,
        undefined,
        providerId,
      );
    }

    logger.info(
      { module: 'agent-runner', agentTemplateId, providerId, model, contentLength: completion.content.length, tokens: completion.tokensUsed },
      `Agent run complete: ${agentTemplateId}`,
    );

    return completion;
  } catch (err) {
    if (isAgentError(err) || (err instanceof ProviderError)) throw err;
    throw new AgentError(
      'RUN_FAILED',
      `Agent run failed: ${err instanceof Error ? err.message : String(err)}`,
      err,
      agentTemplateId,
    );
  }
}

// Re-exports
export { ProviderError } from '@/lib/providers/types';
