/**
 * Infrastructure — Rate Limiting, Token/Cost Tracking, API Key Encryption, Error Recovery
 *
 * Blueprint v4.1 §24 (Security Model — Rate Limiting, API Key Security),
 * §22 Phase 4 (Steps 4.3–4.6), §17 (Job recovery)
 *
 * Consolidated infrastructure module:
 *   1. Rate limiter — per user (100/hr free, 1000/hr pro) + per IP (1000/hr)
 *   2. Token/cost tracker — per message, session, user
 *   3. API key encryption — AES-256-GCM
 *   4. Job error recovery — retry + dead letter (integrates with the queue)
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from 'node:crypto';

// ═══════════════════════════════════════════════════════════════════════════
// 1. RATE LIMITING
// ═══════════════════════════════════════════════════════════════════════════

export type RateLimitTier = 'free' | 'pro' | 'enterprise';

export interface RateLimitConfig {
  readonly maxRequests: number;
  readonly windowMs: number;
}

export const RATE_LIMITS: Readonly<Record<RateLimitTier, RateLimitConfig>> = {
  free: { maxRequests: 100, windowMs: 60 * 60 * 1000 },       // 100/hour
  pro: { maxRequests: 1000, windowMs: 60 * 60 * 1000 },       // 1000/hour
  enterprise: { maxRequests: 10000, windowMs: 60 * 60 * 1000 }, // 10000/hour
};

export const IP_RATE_LIMIT: RateLimitConfig = { maxRequests: 1000, windowMs: 60 * 60 * 1000 };

// In-memory rate limit counters (keyed by `userId` or `ip`).
// For production, swap to Redis. For the sandbox (50 users), in-memory is fine.
const rateLimitBuckets = new Map<string, { count: number; resetAt: number }>();

export interface RateLimitResult {
  readonly allowed: boolean;
  readonly remaining: number;
  readonly resetAt: number;
}

export function checkRateLimit(key: string, config: RateLimitConfig): RateLimitResult {
  const now = Date.now();
  const bucket = rateLimitBuckets.get(key);

  if (!bucket || bucket.resetAt <= now) {
    // New window
    rateLimitBuckets.set(key, { count: 1, resetAt: now + config.windowMs });
    return { allowed: true, remaining: config.maxRequests - 1, resetAt: now + config.windowMs };
  }

  if (bucket.count >= config.maxRequests) {
    return { allowed: false, remaining: 0, resetAt: bucket.resetAt };
  }

  bucket.count++;
  return { allowed: true, remaining: config.maxRequests - bucket.count, resetAt: bucket.resetAt };
}

export function checkUserRateLimit(userId: string, tier: RateLimitTier): RateLimitResult {
  return checkRateLimit(`user:${userId}`, RATE_LIMITS[tier]);
}

export function checkIpRateLimit(ip: string): RateLimitResult {
  return checkRateLimit(`ip:${ip}`, IP_RATE_LIMIT);
}

/** Test-only: clear all rate limit buckets. */
export function _clearRateLimitsForTests(): void {
  rateLimitBuckets.clear();
}

// ═══════════════════════════════════════════════════════════════════════════
// 2. TOKEN / COST TRACKING
// ═══════════════════════════════════════════════════════════════════════════

export interface ProviderPricing {
  readonly inputCostPer1K: number;  // USD per 1K input tokens
  readonly outputCostPer1K: number; // USD per 1K output tokens
}

// Rough pricing (as of 2025) — update from provider docs periodically.
export const PROVIDER_PRICING: Readonly<Record<string, ProviderPricing>> = {
  'gpt-4o': { inputCostPer1K: 0.0025, outputCostPer1K: 0.01 },
  'gpt-4o-mini': { inputCostPer1K: 0.00015, outputCostPer1K: 0.0006 },
  'mistral-large-latest': { inputCostPer1K: 0.002, outputCostPer1K: 0.006 },
  'mistral-small-latest': { inputCostPer1K: 0.0002, outputCostPer1K: 0.0006 },
  'claude-3-5-sonnet-latest': { inputCostPer1K: 0.003, outputCostPer1K: 0.015 },
  'claude-3-5-haiku-latest': { inputCostPer1K: 0.0008, outputCostPer1K: 0.004 },
  'glm-4.6': { inputCostPer1K: 0.001, outputCostPer1K: 0.002 }, // Z.ai estimate
};

export function calculateCost(model: string, inputTokens: number, outputTokens: number): number {
  const pricing = PROVIDER_PRICING[model];
  if (!pricing) return 0;
  return (inputTokens / 1000) * pricing.inputCostPer1K + (outputTokens / 1000) * pricing.outputCostPer1K;
}

export interface UsageSummary {
  readonly totalTokens: number;
  readonly totalCostUsd: number;
  readonly messageCount: number;
}

export async function getSessionUsage(sessionId: string): Promise<UsageSummary> {
  const messages = await db.message.findMany({
    where: { sessionId },
    select: { tokens: true, costUsd: true },
  });
  return {
    totalTokens: messages.reduce((sum, m) => sum + m.tokens, 0),
    totalCostUsd: messages.reduce((sum, m) => sum + m.costUsd, 0),
    messageCount: messages.length,
  };
}

export async function getUserUsage(userId: string): Promise<UsageSummary> {
  // Sum across all sessions in all workspaces owned by the user
  const workspaces = await db.workspace.findMany({
    where: { userId },
    select: { id: true },
  });
  const workspaceIds = workspaces.map((w) => w.id);

  const sessions = await db.session.findMany({
    where: { workspaceId: { in: workspaceIds } },
    select: { id: true },
  });
  const sessionIds = sessions.map((s) => s.id);

  const messages = await db.message.findMany({
    where: { sessionId: { in: sessionIds } },
    select: { tokens: true, costUsd: true },
  });

  return {
    totalTokens: messages.reduce((sum, m) => sum + m.tokens, 0),
    totalCostUsd: messages.reduce((sum, m) => sum + m.costUsd, 0),
    messageCount: messages.length,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// 3. API KEY ENCRYPTION (AES-256-GCM)
// ═══════════════════════════════════════════════════════════════════════════

const ENCRYPTION_KEY_ENV = 'ENCRYPTION_KEY';
const SALT = 'zchat-workspace-v4.1-salt'; // Static salt (the key itself is the secret)
const KEY_LENGTH = 32; // 256 bits for AES-256
const IV_LENGTH = 12;  // 96 bits for GCM

function getEncryptionKey(): Buffer {
  const envKey = process.env[ENCRYPTION_KEY_ENV];
  if (!envKey || envKey.length < 16) {
    throw new Error(`${ENCRYPTION_KEY_ENV} must be set and at least 16 characters. Used to encrypt provider API keys at rest.`);
  }
  return scryptSync(envKey, SALT, KEY_LENGTH);
}

export interface EncryptedKey {
  readonly iv: string;       // base64
  readonly ciphertext: string; // base64 (includes auth tag)
}

export function encryptApiKey(plaintext: string): EncryptedKey {
  const key = getEncryptionKey();
  const iv = randomBytes(IV_LENGTH);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  // Concatenate ciphertext + authTag for storage
  const ciphertextWithTag = Buffer.concat([encrypted, authTag]);
  return {
    iv: iv.toString('base64'),
    ciphertext: ciphertextWithTag.toString('base64'),
  };
}

export function decryptApiKey(encrypted: EncryptedKey): string {
  const key = getEncryptionKey();
  const iv = Buffer.from(encrypted.iv, 'base64');
  const ciphertextWithTag = Buffer.from(encrypted.ciphertext, 'base64');
  // Last 16 bytes are the auth tag
  const ciphertext = ciphertextWithTag.subarray(0, -16);
  const authTag = ciphertextWithTag.subarray(-16);
  const decipher = createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);
  const decrypted = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  return decrypted.toString('utf8');
}

/** Serialize an EncryptedKey for DB storage (JSON string). */
export function serializeEncryptedKey(encrypted: EncryptedKey): string {
  return JSON.stringify(encrypted);
}

/** Deserialize an EncryptedKey from DB storage. */
export function deserializeEncryptedKey(json: string): EncryptedKey | null {
  try {
    const parsed = JSON.parse(json) as { iv?: string; ciphertext?: string };
    if (typeof parsed.iv !== 'string' || typeof parsed.ciphertext !== 'string') return null;
    return { iv: parsed.iv, ciphertext: parsed.ciphertext };
  } catch {
    return null;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// 4. JOB ERROR RECOVERY
// ═══════════════════════════════════════════════════════════════════════════

export interface RecoveryStats {
  readonly recoveredCount: number;
  readonly failedCount: number;
  readonly stillRunningCount: number;
}

export async function recoverJobs(olderThanMs: number = 5 * 60 * 1000): Promise<RecoveryStats> {
  const cutoff = new Date(Date.now() - olderThanMs);

  // Find stale running jobs
  const staleJobs = await db.job.findMany({
    where: {
      status: 'running',
      startedAt: { lt: cutoff },
    },
    select: { id: true, type: true, attempts: true, maxAttempts: true },
  });

  let recoveredCount = 0;
  let failedCount = 0;

  for (const job of staleJobs) {
    if (job.attempts >= job.maxAttempts) {
      // Mark as failed — exceeded max attempts
      await db.job.update({
        where: { id: job.id },
        data: {
          status: 'failed',
          finishedAt: new Date(),
          error: `Job timed out after ${job.attempts} attempts (stale recovery).`,
        },
      });
      failedCount++;
    } else {
      // Re-enqueue for retry
      await db.job.update({
        where: { id: job.id },
        data: {
          status: 'queued',
          startedAt: null,
        },
      });
      recoveredCount++;
    }
  }

  // Count still-running jobs (for reporting)
  const stillRunning = await db.job.count({ where: { status: 'running' } });

  const stats: RecoveryStats = {
    recoveredCount,
    failedCount,
    stillRunningCount: stillRunning,
  };

  logger.info(
    { module: 'infra', op: 'recoverJobs', ...stats, olderThanMs },
    `Job recovery: ${recoveredCount} re-enqueued, ${failedCount} failed, ${stillRunning} still running`,
  );

  return stats;
}
