/**
 * Z.ai Streaming Adapter — 100% Deactivatable (Blueprint §8)
 *
 * Blueprint v4.1 §8 (Z.ai Policy), §7 (Provider System), §18 (Streaming),
 * §22 Phase 1 Step 1.1
 *
 * THE CRITICAL SECURITY PROPERTY (Blueprint §8):
 *
 *   "When Z.ai is disabled (enabled=false):
 *    - streamZai() throws ProviderError(ZAI_DISABLED)
 *    - NO fallback to Z.ai
 *    - NO SDK call
 *    - NO hidden request
 *    - The streamZai() function is never called (by the registry)
 *
 *    Verification: Z.ai code only exists inside streamZai(), which is only
 *    called when provider.kind === 'zai' AND provider.enabled === true.
 *    If disabled, zero Z.ai code executes."
 *
 * IMPLEMENTATION STRATEGY (Option 1 — confirmed by the EM):
 *
 *   The z-ai-web-dev-sdk is loaded via a DYNAMIC `await import()` INSIDE
 *   streamZai(), AFTER the enabled check. This means:
 *
 *     1. The static module graph has ZERO Z.ai SDK code. Importing
 *        stream-zai.ts does NOT load the SDK.
 *     2. The `enabled === false` check runs BEFORE the dynamic import, so
 *        a disabled provider never triggers the SDK load.
 *     3. Tests can verify "no SDK import when disabled" by spying on
 *        `import()` — the dynamic import is the only path to the SDK.
 *
 *   This satisfies BOTH the blueprint's "no SDK call" requirement AND the
 *   spec's stricter "no SDK import" requirement.
 *
 * Why dynamic import (not static)?
 *   A static `import { ZAI } from 'z-ai-web-dev-sdk'` at the top of this
 *   file would be evaluated when ANY module imports stream-zai.ts — including
 *   test files, the registry, or any code that just checks `provider.kind`.
 *   That would import the SDK even when Z.ai is disabled, violating the
 *   spec. Dynamic import defers the load to call time.
 *
 * The ZAI SDK API (assumed shape — tests mock it):
 *   const { ZAI } = await import('z-ai-web-dev-sdk');
 *   const zai = await ZAI.create();
 *   const stream = await zai.chat.completions.create({
 *     model: 'glm-4.6',
 *     messages: [...],
 *     stream: true,
 *   });
 *   for await (const chunk of stream) { ... }
 *
 *   Note (Blueprint §7): "Z.ai SDK — Model parameter ignored by SDK (SDK
 *   always serves glm-4-plus)." We pass `model` through for logging; the SDK
 *   decides what to actually serve.
 */

import { logger } from '@/lib/logger';
import {
  type ChatCompletion,
  type ChatCompletionChunk,
  type ChatMessage,
  type StreamAdapterParams,
  type ToolCall,
  ProviderError,
  isProviderError,
} from '@/lib/providers/types';

// ─── ZAI SDK type shims ────────────────────────────────────────────────────
//
// Minimal type definitions for the z-ai-web-dev-sdk. The real SDK may have
// a richer API; these shims describe only the surface streamZai() uses.
// If the SDK's actual shape differs, update these types — the runtime code
// below does not depend on the exact type names.

interface ZaiSdkStreamChunk {
  choices?: Array<{
    delta?: { content?: string; role?: string; tool_calls?: Array<{ index: number; id?: string; function?: { name?: string; arguments?: string } }> };
    finish_reason?: string | null;
  }>;
}

interface ZaiSdkStream {
  [Symbol.asyncIterator](): AsyncIterator<ZaiSdkStreamChunk>;
}

interface ZaiSdkChatCompletions {
  create(params: {
    model: string;
    messages: ReadonlyArray<Record<string, unknown>>;
    stream: true;
    temperature?: number;
    max_tokens?: number;
    tools?: ReadonlyArray<Record<string, unknown>>;
  }): Promise<ZaiSdkStream>;
}

interface ZaiSdkClient {
  chat: { completions: ZaiSdkChatCompletions };
}

interface ZaiSdkModule {
  ZAI: {
    create(): Promise<ZaiSdkClient>;
  };
}

// ─── streamZai ─────────────────────────────────────────────────────────────

export async function streamZai(params: StreamAdapterParams): Promise<ChatCompletion> {
  const { provider, model, messages, temperature, maxTokens, tools, signal, onChunk } = params;

  // ── Guard: Z.ai must be enabled ──────────────────────────────────────
  //
  // This check runs BEFORE the dynamic import — so a disabled provider
  // never triggers the SDK load. This is the §8 verification point.
  if (!provider.enabled) {
    logger.warn(
      { module: 'provider-zai', providerId: provider.id },
      `Z.ai is disabled — refusing to call SDK (Blueprint §8)`,
    );
    throw new ProviderError(
      'ZAI_DISABLED',
      `Z.ai is disabled. Enable it in the providers settings to use Z.ai. (Blueprint §8: no fallback, no SDK call, no hidden request.)`,
      undefined,
      provider.id,
    );
  }

  // ── Dynamic import — SDK is loaded ONLY when Z.ai is enabled ─────────
  //
  // This is the ONLY line in the entire codebase that imports
  // 'z-ai-web-dev-sdk'. The import is deferred to runtime; the static
  // module graph contains no Z.ai SDK code.
  let sdkModule: ZaiSdkModule;
  try {
    // `Function('return import(...)')()` trick to prevent bundlers from
    // turning this into a static import. The string literal is constructed
    // at runtime so static analyzers can't trace it.
    const dynamicImport = new Function(
      'spec',
      'return import(spec)',
    ) as (spec: string) => Promise<ZaiSdkModule>;
    sdkModule = await dynamicImport('z-ai-web-dev-sdk');
  } catch (err) {
    throw new ProviderError(
      'PROVIDER_NOT_CONFIGURED',
      `Failed to load z-ai-web-dev-sdk. Is the package installed? ${err instanceof Error ? err.message : String(err)}`,
      err,
      provider.id,
    );
  }

  // ── Create the SDK client ────────────────────────────────────────────
  let client: ZaiSdkClient;
  try {
    client = await sdkModule.ZAI.create();
  } catch (err) {
    throw new ProviderError(
      'PROVIDER_NOT_CONFIGURED',
      `ZAI.create() failed: ${err instanceof Error ? err.message : String(err)}`,
      err,
      provider.id,
    );
  }

  // ── Build the request ────────────────────────────────────────────────
  //
  // Note (Blueprint §7): the Z.ai SDK ignores the `model` parameter — it
  // always serves GLM-4-Plus. We pass it through for logging and for the
  // return value's `model` field, but the SDK decides what to serve.
  const requestMessages = messages.map((m) => {
    const msg: Record<string, unknown> = { role: m.role, content: m.content };
    if (m.toolCallId !== undefined) msg['toolCallId'] = m.toolCallId;
    if (m.toolCalls !== undefined) msg['toolCalls'] = m.toolCalls;
    if (m.name !== undefined) msg['name'] = m.name;
    return msg;
  });

  const createParams: {
    model: string;
    messages: ReadonlyArray<Record<string, unknown>>;
    stream: true;
    temperature?: number;
    max_tokens?: number;
    tools?: ReadonlyArray<Record<string, unknown>>;
  } = {
    model,
    messages: requestMessages,
    stream: true,
  };
  if (temperature !== undefined) createParams['temperature'] = temperature;
  if (maxTokens !== undefined) createParams['max_tokens'] = maxTokens;
  if (tools !== undefined && tools.length > 0) {
    createParams['tools'] = tools as unknown as ReadonlyArray<Record<string, unknown>>;
  }

  logger.debug(
    { module: 'provider-zai', providerId: provider.id, model, messageCount: messages.length },
    `Streaming from Z.ai (model=${model}; SDK may serve GLM-4-Plus per §7)`,
  );

  // ── Create the stream ────────────────────────────────────────────────
  let stream: ZaiSdkStream;
  try {
    stream = await client.chat.completions.create(createParams);
  } catch (err) {
    if (err instanceof Error && err.name === 'AbortError') {
      throw new ProviderError(
        'STREAM_ABORTED',
        `Z.ai request was aborted.`,
        err,
        provider.id,
      );
    }
    // The SDK may throw for auth, rate-limit, or server errors. We don't
    // have a reliable way to distinguish them without inspecting the error
    // shape — map to REQUEST_FAILED for now. Phase 4 can refine this.
    throw new ProviderError(
      'REQUEST_FAILED',
      `Z.ai SDK create() failed: ${err instanceof Error ? err.message : String(err)}`,
      err,
      provider.id,
    );
  }

  // ── Consume the stream ───────────────────────────────────────────────
  const chunks: ChatCompletionChunk[] = [];
  let content = '';
  let finishReason = 'stop';
  const toolCallFragments = new Map<number, { id?: string; name?: string; args: string }>();

  try {
    for await (const rawChunk of stream) {
      // Check for abort between chunks
      if (signal?.aborted) {
        throw new ProviderError(
          'STREAM_ABORTED',
          `Z.ai stream was aborted by the client.`,
          undefined,
          provider.id,
        );
      }

      const choice = rawChunk.choices?.[0];
      if (!choice) continue;

      const delta = choice.delta ?? {};
      const chunk: ChatCompletionChunk = {
        delta: {
          ...(delta.content !== undefined ? { content: delta.content } : {}),
          ...(delta.tool_calls !== undefined ? { toolCalls: delta.tool_calls } : {}),
          ...(delta.role !== undefined ? { role: delta.role as ChatCompletionChunk['delta']['role'] } : {}),
        },
        ...(choice.finish_reason ? { finishReason: choice.finish_reason } : {}),
      };

      chunks.push(chunk);
      onChunk?.(chunk);

      // Aggregate
      if (delta.content !== undefined) content += delta.content;
      if (delta.tool_calls !== undefined) {
        for (const tc of delta.tool_calls) {
          const existing = toolCallFragments.get(tc.index) ?? { args: '' };
          if (tc.id !== undefined) existing.id = tc.id;
          if (tc.function?.name !== undefined) existing.name = tc.function.name;
          if (tc.function?.arguments !== undefined) existing.args += tc.function.arguments;
          toolCallFragments.set(tc.index, existing);
        }
      }
      if (choice.finish_reason) finishReason = choice.finish_reason;
    }
  } catch (err) {
    if (isProviderError(err)) throw err;
    if (err instanceof Error && err.name === 'AbortError') {
      throw new ProviderError(
        'STREAM_ABORTED',
        `Z.ai stream was aborted.`,
        err,
        provider.id,
      );
    }
    throw new ProviderError(
      'REQUEST_FAILED',
      `Error reading Z.ai stream: ${err instanceof Error ? err.message : String(err)}`,
      err,
      provider.id,
    );
  }

  if (chunks.length === 0) {
    throw new ProviderError(
      'INVALID_RESPONSE',
      `Z.ai returned an empty stream (no chunks).`,
      undefined,
      provider.id,
    );
  }

  const toolCalls: ToolCall[] = Array.from(toolCallFragments.entries())
    .sort(([a], [b]) => a - b)
    .map(([, frag]) => ({
      id: frag.id ?? '',
      type: 'function' as const,
      function: { name: frag.name ?? '', arguments: frag.args },
    }));

  const tokensUsed = Math.ceil(content.length / 4);

  const completion: ChatCompletion = {
    content,
    toolCalls,
    finishReason,
    tokensUsed,
    costUsd: 0,
    model,
    providerId: provider.id,
  };

  logger.debug(
    { module: 'provider-zai', providerId: provider.id, model, chunkCount: chunks.length, contentLength: content.length },
    `Z.ai stream complete: ${chunks.length} chunks, ${content.length} chars`,
  );

  return completion;
}

// ─── Test-only helper: reset the dynamic-import cache ──────────────────────
//
// Tests need to spy on the dynamic import. Because we use `new Function(...)`
// to construct the import, the spy must be installed at the global level.
// This helper exists so tests have a documented hook for resetting state
// between cases.

export function _resetZaiAdapterForTests(): void {
  // No-op — the dynamic import is stateless (the SDK module cache is managed
  // by the JS runtime). This function exists as a documentation point:
  // tests should use vi.spyOn(globalThis, 'Function') OR mock the module
  // via vi.doMock('z-ai-web-dev-sdk', ...) BEFORE calling streamZai().
}

// Re-exports
export { ProviderError } from '@/lib/providers/types';
export type {
  ChatCompletion,
  ChatCompletionChunk,
  ChatMessage,
  StreamAdapterParams,
} from '@/lib/providers/types';
