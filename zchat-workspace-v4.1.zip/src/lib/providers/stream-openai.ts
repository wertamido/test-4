/**
 * OpenAI-Compatible Streaming Adapter
 *
 * Blueprint v4.1 §7 (Provider System), §18 (Streaming — SSE for chat),
 * §22 Phase 1 Step 1.1
 *
 * Covers 8 providers that all speak the OpenAI chat completions API:
 *   Mistral, OpenAI, Groq, Together, OpenRouter, Cloudflare, Ollama, LM Studio
 *
 * Design goals:
 *  - Native fetch() — no openai SDK, no axios. Blueprint §7: "Direct HTTP,
 *    No SDK Lies."
 *  - Streams the response via ReadableStream, parses SSE chunks, calls
 *    onChunk for each parsed chunk.
 *  - Guards: provider.enabled === false → PROVIDER_DISABLED;
 *    apiKey === null && !isLocal → PROVIDER_NOT_CONFIGURED (local providers
 *    like Ollama/LM Studio don't need an API key).
 *  - HTTP error mapping: 401 → AUTH_FAILED, 429 → RATE_LIMITED, 5xx →
 *    REQUEST_FAILED, other non-2xx → REQUEST_FAILED.
 *  - AbortSignal support for user cancellation → STREAM_ABORTED.
 *  - Aggregates chunks into a final ChatCompletion (content + toolCalls +
 *    finishReason + token estimate).
 *  - Strictly typed. No `any`.
 *
 * The adapter is provider-agnostic — it doesn't know whether it's talking to
 * Mistral or OpenAI or Ollama. The provider config (baseUrl, apiKey) tells
 * it where to send the request.
 */

import { logger } from '@/lib/logger';
import {
  type ChatCompletion,
  type ChatCompletionChunk,
  type ChatMessage,
  type StreamAdapterParams,
  type Tool,
  type ToolCall,
  ProviderError,
} from '@/lib/providers/types';

// ─── Helpers ───────────────────────────────────────────────────────────────

/**
 * Build the OpenAI-compatible request body from the adapter params.
 * Exposed (not exported) so the test suite can verify the body shape without
 * capturing a real fetch call.
 */
function buildRequestBody(params: StreamAdapterParams): Record<string, unknown> {
  const body: Record<string, unknown> = {
    model: params.model,
    messages: params.messages.map((m) => {
      const msg: Record<string, unknown> = { role: m.role, content: m.content };
      if (m.toolCallId !== undefined) msg['toolCallId'] = m.toolCallId;
      if (m.toolCalls !== undefined) msg['toolCalls'] = m.toolCalls;
      if (m.name !== undefined) msg['name'] = m.name;
      return msg;
    }),
    stream: true,
  };
  if (params.temperature !== undefined) body['temperature'] = params.temperature;
  if (params.maxTokens !== undefined) body['max_tokens'] = params.maxTokens;
  if (params.tools !== undefined && params.tools.length > 0) {
    body['tools'] = params.tools as Tool[];
  }
  return body;
}

/**
 * Parse a single SSE `data:` line into a ChatCompletionChunk, or `null` if
 * the line is a keep-alive comment, the [DONE] sentinel, or unparseable.
 *
 * The OpenAI SSE format is:
 *   data: {"id":"...","choices":[{"delta":{"content":"hello"},"finish_reason":null}]}
 *   data: {"id":"...","choices":[{"delta":{},"finish_reason":"stop"}]}
 *   data: [DONE]
 */
function parseSseDataLine(line: string): ChatCompletionChunk | null {
  // Trim leading/trailing whitespace
  const trimmed = line.trim();
  if (trimmed === '') return null;
  if (trimmed === 'data: [DONE]') return null;
  if (!trimmed.startsWith('data:')) return null;

  const jsonStr = trimmed.slice(5).trim();
  if (jsonStr === '') return null;

  try {
    const parsed = JSON.parse(jsonStr) as {
      choices?: Array<{
        delta?: { content?: string; role?: string; tool_calls?: Array<{ index: number; id?: string; function?: { name?: string; arguments?: string } }> };
        finish_reason?: string | null;
      }>;
    };

    const choice = parsed.choices?.[0];
    if (!choice) return null;

    const delta = choice.delta ?? {};
    const chunk: ChatCompletionChunk = {
      delta: {
        ...(delta.content !== undefined ? { content: delta.content } : {}),
        ...(delta.tool_calls !== undefined ? { toolCalls: delta.tool_calls } : {}),
        ...(delta.role !== undefined ? { role: delta.role as ChatCompletionChunk['delta']['role'] } : {}),
      },
      ...(choice.finish_reason ? { finishReason: choice.finish_reason } : {}),
    };

    return chunk;
  } catch {
    // Malformed JSON — skip this chunk rather than failing the whole stream
    return null;
  }
}

/**
 * Aggregate an array of chunks into a single ChatCompletion. Tool calls are
 * reconstructed by concatenating the `arguments` fragments per index.
 */
function aggregateChunks(
  chunks: ReadonlyArray<ChatCompletionChunk>,
  model: string,
  providerId: string,
): ChatCompletion {
  let content = '';
  let finishReason = 'stop';
  const toolCallFragments = new Map<number, { id?: string; name?: string; args: string }>();

  for (const chunk of chunks) {
    if (chunk.delta.content !== undefined) {
      content += chunk.delta.content;
    }
    if (chunk.delta.toolCalls !== undefined) {
      for (const tc of chunk.delta.toolCalls) {
        const existing = toolCallFragments.get(tc.index) ?? { args: '' };
        if (tc.id !== undefined) existing.id = tc.id;
        if (tc.function?.name !== undefined) existing.name = tc.function.name;
        if (tc.function?.arguments !== undefined) existing.args += tc.function.arguments;
        toolCallFragments.set(tc.index, existing);
      }
    }
    if (chunk.finishReason !== undefined) {
      finishReason = chunk.finishReason;
    }
  }

  const toolCalls: ToolCall[] = Array.from(toolCallFragments.entries())
    .sort(([a], [b]) => a - b)
    .map(([, frag]) => ({
      id: frag.id ?? '',
      type: 'function' as const,
      function: {
        name: frag.name ?? '',
        arguments: frag.args,
      },
    }));

  // Token estimate: ~4 chars per token for English text. This is a rough
  // estimate used for cost tracking; the provider's usage object (if present
  // in the final chunk) would be more accurate.
  const tokensUsed = Math.ceil(content.length / 4);

  return {
    content,
    toolCalls,
    finishReason,
    tokensUsed,
    costUsd: 0, // Cost tracking is Phase 4 (Step 4.4)
    model,
    providerId,
  };
}

// ─── streamOpenAICompatible ────────────────────────────────────────────────

export async function streamOpenAICompatible(
  params: StreamAdapterParams,
): Promise<ChatCompletion> {
  const { provider, model, messages, temperature, maxTokens, tools, signal, onChunk } = params;

  // ── Guard: provider must be enabled ──────────────────────────────────
  if (!provider.enabled) {
    throw new ProviderError(
      'PROVIDER_DISABLED',
      `Provider ${provider.name} (${provider.id}) is disabled. Enable it in the providers settings.`,
      undefined,
      provider.id,
    );
  }

  // ── Guard: non-local providers must have an API key ──────────────────
  if (!provider.isLocal && (provider.apiKey === null || provider.apiKey === '')) {
    throw new ProviderError(
      'PROVIDER_NOT_CONFIGURED',
      `Provider ${provider.name} (${provider.id}) has no API key configured. Add one in the providers settings.`,
      undefined,
      provider.id,
    );
  }

  // ── Guard: must have a baseUrl ───────────────────────────────────────
  if (provider.baseUrl === null || provider.baseUrl === '') {
    throw new ProviderError(
      'PROVIDER_NOT_CONFIGURED',
      `Provider ${provider.name} (${provider.id}) has no baseUrl configured.`,
      undefined,
      provider.id,
    );
  }

  const url = provider.baseUrl;
  const body = buildRequestBody(params);

  const headers: Record<string, string> = {
    'content-type': 'application/json',
    accept: 'text/event-stream',
  };
  // Local providers (Ollama, LM Studio) don't require a Bearer token
  if (!provider.isLocal && provider.apiKey) {
    headers['authorization'] = `Bearer ${provider.apiKey}`;
  }

  logger.debug(
    { module: 'provider-openai', providerId: provider.id, model, messageCount: messages.length },
    `Streaming from ${provider.name} (${model})`,
  );

  // ── Make the request ─────────────────────────────────────────────────
  let response: Response;
  try {
    response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
      signal,
    });
  } catch (err) {
    // AbortError → STREAM_ABORTED; everything else → REQUEST_FAILED
    if (err instanceof Error && err.name === 'AbortError') {
      throw new ProviderError(
        'STREAM_ABORTED',
        `Request to ${provider.name} was aborted.`,
        err,
        provider.id,
      );
    }
    throw new ProviderError(
      'REQUEST_FAILED',
      `Failed to reach ${provider.name} at ${url}: ${err instanceof Error ? err.message : String(err)}`,
      err,
      provider.id,
    );
  }

  // ── Map HTTP errors ──────────────────────────────────────────────────
  if (!response.ok) {
    const statusCode = response.status;
    let errorBody = '';
    try {
      errorBody = await response.text();
    } catch {
      // ignore — body may not be readable
    }

    if (statusCode === 401 || statusCode === 403) {
      throw new ProviderError(
        'AUTH_FAILED',
        `${provider.name} rejected the API key (HTTP ${statusCode}). ${errorBody.slice(0, 200)}`,
        undefined,
        provider.id,
        statusCode,
      );
    }
    if (statusCode === 429) {
      throw new ProviderError(
        'RATE_LIMITED',
        `${provider.name} rate-limited the request (HTTP 429). ${errorBody.slice(0, 200)}`,
        undefined,
        provider.id,
        statusCode,
      );
    }
    if (statusCode >= 500) {
      throw new ProviderError(
        'REQUEST_FAILED',
        `${provider.name} returned HTTP ${statusCode}. ${errorBody.slice(0, 200)}`,
        undefined,
        provider.id,
        statusCode,
      );
    }
    // Other 4xx (400, 404, 422, etc.)
    throw new ProviderError(
      'REQUEST_FAILED',
      `${provider.name} returned HTTP ${statusCode}. ${errorBody.slice(0, 200)}`,
      undefined,
      provider.id,
      statusCode,
    );
  }

  // ── Stream the response ──────────────────────────────────────────────
  if (response.body === null) {
    throw new ProviderError(
      'INVALID_RESPONSE',
      `${provider.name} returned a null response body.`,
      undefined,
      provider.id,
    );
  }

  const chunks: ChatCompletionChunk[] = [];
  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';

  try {
    while (true) {
      let readResult: ReadableStreamReadResult<Uint8Array>;
      try {
        readResult = await reader.read();
      } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') {
          throw new ProviderError(
            'STREAM_ABORTED',
            `Stream from ${provider.name} was aborted.`,
            err,
            provider.id,
          );
        }
        throw new ProviderError(
          'REQUEST_FAILED',
          `Error reading stream from ${provider.name}: ${err instanceof Error ? err.message : String(err)}`,
          err,
          provider.id,
        );
      }

      if (readResult.done) break;

      buffer += decoder.decode(readResult.value, { stream: true });

      // SSE events are separated by \n\n (blank line)
      let eventEnd: number;
      while ((eventEnd = buffer.indexOf('\n\n')) !== -1) {
        const eventBlock = buffer.slice(0, eventEnd);
        buffer = buffer.slice(eventEnd + 2);

        // Each event block may have multiple `data:` lines
        for (const line of eventBlock.split('\n')) {
          const chunk = parseSseDataLine(line);
          if (chunk !== null) {
            chunks.push(chunk);
            onChunk?.(chunk);
          }
        }
      }
    }

    // Flush any remaining buffer (some providers don't terminate with \n\n)
    if (buffer.length > 0) {
      for (const line of buffer.split('\n')) {
        const chunk = parseSseDataLine(line);
        if (chunk !== null) {
          chunks.push(chunk);
          onChunk?.(chunk);
        }
      }
    }
  } finally {
    try {
      reader.releaseLock();
    } catch {
      // ignore — reader may already be released
    }
  }

  if (chunks.length === 0) {
    throw new ProviderError(
      'INVALID_RESPONSE',
      `${provider.name} returned an empty stream (no chunks parsed).`,
      undefined,
      provider.id,
    );
  }

  const completion = aggregateChunks(chunks, model, provider.id);

  logger.debug(
    { module: 'provider-openai', providerId: provider.id, model, chunkCount: chunks.length, contentLength: completion.content.length },
    `Stream complete from ${provider.name}: ${chunks.length} chunks, ${completion.content.length} chars`,
  );

  return completion;
}

// Re-export for convenience
export { ProviderError } from '@/lib/providers/types';
export type {
  ChatCompletion,
  ChatCompletionChunk,
  ChatMessage,
  StreamAdapterParams,
} from '@/lib/providers/types';
