/**
 * Provider System — Type Definitions
 *
 * Blueprint v4.1 §7 (Provider System — 10 Providers), §8 (Z.ai Policy),
 * §20 (Interface-Driven Design), §22 Phase 1 Step 1.1
 *
 * Design goals:
 *  - ProviderKind: matches the Prisma `Provider.kind` field. Four variants
 *    cover every provider in §7 (openai | anthropic | zai | custom).
 *  - ChatMessage: the canonical message shape passed to every adapter.
 *    Matches the OpenAI chat completions message format (which Anthropic
 *    and Z.ai SDKs also accept, modulo minor field-name differences the
 *    adapters handle internally).
 *  - ChatCompletionRequest: the input to every adapter. `stream: true` is
 *    mandatory — we always stream (Blueprint §18: SSE for chat).
 *  - ChatCompletionChunk: the streaming output unit. Each adapter parses
 *    its provider-specific SSE/SDK shape into this normalized chunk.
 *  - ProviderError: branded error class, same pattern as DbError/AuthError/
 *    ValidationError/QueueError/StorageError. 8 codes covering every
 *    failure mode in §7 + §8.
 *  - isProviderError: type guard, robust against cross-realm payloads.
 *  - StreamCallback: the function signature adapters call for each chunk.
 *
 * No runtime code beyond the error class. The adapters live in
 * stream-openai.ts and stream-zai.ts. Keeping types separate makes them
 * importable from test files without pulling in fetch/SDK dependencies.
 */

// ─── ProviderKind (matches Prisma Provider.kind) ───────────────────────────

export type ProviderKind = 'openai' | 'anthropic' | 'zai' | 'custom';

// ─── ChatMessage ───────────────────────────────────────────────────────────

export type ChatRole = 'system' | 'user' | 'assistant' | 'tool';

export interface ToolCall {
  readonly id: string;
  readonly type: 'function';
  readonly function: {
    readonly name: string;
    readonly arguments: string; // JSON-stringified args
  };
}

export interface ChatMessage {
  readonly role: ChatRole;
  readonly content: string;
  /** Present when role='tool' — the ID of the tool call this is responding to. */
  readonly toolCallId?: string;
  /** Present when role='assistant' and the model emitted tool calls. */
  readonly toolCalls?: ReadonlyArray<ToolCall>;
  /** Optional name for tool messages (which tool produced this). */
  readonly name?: string;
}

// ─── Tool definition (for function calling) ────────────────────────────────

export interface ToolFunction {
  readonly name: string;
  readonly description: string;
  readonly parameters: Record<string, unknown>; // JSON Schema
}

export interface Tool {
  readonly type: 'function';
  readonly function: ToolFunction;
}

// ─── ChatCompletionRequest ─────────────────────────────────────────────────

export interface ChatCompletionRequest {
  readonly model: string;
  readonly messages: ReadonlyArray<ChatMessage>;
  readonly temperature?: number;
  readonly maxTokens?: number;
  readonly tools?: ReadonlyArray<Tool>;
  /** Always true in v4.1 — we always stream chat responses. */
  readonly stream: true;
}

// ─── ChatCompletionChunk (streaming output) ────────────────────────────────

export interface ChatCompletionDelta {
  /** Partial content string (may be empty string for tool-call-only chunks). */
  readonly content?: string;
  /** Partial tool calls (may be absent for content-only chunks). */
  readonly toolCalls?: ReadonlyArray<{
    readonly index: number;
    readonly id?: string;
    readonly function?: { readonly name?: string; readonly arguments?: string };
  }>;
  /** The role, present only on the first chunk. */
  readonly role?: ChatRole;
}

export interface ChatCompletionChunk {
  readonly delta: ChatCompletionDelta;
  /** Present on the final chunk: 'stop' | 'tool_calls' | 'length' | 'content_filter'. */
  readonly finishReason?: string;
}

// ─── ChatCompletion (final, non-streaming result) ──────────────────────────
//
// Returned by every adapter after the stream completes. Aggregates all
// chunks into a single message.

export interface ChatCompletion {
  readonly content: string;
  readonly toolCalls: ToolCall[];
  readonly finishReason: string;
  /** Total tokens used (if the provider reports it; otherwise 0). */
  readonly tokensUsed: number;
  /** Estimated cost in USD (if the provider reports it; otherwise 0). */
  readonly costUsd: number;
  readonly model: string;
  readonly providerId: string;
}

// ─── Provider config (mirror of Prisma Provider model) ─────────────────────
//
// Adapters receive a `ProviderConfig` rather than the full Prisma `Provider`
// record. This decouples adapters from Prisma and makes them testable without
// a DB. The registry (future task) reads the Prisma record and constructs
// this config.

export interface ProviderConfig {
  readonly id: string;
  readonly name: string;
  readonly kind: ProviderKind;
  readonly baseUrl: string | null;
  readonly apiKey: string | null;
  readonly enabled: boolean;
  readonly isLocal: boolean;
}

// ─── StreamCallback ────────────────────────────────────────────────────────

export type StreamCallback = (chunk: ChatCompletionChunk) => void;

// ─── Adapter params ────────────────────────────────────────────────────────

export interface StreamAdapterParams {
  readonly provider: ProviderConfig;
  readonly model: string;
  readonly messages: ReadonlyArray<ChatMessage>;
  readonly temperature?: number;
  readonly maxTokens?: number;
  readonly tools?: ReadonlyArray<Tool>;
  /** AbortSignal for cancellation (user clicked "Stop"). */
  readonly signal?: AbortSignal;
  /** Called for each chunk as it arrives. */
  readonly onChunk?: StreamCallback;
}

// ─── ProviderError ─────────────────────────────────────────────────────────

export type ProviderErrorCode =
  | 'PROVIDER_DISABLED'
  | 'PROVIDER_NOT_CONFIGURED'
  | 'REQUEST_FAILED'
  | 'RATE_LIMITED'
  | 'AUTH_FAILED'
  | 'INVALID_RESPONSE'
  | 'STREAM_ABORTED'
  | 'ZAI_DISABLED';

const PROVIDER_ERROR_BRAND = Symbol('ProviderError');

export class ProviderError extends Error {
  public readonly [PROVIDER_ERROR_BRAND]: true = true;
  public readonly code: ProviderErrorCode;
  public readonly cause: unknown;
  public readonly providerId?: string;
  public readonly statusCode?: number;

  public constructor(
    code: ProviderErrorCode,
    message: string,
    cause?: unknown,
    providerId?: string,
    statusCode?: number,
  ) {
    super(message);
    this.name = 'ProviderError';
    this.code = code;
    this.cause = cause;
    this.providerId = providerId;
    this.statusCode = statusCode;
    // Restore prototype chain after subclassing Error (TS/ES2015 target quirk)
    Object.setPrototypeOf(this, ProviderError.prototype);
  }
}

/**
 * Type guard for ProviderError. Use this in catch blocks instead of
 * `instanceof` to remain robust against cross-realm / serialized payloads.
 */
export function isProviderError(error: unknown): error is ProviderError {
  return (
    typeof error === 'object' &&
    error !== null &&
    (error as Record<symbol, unknown>)[PROVIDER_ERROR_BRAND] === true
  );
}
