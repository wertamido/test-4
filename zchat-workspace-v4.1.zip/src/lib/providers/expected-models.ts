/**
 * Expected Model Claims — Static Provider Identity Map
 *
 * Blueprint v4.1 §7 (Provider System), §23 (Testing Strategy — "verify
 * response matches expected model"), §8 (Z.ai Policy)
 *
 * Design goals:
 *  - For each of the 10 providers, define what model name the provider
 *    SHOULD respond with when asked "What model are you?"
 *  - Most providers are honest: the response should match the requested
 *    `model` parameter (e.g., asking OpenAI for gpt-4o should yield a
 *    response mentioning "gpt-4o").
 *  - Z.ai is the exception: per Blueprint §7 + §8, the SDK ignores the
 *    `model` parameter and always serves GLM-4-Plus. The verifier should
 *    expect "GLM" in the response, not the requested model.
 *  - LM Studio is unverifiable: it serves whatever model the user loaded
 *    locally. The verifier returns matched=false but does NOT fail.
 *  - `getExpectedModelClaim(providerId, model)` returns the expected
 *    substring to match against (case-insensitive). For most providers,
 *    this is the `model` string itself. For Z.ai, it's "GLM". For LM
 *    Studio, it's an empty string (signaling unverifiable).
 *  - `UNVERIFIABLE_PROVIDERS` lists provider IDs where verification is not
 *    meaningful. The verifier uses this to short-circuit.
 *
 * The map is provider-id-keyed (matches the IDs in prisma/seed-data.ts).
 * Adding a new provider = add an entry here + seed it.
 */

// ─── Provider IDs (must match prisma/seed-data.ts) ─────────────────────────

export type BuiltinProviderId =
  | 'zai'
  | 'mistral'
  | 'openai'
  | 'anthropic'
  | 'groq'
  | 'together'
  | 'openrouter'
  | 'cloudflare'
  | 'ollama'
  | 'lmstudio';

// ─── Unverifiable providers ────────────────────────────────────────────────
//
// Providers where "what model are you?" cannot be answered statically:
//   - lmstudio: serves whatever the user loaded; no way to predict the
//     response without querying the user's local LM Studio instance
//
// For these providers, verifyProviderModel() returns matched=false but
// does NOT throw — verification is "not applicable" rather than "failed".

export const UNVERIFIABLE_PROVIDERS: ReadonlyArray<BuiltinProviderId> = ['lmstudio'];

export function isUnverifiableProvider(providerId: string): boolean {
  return (UNVERIFIABLE_PROVIDERS as ReadonlyArray<string>).includes(providerId);
}

// ─── Z.ai special case ─────────────────────────────────────────────────────
//
// Blueprint §7: "Z.ai | SDK internal → GLM-4-Plus | SDK token | ⚠️ Ignored
// by SDK". Blueprint §8: "When Z.ai is enabled: SDK serves GLM-4-Plus.
// Model parameter ignored by SDK (SDK always serves glm-4-plus)."
//
// So when the user asks Z.ai for any model, the response should mention
// "GLM" (the SDK serves GLM-4-Plus regardless). The verifier matches
// "GLM" (case-insensitive substring) rather than the requested model.

export const ZAI_EXPECTED_CLAIM = 'GLM';

// ─── getExpectedModelClaim ─────────────────────────────────────────────────
//
// Returns the expected substring to match against (case-insensitive) in the
// provider's "What model are you?" response.
//
//   - Z.ai → 'GLM' (regardless of `model` param)
//   - LM Studio → '' (unverifiable — empty string signals "skip match")
//   - All others → the `model` string itself (provider should echo the model)
//
// The substring match is intentionally loose: "gpt-4o" matches a response
// of "I am GPT-4o" or "gpt-4o-mini" (substring). This tolerates minor
// variations in how models self-identify. Stricter matching (exact equality)
// would fail on legitimate responses like "I'm GPT-4o, made by OpenAI".

export function getExpectedModelClaim(providerId: string, model: string): string {
  // Z.ai: always expect "GLM" regardless of the requested model
  if (providerId === 'zai') {
    return ZAI_EXPECTED_CLAIM;
  }

  // LM Studio: unverifiable — empty string
  if (providerId === 'lmstudio') {
    return '';
  }

  // All other providers: expect the requested model name in the response.
  // The provider should honestly echo what it's running.
  return model;
}

// ─── Expected-claim documentation table ────────────────────────────────────
//
// Documentation only — not used at runtime. Helps reviewers understand
// what each provider should claim. Exported so tests can assert on it.

export interface ProviderExpectedClaimDoc {
  readonly providerId: BuiltinProviderId;
  readonly name: string;
  readonly behavior: 'echo-requested-model' | 'always-zai-glm' | 'unverifiable';
  readonly exampleExpectedClaim: string;
  readonly notes: string;
}

export const PROVIDER_CLAIM_DOCS: ReadonlyArray<ProviderExpectedClaimDoc> = [
  {
    providerId: 'zai',
    name: 'Z.ai',
    behavior: 'always-zai-glm',
    exampleExpectedClaim: 'GLM',
    notes: 'SDK ignores `model` param; always serves GLM-4-Plus. Verifier expects "GLM" in the response.',
  },
  {
    providerId: 'mistral',
    name: 'Mistral',
    behavior: 'echo-requested-model',
    exampleExpectedClaim: 'mistral-large-latest',
    notes: 'Honest about the model. Asking for mistral-large-latest yields a response mentioning "mistral-large-latest" or "Mistral Large".',
  },
  {
    providerId: 'openai',
    name: 'OpenAI',
    behavior: 'echo-requested-model',
    exampleExpectedClaim: 'gpt-4o',
    notes: 'Honest. GPT-4o will identify as "GPT-4o" or similar.',
  },
  {
    providerId: 'anthropic',
    name: 'Anthropic',
    behavior: 'echo-requested-model',
    exampleExpectedClaim: 'claude-3-5-sonnet-latest',
    notes: 'Honest. Claude identifies as "Claude 3.5 Sonnet" or similar. (Anthropic adapter not yet implemented — forward-looking entry.)',
  },
  {
    providerId: 'groq',
    name: 'Groq',
    behavior: 'echo-requested-model',
    exampleExpectedClaim: 'llama-3.3-70b-versatile',
    notes: 'Groq serves the requested model on their hardware. Model identifies itself honestly (e.g., "Llama 3.3 70B").',
  },
  {
    providerId: 'together',
    name: 'Together',
    behavior: 'echo-requested-model',
    exampleExpectedClaim: 'meta-llama/Llama-3.3-70B-Instruct-Turbo',
    notes: 'Together serves the requested model. The model identifies itself by its canonical name.',
  },
  {
    providerId: 'openrouter',
    name: 'OpenRouter',
    behavior: 'echo-requested-model',
    exampleExpectedClaim: 'openai/gpt-4o',
    notes: 'OpenRouter routes to the requested model. The model identifies itself honestly.',
  },
  {
    providerId: 'cloudflare',
    name: 'Cloudflare Workers AI',
    behavior: 'echo-requested-model',
    exampleExpectedClaim: '@cf/meta/llama-3.1-8b-instruct',
    notes: 'Cloudflare serves the requested model. The model identifies itself honestly.',
  },
  {
    providerId: 'ollama',
    name: 'Ollama (Local)',
    behavior: 'echo-requested-model',
    exampleExpectedClaim: 'llama3.2',
    notes: 'Ollama is honest about what\'s running locally. Asking for llama3.2 yields "llama3.2" or "Llama 3.2" in the response.',
  },
  {
    providerId: 'lmstudio',
    name: 'LM Studio (Local)',
    behavior: 'unverifiable',
    exampleExpectedClaim: '',
    notes: 'LM Studio serves whatever the user loaded. Cannot verify statically — verifier returns matched=false but does NOT fail.',
  },
];
