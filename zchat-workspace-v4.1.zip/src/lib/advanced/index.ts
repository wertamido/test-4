/**
 * Advanced Features — Memory System, Token Dashboard, File Upload
 *
 * Blueprint v4.1 §22 Phase 5 (selected high-value items)
 *   5.2 Memory system (3-layer: session / workspace / global)
 *   5.3 Token dashboard (aggregated usage data)
 *   5.1 File upload (10MB/file limit)
 *
 * Consolidated into one module. Each feature is in its own section.
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { LocalStorageAdapter } from '@/lib/storage/local';
import { type StorageAdapter, StorageError, validatePath } from '@/lib/storage/adapter';
import { getSession } from '@/lib/sessions/repository';

// ═══════════════════════════════════════════════════════════════════════════
// 1. MEMORY SYSTEM (3-layer: session / workspace / global)
// ═══════════════════════════════════════════════════════════════════════════

export type MemoryLayer = 'session' | 'workspace' | 'global';

export interface MemoryEntry {
  readonly id: string;
  readonly layer: MemoryLayer;
  readonly sessionId: string | null;
  readonly workspaceId: string | null;
  readonly key: string;
  readonly value: string;
  readonly createdAt: Date;
}

export async function setMemory(params: {
  workspaceId: string;
  sessionId?: string;
  layer: MemoryLayer;
  key: string;
  value: string;
}): Promise<MemoryEntry> {
  // Validate layer + scope consistency
  if (params.layer === 'session' && !params.sessionId) {
    throw new Error('Session layer requires sessionId.');
  }
  if (params.layer === 'workspace' && !params.workspaceId) {
    throw new Error('Workspace layer requires workspaceId.');
  }

  // For session layer, store in AgentMemory (reuses the existing table)
  if (params.layer === 'session' && params.sessionId) {
    await getSession(params.sessionId, params.workspaceId);
    const row = await db.agentMemory.create({
      data: {
        sessionId: params.sessionId,
        key: params.key,
        value: params.value,
        scope: 'session',
      },
    });
    return {
      id: row.id, layer: 'session', sessionId: row.sessionId,
      workspaceId: null, key: row.key, value: row.value, createdAt: row.createdAt,
    };
  }

  // For workspace + global layers, store in a separate key-value structure.
  // The MVP uses the agentMemory table with synthetic session IDs:
  //   workspace layer: sessionId = `__ws__:${workspaceId}`
  //   global layer:    sessionId = `__global__`
  const syntheticSessionId = params.layer === 'workspace'
    ? `__ws__:${params.workspaceId}`
    : '__global__';

  const row = await db.agentMemory.create({
    data: {
      sessionId: syntheticSessionId,
      key: params.key,
      value: params.value,
      scope: params.layer,
    },
  });

  return {
    id: row.id, layer: params.layer,
    sessionId: params.layer === 'session' ? row.sessionId : null,
    workspaceId: params.layer === 'workspace' ? params.workspaceId : null,
    key: row.key, value: row.value, createdAt: row.createdAt,
  };
}

export async function getMemory(params: {
  workspaceId: string;
  sessionId?: string;
  layer: MemoryLayer;
  key: string;
}): Promise<MemoryEntry | null> {
  let sessionId: string;
  if (params.layer === 'session' && params.sessionId) {
    await getSession(params.sessionId, params.workspaceId);
    sessionId = params.sessionId;
  } else if (params.layer === 'workspace') {
    sessionId = `__ws__:${params.workspaceId}`;
  } else {
    sessionId = '__global__';
  }

  const row = await db.agentMemory.findFirst({
    where: { sessionId, key: params.key },
    orderBy: { createdAt: 'desc' },
  });

  if (!row) return null;

  return {
    id: row.id, layer: params.layer,
    sessionId: params.layer === 'session' ? row.sessionId : null,
    workspaceId: params.layer === 'workspace' ? params.workspaceId : null,
    key: row.key, value: row.value, createdAt: row.createdAt,
  };
}

export async function listMemory(params: {
  workspaceId: string;
  sessionId?: string;
  layer?: MemoryLayer;
}): Promise<MemoryEntry[]> {
  const layer = params.layer ?? 'session';
  let sessionId: string;
  if (layer === 'session' && params.sessionId) {
    await getSession(params.sessionId, params.workspaceId);
    sessionId = params.sessionId;
  } else if (layer === 'workspace') {
    sessionId = `__ws__:${params.workspaceId}`;
  } else {
    sessionId = '__global__';
  }

  const rows = await db.agentMemory.findMany({
    where: { sessionId },
    orderBy: { createdAt: 'asc' },
  });

  return rows.map((row) => ({
    id: row.id, layer,
    sessionId: layer === 'session' ? row.sessionId : null,
    workspaceId: layer === 'workspace' ? params.workspaceId : null,
    key: row.key, value: row.value, createdAt: row.createdAt,
  }));
}

// ═══════════════════════════════════════════════════════════════════════════
// 2. TOKEN DASHBOARD
// ═══════════════════════════════════════════════════════════════════════════

export interface DashboardDataPoint {
  readonly date: string; // YYYY-MM-DD
  readonly tokens: number;
  readonly costUsd: number;
  readonly messageCount: number;
}

export interface DashboardSummary {
  readonly totalTokens: number;
  readonly totalCostUsd: number;
  readonly totalMessages: number;
  readonly totalSessions: number;
  readonly byDay: DashboardDataPoint[];
  readonly byProvider: Array<{ providerId: string; tokens: number; costUsd: number; messageCount: number }>;
  readonly byModel: Array<{ model: string; tokens: number; costUsd: number; messageCount: number }>;
}

export async function getDashboardData(userId: string, days: number = 30): Promise<DashboardSummary> {
  // Get all workspaces for the user
  const workspaces = await db.workspace.findMany({
    where: { userId },
    select: { id: true },
  });
  const workspaceIds = workspaces.map((w) => w.id);

  // Get all sessions in those workspaces
  const sessions = await db.session.findMany({
    where: { workspaceId: { in: workspaceIds } },
    select: { id: true },
  });
  const sessionIds = sessions.map((s) => s.id);

  // Get all messages in those sessions
  const messages = await db.message.findMany({
    where: { sessionId: { in: sessionIds } },
    select: {
      tokens: true, costUsd: true,
      providerId: true, model: true,
      createdAt: true, sessionId: true,
    },
    orderBy: { createdAt: 'desc' },
  });

  // Aggregate
  const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const recentMessages = messages.filter((m) => m.createdAt >= cutoff);

  const byDayMap = new Map<string, DashboardDataPoint>();
  const byProviderMap = new Map<string, { tokens: number; costUsd: number; messageCount: number }>();
  const byModelMap = new Map<string, { tokens: number; costUsd: number; messageCount: number }>();

  for (const msg of recentMessages) {
    const dateStr = msg.createdAt.toISOString().slice(0, 10); // YYYY-MM-DD
    const day = byDayMap.get(dateStr) ?? { date: dateStr, tokens: 0, costUsd: 0, messageCount: 0 };
    byDayMap.set(dateStr, {
      ...day,
      tokens: day.tokens + msg.tokens,
      costUsd: day.costUsd + msg.costUsd,
      messageCount: day.messageCount + 1,
    });

    const providerKey = msg.providerId ?? 'unknown';
    const provider = byProviderMap.get(providerKey) ?? { tokens: 0, costUsd: 0, messageCount: 0 };
    byProviderMap.set(providerKey, {
      tokens: provider.tokens + msg.tokens,
      costUsd: provider.costUsd + msg.costUsd,
      messageCount: provider.messageCount + 1,
    });

    const modelKey = msg.model ?? 'unknown';
    const model = byModelMap.get(modelKey) ?? { tokens: 0, costUsd: 0, messageCount: 0 };
    byModelMap.set(modelKey, {
      tokens: model.tokens + msg.tokens,
      costUsd: model.costUsd + msg.costUsd,
      messageCount: model.messageCount + 1,
    });
  }

  return {
    totalTokens: messages.reduce((s, m) => s + m.tokens, 0),
    totalCostUsd: messages.reduce((s, m) => s + m.costUsd, 0),
    totalMessages: messages.length,
    totalSessions: sessions.length,
    byDay: Array.from(byDayMap.values()).sort((a, b) => a.date.localeCompare(b.date)),
    byProvider: Array.from(byProviderMap.entries()).map(([providerId, v]) => ({ providerId, ...v })),
    byModel: Array.from(byModelMap.entries()).map(([model, v]) => ({ model, ...v })),
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// 3. FILE UPLOAD (10MB/file limit)
// ═══════════════════════════════════════════════════════════════════════════

export const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB

export interface UploadedFile {
  readonly path: string;       // Storage path (relative to root)
  readonly filename: string;
  readonly size: number;
  readonly contentType: string;
}

export async function uploadFile(params: {
  workspaceId: string;
  sessionId?: string;
  filename: string;
  content: Buffer;
  contentType?: string;
  storage?: StorageAdapter;
}): Promise<UploadedFile> {
  const { workspaceId, sessionId, filename, content } = params;

  // Validate file size
  if (content.length > MAX_FILE_SIZE_BYTES) {
    throw new Error(`File ${filename} exceeds the 10MB limit (${content.length} bytes).`);
  }

  // Validate filename (path traversal defense)
  const safeFilename = validatePath(filename);

  // Build the storage path: uploads/{workspaceId}/{sessionId?}/{filename}
  const pathParts = ['uploads', workspaceId];
  if (sessionId) {
    await getSession(sessionId, workspaceId);
    pathParts.push(sessionId);
  }
  pathParts.push(safeFilename);
  const storagePath = pathParts.join('/');

  const storage = params.storage ?? new LocalStorageAdapter();
  await storage.save(storagePath, content);

  logger.info(
    { module: 'upload', workspaceId, sessionId, filename: safeFilename, size: content.length, path: storagePath },
    `File uploaded: ${safeFilename} (${content.length} bytes)`,
  );

  return {
    path: storagePath,
    filename: safeFilename,
    size: content.length,
    contentType: params.contentType ?? 'application/octet-stream',
  };
}
