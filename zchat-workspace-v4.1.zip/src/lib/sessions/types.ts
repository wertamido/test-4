/**
 * Session Management — Type Definitions
 *
 * Blueprint v4.1 §6 (Session model), §4 (Mistake #2 — NO pending state),
 * §22 Phase 1 Step 1.3, §24 (Security Model — workspace-scoped access)
 *
 * Design goals:
 *  - SessionStatus: matches the Prisma Session.status comment exactly.
 *    idle | planning | executing | verifying | done | error
 *  - SessionRecord: the canonical session shape consumed by the UI + API.
 *    JSON fields (skillIds, repoIds, mcpServerIds) are PARSED arrays on
 *    read, stringified on write. Callers never touch raw JSON strings.
 *  - CreateSessionInput / UpdateSessionInput / ListSessionsQuery: the three
 *    operation shapes. UpdateSessionInput fields are all optional (partial
 *    update); at least one must be present (enforced in the repository).
 *  - SessionError: branded error class, same pattern as DbError/AuthError/
 *    ValidationError/QueueError/StorageError/ProviderError. 7 codes covering
 *    every failure mode in session CRUD + RBAC + status transitions.
 *  - validateStatusTransition: pure function that enforces the session
 *    lifecycle state machine. Exposed so tests can assert on it directly.
 *
 * No runtime code beyond the error class + transition validator. The
 * repository lives in repository.ts.
 *
 * RBAC note (Blueprint §24):
 *   Every repository method takes a `workspaceId` parameter. The repository
 *   enforces that every session belongs to that workspace. The caller (API
 *   route handler) extracts workspaceId from the NextAuth session
 *   (session.user.workspaceId). This means the repository is workspace-
 *   scoped, not user-scoped — the user→workspace mapping is enforced at
 *   the auth layer, not here.
 */

// ─── SessionStatus (matches Prisma Session.status) ─────────────────────────

export type SessionStatus = 'idle' | 'planning' | 'executing' | 'verifying' | 'done' | 'error';

// ─── SessionRecord (Prisma Session model with parsed JSON fields) ──────────

export interface SessionRecord {
  readonly id: string;
  readonly workspaceId: string;
  readonly title: string;
  readonly goal: string | null;
  readonly status: SessionStatus;
  readonly providerId: string | null;
  readonly model: string;
  readonly agentId: string | null;
  /** Parsed from the Prisma JSON string. */
  readonly skillIds: string[];
  /** Parsed from the Prisma JSON string. */
  readonly repoIds: string[];
  /** Parsed from the Prisma JSON string. */
  readonly mcpServerIds: string[];
  readonly pinned: boolean;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

// ─── Operation input types ─────────────────────────────────────────────────

export interface CreateSessionInput {
  readonly workspaceId: string;
  readonly title: string;
  readonly goal?: string;
  readonly providerId?: string;
  readonly model?: string;
}

export interface UpdateSessionInput {
  readonly title?: string;
  readonly goal?: string;
  readonly status?: SessionStatus;
  readonly pinned?: boolean;
  readonly providerId?: string | null;
  readonly model?: string;
  readonly agentId?: string | null;
  readonly skillIds?: string[];
  readonly repoIds?: string[];
  readonly mcpServerIds?: string[];
}

export interface ListSessionsQuery {
  readonly workspaceId: string;
  /** Base64-encoded cursor from a previous listSessions call. */
  readonly cursor?: string;
  /** Default 20, max 100. */
  readonly limit?: number;
  /** Filter by status. */
  readonly status?: SessionStatus;
  /** Filter by pinned flag. */
  readonly pinned?: boolean;
}

export interface ListSessionsResult {
  readonly items: SessionRecord[];
  /** Base64-encoded cursor for the next page, or null if no more items. */
  readonly nextCursor: string | null;
}

// ─── SessionError ──────────────────────────────────────────────────────────

export type SessionErrorCode =
  | 'SESSION_NOT_FOUND'
  | 'WORKSPACE_MISMATCH'
  | 'INVALID_STATUS_TRANSITION'
  | 'CREATE_FAILED'
  | 'UPDATE_FAILED'
  | 'DELETE_FAILED'
  | 'LIST_FAILED';

const SESSION_ERROR_BRAND = Symbol('SessionError');

export class SessionError extends Error {
  public readonly [SESSION_ERROR_BRAND]: true = true;
  public readonly code: SessionErrorCode;
  public readonly cause: unknown;
  public readonly sessionId?: string;
  public readonly workspaceId?: string;

  public constructor(
    code: SessionErrorCode,
    message: string,
    cause?: unknown,
    sessionId?: string,
    workspaceId?: string,
  ) {
    super(message);
    this.name = 'SessionError';
    this.code = code;
    this.cause = cause;
    this.sessionId = sessionId;
    this.workspaceId = workspaceId;
    Object.setPrototypeOf(this, SessionError.prototype);
  }
}

/**
 * Type guard for SessionError. Use this in catch blocks instead of
 * `instanceof` to remain robust against cross-realm / serialized payloads.
 */
export function isSessionError(error: unknown): error is SessionError {
  return (
    typeof error === 'object' &&
    error !== null &&
    (error as Record<symbol, unknown>)[SESSION_ERROR_BRAND] === true
  );
}

// ─── Status transition validation ──────────────────────────────────────────
//
// Session lifecycle state machine (Blueprint §5, §10):
//
//   idle → planning → executing → verifying → done
//                                          → error
//
// Rules:
//   1. Forward progress only — you can skip stages (idle → done is valid for
//      instant mode) but never go backward (planning → idle is invalid).
//   2. `error` is reachable from any non-terminal state (idle, planning,
//      executing, verifying).
//   3. `done` and `error` are terminal — no transitions out. To retry, the
//      user creates a new session.
//
// Implementation: assign each status a numeric order. A transition is valid
// if (a) the target is `error` AND the current is not terminal, OR (b) the
// target's order is strictly greater than the current's order (forward
// progress, and the current is not terminal).

const STATUS_ORDER: Readonly<Record<SessionStatus, number>> = {
  idle: 0,
  planning: 1,
  executing: 2,
  verifying: 3,
  done: 4,
  error: 5,
};

const TERMINAL_STATUSES: ReadonlySet<SessionStatus> = new Set(['done', 'error']);

/**
 * Validate that transitioning from `from` to `to` is allowed.
 * Returns `true` if valid, `false` otherwise.
 *
 * Pure function — no side effects. Exported so tests can assert directly.
 */
export function isValidStatusTransition(
  from: SessionStatus,
  to: SessionStatus,
): boolean {
  // No transition needed (same status)
  if (from === to) return true;

  // Terminal states cannot transition out
  if (TERMINAL_STATUSES.has(from)) return false;

  // `error` is reachable from any non-terminal state
  if (to === 'error') return true;

  // Forward progress: target order must be strictly greater
  return STATUS_ORDER[to] > STATUS_ORDER[from];
}

// ─── Cursor encoding / decoding ────────────────────────────────────────────
//
// Cursor = base64-encoded JSON of { createdAt: ISO string, id: string }.
// The createdAt + id pair is deterministic — even if two sessions share
// the same createdAt, the id breaks the tie.
//
// Encoding/decoding is exported so tests can construct cursors directly.

export interface SessionCursor {
  readonly createdAt: string; // ISO 8601
  readonly id: string;
}

export function encodeCursor(cursor: SessionCursor): string {
  return Buffer.from(JSON.stringify(cursor), 'utf8').toString('base64url');
}

export function decodeCursor(encoded: string): SessionCursor {
  try {
    const json = Buffer.from(encoded, 'base64url').toString('utf8');
    const parsed = JSON.parse(json) as Partial<SessionCursor>;
    if (
      typeof parsed.createdAt !== 'string' ||
      typeof parsed.id !== 'string'
    ) {
      throw new Error('Cursor missing required fields');
    }
    return { createdAt: parsed.createdAt, id: parsed.id };
  } catch (err) {
    throw new SessionError(
      'LIST_FAILED',
      `Invalid cursor: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}
