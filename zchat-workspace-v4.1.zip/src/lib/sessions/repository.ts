/**
 * Session Repository — CRUD + RBAC + Status Transitions + Cursor Pagination
 *
 * Blueprint v4.1 §6 (Session model), §4 (NO pending state), §22 Phase 1 Step 1.3,
 * §24 (Security Model — workspace-scoped access)
 *
 * Design goals:
 *  - DB is the single source of truth (Blueprint §4). No in-memory cache.
 *    Every read goes to the DB; every write goes to the DB.
 *  - Every method enforces workspace-scoped RBAC: the caller passes
 *    `workspaceId`, and the repository verifies every session belongs to
 *    that workspace. Cross-workspace access throws WORKSPACE_MISMATCH.
 *  - Status transitions are validated (Blueprint §5, §10 lifecycle):
 *    idle → planning → executing → verifying → done; error from any
 *    non-terminal state; done + error are terminal.
 *  - JSON fields (skillIds, repoIds, mcpServerIds) are PARSED on read
 *    (Prisma stores them as strings) and STRINGIFIED on write. Callers
 *    never touch raw JSON strings.
 *  - Cursor pagination: cursor = base64(createdAt + id). Deterministic
 *    ordering even when multiple sessions share the same createdAt.
 *  - Uses the db singleton from @/lib/db (no separate PrismaClient).
 *  - Uses the logger from @/lib/logger for structured logging.
 *  - Strictly typed. No `any`.
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import {
  type CreateSessionInput,
  type ListSessionsQuery,
  type ListSessionsResult,
  type SessionRecord,
  type SessionStatus,
  type UpdateSessionInput,
  SessionError,
  isValidStatusTransition,
  encodeCursor,
  decodeCursor,
} from '@/lib/sessions/types';

// ─── Constants ─────────────────────────────────────────────────────────────

const DEFAULT_MODEL = 'glm-4.6';
const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 100;

// ─── Helpers: parse / stringify JSON fields ────────────────────────────────

/**
 * Parse a Prisma Session row into a SessionRecord with parsed JSON arrays.
 * The Prisma model stores skillIds/repoIds/mcpServerIds as JSON strings;
 * this function parses them into string arrays.
 */
function parseSessionRecord(row: {
  id: string;
  workspaceId: string;
  title: string;
  goal: string | null;
  status: string;
  providerId: string | null;
  model: string;
  agentId: string | null;
  skillIds: string;
  repoIds: string;
  mcpServerIds: string;
  pinned: boolean;
  createdAt: Date;
  updatedAt: Date;
}): SessionRecord {
  let skillIds: string[] = [];
  let repoIds: string[] = [];
  let mcpServerIds: string[] = [];

  try {
    skillIds = JSON.parse(row.skillIds) as string[];
  } catch {
    // Corrupt JSON — default to empty array rather than crashing
    skillIds = [];
  }
  try {
    repoIds = JSON.parse(row.repoIds) as string[];
  } catch {
    repoIds = [];
  }
  try {
    mcpServerIds = JSON.parse(row.mcpServerIds) as string[];
  } catch {
    mcpServerIds = [];
  }

  return {
    id: row.id,
    workspaceId: row.workspaceId,
    title: row.title,
    goal: row.goal,
    status: row.status as SessionStatus,
    providerId: row.providerId,
    model: row.model,
    agentId: row.agentId,
    skillIds,
    repoIds,
    mcpServerIds,
    pinned: row.pinned,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };
}

// ─── createSession ─────────────────────────────────────────────────────────

export async function createSession(input: CreateSessionInput): Promise<SessionRecord> {
  const { workspaceId, title, goal, providerId, model } = input;

  if (title.length === 0) {
    throw new SessionError(
      'CREATE_FAILED',
      'Session title must not be empty.',
      undefined,
      undefined,
      workspaceId,
    );
  }

  try {
    const row = await db.session.create({
      data: {
        workspaceId,
        title,
        goal: goal ?? null,
        status: 'idle',
        providerId: providerId ?? null,
        model: model ?? DEFAULT_MODEL,
        agentId: null,
        skillIds: '[]',
        repoIds: '[]',
        mcpServerIds: '[]',
        pinned: false,
      },
    });

    const record = parseSessionRecord(row);

    logger.info(
      { module: 'sessions', op: 'create', sessionId: record.id, workspaceId, title },
      `Session created: ${record.id}`,
    );

    return record;
  } catch (err) {
    if (err instanceof SessionError) throw err;
    throw new SessionError(
      'CREATE_FAILED',
      `Failed to create session: ${err instanceof Error ? err.message : String(err)}`,
      err,
      undefined,
      workspaceId,
    );
  }
}

// ─── getSession ────────────────────────────────────────────────────────────

export async function getSession(
  sessionId: string,
  workspaceId: string,
): Promise<SessionRecord> {
  try {
    const row = await db.session.findUnique({
      where: { id: sessionId },
    });

    if (!row) {
      throw new SessionError(
        'SESSION_NOT_FOUND',
        `Session ${sessionId} not found.`,
        undefined,
        sessionId,
        workspaceId,
      );
    }

    // RBAC: session must belong to the caller's workspace
    if (row.workspaceId !== workspaceId) {
      throw new SessionError(
        'WORKSPACE_MISMATCH',
        `Session ${sessionId} belongs to workspace ${row.workspaceId}, not ${workspaceId}.`,
        undefined,
        sessionId,
        workspaceId,
      );
    }

    return parseSessionRecord(row);
  } catch (err) {
    if (err instanceof SessionError) throw err;
    throw new SessionError(
      'SESSION_NOT_FOUND',
      `Failed to fetch session ${sessionId}: ${err instanceof Error ? err.message : String(err)}`,
      err,
      sessionId,
      workspaceId,
    );
  }
}

// ─── updateSession ─────────────────────────────────────────────────────────

export async function updateSession(
  sessionId: string,
  workspaceId: string,
  input: UpdateSessionInput,
): Promise<SessionRecord> {
  // Verify the session exists + belongs to the workspace (RBAC)
  const existing = await getSession(sessionId, workspaceId);

  // Validate status transition if status is being updated
  if (input.status !== undefined && input.status !== existing.status) {
    if (!isValidStatusTransition(existing.status, input.status)) {
      throw new SessionError(
        'INVALID_STATUS_TRANSITION',
        `Cannot transition session ${sessionId} from '${existing.status}' to '${input.status}'.`,
        undefined,
        sessionId,
        workspaceId,
      );
    }
  }

  // Build the update data — only include fields that are present in the input
  const data: Record<string, unknown> = {};
  if (input.title !== undefined) data['title'] = input.title;
  if (input.goal !== undefined) data['goal'] = input.goal;
  if (input.status !== undefined) data['status'] = input.status;
  if (input.pinned !== undefined) data['pinned'] = input.pinned;
  if (input.providerId !== undefined) data['providerId'] = input.providerId;
  if (input.model !== undefined) data['model'] = input.model;
  if (input.agentId !== undefined) data['agentId'] = input.agentId;
  if (input.skillIds !== undefined) data['skillIds'] = JSON.stringify(input.skillIds);
  if (input.repoIds !== undefined) data['repoIds'] = JSON.stringify(input.repoIds);
  if (input.mcpServerIds !== undefined) data['mcpServerIds'] = JSON.stringify(input.mcpServerIds);

  if (Object.keys(data).length === 0) {
    throw new SessionError(
      'UPDATE_FAILED',
      'UpdateSessionInput must contain at least one field.',
      undefined,
      sessionId,
      workspaceId,
    );
  }

  try {
    const row = await db.session.update({
      where: { id: sessionId },
      data,
    });

    const record = parseSessionRecord(row);

    logger.info(
      {
        module: 'sessions',
        op: 'update',
        sessionId,
        workspaceId,
        updatedFields: Object.keys(data),
      },
      `Session updated: ${sessionId}`,
    );

    return record;
  } catch (err) {
    if (err instanceof SessionError) throw err;
    throw new SessionError(
      'UPDATE_FAILED',
      `Failed to update session ${sessionId}: ${err instanceof Error ? err.message : String(err)}`,
      err,
      sessionId,
      workspaceId,
    );
  }
}

// ─── deleteSession ─────────────────────────────────────────────────────────

export async function deleteSession(
  sessionId: string,
  workspaceId: string,
): Promise<void> {
  // Verify the session exists + belongs to the workspace (RBAC)
  await getSession(sessionId, workspaceId);

  try {
    // Cascading delete is handled by Prisma (sessions → messages, agentRuns,
    // tasks, artifacts, jobs, reasoningRuns) per the schema's onDelete: Cascade
    await db.session.delete({
      where: { id: sessionId },
    });

    logger.info(
      { module: 'sessions', op: 'delete', sessionId, workspaceId },
      `Session deleted: ${sessionId}`,
    );
  } catch (err) {
    if (err instanceof SessionError) throw err;
    throw new SessionError(
      'DELETE_FAILED',
      `Failed to delete session ${sessionId}: ${err instanceof Error ? err.message : String(err)}`,
      err,
      sessionId,
      workspaceId,
    );
  }
}

// ─── listSessions ──────────────────────────────────────────────────────────
//
// Cursor-based pagination. The cursor encodes (createdAt, id) so the
// ordering is deterministic even when multiple sessions share the same
// createdAt. Items are ordered by createdAt DESC, id DESC (newest first).
//
// The nextCursor is null when the current page returned fewer items than
// `limit` (indicating no more items) OR when the query returned exactly
// `limit` items but there are no more (checked by attempting to fetch one
// extra). For simplicity, we fetch `limit + 1` items; if we get `limit + 1`,
// there are more — we return the first `limit` and use the last item's
// (createdAt, id) as the nextCursor.

export async function listSessions(query: ListSessionsQuery): Promise<ListSessionsResult> {
  const { workspaceId, status, pinned } = query;
  const limit = Math.min(Math.max(query.limit ?? DEFAULT_LIMIT, 1), MAX_LIMIT);

  // Build the where clause
  const where: Record<string, unknown> = { workspaceId };
  if (status !== undefined) {
    where['status'] = status;
  }
  if (pinned !== undefined) {
    where['pinned'] = pinned;
  }

  // Decode the cursor if present
  let cursorCondition: Record<string, unknown> | undefined;
  if (query.cursor !== undefined) {
    try {
      const cursor = decodeCursor(query.cursor);
      const cursorDate = new Date(cursor.createdAt);
      // Items strictly "before" the cursor in DESC order:
      // createdAt < cursor.createdAt OR (createdAt = cursor.createdAt AND id < cursor.id)
      cursorCondition = {
        OR: [
          { createdAt: { lt: cursorDate } },
          {
            createdAt: cursorDate,
            id: { lt: cursor.id },
          },
        ],
      };
    } catch (err) {
      if (err instanceof SessionError) throw err;
      throw new SessionError(
        'LIST_FAILED',
        `Invalid cursor: ${err instanceof Error ? err.message : String(err)}`,
        err,
        undefined,
        workspaceId,
      );
    }
  }

  const fullWhere =
    cursorCondition !== undefined
      ? { AND: [where, cursorCondition] }
      : where;

  try {
    // Fetch limit + 1 to determine if there's a next page
    const rows = await db.session.findMany({
      where: fullWhere,
      orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
      take: limit + 1,
    });

    const hasMore = rows.length > limit;
    const pageRows = hasMore ? rows.slice(0, limit) : rows;
    const items = pageRows.map(parseSessionRecord);

    let nextCursor: string | null = null;
    if (hasMore && items.length > 0) {
      const last = items[items.length - 1]!;
      nextCursor = encodeCursor({
        createdAt: last.createdAt.toISOString(),
        id: last.id,
      });
    }

    logger.debug(
      {
        module: 'sessions',
        op: 'list',
        workspaceId,
        status,
        pinned,
        limit,
        returned: items.length,
        hasMore,
      },
      `Listed ${items.length} sessions (hasMore=${hasMore})`,
    );

    return { items, nextCursor };
  } catch (err) {
    if (err instanceof SessionError) throw err;
    throw new SessionError(
      'LIST_FAILED',
      `Failed to list sessions: ${err instanceof Error ? err.message : String(err)}`,
      err,
      undefined,
      workspaceId,
    );
  }
}

// ─── pinSession ────────────────────────────────────────────────────────────

export async function pinSession(
  sessionId: string,
  workspaceId: string,
  pinned: boolean,
): Promise<SessionRecord> {
  return updateSession(sessionId, workspaceId, { pinned });
}

// ─── Re-exports ────────────────────────────────────────────────────────────

export { SessionError, isSessionError } from '@/lib/sessions/types';
export type {
  CreateSessionInput,
  ListSessionsQuery,
  ListSessionsResult,
  SessionRecord,
  SessionStatus,
  UpdateSessionInput,
} from '@/lib/sessions/types';
