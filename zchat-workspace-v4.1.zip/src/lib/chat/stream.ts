/**
 * Chat Streaming Orchestrator — SSE
 *
 * Blueprint v4.1 §18 (SSE for chat), §4 (NO pending state), §22 Phase 1 Step 1.4
 *
 * Lifecycle:
 *   1. RBAC: verify session belongs to workspace
 *   2. Persist user message to DB (BEFORE streaming — no pending state)
 *   3. Yield user_message_saved event
 *   4. Load conversation history from DB
 *   5. Look up provider config from DB
 *   6. Dispatch to streamOpenAICompatible or streamZai based on provider.kind
 *   7. Stream tokens: yield token events as they arrive
 *   8. On completion: persist assistant message (AFTER streaming — no partials stored)
 *   9. Yield assistant_message_saved event
 *  10. On error: yield error event, persist assistant message with error text
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { getSession } from '@/lib/sessions/repository';
import {
  createMessage,
  getMessages,
  type MessageRecord,
  type ToolCall,
} from '@/lib/chat/messages';
import {
  type ProviderConfig,
  type ChatMessage,
  type ChatCompletion,
  ProviderError,
} from '@/lib/providers/types';
import { streamOpenAICompatible } from '@/lib/providers/stream-openai';
import { streamZai } from '@/lib/providers/stream-zai';

// ─── Types ─────────────────────────────────────────────────────────────────

export interface StreamChatParams {
  readonly sessionId: string;
  readonly workspaceId: string;
  readonly userId: string;
  readonly content: string;
  readonly providerId: string;
  readonly model: string;
  readonly skillIds?: ReadonlyArray<string>;
  readonly repoIds?: ReadonlyArray<string>;
  readonly mcpServerIds?: ReadonlyArray<string>;
  readonly signal?: AbortSignal;
}

export interface UserMessageSavedEvent {
  readonly type: 'user_message_saved';
  readonly message: MessageRecord;
}

export interface TokenEvent {
  readonly type: 'token';
  readonly content: string;
}

export interface AssistantMessageSavedEvent {
  readonly type: 'assistant_message_saved';
  readonly message: MessageRecord;
}

export interface ErrorEvent {
  readonly type: 'error';
  readonly code: string;
  readonly message: string;
}

export type ChatStreamEvent =
  | UserMessageSavedEvent
  | TokenEvent
  | AssistantMessageSavedEvent
  | ErrorEvent;

// ─── Provider lookup ───────────────────────────────────────────────────────

async function lookupProvider(providerId: string): Promise<ProviderConfig> {
  const row = await db.provider.findUnique({ where: { id: providerId } });
  if (!row) {
    throw new ProviderError(
      'PROVIDER_NOT_CONFIGURED',
      `Provider ${providerId} not found in DB.`,
      undefined,
      providerId,
    );
  }
  return {
    id: row.id,
    name: row.name,
    kind: row.kind as ProviderConfig['kind'],
    baseUrl: row.baseUrl,
    apiKey: row.apiKey,
    enabled: row.enabled,
    isLocal: row.isLocal,
  };
}

// ─── System prompt assembly ────────────────────────────────────────────────
//
// Blueprint §12: System Prompt Assembly Order
//   1. Base system prompt (or user override)
//   2. Agent persona (if selected)
//   3. Skills sorted ASCENDING (Light → Medium → Strict)
//   4. Pinned repo context (README + 5 citation rules)
//   5. Conversation history
//
// For the MVP chat stream, we assemble (1) + (3) + (5). Agent personas (2)
// and repo context (4) come in Phase 1 Steps 1.6 + 1.8.

async function buildSystemPrompt(params: StreamChatParams): Promise<string> {
  const parts: string[] = [];

  // 1. Base system prompt
  parts.push('You are Z-Chat Workspace, a helpful AI assistant. Be concise and accurate.');

  // 3. Skills (Phase 1 Step 1.5 will populate this — for now, look up enabled skills by ID)
  if (params.skillIds && params.skillIds.length > 0) {
    try {
      const skills = await db.skill.findMany({
        where: { id: { in: [...params.skillIds] }, enabled: true },
        orderBy: { strength: 'asc' }, // Light → Medium → Strict
      });
      for (const skill of skills) {
        parts.push(`\n--- Skill: ${skill.name} (strength ${skill.strength}) ---\n${skill.systemPrompt}`);
      }
    } catch (err) {
      logger.warn(
        { module: 'chat', err, skillIds: params.skillIds },
        `Failed to load skills: ${err instanceof Error ? err.message : String(err)}`,
      );
    }
  }

  return parts.join('\n\n');
}

// ─── streamChat (async generator) ──────────────────────────────────────────

export async function* streamChat(
  params: StreamChatParams,
): AsyncGenerator<ChatStreamEvent> {
  const { sessionId, workspaceId, userId, content, providerId, model, signal } = params;

  logger.info(
    { module: 'chat', op: 'stream', sessionId, workspaceId, userId, providerId, model, contentLength: content.length },
    `Chat stream starting: session=${sessionId} provider=${providerId} model=${model}`,
  );

  // ── 1. RBAC: verify session belongs to workspace ──────────────────────
  const session = await getSession(sessionId, workspaceId);

  // ── 2. Persist user message BEFORE streaming (no pending state) ────────
  const userMessage = await createMessage(sessionId, 'user', content, {
    providerId,
    model,
  });

  // ── 3. Yield user_message_saved ────────────────────────────────────────
  yield { type: 'user_message_saved', message: userMessage };

  // ── 4. Build system prompt + load conversation history ─────────────────
  const systemPrompt = await buildSystemPrompt(params);

  // Load history (excluding the just-saved user message — we'll add it manually)
  const history = await getMessages(sessionId, workspaceId, { limit: 50 });

  const chatMessages: ChatMessage[] = [
    { role: 'system', content: systemPrompt },
    // Include history EXCEPT the last message (which is the user message we just saved)
    ...history
      .filter((m) => m.id !== userMessage.id)
      .map((m): ChatMessage => ({
        role: m.role,
        content: m.content,
        ...(m.toolCalls.length > 0 ? { toolCalls: m.toolCalls } : {}),
      })),
    // The current user message
    { role: 'user', content },
  ];

  // ── 5. Look up provider config ─────────────────────────────────────────
  const provider = await lookupProvider(providerId);

  // ── 6. Dispatch to the appropriate adapter ─────────────────────────────
  let completion: ChatCompletion;
  try {
    const adapterParams = {
      provider,
      model,
      messages: chatMessages,
      stream: true as const,
      signal,
      onChunk: (chunk: { delta: { content?: string } }) => {
        // We can't yield from inside onChunk (it's a sync callback), so we
        // collect content here and yield in the loop below. The adapter
        // calls onChunk synchronously per chunk; we accumulate + yield after.
        // NOTE: The actual token-by-token streaming is handled by the adapter
        // itself. For true streaming, the API route handler should use the
        // onChunk callback to write SSE data directly. This generator yields
        // the aggregated result. See streamChatToSse for the SSE wrapper.
        void chunk; // placeholder — see note above
      },
    };

    if (provider.kind === 'zai') {
      completion = await streamZai(adapterParams);
    } else if (provider.kind === 'openai') {
      completion = await streamOpenAICompatible(adapterParams);
    } else {
      throw new ProviderError(
        'PROVIDER_NOT_CONFIGURED',
        `Provider kind '${provider.kind}' is not supported for chat streaming.`,
        undefined,
        providerId,
      );
    }
  } catch (err) {
    // ── 10. Error path: yield error + persist error message ───────────────
    const errorCode = err instanceof ProviderError ? err.code : 'STREAM_FAILED';
    const errorMessage = err instanceof Error ? err.message : String(err);

    logger.error(
      { module: 'chat', op: 'stream', sessionId, err, errorCode },
      `Chat stream failed: ${errorMessage}`,
    );

    yield { type: 'error', code: errorCode, message: errorMessage };

    // Persist an assistant message with the error text so the conversation
    // history shows what went wrong
    const errorMessageRecord = await createMessage(
      sessionId,
      'assistant',
      `[Error: ${errorMessage}]`,
      { providerId, model, tokens: 0, costUsd: 0 },
    );
    yield { type: 'assistant_message_saved', message: errorMessageRecord };

    return;
  }

  // ── 7. Yield token events ──────────────────────────────────────────────
  //
  // For the MVP, we yield the complete content as a single token event.
  // True token-by-token streaming (where each chunk is yielded as it arrives
  // from the provider) requires the API route handler to use the adapter's
  // onChunk callback directly. This generator yields the aggregated content
  // as one token event for simplicity. Phase 1 Step 1.4 (API route) will
  // wire up true streaming.
  if (completion.content.length > 0) {
    yield { type: 'token', content: completion.content };
  }

  // ── 8. Persist assistant message AFTER streaming ───────────────────────
  const assistantMessage = await createMessage(
    sessionId,
    'assistant',
    completion.content,
    {
      providerId,
      model,
      tokens: completion.tokensUsed,
      costUsd: completion.costUsd,
      ...(completion.toolCalls.length > 0 ? { toolCalls: completion.toolCalls as ToolCall[] } : {}),
    },
  );

  // ── 9. Yield assistant_message_saved ───────────────────────────────────
  yield { type: 'assistant_message_saved', message: assistantMessage };

  logger.info(
    { module: 'chat', op: 'stream', sessionId, messageId: assistantMessage.id, tokens: completion.tokensUsed, contentLength: completion.content.length },
    `Chat stream complete: session=${sessionId} message=${assistantMessage.id}`,
  );

  void session; // session was used for RBAC; reference to suppress unused warning
}

// ─── streamChatToSse ───────────────────────────────────────────────────────
//
// Converts the async generator to a ReadableStream<Uint8Array> that emits
// SSE-formatted data. Each event: `data: <JSON>\n\n`. On completion: `data: [DONE]\n\n`.

export function streamChatToSse(
  stream: AsyncGenerator<ChatStreamEvent>,
): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();

  return new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        while (true) {
          const { done, value } = await stream.next();
          if (done) break;
          const sseData = `data: ${JSON.stringify(value)}\n\n`;
          controller.enqueue(encoder.encode(sseData));
        }
        controller.enqueue(encoder.encode('data: [DONE]\n\n'));
      } catch (err) {
        // Emit an error event before closing
        const errorEvent: ChatStreamEvent = {
          type: 'error',
          code: 'STREAM_FAILED',
          message: err instanceof Error ? err.message : String(err),
        };
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(errorEvent)}\n\n`));
        controller.enqueue(encoder.encode('data: [DONE]\n\n'));
      } finally {
        controller.close();
      }
    },
    cancel() {
      // The consumer (API route) aborted the stream. The async generator
      // will be garbage-collected; we can't force-stop it, but it will
      // stop on the next `yield` when the runtime notices the stream is
      // cancelled.
    },
  });
}
