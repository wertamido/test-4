/**
 * Message Persistence Layer
 *
 * Blueprint v4.1 §6 (Message model), §4 (NO pending state), §22 Phase 1 Step 1.4,
 * §24 (workspace-scoped RBAC)
 *
 * The Message table is the conversation log. Every chat turn produces two
 * rows: one for the user message, one for the assistant response. Messages
 * are never mutated or deleted (append-only conversation history).
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { getSession } from '@/lib/sessions/repository';
import {
  type SessionRecord,
} from '@/lib/sessions/types';

// ─── Types ─────────────────────────────────────────────────────────────────

export type MessageRole = 'user' | 'assistant' | 'system' | 'tool';

export interface ToolCall {
  readonly id: string;
  readonly type: 'function';
  readonly function: { readonly name: string; readonly arguments: string };
}

export interface MessageRecord {
  readonly id: string;
  readonly sessionId: string;
  readonly role: MessageRole;
  readonly content: string;
  readonly toolCalls: ToolCall[];
  readonly tokens: number;
  readonly costUsd: number;
  readonly providerId: string | null;
  readonly model: string | null;
  readonly agentRunId: string | null;
  readonly createdAt: Date;
}

export interface CreateMessageOptions {
  readonly providerId?: string | null;
  readonly model?: string | null;
  readonly agentRunId?: string | null;
  readonly toolCalls?: ToolCall[];
  readonly tokens?: number;
  readonly costUsd?: number;
}

export interface GetMessagesOptions {
  /** Base64 cursor encoding { createdAt, id }. Items AFTER this cursor (newer). */
  readonly cursor?: string;
  /** Default 50, max 200. */
  readonly limit?: number;
}

// ─── MessageError ──────────────────────────────────────────────────────────

export type MessageErrorCode = 'MESSAGE_NOT_FOUND' | 'CREATE_FAILED' | 'LIST_FAILED';

const MESSAGE_ERROR_BRAND = Symbol('MessageError');

export class MessageError extends Error {
  public readonly [MESSAGE_ERROR_BRAND]: true = true;
  public readonly code: MessageErrorCode;
  public readonly cause: unknown;
  public readonly messageId?: string;

  public constructor(code: MessageErrorCode, message: string, cause?: unknown, messageId?: string) {
    super(message);
    this.name = 'MessageError';
    this.code = code;
    this.cause = cause;
    this.messageId = messageId;
    Object.setPrototypeOf(this, MessageError.prototype);
  }
}

export function isMessageError(error: unknown): error is MessageError {
  return (
    typeof error === 'object' &&
    error !== null &&
    (error as Record<symbol, unknown>)[MESSAGE_ERROR_BRAND] === true
  );
}

// ─── Helpers ───────────────────────────────────────────────────────────────

function parseMessageRow(row: {
  id: string;
  sessionId: string;
  role: string;
  content: string;
  toolCalls: string;
  tokens: number;
  costUsd: number;
  providerId: string | null;
  model: string | null;
  agentRunId: string | null;
  createdAt: Date;
}): MessageRecord {
  let toolCalls: ToolCall[] = [];
  try {
    const parsed = JSON.parse(row.toolCalls) as unknown;
    if (Array.isArray(parsed)) {
      toolCalls = parsed as ToolCall[];
    }
  } catch {
    toolCalls = [];
  }
  return {
    id: row.id,
    sessionId: row.sessionId,
    role: row.role as MessageRole,
    content: row.content,
    toolCalls,
    tokens: row.tokens,
    costUsd: row.costUsd,
    providerId: row.providerId,
    model: row.model,
    agentRunId: row.agentRunId,
    createdAt: row.createdAt,
  };
}

function encodeMessageCursor(createdAt: Date, id: string): string {
  return Buffer.from(JSON.stringify({ createdAt: createdAt.toISOString(), id }), 'utf8').toString('base64url');
}

function decodeMessageCursor(encoded: string): { createdAt: Date; id: string } {
  try {
    const json = Buffer.from(encoded, 'base64url').toString('utf8');
    const parsed = JSON.parse(json) as { createdAt?: string; id?: string };
    if (typeof parsed.createdAt !== 'string' || typeof parsed.id !== 'string') {
      throw new Error('cursor missing fields');
    }
    return { createdAt: new Date(parsed.createdAt), id: parsed.id };
  } catch (err) {
    throw new MessageError('LIST_FAILED', `Invalid cursor: ${err instanceof Error ? err.message : String(err)}`, err);
  }
}

// ─── createMessage ─────────────────────────────────────────────────────────

export async function createMessage(
  sessionId: string,
  role: MessageRole,
  content: string,
  options?: CreateMessageOptions,
): Promise<MessageRecord> {
  try {
    const row = await db.message.create({
      data: {
        sessionId,
        role,
        content,
        toolCalls: options?.toolCalls ? JSON.stringify(options.toolCalls) : '[]',
        tokens: options?.tokens ?? 0,
        costUsd: options?.costUsd ?? 0,
        providerId: options?.providerId ?? null,
        model: options?.model ?? null,
        agentRunId: options?.agentRunId ?? null,
      },
    });
    const record = parseMessageRow(row);
    logger.debug(
      { module: 'messages', op: 'create', messageId: record.id, sessionId, role, contentLength: content.length },
      `Message created: ${record.id} (role=${role})`,
    );
    return record;
  } catch (err) {
    throw new MessageError(
      'CREATE_FAILED',
      `Failed to create message: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}

// ─── getMessages ───────────────────────────────────────────────────────────

const DEFAULT_MESSAGE_LIMIT = 50;
const MAX_MESSAGE_LIMIT = 200;

export async function getMessages(
  sessionId: string,
  workspaceId: string,
  options?: GetMessagesOptions,
): Promise<MessageRecord[]> {
  // RBAC: verify session belongs to workspace
  await getSession(sessionId, workspaceId);

  const limit = Math.min(Math.max(options?.limit ?? DEFAULT_MESSAGE_LIMIT, 1), MAX_MESSAGE_LIMIT);

  const where: Record<string, unknown> = { sessionId };
  if (options?.cursor !== undefined) {
    try {
      const cursor = decodeMessageCursor(options.cursor);
      where['OR'] = [
        { createdAt: { gt: cursor.createdAt } },
        { createdAt: cursor.createdAt, id: { gt: cursor.id } },
      ];
    } catch (err) {
      if (isMessageError(err)) throw err;
      throw new MessageError('LIST_FAILED', `Invalid cursor: ${err instanceof Error ? err.message : String(err)}`, err);
    }
  }

  try {
    const rows = await db.message.findMany({
      where,
      orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
      take: limit,
    });
    return rows.map(parseMessageRow);
  } catch (err) {
    if (isMessageError(err)) throw err;
    throw new MessageError(
      'LIST_FAILED',
      `Failed to list messages: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}

// ─── getMessage ────────────────────────────────────────────────────────────

export async function getMessage(
  messageId: string,
  workspaceId: string,
): Promise<MessageRecord> {
  try {
    const row = await db.message.findUnique({ where: { id: messageId } });
    if (!row) {
      throw new MessageError('MESSAGE_NOT_FOUND', `Message ${messageId} not found.`, undefined, messageId);
    }
    // RBAC: verify the message's session belongs to the workspace
    await getSession(row.sessionId, workspaceId);
    return parseMessageRow(row);
  } catch (err) {
    if (isMessageError(err)) throw err;
    throw new MessageError(
      'MESSAGE_NOT_FOUND',
      `Failed to fetch message ${messageId}: ${err instanceof Error ? err.message : String(err)}`,
      err,
      messageId,
    );
  }
}

// ─── Cursor export (for pagination) ────────────────────────────────────────

export function getMessageCursor(message: MessageRecord): string {
  return encodeMessageCursor(message.createdAt, message.id);
}

// Re-export session type for convenience
export type { SessionRecord };
