/**
 * Zod Validation Schemas — Every API Input Validated
 *
 * Blueprint v4.1 §0.4 (Zod validation schemas), §23 (Testing Strategy),
 * §10 (orchestration limits), §11 (agent temperature), §12 (skills strength),
 * §14 (github pinning max 3), §17 (job recovery)
 *
 * Design goals:
 *  - Every API input goes through a Zod schema before reaching a handler.
 *    Invalid input = 400 with per-field error messages (Blueprint §0.4).
 *  - Schemas mirror the Prisma model field names exactly (camelCase).
 *  - Every schema exported as both `xxxSchema` (runtime) and `Xxx` (inferred type).
 *  - Business-rule constraints enforced via .refine() where Zod's built-in
 *    validators aren't sufficient; otherwise use .min()/.max()/.int().
 *  - Typed ValidationError mirroring DbError (src/lib/db.ts) and AuthError
 *    (src/lib/auth.ts): branded symbol, type guard, code union.
 *  - validate() helper is the single entrypoint — handlers call
 *    `validate(createSessionSchema, body)` instead of `schema.parse(body)`.
 *
 * Constraints enforced (from blueprint):
 *  - §10  maxDepth 0..3, maxAgents 1..20, maxSubAgents 0..20
 *  - §11  temperature 0..2
 *  - §12  strength 1 | 2 | 3
 *  - §14  repoIds max 3 (pinned repos)
 *  - §17  olderThanMs positive integer, capped at 24h
 *  - §22  pagination limit 1..100, default 20
 *
 * Zod version: v4. The string-format methods (`.email()`, `.url()`) on
 * `z.string()` are deprecated in v4 but still functional; we use them for
 * cross-version compatibility. In pure-v4 environments, callers may swap
 * to the top-level `z.email()` / `z.url()` forms without behavioral change.
 */

import { z, type ZodSchema } from 'zod';

// ─── ValidationError (mirrors DbError / AuthError pattern) ─────────────────

export type ValidationErrorCode = 'VALIDATION_FAILED' | 'SCHEMA_MISSING';

const VALIDATION_ERROR_BRAND = Symbol('ValidationError');

export interface ValidationIssue {
  readonly path: string;
  readonly message: string;
  readonly code: string;
}

export class ValidationError extends Error {
  public readonly [VALIDATION_ERROR_BRAND]: true = true;
  public readonly code: ValidationErrorCode;
  public readonly cause: unknown;
  public readonly issues: ReadonlyArray<ValidationIssue>;

  public constructor(
    code: ValidationErrorCode,
    message: string,
    cause?: unknown,
    issues: ReadonlyArray<ValidationIssue> = [],
  ) {
    super(message);
    this.name = 'ValidationError';
    this.code = code;
    this.cause = cause;
    this.issues = issues;
    // Restore prototype chain after subclassing Error (TS/ES2015 target quirk)
    Object.setPrototypeOf(this, ValidationError.prototype);
  }
}

/**
 * Type guard for ValidationError. Use this in catch blocks instead of
 * `instanceof` to remain robust against cross-realm / serialized payloads.
 */
export function isValidationError(error: unknown): error is ValidationError {
  return (
    typeof error === 'object' &&
    error !== null &&
    (error as Record<symbol, unknown>)[VALIDATION_ERROR_BRAND] === true
  );
}

// ─── validate() helper ─────────────────────────────────────────────────────
//
// Single entrypoint for input validation. Handlers call:
//   const body = validate(createSessionSchema, await req.json());
// On failure, throws ValidationError(code='VALIDATION_FAILED') with the full
// Zod issue list attached. The API error boundary (Task 0.5) catches this and
// returns a 400 with `{ error, issues }`.

export function validate<T>(schema: ZodSchema<T>, input: unknown): T {
  const result = schema.safeParse(input);
  if (!result.success) {
    const issues: ValidationIssue[] = result.error.issues.map((issue) => ({
      path: issue.path.map((segment) => String(segment)).join('.'),
      message: issue.message,
      code: 'invalid_input',
    }));
    throw new ValidationError(
      'VALIDATION_FAILED',
      `Validation failed: ${issues.map((i) => `${i.path || '(root)'}: ${i.message}`).join('; ')}`,
      result.error,
      issues,
    );
  }
  return result.data;
}

/**
 * Non-throwing variant. Returns a discriminated union so callers can avoid
 * try/catch in performance-sensitive paths. Mirrors Zod's `safeParse` shape.
 */
export function safeValidate<T>(
  schema: ZodSchema<T>,
  input: unknown,
):
  | { success: true; data: T }
  | { success: false; error: ValidationError } {
  const result = schema.safeParse(input);
  if (result.success) {
    return { success: true, data: result.data };
  }
  const issues: ValidationIssue[] = result.error.issues.map((issue) => ({
    path: issue.path.map((segment) => String(segment)).join('.'),
    message: issue.message,
    code: 'invalid_input',
  }));
  return {
    success: false,
    error: new ValidationError(
      'VALIDATION_FAILED',
      `Validation failed: ${issues.map((i) => `${i.path || '(root)'}: ${i.message}`).join('; ')}`,
      result.error,
      issues,
    ),
  };
}

// ─── Shared primitives ─────────────────────────────────────────────────────

/** CUID-style identifier. Accepts any non-empty string up to 100 chars. */
export const cuidSchema = z.string().min(1).max(100);

/** Non-empty string with a sane upper bound for general text fields. */
export const nonEmptyStringSchema = z.string().min(1).max(10000);

// ─── Enums (string literal unions) ─────────────────────────────────────────

export const sessionStatusSchema = z.enum([
  'idle',
  'planning',
  'executing',
  'verifying',
  'done',
  'error',
]);
export type SessionStatus = z.infer<typeof sessionStatusSchema>;

export const messageRoleSchema = z.enum(['user', 'assistant', 'system', 'tool']);
export type MessageRole = z.infer<typeof messageRoleSchema>;

export const providerKindSchema = z.enum(['openai', 'anthropic', 'zai', 'custom']);
export type ProviderKind = z.infer<typeof providerKindSchema>;

export const agentCategorySchema = z.enum(['orchestrator', 'worker', 'specialist']);
export type AgentCategory = z.infer<typeof agentCategorySchema>;

export const mcpTransportSchema = z.enum(['stdio', 'sse']);
export type McpTransport = z.infer<typeof mcpTransportSchema>;

export const orchestrateModeSchema = z.enum(['auto', 'manual']);
export type OrchestrateMode = z.infer<typeof orchestrateModeSchema>;

export const reasoningModeSchema = z.enum([
  'instant',
  'standard',
  'reasoning',
  'deep',
  'autonomous',
]);
export type ReasoningMode = z.infer<typeof reasoningModeSchema>;

export const exportFormatSchema = z.enum(['zip', 'tar']);
export type ExportFormat = z.infer<typeof exportFormatSchema>;

export const githubSortSchema = z.enum(['stars', 'updated', 'forks']);
export type GithubSort = z.infer<typeof githubSortSchema>;

export const jobTypeSchema = z.enum([
  'chat',
  'reasoning',
  'agent_run',
  'title_gen',
  'mcp_discover',
]);
export type JobType = z.infer<typeof jobTypeSchema>;

export const jobStatusEnumSchema = z.enum(['queued', 'running', 'done', 'failed']);
export type JobStatus = z.infer<typeof jobStatusEnumSchema>;

export const taskStatusSchema = z.enum([
  'pending',
  'in_progress',
  'blocked',
  'done',
  'failed',
]);
export type TaskStatus = z.infer<typeof taskStatusSchema>;

export const agentRunStatusSchema = z.enum([
  'pending',
  'planning',
  'executing',
  'waiting_subagents',
  'merging',
  'done',
  'error',
]);
export type AgentRunStatus = z.infer<typeof agentRunStatusSchema>;

export const artifactTypeSchema = z.enum([
  'code',
  'diff',
  'doc',
  'design',
  'data',
  'test',
]);
export type ArtifactType = z.infer<typeof artifactTypeSchema>;

export const agentMessageTypeSchema = z.enum([
  'task_assignment',
  'task_result',
  'question',
  'finding',
  'handoff',
]);
export type AgentMessageType = z.infer<typeof agentMessageTypeSchema>;

export const memoryScopeSchema = z.enum(['session', 'workspace', 'global']);
export type MemoryScope = z.infer<typeof memoryScopeSchema>;

// ─── Pagination (§22 — limit 1..100, default 20) ───────────────────────────

export const paginationSchema = z.object({
  cursor: z.string().min(1).max(200).optional(),
  limit: z.number().int().min(1).max(100).default(20),
});
export type Pagination = z.infer<typeof paginationSchema>;

// ─── Session ───────────────────────────────────────────────────────────────

export const createSessionSchema = z.object({
  title: z.string().min(1).max(200),
  goal: z.string().max(10000).optional(),
});
export type CreateSession = z.infer<typeof createSessionSchema>;

export const updateSessionSchema = z
  .object({
    title: z.string().min(1).max(200).optional(),
    goal: z.string().max(10000).optional(),
    status: sessionStatusSchema.optional(),
    pinned: z.boolean().optional(),
  })
  .refine((data) => Object.keys(data).length > 0, {
    message: 'At least one field must be provided',
  });
export type UpdateSession = z.infer<typeof updateSessionSchema>;

export const listSessionsSchema = z.object({
  workspaceId: cuidSchema,
  cursor: z.string().min(1).max(200).optional(),
  limit: z.number().int().min(1).max(100).default(20),
});
export type ListSessions = z.infer<typeof listSessionsSchema>;

// ─── Message ───────────────────────────────────────────────────────────────
//
// `role` defaults to 'user' — the only role a client may send. Assistant,
// system, and tool messages are created server-side only.

export const sendMessageSchema = z.object({
  sessionId: cuidSchema,
  content: z.string().min(1).max(32000),
  role: z.literal('user').default('user'),
  skillIds: z.array(cuidSchema).max(42).optional(),
  repoIds: z.array(cuidSchema).max(3).optional(), // §14 — max 3 pinned repos
  mcpServerIds: z.array(cuidSchema).max(10).optional(),
});
export type SendMessage = z.infer<typeof sendMessageSchema>;

// ─── Provider ──────────────────────────────────────────────────────────────

export const createProviderSchema = z.object({
  id: z.string().min(1).max(100),
  name: z.string().min(1).max(100),
  kind: providerKindSchema,
  baseUrl: z.string().url().optional(),
  apiKey: z.string().max(500).optional(),
  models: z.array(z.string().min(1).max(100)).max(100).optional(),
  enabled: z.boolean(),
  isLocal: z.boolean(),
  installUrl: z.string().url().optional(),
  docsUrl: z.string().url().optional(),
});
export type CreateProvider = z.infer<typeof createProviderSchema>;

export const updateProviderSchema = z
  .object({
    enabled: z.boolean().optional(),
    apiKey: z.string().max(500).optional(),
    models: z.array(z.string().min(1).max(100)).max(100).optional(),
  })
  .refine((data) => Object.keys(data).length > 0, {
    message: 'At least one field must be provided',
  });
export type UpdateProvider = z.infer<typeof updateProviderSchema>;

export const testProviderSchema = z.object({
  id: z.string().min(1).max(100),
});
export type TestProvider = z.infer<typeof testProviderSchema>;

// ─── Skill (§12 — strength 1|2|3) ──────────────────────────────────────────

export const strengthSchema = z.union([
  z.literal(1),
  z.literal(2),
  z.literal(3),
]);
export type Strength = z.infer<typeof strengthSchema>;

export const createSkillSchema = z.object({
  id: z.string().min(1).max(100),
  name: z.string().min(1).max(100),
  description: z.string().min(1).max(1000),
  systemPrompt: z.string().min(1).max(20000),
  category: z.string().min(1).max(50),
  strength: strengthSchema,
  icon: z.string().min(1).max(50).optional(),
});
export type CreateSkill = z.infer<typeof createSkillSchema>;

export const updateSkillSchema = z
  .object({
    enabled: z.boolean().optional(),
    strength: strengthSchema.optional(),
  })
  .refine((data) => Object.keys(data).length > 0, {
    message: 'At least one field must be provided',
  });
export type UpdateSkill = z.infer<typeof updateSkillSchema>;

// ─── AgentTemplate (§10 — maxSubAgents 0..20, §11 — temperature 0..2) ──────

export const createAgentTemplateSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().min(1).max(1000),
  systemPrompt: z.string().min(1).max(20000),
  category: agentCategorySchema,
  preferredProvider: z.string().min(1).max(100).optional(),
  preferredModel: z.string().min(1).max(100).optional(),
  temperature: z.number().min(0).max(2),
  canSpawnAgents: z.boolean(),
  maxSubAgents: z.number().int().min(0).max(20), // §10 — max 20 agents per session
});
export type CreateAgentTemplate = z.infer<typeof createAgentTemplateSchema>;

export const updateAgentTemplateSchema = z
  .object({
    enabled: z.boolean().optional(),
    temperature: z.number().min(0).max(2).optional(),
    maxSubAgents: z.number().int().min(0).max(20).optional(),
  })
  .refine((data) => Object.keys(data).length > 0, {
    message: 'At least one field must be provided',
  });
export type UpdateAgentTemplate = z.infer<typeof updateAgentTemplateSchema>;

// ─── McpServer ─────────────────────────────────────────────────────────────
//
// Refine: stdio transport requires `command`; sse transport requires `url`.
// This mirrors how MCP servers are actually spawned (Blueprint §13).

export const createMcpServerSchema = z
  .object({
    name: z.string().min(1).max(100),
    transport: mcpTransportSchema,
    command: z.string().min(1).max(500).optional(),
    args: z.array(z.string().max(500)).max(50).optional(),
    url: z.string().url().optional(),
    env: z.record(z.string(), z.string()).optional(),
  })
  .refine(
    (data) =>
      data.transport === 'stdio'
        ? data.command !== undefined
        : data.url !== undefined,
    {
      message:
        'stdio transport requires `command`; sse transport requires `url`',
    },
  );
export type CreateMcpServer = z.infer<typeof createMcpServerSchema>;

export const testMcpServerSchema = z.object({
  id: cuidSchema,
});
export type TestMcpServer = z.infer<typeof testMcpServerSchema>;

export const updateMcpServerSchema = z
  .object({
    enabled: z.boolean().optional(),
    toolsCache: z.array(z.string().max(200)).max(500).optional(),
  })
  .refine((data) => Object.keys(data).length > 0, {
    message: 'At least one field must be provided',
  });
export type UpdateMcpServer = z.infer<typeof updateMcpServerSchema>;

// ─── GithubRepo (§14 — max 3 pinned repos) ─────────────────────────────────

export const searchGithubSchema = z.object({
  query: z.string().min(1).max(500),
  language: z.string().min(1).max(50).optional(),
  sort: githubSortSchema.optional(),
});
export type SearchGithub = z.infer<typeof searchGithubSchema>;

export const importGithubSchema = z.object({
  fullName: z.string().min(1).max(200),
  url: z.string().url(),
  owner: z.string().min(1).max(100),
});
export type ImportGithub = z.infer<typeof importGithubSchema>;

export const pinGithubSchema = z.object({
  repoIds: z.array(cuidSchema).min(0).max(3), // §14 — max 3 pinned repos
});
export type PinGithub = z.infer<typeof pinGithubSchema>;

// ─── Orchestrate (§10 — maxDepth 0..3, maxAgents 1..20) ────────────────────

export const startOrchestrateSchema = z.object({
  sessionId: cuidSchema,
  goal: z.string().min(1).max(10000),
  leadAgentId: cuidSchema,
  providerId: z.string().min(1).max(100),
  model: z.string().min(1).max(100),
  maxDepth: z.number().int().min(0).max(3), // §10 — depth limit 3
  maxAgents: z.number().int().min(1).max(20), // §10 — max 20 agents
  mode: orchestrateModeSchema,
});
export type StartOrchestrate = z.infer<typeof startOrchestrateSchema>;

// ─── Job (§17 — DB-backed queue) ───────────────────────────────────────────

export const getJobStatusSchema = z.object({
  id: cuidSchema,
});
export type GetJobStatus = z.infer<typeof getJobStatusSchema>;

// olderThanMs: positive integer, capped at 24h (Blueprint §17 — worker finds
// 'running' jobs older than 5 minutes and resets them). 24h cap prevents
// accidental recovery of ancient jobs that should stay failed.
export const recoverJobsSchema = z.object({
  olderThanMs: z.number().int().min(1).max(24 * 60 * 60 * 1000),
});
export type RecoverJobs = z.infer<typeof recoverJobsSchema>;

// ─── Reasoning ─────────────────────────────────────────────────────────────

export const startReasoningSchema = z.object({
  sessionId: cuidSchema,
  goal: z.string().min(1).max(10000),
  mode: reasoningModeSchema,
});
export type StartReasoning = z.infer<typeof startReasoningSchema>;

// ─── Workspace settings ────────────────────────────────────────────────────
//
// `settings` is stored as a JSON string in Prisma (model Workspace.settings
// is `String @default("{}")`). Validate that the input is parseable JSON.

export const updateWorkspaceSettingsSchema = z.object({
  settings: z
    .string()
    .min(2)
    .max(100000)
    .refine(
      (val) => {
        try {
          JSON.parse(val);
          return true;
        } catch {
          return false;
        }
      },
      { message: 'settings must be a valid JSON string' },
    ),
});
export type UpdateWorkspaceSettings = z.infer<typeof updateWorkspaceSettingsSchema>;

// ─── Export ────────────────────────────────────────────────────────────────

export const exportProjectSchema = z.object({
  sessionId: cuidSchema,
  format: exportFormatSchema,
});
export type ExportProject = z.infer<typeof exportProjectSchema>;
