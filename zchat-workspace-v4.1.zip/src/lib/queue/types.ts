/**
 * Job Queue — Type Definitions
 *
 * Blueprint v4.1 §17 (Job Queue — Database-Backed, Persistent), §22 Phase 0 Step 0.7
 *
 * Design goals:
 *  - All queue types in one file so the implementation can import a single module
 *  - Discriminated unions for payload + result so handlers can switch on `type`
 *    and get exhaustive type narrowing
 *  - JobRecord mirrors the Prisma Job model 1:1 — no mapping layer needed
 *  - QueueError follows the branded-symbol pattern established by DbError,
 *    AuthError, and ValidationError
 *
 * No runtime code in this file — types only. The implementation lives in
 * src/lib/queue/db-queue.ts. Keeping types separate makes them importable
 * from test files without pulling in the singleton logger / db dependencies.
 */

// ─── JobType (matches Prisma Job.type comment) ─────────────────────────────

export type JobType =
  | 'chat'
  | 'reasoning'
  | 'agent_run'
  | 'title_gen'
  | 'mcp_discover';

// ─── JobStatus (matches Prisma Job.status comment) ─────────────────────────

export type JobStatus = 'queued' | 'running' | 'done' | 'failed';

// ─── Payload variants (discriminated union by `type`) ──────────────────────

export interface ChatJobPayload {
  type: 'chat';
  sessionId: string;
  messageContent: string;
  providerId: string;
  model: string;
  skillIds?: ReadonlyArray<string>;
  repoIds?: ReadonlyArray<string>;
  mcpServerIds?: ReadonlyArray<string>;
}

export interface ReasoningJobPayload {
  type: 'reasoning';
  sessionId: string;
  goal: string;
  mode: 'instant' | 'standard' | 'reasoning' | 'deep' | 'autonomous';
  providerId: string;
  model: string;
}

export interface AgentRunJobPayload {
  type: 'agent_run';
  sessionId: string;
  agentRunId: string;
  task: string;
  providerId: string;
  model: string;
  depth: number;
  parentRunId?: string;
}

export interface TitleGenJobPayload {
  type: 'title_gen';
  sessionId: string;
  firstMessage: string;
  providerId: string;
  model: string;
}

export interface McpDiscoverJobPayload {
  type: 'mcp_discover';
  mcpServerId: string;
  command: string;
  args: ReadonlyArray<string>;
  env?: Readonly<Record<string, string>>;
}

export type JobPayload =
  | ChatJobPayload
  | ReasoningJobPayload
  | AgentRunJobPayload
  | TitleGenJobPayload
  | McpDiscoverJobPayload;

// ─── Result variants (discriminated union by `type`) ───────────────────────

export interface ChatJobResult {
  type: 'chat';
  message: string;
  tokens: number;
  costUsd: number;
}

export interface ReasoningJobResult {
  type: 'reasoning';
  finalAnswer: string;
  totalTokens: number;
  costUsd: number;
  durationMs: number;
}

export interface AgentRunJobResult {
  type: 'agent_run';
  agentRunId: string;
  result: string;
  tokensUsed: number;
  costUsd: number;
  durationMs: number;
}

export interface TitleGenJobResult {
  type: 'title_gen';
  title: string;
}

export interface McpDiscoverJobResult {
  type: 'mcp_discover';
  tools: ReadonlyArray<{ name: string; description: string }>;
}

export type JobResult =
  | ChatJobResult
  | ReasoningJobResult
  | AgentRunJobResult
  | TitleGenJobResult
  | McpDiscoverJobResult;

// ─── JobRecord (Prisma Job model 1:1) ──────────────────────────────────────
//
// Mirrors the Prisma model declared in prisma/schema.prisma. Keeping this
// type hand-written (rather than importing from @prisma/client) means the
// queue module can be unit-tested without the Prisma client being generated
// — useful during early Phase 0 before `prisma generate` has been run.

export interface JobRecord {
  id: string;
  sessionId: string;
  type: JobType;
  status: JobStatus;
  payload: string; // JSON-stringified JobPayload
  result: string | null; // JSON-stringified JobResult
  error: string | null;
  attempts: number;
  maxAttempts: number;
  startedAt: Date | null;
  finishedAt: Date | null;
  createdAt: Date;
}

// ─── JobHandler ────────────────────────────────────────────────────────────

export type JobHandler = (job: JobRecord) => Promise<JobResult>;

// ─── QueueError ────────────────────────────────────────────────────────────
//
// Branded error class — same pattern as DbError, AuthError, ValidationError.
// The symbol brand survives across module boundaries and is robust against
// cross-realm / serialized payloads.

export type QueueErrorCode =
  | 'ENQUEUE_FAILED'
  | 'CLAIM_FAILED'
  | 'COMPLETE_FAILED'
  | 'FAIL_FAILED'
  | 'RECOVER_FAILED'
  | 'NO_HANDLER'
  | 'MAX_ATTEMPTS_EXCEEDED'
  | 'JOB_NOT_FOUND';

const QUEUE_ERROR_BRAND = Symbol('QueueError');

export class QueueError extends Error {
  public readonly [QUEUE_ERROR_BRAND]: true = true;
  public readonly code: QueueErrorCode;
  public readonly cause: unknown;
  public readonly jobId?: string;

  public constructor(
    code: QueueErrorCode,
    message: string,
    cause?: unknown,
    jobId?: string,
  ) {
    super(message);
    this.name = 'QueueError';
    this.code = code;
    this.cause = cause;
    this.jobId = jobId;
    // Restore prototype chain after subclassing Error (TS/ES2015 target quirk)
    Object.setPrototypeOf(this, QueueError.prototype);
  }
}

/**
 * Type guard for QueueError. Use this in catch blocks instead of `instanceof`
 * to remain robust against cross-realm / serialized error payloads.
 */
export function isQueueError(error: unknown): error is QueueError {
  return (
    typeof error === 'object' &&
    error !== null &&
    (error as Record<symbol, unknown>)[QUEUE_ERROR_BRAND] === true
  );
}

// ─── Helpers ───────────────────────────────────────────────────────────────

/**
 * Parse a JobRecord.payload (JSON string) into a typed JobPayload.
 * Throws QueueError on parse failure — never returns `any`.
 */
export function parseJobPayload(payload: string): JobPayload {
  try {
    const parsed = JSON.parse(payload) as unknown;
    if (
      typeof parsed !== 'object' ||
      parsed === null ||
      typeof (parsed as { type?: unknown }).type !== 'string'
    ) {
      throw new QueueError(
        'CLAIM_FAILED',
        'Job payload is not a valid JobPayload object (missing or non-string `type`).',
      );
    }
    return parsed as JobPayload;
  } catch (err) {
    if (isQueueError(err)) throw err;
    throw new QueueError(
      'CLAIM_FAILED',
      `Failed to parse job payload JSON: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}

/**
 * Parse a JobRecord.result (JSON string) into a typed JobResult.
 * Throws QueueError on parse failure.
 */
export function parseJobResult(result: string): JobResult {
  try {
    const parsed = JSON.parse(result) as unknown;
    if (
      typeof parsed !== 'object' ||
      parsed === null ||
      typeof (parsed as { type?: unknown }).type !== 'string'
    ) {
      throw new QueueError(
        'COMPLETE_FAILED',
        'Job result is not a valid JobResult object (missing or non-string `type`).',
      );
    }
    return parsed as JobResult;
  } catch (err) {
    if (isQueueError(err)) throw err;
    throw new QueueError(
      'COMPLETE_FAILED',
      `Failed to parse job result JSON: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}
