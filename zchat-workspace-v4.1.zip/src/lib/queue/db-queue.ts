/**
 * DB-Backed Job Queue — Persistent, Survives Restarts
 *
 * Blueprint v4.1 §17 (Job Queue — Database-Backed, Persistent), §22 Phase 0 Step 0.7
 *
 * Design goals:
 *  - 100% DB-backed. No better-queue, no Redis, no in-memory job state.
 *  - Job records live in the Prisma `Job` table. The DB is the single source
 *    of truth (Blueprint §4 — "NO pending state").
 *  - Atomic claim: two concurrent workers can never grab the same job.
 *    Implementation uses `runInTransaction` (from src/lib/db.ts) wrapping a
 *    SELECT-then-UPDATE inside a single transaction. SQLite guarantees
 *    SERIALIZABLE-ish behavior within a transaction; PostgreSQL would use
 *    `SELECT ... FOR UPDATE` for stricter isolation.
 *  - Recovery: `recoverStaleJobs(olderThanMs)` finds 'running' jobs whose
 *    `startedAt` is older than the threshold and resets them to 'queued'.
 *    Blueprint §17 — "Worker finds 'running' jobs older than 5 minutes and
 *    resets them to 'queued' and reprocesses. NO DATA LOSS."
 *  - Retry policy: on handler failure, attempts increments. If attempts <
 *    maxAttempts, the job is re-enqueued (status='queued', startedAt=null).
 *    If attempts >= maxAttempts, the job is marked 'failed' permanently.
 *  - Handler registry: in-memory `Map<JobType, JobHandler>`. This is NOT
 *    pending state — it's code configuration (handler functions are
 *    stateless). The DB still owns all job records.
 *
 * Why not just `db.job.update(...)` for the claim?
 *  - A naive `findFirst` + `update` between two workers can race: both find
 *    the same queued job, both update it. The transaction wrapper prevents
 *    this — within a single SQLite transaction, the SELECT and UPDATE are
 *    atomic.
 *
 * Postgres production note:
 *  - For tighter isolation, swap the inner query to `SELECT ... FOR UPDATE`
 *    via `$queryRaw`. The current Prisma-only implementation is portable
 *    across SQLite and Postgres at the cost of weaker isolation (which is
 *    acceptable because we use `runInTransaction` for the whole claim).
 */

import { db, runInTransaction } from '@/lib/db';
import { logger } from '@/lib/logger';
import {
  type JobHandler,
  type JobPayload,
  type JobRecord,
  type JobResult,
  type JobType,
  QueueError,
  isQueueError,
} from '@/lib/queue/types';

// ─── Constants ─────────────────────────────────────────────────────────────

export const DEFAULT_MAX_ATTEMPTS = 3;
export const DEFAULT_STALE_THRESHOLD_MS = 5 * 60 * 1000; // 5 min — Blueprint §17

// ─── Handler registry ──────────────────────────────────────────────────────

const handlers = new Map<JobType, JobHandler>();

/**
 * Register a handler for a job type. Calling this multiple times for the same
 * type replaces the previous handler — useful for tests.
 *
 * The registry is in-memory by design. It contains handler functions only,
 * not job state. If the process restarts, handlers are re-registered during
 * module load (via `registerHandler` calls in module-level code), but job
 * records persist in the DB.
 */
export function registerHandler(type: JobType, handler: JobHandler): void {
  handlers.set(type, handler);
  logger.debug({ module: 'queue', jobType: type }, `Handler registered for job type: ${type}`);
}

/** Test-only escape hatch — clears all registered handlers. */
export function _clearHandlersForTests(): void {
  handlers.clear();
}

// ─── enqueue ───────────────────────────────────────────────────────────────

export async function enqueue(
  sessionId: string,
  type: JobType,
  payload: JobPayload,
  options?: { maxAttempts?: number },
): Promise<string> {
  if (payload.type !== type) {
    throw new QueueError(
      'ENQUEUE_FAILED',
      `Payload type '${payload.type}' does not match declared JobType '${type}'.`,
    );
  }

  const maxAttempts = options?.maxAttempts ?? DEFAULT_MAX_ATTEMPTS;
  let payloadJson: string;
  try {
    payloadJson = JSON.stringify(payload);
  } catch (err) {
    throw new QueueError(
      'ENQUEUE_FAILED',
      `Failed to serialize payload: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }

  try {
    const job = await db.job.create({
      data: {
        sessionId,
        type,
        status: 'queued',
        payload: payloadJson,
        attempts: 0,
        maxAttempts,
      },
    });
    logger.info(
      { module: 'queue', jobId: job.id, sessionId, jobType: type },
      `Job enqueued: ${type}`,
    );
    return job.id;
  } catch (err) {
    throw new QueueError(
      'ENQUEUE_FAILED',
      `Failed to insert job: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}

// ─── claimNext — atomic ────────────────────────────────────────────────────
//
// Two-step atomic claim inside a single transaction:
//   1. SELECT the oldest queued job (findFirst by status='queued', orderBy
//      createdAt asc, take 1)
//   2. UPDATE it: status='running', startedAt=now, attempts=attempts+1
//
// The transaction ensures no two concurrent workers can both find and claim
// the same job — the second worker's findFirst will return null after the
// first worker's update has committed (or, in the race window, SQLite's
// transaction isolation will serialize the two operations).
//
// Returns the updated JobRecord (with status='running'), or null if the
// queue was empty.

export async function claimNext(): Promise<JobRecord | null> {
  try {
    return await runInTransaction(async (tx) => {
      const queued = await tx.job.findFirst({
        where: { status: 'queued' },
        orderBy: { createdAt: 'asc' },
        take: 1,
      });

      if (!queued) {
        return null;
      }

      const claimed = await tx.job.update({
        where: { id: queued.id },
        data: {
          status: 'running',
          startedAt: new Date(),
          attempts: { increment: 1 },
        },
      });

      return claimed as unknown as JobRecord;
    });
  } catch (err) {
    if (isQueueError(err)) throw err;
    throw new QueueError(
      'CLAIM_FAILED',
      `Failed to claim next job: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}

// ─── complete ──────────────────────────────────────────────────────────────

export async function complete(jobId: string, result: JobResult): Promise<void> {
  let resultJson: string;
  try {
    resultJson = JSON.stringify(result);
  } catch (err) {
    throw new QueueError(
      'COMPLETE_FAILED',
      `Failed to serialize result: ${err instanceof Error ? err.message : String(err)}`,
      err,
      jobId,
    );
  }

  try {
    const updated = await db.job.update({
      where: { id: jobId },
      data: {
        status: 'done',
        finishedAt: new Date(),
        result: resultJson,
        error: null,
      },
    });

    if (!updated) {
      throw new QueueError(
        'JOB_NOT_FOUND',
        `Cannot complete job — no job with id ${jobId}.`,
        undefined,
        jobId,
      );
    }

    logger.info(
      { module: 'queue', jobId, status: 'done' },
      `Job completed: ${jobId}`,
    );
  } catch (err) {
    if (isQueueError(err)) throw err;
    throw new QueueError(
      'COMPLETE_FAILED',
      `Failed to complete job ${jobId}: ${err instanceof Error ? err.message : String(err)}`,
      err,
      jobId,
    );
  }
}

// ─── fail ──────────────────────────────────────────────────────────────────
//
// Failure policy:
//   - If `attempts >= maxAttempts` → terminal failure: status='failed',
//     finishedAt=now, error=message
//   - Otherwise → retry: status='queued', startedAt=null, error=message
//     (finishedAt stays null because the job is not finished — it's requeued)
//
// The caller passes the CURRENT attempts value (read from the JobRecord at
// claim time). We don't re-read the job from the DB here because:
//   1. The job's `attempts` was incremented atomically during claimNext
//   2. Re-reading would race with concurrent updates
//   3. The caller already has the authoritative value in hand

export async function fail(
  jobId: string,
  error: Error | string,
  currentAttempts: number,
  maxAttempts: number,
): Promise<void> {
  const errorMessage = error instanceof Error ? error.message : String(error);
  const isTerminal = currentAttempts >= maxAttempts;

  try {
    if (isTerminal) {
      await db.job.update({
        where: { id: jobId },
        data: {
          status: 'failed',
          finishedAt: new Date(),
          error: errorMessage,
        },
      });
      logger.warn(
        { module: 'queue', jobId, status: 'failed', attempts: currentAttempts, maxAttempts },
        `Job failed permanently: ${jobId}`,
      );
    } else {
      await db.job.update({
        where: { id: jobId },
        data: {
          status: 'queued',
          startedAt: null,
          error: errorMessage,
        },
      });
      logger.info(
        { module: 'queue', jobId, status: 'queued', attempts: currentAttempts, maxAttempts },
        `Job re-enqueued for retry: ${jobId} (attempt ${currentAttempts}/${maxAttempts})`,
      );
    }
  } catch (err) {
    if (isQueueError(err)) throw err;
    throw new QueueError(
      'FAIL_FAILED',
      `Failed to mark job ${jobId} as failed/retry: ${err instanceof Error ? err.message : String(err)}`,
      err,
      jobId,
    );
  }
}

// ─── recoverStaleJobs ──────────────────────────────────────────────────────
//
// Blueprint §17 — "On restart, worker finds 'running' jobs older than 5
// minutes, resets them to 'queued' and reprocesses. NO DATA LOSS."
//
// We DO NOT increment attempts here — the original attempt may have been
// making forward progress when the process died. Resetting attempts would
// unfairly punish jobs that crashed mid-execution. The job's `attempts`
// counter is only incremented on the next claimNext() call.

export async function recoverStaleJobs(
  olderThanMs: number = DEFAULT_STALE_THRESHOLD_MS,
): Promise<number> {
  const cutoff = new Date(Date.now() - olderThanMs);

  try {
    const result = await db.job.updateMany({
      where: {
        status: 'running',
        startedAt: { lt: cutoff },
      },
      data: {
        status: 'queued',
        startedAt: null,
      },
    });

    if (result.count > 0) {
      logger.warn(
        { module: 'queue', recoveredCount: result.count, olderThanMs, cutoff: cutoff.toISOString() },
        `Recovered ${result.count} stale job(s)`,
      );
    }

    return result.count;
  } catch (err) {
    if (isQueueError(err)) throw err;
    throw new QueueError(
      'RECOVER_FAILED',
      `Failed to recover stale jobs: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}

// ─── getJob / getJobsBySession ─────────────────────────────────────────────

export async function getJob(jobId: string): Promise<JobRecord | null> {
  try {
    const job = await db.job.findUnique({ where: { id: jobId } });
    return job as unknown as JobRecord | null;
  } catch (err) {
    throw new QueueError(
      'CLAIM_FAILED',
      `Failed to fetch job ${jobId}: ${err instanceof Error ? err.message : String(err)}`,
      err,
      jobId,
    );
  }
}

export async function getJobsBySession(sessionId: string): Promise<JobRecord[]> {
  try {
    const jobs = await db.job.findMany({
      where: { sessionId },
      orderBy: { createdAt: 'asc' },
    });
    return jobs as unknown as JobRecord[];
  } catch (err) {
    throw new QueueError(
      'CLAIM_FAILED',
      `Failed to fetch jobs for session ${sessionId}: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}

// ─── processNext ───────────────────────────────────────────────────────────
//
// Claims + executes + completes/fails one job. Returns true if a job was
// processed, false if the queue was empty.
//
// Handler lookup happens AFTER claim, not before. This means a job can be
// enqueued without a handler being registered yet (handlers may be registered
// lazily as modules load). If no handler exists at process time, the job
// fails with NO_HANDLER — and since this is a code bug (not a transient
// failure), we mark it terminal immediately regardless of attempts.

export async function processNext(): Promise<boolean> {
  const job = await claimNext();
  if (!job) {
    return false;
  }

  const handler = handlers.get(job.type);
  if (!handler) {
    // Terminal failure — no point retrying if the handler isn't registered.
    // This is a code bug, not a transient failure.
    const err = new QueueError(
      'NO_HANDLER',
      `No handler registered for job type '${job.type}'`,
      undefined,
      job.id,
    );
    logger.error(
      { module: 'queue', jobId: job.id, jobType: job.type },
      `No handler for job ${job.id} (type=${job.type}) — marking terminal failure`,
    );
    await db.job.update({
      where: { id: job.id },
      data: {
        status: 'failed',
        finishedAt: new Date(),
        error: err.message,
      },
    });
    // Re-throw so the caller (worker loop) sees the misconfiguration.
    throw err;
  }

  try {
    const result = await handler(job);
    await complete(job.id, result);
    return true;
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    logger.warn(
      { module: 'queue', jobId: job.id, jobType: job.type, error: errorMessage, attempts: job.attempts, maxAttempts: job.maxAttempts },
      `Job handler threw: ${job.id}`,
    );

    // If the handler threw a QueueError(NO_HANDLER), treat as terminal.
    if (isQueueError(err) && err.code === 'NO_HANDLER') {
      await db.job.update({
        where: { id: job.id },
        data: {
          status: 'failed',
          finishedAt: new Date(),
          error: errorMessage,
        },
      });
      throw err;
    }

    // Normal retry/fail path.
    await fail(job.id, errorMessage, job.attempts, job.maxAttempts);

    // Re-throw QueueError-sourced failures so the worker can see them in logs,
    // but DO NOT re-throw generic handler errors — those are expected and
    // have already been recorded in the job row.
    if (isQueueError(err)) {
      throw err;
    }
    return true;
  }
}

// ─── Re-exports ────────────────────────────────────────────────────────────

export { QueueError, isQueueError } from '@/lib/queue/types';
export type {
  JobHandler,
  JobPayload,
  JobRecord,
  JobResult,
  JobType,
  JobStatus,
} from '@/lib/queue/types';
