/**
 * NextAuth.js v4 — Configuration & Auth Helpers
 *
 * Blueprint v4.1 §24 (Security Model), §25 (Scaling Strategy), §20 (Interface-Driven Design)
 *
 * Design goals:
 *  - JWT session strategy (stateless, scales to 10M users per §25)
 *  - 24-hour session expiry (§24)
 *  - Workspace-scoped session — workspaceId injected into JWT + Session.user
 *  - Strict Zod validation on credentials (§0.4 prerequisite pattern)
 *  - bcryptjs (pure JS, no native deps) for password hashing with constant-time compare
 *  - Typed AuthError mirroring DbError from src/lib/db.ts
 *  - Fail-fast on missing NEXTAUTH_SECRET (lazy — only when getAuthOptions() is called)
 *  - Testable: pure helpers (authorizeUser, lookupWorkspaceId, encodeAuthToken) extracted
 *    from the NextAuth wrapper so unit tests don't need to spin up the full NextAuth stack
 *
 * The singleton Prisma client from src/lib/db.ts is the only DB entrypoint.
 *
 * Standalone JWT helpers (encodeAuthToken / decodeAuthToken) are NOT NextAuth-specific.
 * They will be reused by the WebSocket mini-service on :3001 (§18) for session
 * authentication on long-lived connections, and by future token flows (email verify,
 * password reset) in later phases.
 */

import { type NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { db } from '@/lib/db';

// ─── AuthError (mirrors DbError pattern from src/lib/db.ts) ────────────────

export type AuthErrorCode =
  | 'INVALID_CREDENTIALS'
  | 'USER_NOT_FOUND'
  | 'PASSWORD_MISMATCH'
  | 'VALIDATION_FAILED'
  | 'NO_WORKSPACE'
  | 'JWT_OPERATION_FAILED'
  | 'AUTH_CONFIG_MISSING';

const AUTH_ERROR_BRAND = Symbol('AuthError');

export class AuthError extends Error {
  public readonly [AUTH_ERROR_BRAND]: true = true;
  public readonly code: AuthErrorCode;
  public readonly cause: unknown;

  public constructor(code: AuthErrorCode, message: string, cause?: unknown) {
    super(message);
    this.name = 'AuthError';
    this.code = code;
    this.cause = cause;
    // Restore prototype chain after subclassing Error (TS/ES2015 target quirk)
    Object.setPrototypeOf(this, AuthError.prototype);
  }
}

/**
 * Type guard for AuthError. Use this in catch blocks instead of `instanceof`
 * to remain robust against cross-realm / serialized error payloads.
 */
export function isAuthError(error: unknown): error is AuthError {
  return (
    typeof error === 'object' &&
    error !== null &&
    (error as Record<symbol, unknown>)[AUTH_ERROR_BRAND] === true
  );
}

// ─── Zod validation (§0.4 prerequisite pattern) ───────────────────────────

export const credentialsSchema = z.object({
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Invalid email format'),
  password: z
    .string()
    .min(1, 'Password is required')
    .min(8, 'Password must be at least 8 characters'),
});

export type Credentials = z.infer<typeof credentialsSchema>;

// ─── Password hashing (bcryptjs, constant-time compare) ────────────────────

const SALT_ROUNDS = 12;

export async function hashPassword(plain: string): Promise<string> {
  const salt = await bcrypt.genSalt(SALT_ROUNDS);
  return bcrypt.hash(plain, salt);
}

/**
 * Verify a plaintext password against a bcrypt hash.
 *
 * bcrypt.compare is constant-time by design (it always performs the full
 * hash computation even when the prefix mismatches), so callers do not need
 * to add additional timing protections.
 */
export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

// ─── Standalone JWT helpers (used by WebSocket :3001 + future token flows) ─

const TOKEN_ISSUER = 'zchat';
const TOKEN_AUDIENCE = 'zchat-user';
const MIN_SECRET_LENGTH = 16;
const DEFAULT_TOKEN_TTL_SECONDS = 60 * 60 * 24; // 24h — matches NextAuth maxAge

export interface AuthTokenPayload {
  userId: string;
  email: string;
  workspaceId: string;
  tier: string;
}

function assertSecretUsable(secret: string | undefined): asserts secret is string {
  if (!secret || secret.length < MIN_SECRET_LENGTH) {
    throw new AuthError(
      'AUTH_CONFIG_MISSING',
      `JWT secret must be at least ${MIN_SECRET_LENGTH} characters (got ${secret ? secret.length : 0}).`,
    );
  }
}

export function encodeAuthToken(
  payload: AuthTokenPayload,
  secret: string,
  expiresInSeconds: number = DEFAULT_TOKEN_TTL_SECONDS,
): string {
  assertSecretUsable(secret);
  try {
    return jwt.sign(payload, secret, {
      expiresIn: expiresInSeconds,
      issuer: TOKEN_ISSUER,
      audience: TOKEN_AUDIENCE,
    });
  } catch (err) {
    throw new AuthError(
      'JWT_OPERATION_FAILED',
      `Failed to encode token: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}

export function decodeAuthToken(token: string, secret: string): AuthTokenPayload {
  assertSecretUsable(secret);
  try {
    const decoded = jwt.verify(token, secret, {
      issuer: TOKEN_ISSUER,
      audience: TOKEN_AUDIENCE,
    });
    if (typeof decoded === 'string') {
      throw new AuthError(
        'JWT_OPERATION_FAILED',
        'Decoded token is a string, not an object — payload missing.',
      );
    }
    const payload = decoded as Partial<AuthTokenPayload>;
    if (
      typeof payload.userId !== 'string' ||
      typeof payload.email !== 'string' ||
      typeof payload.workspaceId !== 'string' ||
      typeof payload.tier !== 'string'
    ) {
      throw new AuthError(
        'JWT_OPERATION_FAILED',
        'Token payload missing required fields (userId, email, workspaceId, tier).',
      );
    }
    return {
      userId: payload.userId,
      email: payload.email,
      workspaceId: payload.workspaceId,
      tier: payload.tier,
    };
  } catch (err) {
    if (isAuthError(err)) throw err;
    throw new AuthError(
      'JWT_OPERATION_FAILED',
      `Failed to decode token: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}

// ─── Workspace lookup ──────────────────────────────────────────────────────

/**
 * Resolve the user's primary workspace. The first workspace (by createdAt)
 * is treated as primary. Throws AuthError(NO_WORKSPACE) if the user has none.
 *
 * All downstream API queries MUST scope to this workspaceId (Blueprint §24
 * RBAC: "Every query scoped to workspace_id").
 */
export async function lookupWorkspaceId(userId: string): Promise<string> {
  const ws = await db.workspace.findFirst({
    where: { userId },
    orderBy: { createdAt: 'asc' },
    select: { id: true },
  });
  if (!ws) {
    throw new AuthError(
      'NO_WORKSPACE',
      `User ${userId} has no workspace. Create one before authenticating.`,
    );
  }
  return ws.id;
}

// ─── AuthUser (returned by authorize, distinct from NextAuth's User) ───────

export interface AuthUser {
  id: string;
  email: string;
  name?: string | null;
  tier: string;
}

// ─── Authorize logic (testable, separated from NextAuth wrapper) ───────────

/**
 * Validate credentials, look up the user, verify the password, return AuthUser.
 *
 * Throws AuthError on every failure path so callers can switch on `code`:
 *   VALIDATION_FAILED  — Zod rejected the input shape
 *   USER_NOT_FOUND     — email not in DB
 *   INVALID_CREDENTIALS — user exists but has no password (OAuth-only user)
 *   PASSWORD_MISMATCH  — password hash didn't match
 *
 * Never returns null — NextAuth's `authorize` callback wraps this and
 * surfaces the AuthError.message in the redirect URL's `?error=` param.
 */
export async function authorizeUser(credentials: unknown): Promise<AuthUser> {
  const parsed = credentialsSchema.safeParse(credentials);
  if (!parsed.success) {
    throw new AuthError(
      'VALIDATION_FAILED',
      `Credential validation failed: ${parsed.error.issues.map((i) => i.message).join('; ')}`,
    );
  }
  const { email, password } = parsed.data;

  const user = await db.user.findUnique({
    where: { email },
    select: {
      id: true,
      email: true,
      name: true,
      passwordHash: true,
      tier: true,
    },
  });

  if (!user) {
    throw new AuthError('USER_NOT_FOUND', `No user found with email ${email}.`);
  }
  if (!user.passwordHash) {
    throw new AuthError(
      'INVALID_CREDENTIALS',
      `User ${email} has no password set (OAuth-only account).`,
    );
  }

  const passwordMatches = await verifyPassword(password, user.passwordHash);
  if (!passwordMatches) {
    throw new AuthError('PASSWORD_MISMATCH', `Password verification failed for ${email}.`);
  }

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    tier: user.tier,
  };
}

// ─── NextAuth type augmentation ────────────────────────────────────────────
//
// Adds workspaceId + tier to Session.user and JWT so the rest of the app
// can read workspaceId off the session without an extra DB round-trip.

declare module 'next-auth' {
  interface User {
    tier?: string;
  }
  interface Session {
    user: {
      id: string;
      email: string;
      name?: string | null;
      image?: string | null;
      workspaceId?: string;
      tier?: string;
    };
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    userId?: string;
    workspaceId?: string;
    tier?: string;
  }
}

// ─── Config validation ─────────────────────────────────────────────────────

export function assertAuthConfigured(): void {
  const secret = process.env.NEXTAUTH_SECRET;
  if (!secret || secret.length < MIN_SECRET_LENGTH) {
    throw new AuthError(
      'AUTH_CONFIG_MISSING',
      `NEXTAUTH_SECRET environment variable is missing or shorter than ${MIN_SECRET_LENGTH} characters.`,
    );
  }
}

// ─── NextAuth options (lazy + cached) ──────────────────────────────────────

const TWENTY_FOUR_HOURS_SECONDS = 60 * 60 * 24;

let _cachedOptions: NextAuthOptions | null = null;

/**
 * Build (and cache) the NextAuth options object.
 *
 * Caching is intentional: the options object is created once per process and
 * shared across all requests. The jwt/session callbacks close over `db` and
 * `lookupWorkspaceId` — both of which are stable references.
 *
 * Tests that need to mutate process.env.NEXTAUTH_SECRET between cases must
 * call `_resetAuthOptionsCacheForTests()` first.
 */
export function getAuthOptions(): NextAuthOptions {
  if (_cachedOptions) return _cachedOptions;
  assertAuthConfigured();

  _cachedOptions = {
    session: {
      strategy: 'jwt',
      maxAge: TWENTY_FOUR_HOURS_SECONDS,
    },
    providers: [
      CredentialsProvider({
        name: 'Credentials',
        credentials: {
          email: { label: 'Email', type: 'email', placeholder: 'you@example.com' },
          password: { label: 'Password', type: 'password' },
        },
        authorize: async (credentials) => {
          // authorizeUser returns AuthUser | throws AuthError.
          // NextAuth v4 surfaces the thrown Error.message in the redirect
          // URL's ?error= param so the login page can display it.
          return authorizeUser(credentials);
        },
      }),
    ],
    callbacks: {
      jwt: async ({ token, user }) => {
        // `user` is only present on the very first sign-in call. After that,
        // NextAuth persists the token and `user` is undefined. We must do
        // the workspace lookup exactly once per session.
        if (user) {
          token.userId = user.id;
          token.tier = user.tier;
          token.workspaceId = await lookupWorkspaceId(user.id);
        }
        return token;
      },
      session: async ({ session, token }) => {
        if (session.user) {
          session.user.id = token.userId ?? session.user.id;
          session.user.workspaceId = token.workspaceId;
          session.user.tier = token.tier;
        }
        return session;
      },
    },
    pages: {
      signIn: '/login',
      error: '/login',
    },
  };

  return _cachedOptions;
}

/**
 * Reset the cached NextAuth options. Test-only — production code should
 * never call this. Exposed so tests can mutate process.env.NEXTAUTH_SECRET
 * between cases without leaking state.
 *
 * @internal
 */
export function _resetAuthOptionsCacheForTests(): void {
  _cachedOptions = null;
}
