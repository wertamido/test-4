/**
 * Skills System — Catalog + Registry
 * Blueprint v4.1 §12 (Skills System), §22 Phase 1 Step 1.5
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

export type SkillStrength = 1 | 2 | 3;

export interface SkillRecord {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly icon: string;
  readonly category: string;
  readonly systemPrompt: string;
  readonly strength: SkillStrength;
  readonly enabled: boolean;
  readonly builtin: boolean;
}

let catalog: Map<string, SkillRecord> = new Map();
let catalogLoaded = false;

export async function refreshSkillCatalog(): Promise<void> {
  try {
    const rows = await db.skill.findMany();
    catalog = new Map();
    for (const row of rows) {
      catalog.set(row.id, {
        id: row.id, name: row.name, description: row.description,
        icon: row.icon, category: row.category, systemPrompt: row.systemPrompt,
        strength: row.strength as SkillStrength, enabled: row.enabled, builtin: row.builtin,
      });
    }
    catalogLoaded = true;
    logger.info({ module: 'skills', count: catalog.size }, `Skill catalog loaded: ${catalog.size} skills`);
  } catch (err) {
    throw new Error(`Failed to load skill catalog: ${err instanceof Error ? err.message : String(err)}`);
  }
}

async function ensureCatalogLoaded(): Promise<void> {
  if (!catalogLoaded) await refreshSkillCatalog();
}

export async function getSkill(skillId: string): Promise<SkillRecord> {
  await ensureCatalogLoaded();
  const skill = catalog.get(skillId);
  if (!skill) throw new Error(`Skill ${skillId} not found`);
  return skill;
}

export async function getAllSkills(): Promise<SkillRecord[]> {
  await ensureCatalogLoaded();
  return Array.from(catalog.values());
}

export async function assembleSkillsPrompt(skillIds: ReadonlyArray<string>): Promise<string> {
  if (skillIds.length === 0) return '';
  await ensureCatalogLoaded();
  const skills: SkillRecord[] = [];
  for (const id of skillIds) {
    const skill = catalog.get(id);
    if (!skill || !skill.enabled) continue;
    skills.push(skill);
  }
  if (skills.length === 0) return '';
  skills.sort((a, b) => a.strength - b.strength);
  return skills.map((s) => `--- Skill: ${s.name} (strength ${s.strength}) ---\n${s.systemPrompt}`).join('\n\n');
}

export function _setCatalogForTests(skills: SkillRecord[]): void {
  catalog = new Map(skills.map((s) => [s.id, s]));
  catalogLoaded = true;
}

export function _resetCatalogForTests(): void {
  catalog = new Map();
  catalogLoaded = false;
}
