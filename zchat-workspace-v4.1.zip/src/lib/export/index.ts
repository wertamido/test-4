/**
 * Project Download — ZIP/TAR Export
 *
 * Blueprint v4.1 §22 Phase 1 Step 1.11
 *
 * Exports a session's artifacts as a downloadable ZIP or TAR. Uses the
 * StorageAdapter to read artifact files + Node's zlib for compression.
 * No external zip library — we build a minimal ZIP writer (uncompressed
 * STORE method) to avoid adding a dependency.
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { getSession } from '@/lib/sessions/repository';
import { LocalStorageAdapter } from '@/lib/storage/local';
import {
  type StorageAdapter,
  type StorageItem,
  StorageError,
} from '@/lib/storage/adapter';
import { createGzip } from 'node:zlib';
import { Readable } from 'node:stream';

// ─── Types ─────────────────────────────────────────────────────────────────

export type ExportFormat = 'zip' | 'tar';

export interface ExportResult {
  readonly format: ExportFormat;
  readonly buffer: Buffer;
  readonly filename: string;
  readonly fileCount: number;
  readonly totalBytes: number;
}

export type ExportErrorCode = 'SESSION_NOT_FOUND' | 'NO_ARTIFACTS' | 'EXPORT_FAILED';

const EXPORT_ERROR_BRAND = Symbol('ExportError');

export class ExportError extends Error {
  public readonly [EXPORT_ERROR_BRAND]: true = true;
  public readonly code: ExportErrorCode;
  public readonly cause: unknown;

  public constructor(code: ExportErrorCode, message: string, cause?: unknown) {
    super(message);
    this.name = 'ExportError';
    this.code = code;
    this.cause = cause;
    Object.setPrototypeOf(this, ExportError.prototype);
  }
}

export function isExportError(error: unknown): error is ExportError {
  return typeof error === 'object' && error !== null && (error as Record<symbol, unknown>)[EXPORT_ERROR_BRAND] === true;
}

// ─── exportProject ─────────────────────────────────────────────────────────

export async function exportProject(
  sessionId: string,
  workspaceId: string,
  format: ExportFormat,
  storage?: StorageAdapter,
): Promise<ExportResult> {
  // RBAC: verify session belongs to workspace
  await getSession(sessionId, workspaceId);

  // Load artifacts from DB
  const artifacts = await db.artifact.findMany({
    where: { sessionId },
    orderBy: { createdAt: 'asc' },
  });

  if (artifacts.length === 0) {
    throw new ExportError('NO_ARTIFACTS', `Session ${sessionId} has no artifacts to export.`);
  }

  const storageAdapter = storage ?? new LocalStorageAdapter();

  // Collect files: each artifact's storageUrl (if set) + a manifest
  const files: Array<{ name: string; content: Buffer }> = [];

  for (const artifact of artifacts) {
    if (artifact.storageUrl) {
      try {
        const content = await storageAdapter.read(artifact.storageUrl);
        const filename = artifact.filename ?? artifact.id;
        files.push({ name: filename, content });
      } catch (err) {
        logger.warn(
          { module: 'export', sessionId, artifactId: artifact.id, err },
          `Failed to read artifact ${artifact.id}: ${err instanceof Error ? err.message : String(err)}`,
        );
      }
    } else if (artifact.content) {
      const filename = artifact.filename ?? `${artifact.id}.txt`;
      files.push({ name: filename, content: Buffer.from(artifact.content, 'utf8') });
    }
  }

  if (files.length === 0) {
    throw new ExportError('NO_ARTIFACTS', `Session ${sessionId} artifacts have no readable content.`);
  }

  // Add a manifest
  const manifest = {
    sessionId,
    exportedAt: new Date().toISOString(),
    format,
    fileCount: files.length,
    files: files.map((f) => ({ name: f.name, size: f.content.length })),
  };
  files.push({ name: 'manifest.json', content: Buffer.from(JSON.stringify(manifest, null, 2), 'utf8') });

  const totalBytes = files.reduce((sum, f) => sum + f.content.length, 0);

  let buffer: Buffer;
  try {
    if (format === 'zip') {
      buffer = buildZip(files);
    } else {
      buffer = buildTar(files);
    }
  } catch (err) {
    throw new ExportError(
      'EXPORT_FAILED',
      `Failed to build ${format}: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }

  const filename = `session-${sessionId}.${format}`;

  logger.info(
    { module: 'export', sessionId, format, fileCount: files.length, totalBytes, bufferBytes: buffer.length },
    `Exported ${files.length} files as ${format} (${buffer.length} bytes)`,
  );

  return {
    format,
    buffer,
    filename,
    fileCount: files.length,
    totalBytes,
  };
}

// ─── Minimal ZIP writer (STORE method, no compression) ─────────────────────
//
// Implements the ZIP file format per the APPNOTE spec. Uses the STORE
// (no compression) method for simplicity. The resulting ZIP is valid and
// extractable by any ZIP tool, just not compressed.

function buildZip(files: Array<{ name: string; content: Buffer }>): Buffer {
  const chunks: Buffer[] = [];
  const centralDirectory: Buffer[] = [];
  let offset = 0;

  for (const file of files) {
    const nameBuf = Buffer.from(file.name, 'utf8');
    const content = file.content;
    const crc = crc32(content);

    // Local file header
    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0); // signature
    localHeader.writeUInt16LE(20, 4); // version needed
    localHeader.writeUInt16LE(0, 6); // flags
    localHeader.writeUInt16LE(0, 8); // compression (0 = STORE)
    localHeader.writeUInt16LE(0, 10); // mod time
    localHeader.writeUInt16LE(0, 12); // mod date
    localHeader.writeUInt32LE(crc, 14); // crc32
    localHeader.writeUInt32LE(content.length, 18); // compressed size
    localHeader.writeUInt32LE(content.length, 22); // uncompressed size
    localHeader.writeUInt16LE(nameBuf.length, 26); // filename length
    localHeader.writeUInt16LE(0, 28); // extra field length

    chunks.push(localHeader, nameBuf, content);

    // Central directory entry
    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0); // signature
    centralHeader.writeUInt16LE(20, 4); // version made by
    centralHeader.writeUInt16LE(20, 6); // version needed
    centralHeader.writeUInt16LE(0, 8); // flags
    centralHeader.writeUInt16LE(0, 10); // compression
    centralHeader.writeUInt16LE(0, 12); // mod time
    centralHeader.writeUInt16LE(0, 14); // mod date
    centralHeader.writeUInt32LE(crc, 16); // crc32
    centralHeader.writeUInt32LE(content.length, 20); // compressed size
    centralHeader.writeUInt32LE(content.length, 24); // uncompressed size
    centralHeader.writeUInt16LE(nameBuf.length, 28); // filename length
    centralHeader.writeUInt16LE(0, 30); // extra field length
    centralHeader.writeUInt16LE(0, 32); // comment length
    centralHeader.writeUInt16LE(0, 34); // disk number
    centralHeader.writeUInt16LE(0, 36); // internal attrs
    centralHeader.writeUInt32LE(0, 38); // external attrs
    centralHeader.writeUInt32LE(offset, 42); // relative offset of local header
    centralDirectory.push(centralHeader, nameBuf);

    offset += localHeader.length + nameBuf.length + content.length;
  }

  // End of central directory
  const cdOffset = offset;
  const cdSize = centralDirectory.reduce((sum, b) => sum + b.length, 0);
  chunks.push(...centralDirectory);

  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); // signature
  eocd.writeUInt16LE(0, 4); // disk number
  eocd.writeUInt16LE(0, 6); // disk with CD
  eocd.writeUInt16LE(files.length, 8); // entries on this disk
  eocd.writeUInt16LE(files.length, 10); // total entries
  eocd.writeUInt32LE(cdSize, 12); // CD size
  eocd.writeUInt32LE(cdOffset, 16); // CD offset
  eocd.writeUInt16LE(0, 20); // comment length
  chunks.push(eocd);

  return Buffer.concat(chunks);
}

// ─── Minimal TAR writer (POSIX ustar) ──────────────────────────────────────

function buildTar(files: Array<{ name: string; content: Buffer }>): Buffer {
  const chunks: Buffer[] = [];

  for (const file of files) {
    const name = file.name.slice(0, 100);
    const content = file.content;
    const size = content.length;
    const sizeOctal = size.toString(8).padStart(11, '0') + '\0';

    const header = Buffer.alloc(512, 0);
    header.write(name, 0, 'utf8');
    header.write('0000644', 100, 'utf8'); // mode
    header.write('0001750', 108, 'utf8'); // uid
    header.write('0001750', 116, 'utf8'); // gid
    header.write(sizeOctal, 124, 'utf8'); // size
    header.write(Math.floor(Date.now() / 1000).toString(8).padStart(11, '0') + '\0', 136, 'utf8'); // mtime
    header.write('        ', 148, 'utf8'); // checksum placeholder (8 spaces)
    header.write('0', 156, 'utf8'); // typeflag (regular file)
    header.write('ustar\0', 257, 'utf8'); // magic
    header.write('00', 263, 'utf8'); // version

    // Compute checksum
    let checksum = 0;
    for (let i = 0; i < 512; i++) {
      checksum += header[i]!;
    }
    header.write(checksum.toString(8).padStart(6, '0') + '\0 ', 148, 'utf8');

    chunks.push(header);

    // File content, padded to 512-byte boundary
    chunks.push(content);
    const padding = (512 - (content.length % 512)) % 512;
    if (padding > 0) {
      chunks.push(Buffer.alloc(padding, 0));
    }
  }

  // End-of-archive: two 512-byte blocks of zeros
  chunks.push(Buffer.alloc(1024, 0));

  return Buffer.concat(chunks);
}

// ─── CRC32 (for ZIP) ───────────────────────────────────────────────────────

const CRC_TABLE: number[] = (() => {
  const table: number[] = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Buffer): number {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) {
    crc = CRC_TABLE[(crc ^ buf[i]!) & 0xFF]! ^ (crc >>> 8);
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}
