/**
 * Prisma Client Singleton — SQLite (sandbox) → PostgreSQL (production)
 *
 * Blueprint v4.1 §6 (Database Schema), §20 (Interface-Driven Design)
 *
 * Design goals:
 *  - Single PrismaClient per process (avoids hot-reload connection exhaustion in dev)
 *  - Strict error handling with a typed DbError hierarchy (no `any`)
 *  - Health check helpers for readiness probes (Blueprint §17 worker startup)
 *  - Graceful shutdown on SIGINT / SIGTERM (Blueprint §17 — DB-backed queue)
 *  - Transaction wrapper that maps failures to DbError(code='TRANSACTION_FAILED')
 *
 * The singleton exported from this module is the ONLY way other modules may
 * touch the database. Direct `new PrismaClient()` calls elsewhere are
 * forbidden — they leak connections and bypass shutdown handling.
 */

import { PrismaClient, Prisma } from '@prisma/client';

// ─── Branded error type ────────────────────────────────────────────────────
//
// Blueprint §12 — Type Safety Enforcer skill: no `any`, branded types where
// they add discriminant value. DbError carries a `code` so callers can switch
// on it without string-matching messages.

export type DbErrorCode =
  | 'CONNECTION_FAILED'
  | 'QUERY_FAILED'
  | 'TRANSACTION_FAILED'
  | 'CLIENT_NOT_INITIALIZED'
  | 'SHUTDOWN_IN_PROGRESS';

const DB_ERROR_BRAND = Symbol('DbError');

export class DbError extends Error {
  public readonly [DB_ERROR_BRAND]: true = true;
  public readonly code: DbErrorCode;
  public readonly cause: unknown;

  public constructor(code: DbErrorCode, message: string, cause?: unknown) {
    super(message);
    this.name = 'DbError';
    this.code = code;
    this.cause = cause;
    // Restore prototype chain after subclassing Error (TS/ES2015 target quirk)
    Object.setPrototypeOf(this, DbError.prototype);
  }
}

/**
 * Type guard for DbError. Use this in catch blocks instead of `instanceof`
 * to remain robust against cross-realm / serialized error payloads.
 */
export function isDbError(error: unknown): error is DbError {
  return (
    typeof error === 'object' &&
    error !== null &&
    (error as Record<symbol, unknown>)[DB_ERROR_BRAND] === true
  );
}

// ─── Prisma error mapping ──────────────────────────────────────────────────

function mapPrismaError(error: unknown): DbError {
  if (error instanceof Prisma.PrismaClientInitializationError) {
    return new DbError(
      'CONNECTION_FAILED',
      `Database connection failed: ${error.message}`,
      error,
    );
  }
  if (error instanceof Prisma.PrismaClientRustPanicError) {
    return new DbError(
      'CONNECTION_FAILED',
      `Database engine panic: ${error.message}`,
      error,
    );
  }
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    return new DbError(
      'QUERY_FAILED',
      `Database query failed (P${error.code}): ${error.message}`,
      error,
    );
  }
  if (error instanceof Prisma.PrismaClientUnknownRequestError) {
    return new DbError(
      'QUERY_FAILED',
      `Database query failed (unknown request error): ${error.message}`,
      error,
    );
  }
  if (error instanceof Prisma.PrismaClientValidationError) {
    return new DbError(
      'QUERY_FAILED',
      `Database query validation failed: ${error.message}`,
      error,
    );
  }
  return new DbError(
    'QUERY_FAILED',
    `Unexpected database error: ${error instanceof Error ? error.message : String(error)}`,
    error,
  );
}

// ─── Singleton lifecycle ───────────────────────────────────────────────────

const globalForPrisma = globalThis as unknown as {
  __prismaClient?: PrismaClient;
  __prismaShutdownRegistered?: boolean;
};

let shutdownInProgress = false;

function createClient(): PrismaClient {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl || databaseUrl.trim() === '') {
    throw new DbError(
      'CLIENT_NOT_INITIALIZED',
      'DATABASE_URL environment variable is not set. Cannot initialize Prisma client.',
    );
  }

  const isDev = process.env.NODE_ENV !== 'production';

  const client = new PrismaClient({
    log: isDev
      ? [
          { emit: 'stdout', level: 'query' },
          { emit: 'stdout', level: 'warn' },
          { emit: 'stdout', level: 'error' },
        ]
      : [
          { emit: 'stdout', level: 'warn' },
          { emit: 'stdout', level: 'error' },
        ],
  });

  // Register shutdown handlers exactly once per process. Prisma's $disconnect
  // closes the underlying connection pool; without this, SIGTERM from a
  // process manager would leave queries in flight.
  if (!globalForPrisma.__prismaShutdownRegistered) {
    const gracefulShutdown = async (signal: NodeJS.Signals): Promise<void> => {
      if (shutdownInProgress) return;
      shutdownInProgress = true;
      try {
        const instance = globalForPrisma.__prismaClient;
        if (instance) {
          await instance.$disconnect();
        }
      } catch (err) {
        // Best-effort; cannot recover during shutdown. Emit a structured log
        // line so pino / log aggregators can pick it up once §0.6 lands.
        console.error(
          JSON.stringify({
            level: 'error',
            msg: 'prisma.disconnect.failed.during.shutdown',
            signal,
            error: err instanceof Error ? err.message : String(err),
          }),
        );
      } finally {
        process.exit(0);
      }
    };
    process.on('SIGINT', (sig) => void gracefulShutdown(sig));
    process.on('SIGTERM', (sig) => void gracefulShutdown(sig));
    globalForPrisma.__prismaShutdownRegistered = true;
  }

  return client;
}

/**
 * The singleton Prisma client. All database access in the codebase MUST go
 * through this export. Never instantiate `PrismaClient` directly elsewhere.
 *
 * Lazily instantiated on first module import. The globalThis stash ensures
 * Next.js dev hot-reload reuses the same instance instead of spawning a new
 * PrismaClient per reload (which would exhaust the SQLite file handle pool).
 */
export const db: PrismaClient =
  globalForPrisma.__prismaClient ?? createClient();

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.__prismaClient = db;
}

// ─── Health & lifecycle helpers ────────────────────────────────────────────

/**
 * Verify the database connection is alive. Throws DbError on failure.
 *
 * Used by:
 *  - HTTP /api/health readiness probe
 *  - Worker startup self-check (Blueprint §17 — DB-backed job queue)
 *  - Manual smoke tests
 */
export async function assertDbHealthy(): Promise<void> {
  if (shutdownInProgress) {
    throw new DbError(
      'SHUTDOWN_IN_PROGRESS',
      'Database client is shutting down; refusing new operations.',
    );
  }
  try {
    await db.$connect();
    await db.$queryRaw`SELECT 1`;
  } catch (error) {
    throw mapPrismaError(error);
  }
}

/**
 * Non-throwing health check. Returns `true` if the database is reachable,
 * `false` otherwise. Safe for HTTP health endpoints — never throws.
 */
export async function isDbHealthy(): Promise<boolean> {
  try {
    await assertDbHealthy();
    return true;
  } catch {
    return false;
  }
}

/**
 * Run an operation inside a Prisma interactive transaction with strict error
 * mapping.
 *
 * Blueprint §4 — "Provider disable = automatic session migration in DB
 * transaction." All multi-step DB mutations should use this wrapper so
 * transaction failures map to DbError(code='TRANSACTION_FAILED').
 *
 * If the body throws a DbError, it is re-thrown unchanged so the original
 * code is preserved for downstream handling.
 */
export async function runInTransaction<T>(
  fn: (tx: Prisma.TransactionClient) => Promise<T>,
  options?: { timeoutMs?: number; maxWaitMs?: number },
): Promise<T> {
  if (shutdownInProgress) {
    throw new DbError(
      'SHUTDOWN_IN_PROGRESS',
      'Database client is shutting down; refusing new transactions.',
    );
  }
  try {
    return await db.$transaction(fn, {
      timeout: options?.timeoutMs ?? 5000,
      maxWait: options?.maxWaitMs ?? 2000,
    });
  } catch (error) {
    if (isDbError(error)) {
      throw error;
    }
    throw new DbError(
      'TRANSACTION_FAILED',
      `Transaction failed: ${error instanceof Error ? error.message : String(error)}`,
      error,
    );
  }
}

/**
 * Explicitly disconnect the singleton. Mainly for tests and explicit
 * teardown. After calling this, the singleton remains in memory but will
 * lazily reconnect on the next operation via Prisma's internal pool.
 */
export async function disconnectDb(): Promise<void> {
  try {
    await db.$disconnect();
  } catch (error) {
    throw mapPrismaError(error);
  }
}

// ─── Re-exports ────────────────────────────────────────────────────────────
//
// Consumers should import Prisma client helpers from `@/lib/db` rather than
// `@prisma/client` directly, so the singleton boundary is enforced and the
// error-mapping helpers are always in scope.

export { PrismaClient, Prisma };
export default db;
