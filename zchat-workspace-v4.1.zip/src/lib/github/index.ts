/**
 * GitHub Integration — Search + Import + Pin + Context Injection
 *
 * Blueprint v4.1 §14 (GitHub Integration), §22 Phase 1 Step 1.8
 *
 * Three modes:
 *   1. Context Injection (Pinned Repos) — README in system prompt with
 *      5 citation rules. Max 3 repos. 6000 char cap.
 *   2. Agent Tool (github_search) — all agents can search GitHub repos
 *   3. Import + Cache — search → import (fetch README) → cache in DB
 *
 * This module implements the search, import, pin, and context-injection
 * logic. The github_search AGENT TOOL is registered separately in the
 * agents/tools module (Phase 2).
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

// ─── Types ─────────────────────────────────────────────────────────────────

export interface GithubSearchResult {
  readonly id: number;
  readonly fullName: string;
  readonly description: string | null;
  readonly url: string;
  readonly stars: number;
  readonly language: string | null;
  readonly owner: string;
}

export interface GithubRepoRecord {
  readonly id: string;
  readonly workspaceId: string | null;
  readonly fullName: string;
  readonly description: string | null;
  readonly url: string;
  readonly stars: number;
  readonly language: string | null;
  readonly owner: string;
  readonly readmeCache: string | null;
  readonly createdAt: Date;
}

export interface GithubSearchParams {
  readonly query: string;
  readonly language?: string;
  readonly sort?: 'stars' | 'updated' | 'forks';
  readonly perPage?: number;
}

export type GithubErrorCode =
  | 'SEARCH_FAILED'
  | 'IMPORT_FAILED'
  | 'REPO_NOT_FOUND'
  | 'README_FETCH_FAILED'
  | 'PIN_LIMIT_EXCEEDED';

const GITHUB_ERROR_BRAND = Symbol('GithubError');

export class GithubError extends Error {
  public readonly [GITHUB_ERROR_BRAND]: true = true;
  public readonly code: GithubErrorCode;
  public readonly cause: unknown;

  public constructor(code: GithubErrorCode, message: string, cause?: unknown) {
    super(message);
    this.name = 'GithubError';
    this.code = code;
    this.cause = cause;
    Object.setPrototypeOf(this, GithubError.prototype);
  }
}

export function isGithubError(error: unknown): error is GithubError {
  return (
    typeof error === 'object' &&
    error !== null &&
    (error as Record<symbol, unknown>)[GITHUB_ERROR_BRAND] === true
  );
}

// ─── Constants (Blueprint §14) ─────────────────────────────────────────────

export const MAX_PINNED_REPOS = 3;
export const README_CHAR_CAP = 6000;

// ─── searchGithubRepos ─────────────────────────────────────────────────────
//
// Uses the GitHub Search API (unauthenticated, rate-limited to 10 req/min).
// For production, add a GITHUB_TOKEN env var for higher rate limits.

export async function searchGithubRepos(params: GithubSearchParams): Promise<GithubSearchResult[]> {
  const { query, language, sort = 'stars', perPage = 10 } = params;

  const searchParams = new URLSearchParams({
    q: language ? `${query} language:${language}` : query,
    sort,
    order: 'desc',
    per_page: String(Math.min(perPage, 30)),
  });

  const url = `https://api.github.com/search/repositories?${searchParams.toString()}`;

  logger.info({ module: 'github', op: 'search', query, language, sort }, `Searching GitHub: ${query}`);

  let response: Response;
  try {
    response = await fetch(url, {
      headers: {
        accept: 'application/vnd.github+json',
        'user-agent': 'zchat-workspace/4.1',
        ...(process.env.GITHUB_TOKEN ? { authorization: `Bearer ${process.env.GITHUB_TOKEN}` } : {}),
      },
    });
  } catch (err) {
    throw new GithubError(
      'SEARCH_FAILED',
      `GitHub search request failed: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }

  if (!response.ok) {
    throw new GithubError(
      'SEARCH_FAILED',
      `GitHub search returned HTTP ${response.status}`,
      undefined,
    );
  }

  const data = (await response.json()) as {
    items?: Array<{
      id: number;
      full_name: string;
      description: string | null;
      html_url: string;
      stargazers_count: number;
      language: string | null;
      owner: { login: string };
    }>;
  };

  const items = data.items ?? [];

  return items.map((item) => ({
    id: item.id,
    fullName: item.full_name,
    description: item.description,
    url: item.html_url,
    stars: item.stargazers_count,
    language: item.language,
    owner: item.owner.login,
  }));
}

// ─── fetchReadme ───────────────────────────────────────────────────────────

async function fetchReadme(fullName: string): Promise<string> {
  const url = `https://api.github.com/repos/${fullName}/readme`;
  let response: Response;
  try {
    response = await fetch(url, {
      headers: {
        accept: 'application/vnd.github.raw',
        'user-agent': 'zchat-workspace/4.1',
        ...(process.env.GITHUB_TOKEN ? { authorization: `Bearer ${process.env.GITHUB_TOKEN}` } : {}),
      },
    });
  } catch (err) {
    throw new GithubError(
      'README_FETCH_FAILED',
      `Failed to fetch README for ${fullName}: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }

  if (!response.ok) {
    throw new GithubError(
      'README_FETCH_FAILED',
      `README fetch for ${fullName} returned HTTP ${response.status}`,
      undefined,
    );
  }

  return response.text();
}

// ─── importGithubRepo ──────────────────────────────────────────────────────

export async function importGithubRepo(
  workspaceId: string,
  result: GithubSearchResult,
): Promise<GithubRepoRecord> {
  logger.info({ module: 'github', op: 'import', fullName: result.fullName, workspaceId }, `Importing ${result.fullName}`);

  // Fetch README
  let readmeCache: string | null = null;
  try {
    readmeCache = await fetchReadme(result.fullName);
  } catch (err) {
    if (isGithubError(err)) {
      logger.warn({ module: 'github', fullName: result.fullName, err: err.message }, `README fetch failed — importing without README`);
      readmeCache = null;
    } else {
      throw err;
    }
  }

  // Upsert into DB (use fullName as the natural key — we generate a cuid for the PK)
  try {
    // Check if already imported (by fullName + workspaceId)
    const existing = await db.githubRepo.findFirst({
      where: { fullName: result.fullName, workspaceId },
    });

    if (existing) {
      // Update the existing record
      const updated = await db.githubRepo.update({
        where: { id: existing.id },
        data: {
          description: result.description,
          url: result.url,
          stars: result.stars,
          language: result.language,
          owner: result.owner,
          readmeCache,
        },
      });
      return toRecord(updated);
    }

    // Create new
    const created = await db.githubRepo.create({
      data: {
        workspaceId,
        fullName: result.fullName,
        description: result.description,
        url: result.url,
        stars: result.stars,
        language: result.language,
        owner: result.owner,
        readmeCache,
      },
    });
    return toRecord(created);
  } catch (err) {
    throw new GithubError(
      'IMPORT_FAILED',
      `Failed to import repo ${result.fullName}: ${err instanceof Error ? err.message : String(err)}`,
      err,
    );
  }
}

function toRecord(row: {
  id: string; workspaceId: string | null; fullName: string; description: string | null;
  url: string; stars: number; language: string | null; owner: string; readmeCache: string | null; createdAt: Date;
}): GithubRepoRecord {
  return {
    id: row.id,
    workspaceId: row.workspaceId,
    fullName: row.fullName,
    description: row.description,
    url: row.url,
    stars: row.stars,
    language: row.language,
    owner: row.owner,
    readmeCache: row.readmeCache,
    createdAt: row.createdAt,
  };
}

// ─── getImportedRepos ──────────────────────────────────────────────────────

export async function getImportedRepos(workspaceId: string): Promise<GithubRepoRecord[]> {
  const rows = await db.githubRepo.findMany({
    where: { workspaceId },
    orderBy: { createdAt: 'desc' },
  });
  return rows.map(toRecord);
}

// ─── Pin repos (session-level) ─────────────────────────────────────────────
//
// Pinned repos are stored on the Session model (repoIds JSON array).
// Max 3 repos per session (Blueprint §14).

export async function pinReposToSession(
  sessionId: string,
  workspaceId: string,
  repoIds: string[],
): Promise<void> {
  if (repoIds.length > MAX_PINNED_REPOS) {
    throw new GithubError(
      'PIN_LIMIT_EXCEEDED',
      `Cannot pin ${repoIds.length} repos — max is ${MAX_PINNED_REPOS} (Blueprint §14).`,
    );
  }

  // Verify all repo IDs belong to the workspace
  for (const repoId of repoIds) {
    const repo = await db.githubRepo.findUnique({ where: { id: repoId } });
    if (!repo || repo.workspaceId !== workspaceId) {
      throw new GithubError(
        'REPO_NOT_FOUND',
        `Repo ${repoId} not found in workspace ${workspaceId}.`,
      );
    }
  }

  // Update the session's repoIds
  // We use a direct db.session.update to avoid the status-transition validation
  // in the sessions repository (pinning repos is not a status change)
  await db.session.update({
    where: { id: sessionId },
    data: { repoIds: JSON.stringify(repoIds) },
  });

  logger.info(
    { module: 'github', op: 'pin', sessionId, workspaceId, repoIds },
    `Pinned ${repoIds.length} repos to session ${sessionId}`,
  );
}

// ─── Context injection ─────────────────────────────────────────────────────
//
// Blueprint §14: "README in system prompt with 5 citation rules. Max 3 repos.
// 6000 char cap."
//
// This function assembles the repo context block for the system prompt.
// It includes:
//   1. Each repo's name + URL + README (truncated to fit the 6000 char cap)
//   2. The 5 citation rules

const CITATION_RULES = `
When referencing information from the pinned repositories:
1. Cite the repo by name (e.g., "Per the next.js repo...").
2. Include the file path when citing specific code (e.g., "next.js/packages/next/server/next.ts").
3. Quote the relevant snippet when making claims about the code.
4. Distinguish between the repo's documentation and your own inferences.
5. If the repo does not contain the answer, say so — do not fabricate citations.
`.trim();

export async function buildRepoContext(
  workspaceId: string,
  repoIds: ReadonlyArray<string>,
): Promise<string> {
  if (repoIds.length === 0) {
    return '';
  }

  const repos: GithubRepoRecord[] = [];
  for (const repoId of repoIds) {
    const row = await db.githubRepo.findUnique({ where: { id: repoId } });
    if (!row || row.workspaceId !== workspaceId) continue;
    repos.push(toRecord(row));
  }

  if (repos.length === 0) {
    return '';
  }

  // Distribute the 6000 char cap across repos (roughly equal)
  const charsPerRepo = Math.floor(README_CHAR_CAP / repos.length);
  const parts: string[] = [];

  for (const repo of repos) {
    const readme = repo.readmeCache ?? '(No README available)';
    const truncated = readme.length > charsPerRepo
      ? readme.slice(0, charsPerRepo) + '\n... (truncated)'
      : readme;
    parts.push(`--- Repo: ${repo.fullName} ---\nURL: ${repo.url}\n\n${truncated}`);
  }

  parts.push(`--- Citation Rules ---\n${CITATION_RULES}`);

  return parts.join('\n\n');
}
