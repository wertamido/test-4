export type SessionStatus = 'idle' | 'planning' | 'executing' | 'verifying' | 'done' | 'error';

export interface SessionRecord {
  id: string;
  workspaceId: string;
  title: string;
  goal: string | null;
  status: SessionStatus;
  providerId: string | null;
  model: string;
  agentId: string | null;
  skillIds: string[];
  repoIds: string[];
  mcpServerIds: string[];
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export type MessageRole = 'user' | 'assistant' | 'system' | 'tool';

export interface ToolCall {
  id: string;
  type: 'function';
  function: { name: string; arguments: string };
}

export interface MessageRecord {
  id: string;
  sessionId: string;
  role: MessageRole;
  content: string;
  toolCalls: ToolCall[];
  tokens: number;
  costUsd: number;
  providerId: string | null;
  model: string | null;
  agentRunId: string | null;
  createdAt: string;
}

export type ProviderKind = 'openai' | 'anthropic' | 'zai' | 'custom';

export interface ProviderRecord {
  id: string;
  name: string;
  kind: ProviderKind;
  baseUrl: string | null;
  apiKey: string | null;
  models: string[];
  enabled: boolean;
  isLocal: boolean;
  installUrl: string | null;
  docsUrl: string | null;
}

export interface SkillRecord {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: string;
  systemPrompt: string;
  strength: 1 | 2 | 3;
  enabled: boolean;
  builtin: boolean;
}

export interface AgentTemplateRecord {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'orchestrator' | 'worker' | 'specialist';
  preferredProvider: string | null;
  preferredModel: string | null;
  temperature: number;
  canSpawnAgents: boolean;
  maxSubAgents: number;
  builtin: boolean;
  enabled: boolean;
}

export interface WorkspaceSettings {
  theme: 'black' | 'zinc';
  density: 'compact' | 'comfortable' | 'spacious';
  defaultProviderId: string | null;
  defaultModel: string;
  defaultTemperature: number;
  defaultMaxTokens: number;
  sendOnEnter: boolean;
  showTokenCount: boolean;
  streamingEnabled: boolean;
}

export interface ApiResult<T> {
  success: boolean;
  status: number;
  data?: T;
  error?: { code: string; message: string; issues?: Array<{ path: string; message: string }> };
}
