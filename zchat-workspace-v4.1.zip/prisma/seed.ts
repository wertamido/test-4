/**
 * Prisma Seed Script — Idempotent, Transactional, Logged
 *
 * Blueprint v4.1 §22 Phase 0 Step 0.9, §7 (Providers), §11 (Agent Templates),
 * §12 (Skills), §8 (Z.ai Policy)
 *
 * Usage:
 *   npm run db:seed        # tsx prisma/seed.ts
 *
 * What it does:
 *   1. Hashes the demo user password via hashPassword() from src/lib/auth.ts
 *   2. Upserts 1 demo User (idempotent — email is unique, upsert by email)
 *   3. Upserts 1 Workspace for the demo user
 *   4. Upserts 10 Providers (built-in, workspaceId=null)
 *   5. Upserts 42 Skills (built-in)
 *   6. Upserts 10 AgentTemplates (built-in)
 *
 * All upserts run inside a single db.$transaction so a failure in any one
 * rolls back all changes. The script logs progress via pino and exits with
 * code 0 on success, 1 on failure.
 *
 * Idempotency: every upsert uses the record's `id` (for providers, skills,
 * agent templates) or `email` (for users) as the unique key. Running the
 * script twice produces the same end state — no duplicate rows, no errors.
 *
 * Strictly typed. No `any`. Uses the db singleton from src/lib/db.ts.
 */

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { hashPassword } from '@/lib/auth';
import {
  demoUser,
  providers,
  skills,
  agentTemplates,
  EXPECTED_PROVIDER_COUNT,
  EXPECTED_AGENT_TEMPLATE_COUNT,
} from './seed-data';
import type { Prisma } from '@prisma/client';

// ─── Exit codes ────────────────────────────────────────────────────────────

const EXIT_SUCCESS = 0;
const EXIT_FAILURE = 1;

// ─── Main ──────────────────────────────────────────────────────────────────

async function main(): Promise<void> {
  logger.info({ module: 'seed' }, 'Seed script starting...');

  // ── Sanity checks against the static arrays ─────────────────────────────
  if (providers.length !== EXPECTED_PROVIDER_COUNT) {
    throw new Error(
      `Provider count mismatch: expected ${EXPECTED_PROVIDER_COUNT}, got ${providers.length}`,
    );
  }
  if (agentTemplates.length !== EXPECTED_AGENT_TEMPLATE_COUNT) {
    throw new Error(
      `Agent template count mismatch: expected ${EXPECTED_AGENT_TEMPLATE_COUNT}, got ${agentTemplates.length}`,
    );
  }
  if (skills.length !== 42) {
    throw new Error(`Skill count mismatch: expected 42, got ${skills.length}`);
  }

  // ── Hash the demo password ──────────────────────────────────────────────
  // Per Blueprint §24, never store plaintext passwords. hashPassword uses
  // bcryptjs with 12 salt rounds (constant-time compare on verify).
  logger.info({ module: 'seed' }, 'Hashing demo user password (bcryptjs, 12 rounds)...');
  const passwordHash = await hashPassword(demoUser.passwordPlain);

  // ── Run all upserts in a single transaction ─────────────────────────────
  //
  // Prisma's $transaction takes an array of promises OR a callback. We use
  // the callback form so we can interleave reads (none here) and writes,
  // and so the entire seed is atomic — a failure in any upsert rolls back
  // everything.
  //
  // Why not Promise.all? Because Prisma's $transaction with an array
  // already runs them in parallel within the transaction. The callback form
  // is sequential but easier to read and easier to extend (e.g., if a
  // later step needs the ID of an earlier step).

  logger.info({ module: 'seed' }, 'Beginning transactional seed...');

  await db.$transaction(async (tx) => {
    // ── Demo user ──────────────────────────────────────────────────────
    logger.info({ module: 'seed', email: demoUser.email }, 'Upserting demo user...');
    const user = await tx.user.upsert({
      where: { email: demoUser.email },
      update: {
        name: demoUser.name,
        passwordHash,
        tier: demoUser.tier,
      },
      create: {
        email: demoUser.email,
        name: demoUser.name,
        passwordHash,
        tier: demoUser.tier,
      },
    });

    // ── Demo workspace ─────────────────────────────────────────────────
    // Use a deterministic workspace ID so re-running the seed updates the
    // same workspace rather than creating duplicates. We upsert by
    // (userId, name) — there is no unique constraint on this pair in the
    // schema, so we first try to find, then create if missing.
    logger.info({ module: 'seed', userId: user.id }, 'Upserting demo workspace...');
    const existingWorkspace = await tx.workspace.findFirst({
      where: { userId: user.id, name: 'Demo Workspace' },
      select: { id: true },
    });

    if (existingWorkspace) {
      await tx.workspace.update({
        where: { id: existingWorkspace.id },
        data: { name: 'Demo Workspace', settings: '{}' },
      });
    } else {
      await tx.workspace.create({
        data: {
          userId: user.id,
          name: 'Demo Workspace',
          settings: '{}',
        },
      });
    }

    // ── Providers ──────────────────────────────────────────────────────
    logger.info({ module: 'seed', count: providers.length }, 'Upserting providers...');
    for (const p of providers) {
      await tx.provider.upsert({
        where: { id: p.id },
        update: {
          name: p.name,
          kind: p.kind,
          baseUrl: p.baseUrl,
          apiKey: p.apiKey,
          models: p.models,
          enabled: p.enabled,
          isLocal: p.isLocal,
          installUrl: p.installUrl,
          docsUrl: p.docsUrl,
          workspaceId: p.workspaceId,
        },
        create: {
          id: p.id,
          name: p.name,
          kind: p.kind,
          baseUrl: p.baseUrl,
          apiKey: p.apiKey,
          models: p.models,
          enabled: p.enabled,
          isLocal: p.isLocal,
          installUrl: p.installUrl,
          docsUrl: p.docsUrl,
          workspaceId: p.workspaceId,
        },
      });
    }

    // ── Skills ─────────────────────────────────────────────────────────
    logger.info({ module: 'seed', count: skills.length }, 'Upserting skills...');
    for (const s of skills) {
      await tx.skill.upsert({
        where: { id: s.id },
        update: {
          name: s.name,
          description: s.description,
          icon: s.icon,
          category: s.category,
          systemPrompt: s.systemPrompt,
          strength: s.strength,
          enabled: s.enabled,
          builtin: s.builtin,
        },
        create: {
          id: s.id,
          name: s.name,
          description: s.description,
          icon: s.icon,
          category: s.category,
          systemPrompt: s.systemPrompt,
          strength: s.strength,
          enabled: s.enabled,
          builtin: s.builtin,
        },
      });
    }

    // ── Agent templates ────────────────────────────────────────────────
    logger.info({ module: 'seed', count: agentTemplates.length }, 'Upserting agent templates...');
    for (const a of agentTemplates) {
      await tx.agentTemplate.upsert({
        where: { id: a.id },
        update: {
          name: a.name,
          description: a.description,
          icon: a.icon,
          category: a.category,
          systemPrompt: a.systemPrompt,
          tools: a.tools,
          mcpTools: a.mcpTools,
          preferredProvider: a.preferredProvider,
          preferredModel: a.preferredModel,
          temperature: a.temperature,
          canSpawnAgents: a.canSpawnAgents,
          maxSubAgents: a.maxSubAgents,
          builtin: a.builtin,
          enabled: a.enabled,
        },
        create: {
          id: a.id,
          name: a.name,
          description: a.description,
          icon: a.icon,
          category: a.category,
          systemPrompt: a.systemPrompt,
          tools: a.tools,
          mcpTools: a.mcpTools,
          preferredProvider: a.preferredProvider,
          preferredModel: a.preferredModel,
          temperature: a.temperature,
          canSpawnAgents: a.canSpawnAgents,
          maxSubAgents: a.maxSubAgents,
          builtin: a.builtin,
          enabled: a.enabled,
        },
      });
    }
  });

  logger.info(
    { module: 'seed', providers: providers.length, skills: skills.length, agentTemplates: agentTemplates.length },
    'Seed completed successfully.',
  );
}

// ─── Entry point ───────────────────────────────────────────────────────────

main()
  .then(() => {
    process.exit(EXIT_SUCCESS);
  })
  .catch((err: unknown) => {
    logger.error(
      {
        module: 'seed',
        err,
      },
      `Seed failed: ${err instanceof Error ? err.message : String(err)}`,
    );
    process.exit(EXIT_FAILURE);
  });

// ─── Type exports for tests ────────────────────────────────────────────────
//
// Export the Prisma transaction type so test files can construct type-safe
// mock transaction clients if needed.

export type { Prisma };
