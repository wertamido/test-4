/**
 * Vitest Configuration
 *
 * Blueprint v4.1 §20 (Vitest — Testing Framework), §22 Phase 0 Step 0.8
 *
 * Design goals:
 *  - Compatible with Next.js 16 App Router (no Jest, no jest.config.js)
 *  - Default test environment: 'node' (covers db.test.ts, auth.test.ts,
 *    validation.test.ts, logger.test.ts, queue.test.ts — all server-side)
 *  - Per-file jsdom opt-in via `// @vitest-environment jsdom` comment in
 *    *.test.tsx files. This is the cleanest approach because:
 *      (a) It's documented in Vitest's official docs
 *      (b) It co-locates the environment declaration with the test that needs it
 *      (c) It avoids glob-matching config that breaks when test files move
 *    The ErrorBoundary tests (tests/unit/error-boundary.test.ts) use
 *    @testing-library/react which needs jsdom — they opt in via the comment.
 *  - Resolve alias '@' → './src' mirrors tsconfig.json `paths`
 *  - v8 coverage with 80% thresholds across lines/functions/branches/statements
 *  - 'forks' pool: more isolated than 'threads', safer for code that touches
 *    Prisma (which has native bindings + connection-pool state that doesn't
 *    always survive thread reuse cleanly)
 *  - Setup file: tests/setup.ts runs once before all tests; sets env vars
 *    + suppresses console.error noise
 *  - Globals: true — `describe`/`it`/`expect` work without imports. Existing
 *    test files DO import them (which is fine — the imports become no-ops
 *    when globals are enabled).
 *
 * Strictly typed via `defineConfig` from 'vitest/config'. No `any`.
 */

import { defineConfig } from 'vitest/config';
import { resolve } from 'node:path';

export default defineConfig({
  resolve: {
    alias: {
      '@': resolve(__dirname, './src'),
    },
  },
  test: {
    // Default environment for *.test.ts files. *.test.tsx files override
    // via the `// @vitest-environment jsdom` comment at the top of the file.
    environment: 'node',

    // Run setup file before all tests
    setupFiles: ['./tests/setup.ts'],

    // Allow describe/it/expect as globals (existing tests still import them,
    // which is fine — explicit imports are no-ops when globals are enabled)
    globals: true,

    // Test file globs
    include: ['tests/unit/**/*.test.ts', 'tests/unit/**/*.test.tsx'],

    // Excluded directories — never scan these
    exclude: ['node_modules', '.next', 'dist', 'prisma'],

    // 'forks' pool: child processes per test file. Better isolation than
    // 'threads' for code that uses Prisma (native bindings + connection state).
    pool: 'forks',

    // Coverage configuration
    coverage: {
      provider: 'v8',
      reporter: ['text', 'text-summary', 'lcov', 'html'],
      reportsDirectory: './coverage',
      include: ['src/**/*.ts', 'src/**/*.tsx'],
      exclude: [
        'src/**/*.test.ts',
        'src/**/*.test.tsx',
        'src/**/__mocks__/**',
        'src/**/types.ts',
        'src/**/index.ts',
        'src/app/**', // App Router route handlers are integration-tested
      ],
      thresholds: {
        lines: 80,
        functions: 80,
        branches: 80,
        statements: 80,
      },
    },

    // Per-test timeout — generous because some tests do real bcrypt hashing
    // (12 salt rounds ≈ 100ms per hash on a slow CI)
    testTimeout: 10_000,
    hookTimeout: 10_000,
  },
});
