/**
 * WebSocket Server — Type Definitions
 *
 * Blueprint v4.1 §18 (Streaming — SSE + WebSocket), §10 (Agent Orchestration),
 * §22 Phase 0 Step 0.11
 *
 * Design goals:
 *  - WsServerEvent: discriminated union of every event the server pushes to
 *    connected clients. Used by the orchestrator → broadcastToSession() →
 *    client. Discriminant field is `type`.
 *  - WsClientMessage: discriminated union of every message a client sends
 *    to the server. Discriminant field is `type`.
 *  - WsErrorCode: string-literal union for error subtypes sent in `error`
 *    events. Matches the blueprint's event list: agent_spawned, task_assigned,
 *    task_complete, artifact_produced, phase_start, phase_complete, done, error.
 *  - WsCloseCode: numeric close-code constants. Standard 1001 (going away)
 *    for graceful shutdown; custom 4xxx codes for auth/access failures per
 *    WebSocket spec (4xxx range is application-defined).
 *
 * No runtime code in this file — types only. The implementation lives in
 * mini-services/ws-server/index.ts. Keeping types separate makes them
 * importable from test files without spinning up the server.
 */

// ─── WsServerEvent (server → client) ───────────────────────────────────────
//
// Every event carries:
//   - type: the discriminant
//   - sessionId: which session the event pertains to
//   - timestamp: epoch milliseconds
//
// Blueprint §10 lists the orchestration events: phase_start, agent_spawned,
// task_assigned, task_complete, artifact_produced, done.

export interface AgentSpawnedEvent {
  type: 'agent_spawned';
  sessionId: string;
  timestamp: number;
  agentRunId: string;
  agentName: string;
  parentRunId: string | null;
  depth: number;
  provider: string;
  model: string;
  task: string;
}

export interface TaskAssignedEvent {
  type: 'task_assigned';
  sessionId: string;
  timestamp: number;
  taskId: string;
  title: string;
  assignedToAgentRunId: string | null;
  priority: number;
  dependencies: ReadonlyArray<string>;
}

export interface TaskCompleteEvent {
  type: 'task_complete';
  sessionId: string;
  timestamp: number;
  taskId: string;
  result: string | null;
  status: 'done' | 'failed';
  durationMs: number;
}

export interface ArtifactProducedEvent {
  type: 'artifact_produced';
  sessionId: string;
  timestamp: number;
  artifactId: string;
  agentRunId: string | null;
  artifactType: 'code' | 'diff' | 'doc' | 'design' | 'data' | 'test';
  filename: string | null;
  storageUrl: string | null;
}

export interface PhaseStartEvent {
  type: 'phase_start';
  sessionId: string;
  timestamp: number;
  reasoningRunId: string;
  phase: number;
  phaseName: string;
}

export interface PhaseCompleteEvent {
  type: 'phase_complete';
  sessionId: string;
  timestamp: number;
  reasoningRunId: string;
  phase: number;
  phaseName: string;
  durationMs: number;
  tokenDelta: number;
}

export interface DoneEvent {
  type: 'done';
  sessionId: string;
  timestamp: number;
  finalArtifactIds: ReadonlyArray<string>;
  totalTokens: number;
  totalCostUsd: number;
  durationMs: number;
}

export interface ErrorEvent {
  type: 'error';
  sessionId: string;
  timestamp: number;
  code: WsErrorCode;
  message: string;
  agentRunId?: string;
  taskId?: string;
}

export type WsServerEvent =
  | AgentSpawnedEvent
  | TaskAssignedEvent
  | TaskCompleteEvent
  | ArtifactProducedEvent
  | PhaseStartEvent
  | PhaseCompleteEvent
  | DoneEvent
  | ErrorEvent;

// ─── WsClientMessage (client → server) ─────────────────────────────────────

export interface SubscribeMessage {
  type: 'subscribe';
  sessionId: string;
}

export interface UnsubscribeMessage {
  type: 'unsubscribe';
  sessionId: string;
}

export interface PingMessage {
  type: 'ping';
  clientTime: number;
}

export type WsClientMessage =
  | SubscribeMessage
  | UnsubscribeMessage
  | PingMessage;

// ─── WsErrorCode ───────────────────────────────────────────────────────────
//
// Sent inside ErrorEvent. The client uses `code` to decide how to surface
// the error to the user.

export type WsErrorCode =
  | 'AUTH_FAILED'
  | 'SESSION_NOT_FOUND'
  | 'SESSION_ACCESS_DENIED'
  | 'INVALID_MESSAGE'
  | 'ORCHESTRATION_FAILED';

// ─── WsCloseCode ───────────────────────────────────────────────────────────
//
// WebSocket close codes. The 4xxx range is application-defined per RFC 6455.
//
//   1001 — Going Away (standard, used for graceful shutdown)
//   4001 — Auth failed (JWT missing, invalid, or expired)
//   4002 — Session not found (sessionId does not exist in DB)
//   4003 — Access denied (session exists but belongs to a different workspace)

export const WsCloseCode = {
  GOING_AWAY: 1001,
  AUTH_FAILED: 4001,
  SESSION_NOT_FOUND: 4002,
  ACCESS_DENIED: 4003,
} as const;

export type WsCloseCodeValue = (typeof WsCloseCode)[keyof typeof WsCloseCode];

// ─── Connection metadata ───────────────────────────────────────────────────

/**
 * Per-connection metadata stored alongside the WebSocket instance.
 * Captured at connection time so we can log/broadcast without re-parsing
 * the query string.
 */
export interface WsConnectionMeta {
  userId: string;
  email: string;
  workspaceId: string;
  tier: string;
  /** Sessions this connection is currently subscribed to. */
  subscribedSessionIds: Set<string>;
  /** Whether the connection is alive (set false on close, true on pong). */
  isAlive: boolean;
  /** When the connection was established (epoch ms). */
  connectedAt: number;
}
