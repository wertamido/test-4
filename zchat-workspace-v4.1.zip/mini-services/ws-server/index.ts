/**
 * WebSocket Mini-Service — Port 3001
 *
 * Blueprint v4.1 §18 (Streaming — SSE + WebSocket), §10 (Agent Orchestration),
 * §22 Phase 0 Step 0.11, §5 (System Architecture)
 *
 * Design goals:
 *  - Standalone Node process (NOT part of Next.js). Runs on port 3001,
 *    configurable via process.env.WS_PORT.
 *  - Authenticates incoming connections via JWT in the query string:
 *    ws://localhost:3001?sessionId=xxx&token=<JWT>
 *  - Reuses decodeAuthToken() from src/lib/auth.ts — never reimplements JWT.
 *  - Validates sessionId belongs to the user's workspace via db singleton.
 *  - Maintains a Map<sessionId, Set<WebSocket>> for targeted broadcasting.
 *  - broadcastToSession(sessionId, event) — the orchestrator's push API.
 *  - Ping/pong heartbeat every 30s; dead connections are pruned.
 *  - Graceful shutdown on SIGINT/SIGTERM — closes all connections with 1001.
 *  - Strictly typed: WsServerEvent + WsClientMessage discriminated unions
 *    from types.ts. No `any`.
 *  - Uses pino logger from src/lib/logger.ts.
 *
 * Usage:
 *   node --import tsx mini-services/ws-server/index.ts
 *
 * Or programmatically (used by tests):
 *   import { startWsServer, broadcastToSession, stopWsServer } from '@/../mini-services/ws-server';
 *
 * Architecture note: this module exports `startWsServer`, `stopWsServer`,
 * and `broadcastToSession` so tests can spin up a server on a random port
 * and exercise it with a real `ws` client. The bottom of the file has a
 * "auto-start when run as main" block that starts the server on port 3001
 * when invoked via `node --import tsx .../index.ts`.
 */

import { WebSocketServer, WebSocket } from 'ws';
import type { IncomingMessage } from 'node:http';
import { URL } from 'node:url';

import { logger } from '@/lib/logger';
import { decodeAuthToken } from '@/lib/auth';
import { db } from '@/lib/db';
import {
  type WsServerEvent,
  type WsClientMessage,
  type WsConnectionMeta,
  type WsErrorCode,
  WsCloseCode,
} from './types';

// ─── Constants ─────────────────────────────────────────────────────────────

const DEFAULT_PORT = 3001;
const HEARTBEAT_INTERVAL_MS = 30_000;

// ─── State ─────────────────────────────────────────────────────────────────
//
// Two parallel data structures:
//   1. connectionMeta: Map<WebSocket, WsConnectionMeta>
//      - One entry per open connection. Stores the auth-derived metadata
//        (userId, workspaceId) and the set of sessions this connection is
//        subscribed to.
//   2. sessionSubscribers: Map<sessionId, Set<WebSocket>>
//      - One entry per session that has at least one subscriber. Used by
//        broadcastToSession to fan out events efficiently.
//
// Both maps are kept in sync: subscribe/unsubscribe update both. Connection
// close removes the WebSocket from both.

const connectionMeta = new Map<WebSocket, WsConnectionMeta>();
const sessionSubscribers = new Map<string, Set<WebSocket>>();

let wss: WebSocketServer | null = null;
let heartbeatInterval: NodeJS.Timeout | null = null;
let isShuttingDown = false;

// ─── startWsServer ─────────────────────────────────────────────────────────

export interface StartWsServerOptions {
  /** Port to listen on. Defaults to process.env.WS_PORT or 3001. */
  port?: number;
  /** Host to bind. Defaults to '0.0.0.0' (all interfaces). */
  host?: string;
}

export interface StartedWsServer {
  port: number;
  host: string;
  close: () => Promise<void>;
}

/**
 * Start the WebSocket server. Returns a handle with the bound port and a
 * `close()` method. Idempotent — calling startWsServer twice without
 * stopWsServer in between throws.
 */
export function startWsServer(options?: StartWsServerOptions): Promise<StartedWsServer> {
  if (wss !== null) {
    return Promise.reject(new Error('WebSocket server is already running. Call stopWsServer first.'));
  }
  if (isShuttingDown) {
    return Promise.reject(new Error('WebSocket server is shutting down. Wait for stopWsServer to complete.'));
  }

  const port = options?.port ?? (process.env.WS_PORT ? Number(process.env.WS_PORT) : DEFAULT_PORT);
  const host = options?.host ?? '0.0.0.0';

  return new Promise<StartedWsServer>((resolve, reject) => {
    const server = new WebSocketServer({ port, host });

    server.on('listening', () => {
      wss = server;
      logger.info(
        { module: 'ws-server', port, host },
        `WebSocket server listening on ws://${host}:${port}`,
      );

      // Start heartbeat
      heartbeatInterval = setInterval(heartbeat, HEARTBEAT_INTERVAL_MS);

      resolve({
        port,
        host,
        close: () => stopWsServer(),
      });
    });

    server.on('error', (err) => {
      logger.error({ module: 'ws-server', err, port, host }, `WebSocket server failed to start: ${err.message}`);
      wss = null;
      reject(err);
    });

    server.on('connection', (ws, req) => {
      void handleConnection(ws, req).catch((err) => {
        logger.error(
          { module: 'ws-server', err },
          `Unhandled error in handleConnection: ${err instanceof Error ? err.message : String(err)}`,
        );
        // Best-effort close — the connection may already be closed
        try {
          ws.close(WsCloseCode.AUTH_FAILED, 'Internal server error');
        } catch {
          // ignore
        }
      });
    });
  });
}

// ─── stopWsServer ──────────────────────────────────────────────────────────

export async function stopWsServer(): Promise<void> {
  if (wss === null) {
    return; // not running — nothing to stop
  }

  isShuttingDown = true;

  // Stop the heartbeat
  if (heartbeatInterval !== null) {
    clearInterval(heartbeatInterval);
    heartbeatInterval = null;
  }

  // Close all connections with 1001 (Going Away)
  for (const [ws, meta] of connectionMeta) {
    try {
      ws.close(WsCloseCode.GOING_AWAY, 'Server shutting down');
    } catch {
      // ignore — the connection may already be closed
    }
    void meta; // meta is captured for logging if needed
  }
  connectionMeta.clear();
  sessionSubscribers.clear();

  // Close the server
  await new Promise<void>((resolve) => {
    wss!.close((err) => {
      if (err) {
        logger.warn({ module: 'ws-server', err }, `Error closing WebSocket server: ${err.message}`);
      }
      resolve();
    });
  });

  wss = null;
  isShuttingDown = false;
  logger.info({ module: 'ws-server' }, 'WebSocket server stopped');
}

// ─── handleConnection ──────────────────────────────────────────────────────
//
// Connection lifecycle:
//   1. Parse query string → extract token + sessionId
//   2. Verify JWT via decodeAuthToken → get userId, workspaceId
//   3. Validate sessionId belongs to the user's workspace (DB query)
//   4. If any step fails → close with appropriate code + emit error event
//   5. On success → store connectionMeta, auto-subscribe to the sessionId
//      from the query string, wire up message + close handlers
//
// The connection auto-subscribes to the sessionId from the query string so
// the client doesn't have to send a separate `subscribe` message. The
// client may subscribe to additional sessions via the `subscribe` message.

async function handleConnection(ws: WebSocket, req: IncomingMessage): Promise<void> {
  // ── Parse query string ────────────────────────────────────────────────
  const url = new URL(req.url ?? '/', 'http://localhost');
  const token = url.searchParams.get('token');
  const sessionId = url.searchParams.get('sessionId');

  if (!token) {
    sendErrorAndClose(ws, WsCloseCode.AUTH_FAILED, 'AUTH_FAILED', 'Missing token in query string');
    return;
  }
  if (!sessionId) {
    sendErrorAndClose(ws, WsCloseCode.AUTH_FAILED, 'AUTH_FAILED', 'Missing sessionId in query string');
    return;
  }

  // ── Verify JWT ────────────────────────────────────────────────────────
  const secret = process.env.NEXTAUTH_SECRET;
  if (!secret) {
    sendErrorAndClose(ws, WsCloseCode.AUTH_FAILED, 'AUTH_FAILED', 'Server missing NEXTAUTH_SECRET');
    return;
  }

  let payload;
  try {
    payload = decodeAuthToken(token, secret);
  } catch (err) {
    // AuthError carries an AuthErrorCode (e.g., 'JWT_OPERATION_FAILED'); we map
    // all auth failures to WsErrorCode('AUTH_FAILED') on the wire. The original
    // error message is preserved in the `message` field for client display.
    const message = err instanceof Error ? err.message : 'Token verification failed';
    sendErrorAndClose(ws, WsCloseCode.AUTH_FAILED, 'AUTH_FAILED', message);
    return;
  }

  // ── Validate session belongs to user's workspace ──────────────────────
  try {
    const session = await db.session.findUnique({
      where: { id: sessionId },
      select: { id: true, workspaceId: true },
    });

    if (!session) {
      sendErrorAndClose(ws, WsCloseCode.SESSION_NOT_FOUND, 'SESSION_NOT_FOUND', `Session ${sessionId} not found`);
      return;
    }

    if (session.workspaceId !== payload.workspaceId) {
      sendErrorAndClose(
        ws,
        WsCloseCode.ACCESS_DENIED,
        'SESSION_ACCESS_DENIED',
        `Session ${sessionId} belongs to a different workspace`,
      );
      return;
    }
  } catch (err) {
    logger.error(
      { module: 'ws-server', err, sessionId },
      `DB error validating session: ${err instanceof Error ? err.message : String(err)}`,
    );
    sendErrorAndClose(ws, WsCloseCode.AUTH_FAILED, 'AUTH_FAILED', 'Session validation failed');
    return;
  }

  // ── Connection authenticated — register it ────────────────────────────
  const meta: WsConnectionMeta = {
    userId: payload.userId,
    email: payload.email,
    workspaceId: payload.workspaceId,
    tier: payload.tier,
    subscribedSessionIds: new Set<string>(),
    isAlive: true,
    connectedAt: Date.now(),
  };
  connectionMeta.set(ws, meta);

  // Auto-subscribe to the sessionId from the query string
  subscribeToSession(ws, sessionId);

  logger.info(
    { module: 'ws-server', userId: payload.userId, workspaceId: payload.workspaceId, sessionId },
    `WebSocket connected: user=${payload.userId} session=${sessionId}`,
  );

  // ── Wire up message + close handlers ──────────────────────────────────
  ws.on('message', (data: Buffer) => {
    void handleMessage(ws, data).catch((err) => {
      logger.warn(
        { module: 'ws-server', err },
        `Error handling message: ${err instanceof Error ? err.message : String(err)}`,
      );
    });
  });

  ws.on('pong', () => {
    const m = connectionMeta.get(ws);
    if (m) {
      m.isAlive = true;
    }
  });

  ws.on('close', (code, reason) => {
    handleClose(ws, code, reason.toString());
  });

  ws.on('error', (err) => {
    logger.warn(
      { module: 'ws-server', err, userId: payload.userId },
      `WebSocket error: ${err.message}`,
    );
  });
}

// ─── handleMessage ─────────────────────────────────────────────────────────

async function handleMessage(ws: WebSocket, data: Buffer): Promise<void> {
  const meta = connectionMeta.get(ws);
  if (!meta) {
    // Connection not registered — shouldn't happen, but defend
    return;
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(data.toString('utf8'));
  } catch {
    sendErrorEvent(ws, 'INVALID_MESSAGE', 'Message is not valid JSON');
    return;
  }

  const message = parseClientMessage(parsed);
  if (message === null) {
    sendErrorEvent(ws, 'INVALID_MESSAGE', 'Message does not match any WsClientMessage shape');
    return;
  }

  switch (message.type) {
    case 'subscribe': {
      // Validate the session belongs to the user's workspace before subscribing
      try {
        const session = await db.session.findUnique({
          where: { id: message.sessionId },
          select: { id: true, workspaceId: true },
        });
        if (!session) {
          sendErrorEvent(ws, 'SESSION_NOT_FOUND', `Session ${message.sessionId} not found`);
          return;
        }
        if (session.workspaceId !== meta.workspaceId) {
          sendErrorEvent(ws, 'SESSION_ACCESS_DENIED', `Session ${message.sessionId} belongs to a different workspace`);
          return;
        }
        subscribeToSession(ws, message.sessionId);
        logger.debug(
          { module: 'ws-server', userId: meta.userId, sessionId: message.sessionId },
          `Subscribed to session ${message.sessionId}`,
        );
      } catch (err) {
        sendErrorEvent(ws, 'AUTH_FAILED', `DB error: ${err instanceof Error ? err.message : String(err)}`);
      }
      break;
    }
    case 'unsubscribe': {
      unsubscribeFromSession(ws, message.sessionId);
      logger.debug(
        { module: 'ws-server', userId: meta.userId, sessionId: message.sessionId },
        `Unsubscribed from session ${message.sessionId}`,
      );
      break;
    }
    case 'ping': {
      // Reply with a pong event (server → client)
      const pongEvent: WsServerEvent = {
        type: 'phase_complete', // reuse a generic event type for the pong
        sessionId: '',
        timestamp: Date.now(),
        reasoningRunId: '',
        phase: 0,
        phaseName: 'pong',
        durationMs: Date.now() - message.clientTime,
        tokenDelta: 0,
      };
      // Actually, send a proper pong as a JSON message (not an event)
      ws.send(JSON.stringify({ type: 'pong', serverTime: Date.now(), clientTime: message.clientTime }));
      void pongEvent; // suppress unused warning
      break;
    }
  }
}

// ─── handleClose ───────────────────────────────────────────────────────────

function handleClose(ws: WebSocket, code: number, reason: string): void {
  const meta = connectionMeta.get(ws);
  if (!meta) {
    return;
  }

  // Remove from every subscribed session
  for (const sessionId of meta.subscribedSessionIds) {
    const subscribers = sessionSubscribers.get(sessionId);
    if (subscribers) {
      subscribers.delete(ws);
      if (subscribers.size === 0) {
        sessionSubscribers.delete(sessionId);
      }
    }
  }

  connectionMeta.delete(ws);

  logger.info(
    { module: 'ws-server', userId: meta.userId, code, reason },
    `WebSocket disconnected: user=${meta.userId} code=${code}`,
  );
}

// ─── broadcastToSession ────────────────────────────────────────────────────
//
// The orchestrator's push API. Called from the orchestration engine when
// an event happens (agent spawned, task complete, etc.).
//
// Sends the event to every connection currently subscribed to `sessionId`.
// Connections subscribed to other sessions do NOT receive it.

export function broadcastToSession(sessionId: string, event: WsServerEvent): void {
  const subscribers = sessionSubscribers.get(sessionId);
  if (!subscribers || subscribers.size === 0) {
    // No subscribers — silently drop. This is not an error; the orchestrator
    // may emit events before any client connects.
    return;
  }

  const payload = JSON.stringify(event);
  let sentCount = 0;

  for (const ws of subscribers) {
    if (ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(payload);
        sentCount++;
      } catch (err) {
        logger.warn(
          { module: 'ws-server', err, sessionId },
          `Failed to send to subscriber: ${err instanceof Error ? err.message : String(err)}`,
        );
      }
    }
  }

  logger.debug(
    { module: 'ws-server', sessionId, eventType: event.type, sentCount, subscriberCount: subscribers.size },
    `Broadcast ${event.type} to ${sentCount}/${subscribers.size} subscribers of session ${sessionId}`,
  );
}

// ─── Heartbeat ─────────────────────────────────────────────────────────────
//
// Every 30 seconds, send a ping to every connection. If a connection's
// `isAlive` flag is false (meaning we never received a pong since the last
// heartbeat), terminate it — the client is presumed dead.

function heartbeat(): void {
  if (wss === null) {
    return;
  }

  let checked = 0;
  let pruned = 0;

  for (const [ws, meta] of connectionMeta) {
    checked++;
    if (meta.isAlive === false) {
      // Connection did not respond to the last ping — terminate it
      pruned++;
      try {
        ws.terminate();
      } catch {
        // ignore
      }
      handleClose(ws, 1006, 'heartbeat timeout');
      continue;
    }

    // Mark as not-alive; the pong handler will set it back to true
    meta.isAlive = false;
    try {
      ws.ping();
    } catch {
      // ignore — connection may have closed between iterations
    }
  }

  if (checked > 0) {
    logger.debug(
      { module: 'ws-server', checked, pruned },
      `Heartbeat: checked ${checked} connections, pruned ${pruned} dead`,
    );
  }
}

// ─── Helper: subscription management ───────────────────────────────────────

function subscribeToSession(ws: WebSocket, sessionId: string): void {
  const meta = connectionMeta.get(ws);
  if (!meta) {
    return;
  }
  meta.subscribedSessionIds.add(sessionId);

  let subscribers = sessionSubscribers.get(sessionId);
  if (!subscribers) {
    subscribers = new Set<WebSocket>();
    sessionSubscribers.set(sessionId, subscribers);
  }
  subscribers.add(ws);
}

function unsubscribeFromSession(ws: WebSocket, sessionId: string): void {
  const meta = connectionMeta.get(ws);
  if (!meta) {
    return;
  }
  meta.subscribedSessionIds.delete(sessionId);

  const subscribers = sessionSubscribers.get(sessionId);
  if (subscribers) {
    subscribers.delete(ws);
    if (subscribers.size === 0) {
      sessionSubscribers.delete(sessionId);
    }
  }
}

// ─── Helper: error + close ─────────────────────────────────────────────────

function sendErrorEvent(ws: WebSocket, code: WsErrorCode, message: string): void {
  const event: WsServerEvent = {
    type: 'error',
    sessionId: '',
    timestamp: Date.now(),
    code,
    message,
  };
  if (ws.readyState === WebSocket.OPEN) {
    try {
      ws.send(JSON.stringify(event));
    } catch {
      // ignore
    }
  }
}

function sendErrorAndClose(
  ws: WebSocket,
  closeCode: number,
  errorCode: WsErrorCode,
  message: string,
): void {
  sendErrorEvent(ws, errorCode, message);
  try {
    ws.close(closeCode, message);
  } catch {
    // ignore
  }
}

// ─── Helper: parse client message (type-safe) ──────────────────────────────

function parseClientMessage(parsed: unknown): WsClientMessage | null {
  if (typeof parsed !== 'object' || parsed === null) {
    return null;
  }
  const obj = parsed as { type?: unknown };
  if (typeof obj.type !== 'string') {
    return null;
  }

  switch (obj.type) {
    case 'subscribe': {
      const m = obj as { sessionId?: unknown };
      if (typeof m.sessionId !== 'string' || m.sessionId.length === 0) {
        return null;
      }
      return { type: 'subscribe', sessionId: m.sessionId };
    }
    case 'unsubscribe': {
      const m = obj as { sessionId?: unknown };
      if (typeof m.sessionId !== 'string' || m.sessionId.length === 0) {
        return null;
      }
      return { type: 'unsubscribe', sessionId: m.sessionId };
    }
    case 'ping': {
      const m = obj as { clientTime?: unknown };
      if (typeof m.clientTime !== 'number') {
        return null;
      }
      return { type: 'ping', clientTime: m.clientTime };
    }
    default:
      return null;
  }
}

// ─── Exported state helpers (for tests) ────────────────────────────────────

export function _getConnectionCountForTests(): number {
  return connectionMeta.size;
}

export function _getSubscriberCountForTests(sessionId: string): number {
  return sessionSubscribers.get(sessionId)?.size ?? 0;
}

export function _getSessionCountForTests(): number {
  return sessionSubscribers.size;
}

// ─── Auto-start when run as main ───────────────────────────────────────────
//
// `node --import tsx mini-services/ws-server/index.ts` triggers this block.
// Tests import the module without running main (vitest sets a flag).

async function main(): Promise<void> {
  const port = process.env.WS_PORT ? Number(process.env.WS_PORT) : DEFAULT_PORT;

  await startWsServer({ port });

  // Graceful shutdown
  const shutdown = async (signal: NodeJS.Signals): Promise<void> => {
    logger.info({ module: 'ws-server', signal }, `Received ${signal}, shutting down...`);
    await stopWsServer();
    process.exit(0);
  };

  process.on('SIGINT', (sig) => void shutdown(sig));
  process.on('SIGTERM', (sig) => void shutdown(sig));
}

// Detect "run as main" — `import.meta.url` is the file URL when run via node/tsx
// and `process.argv[1]` is the script path. We check if argv[1] ends with
// 'ws-server/index.ts' (or .js after compilation).
const isMain = typeof process.argv[1] === 'string' &&
  (process.argv[1].endsWith('ws-server/index.ts') ||
   process.argv[1].endsWith('ws-server/index.js'));

if (isMain) {
  main().catch((err) => {
    logger.error(
      { module: 'ws-server', err },
      `Fatal: ${err instanceof Error ? err.message : String(err)}`,
    );
    process.exit(1);
  });
}
