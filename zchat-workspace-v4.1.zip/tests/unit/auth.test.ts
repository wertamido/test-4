/**
 * Unit tests for src/lib/auth.ts
 *
 * Blueprint v4.1 §24 (Security Model), §23 (Testing Strategy)
 *
 * Covers:
 *  - credentialsSchema (Zod): valid email, invalid email, missing/short password
 *  - hashPassword / verifyPassword: roundtrip, wrong password, salt uniqueness
 *  - encodeAuthToken / decodeAuthToken: roundtrip with workspaceId, wrong secret,
 *    malformed token, short-secret rejection
 *  - lookupWorkspaceId: hit, miss (AuthError NO_WORKSPACE)
 *  - authorizeUser: invalid input, unknown email, wrong password, correct
 *    credentials, OAuth-only user (no passwordHash)
 *  - assertAuthConfigured / getAuthOptions: missing/short secret, valid secret,
 *    cache stability, jwt+session callback wiring
 *  - AuthError + isAuthError: type guard behavior
 *
 * Mocking strategy: `@/lib/db` is mocked with vitest's vi.mock so the suite
 * never touches a real database. The mock provides vi.fn() stubs for the two
 * Prisma methods auth.ts calls (user.findUnique, workspace.findFirst).
 *
 * NEXTAUTH_SECRET is set/removed per-test with try/finally restoration so the
 * suite is hermetic regardless of the ambient environment.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

// vi.mock is hoisted by vitest to the top of the file, so the mock factory
// runs before the `import { ... } from '@/lib/auth'` line below. The factory
// must return an object shaped like the `db` export of src/lib/db.ts.
vi.mock('@/lib/db', () => ({
  db: {
    user: { findUnique: vi.fn() },
    workspace: { findFirst: vi.fn() },
  },
}));

import { db } from '@/lib/db';
import {
  AuthError,
  isAuthError,
  credentialsSchema,
  hashPassword,
  verifyPassword,
  authorizeUser,
  encodeAuthToken,
  decodeAuthToken,
  lookupWorkspaceId,
  assertAuthConfigured,
  getAuthOptions,
  _resetAuthOptionsCacheForTests,
  type AuthTokenPayload,
} from '@/lib/auth';
import type { NextAuthOptions } from 'next-auth';

// ─── Test constants ────────────────────────────────────────────────────────

const TEST_SECRET = 'test-secret-min-16-chars-long';
const TEST_EMAIL = 'user@example.com';
const TEST_PASSWORD = 'correct-horse-battery-staple';

// Helper: snapshot + restore an env var across a test block
function withEnv(key: string, value: string | undefined, fn: () => void | Promise<void>): () => Promise<void> {
  return async () => {
    const old = process.env[key];
    if (value === undefined) delete process.env[key];
    else process.env[key] = value;
    try {
      await fn();
    } finally {
      if (old === undefined) delete process.env[key];
      else process.env[key] = old;
    }
  };
}

// ─── credentialsSchema ─────────────────────────────────────────────────────

describe('credentialsSchema', () => {
  it('accepts a valid email + password (≥8 chars)', () => {
    const result = credentialsSchema.safeParse({
      email: TEST_EMAIL,
      password: TEST_PASSWORD,
    });
    expect(result.success).toBe(true);
  });

  it('rejects an invalid email', () => {
    const result = credentialsSchema.safeParse({
      email: 'not-an-email',
      password: TEST_PASSWORD,
    });
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.issues.some((i) => i.message.toLowerCase().includes('email'))).toBe(true);
    }
  });

  it('rejects a missing password (empty string)', () => {
    const result = credentialsSchema.safeParse({
      email: TEST_EMAIL,
      password: '',
    });
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.issues.some((i) => i.message.toLowerCase().includes('password'))).toBe(true);
    }
  });

  it('rejects a password shorter than 8 characters', () => {
    const result = credentialsSchema.safeParse({
      email: TEST_EMAIL,
      password: 'short',
    });
    expect(result.success).toBe(false);
  });

  it('rejects a missing email (empty string)', () => {
    const result = credentialsSchema.safeParse({
      email: '',
      password: TEST_PASSWORD,
    });
    expect(result.success).toBe(false);
  });

  it('rejects a non-string email', () => {
    const result = credentialsSchema.safeParse({
      email: 123,
      password: TEST_PASSWORD,
    });
    expect(result.success).toBe(false);
  });
});

// ─── hashPassword / verifyPassword ─────────────────────────────────────────

describe('hashPassword / verifyPassword', () => {
  it('hashes a plaintext password and verifies it round-trips', async () => {
    const hash = await hashPassword(TEST_PASSWORD);
    expect(hash).not.toBe(TEST_PASSWORD);
    expect(typeof hash).toBe('string');
    expect(hash.length).toBeGreaterThan(0);

    const ok = await verifyPassword(TEST_PASSWORD, hash);
    expect(ok).toBe(true);
  });

  it('rejects a wrong password against a known hash', async () => {
    const hash = await hashPassword(TEST_PASSWORD);
    const ok = await verifyPassword('definitely-wrong', hash);
    expect(ok).toBe(false);
  });

  it('produces different hashes for the same input (random salt)', async () => {
    const a = await hashPassword(TEST_PASSWORD);
    const b = await hashPassword(TEST_PASSWORD);
    expect(a).not.toBe(b);
  });

  it('still accepts the correct password after multiple hashes are generated', async () => {
    const hash = await hashPassword(TEST_PASSWORD);
    // Generate unrelated hashes that must not interfere with verification
    await hashPassword('other-password-1');
    await hashPassword('other-password-2');
    const ok = await verifyPassword(TEST_PASSWORD, hash);
    expect(ok).toBe(true);
  });
});

// ─── encodeAuthToken / decodeAuthToken ─────────────────────────────────────

describe('encodeAuthToken / decodeAuthToken', () => {
  const payload: AuthTokenPayload = {
    userId: 'user-abc',
    email: TEST_EMAIL,
    workspaceId: 'ws-xyz',
    tier: 'pro',
  };

  it('round-trips a payload with workspaceId preserved', () => {
    const token = encodeAuthToken(payload, TEST_SECRET);
    expect(typeof token).toBe('string');
    expect(token.split('.')).toHaveLength(3); // header.payload.signature

    const decoded = decodeAuthToken(token, TEST_SECRET);
    expect(decoded.userId).toBe(payload.userId);
    expect(decoded.email).toBe(payload.email);
    expect(decoded.workspaceId).toBe(payload.workspaceId);
    expect(decoded.tier).toBe(payload.tier);
  });

  it('throws AuthError(JWT_OPERATION_FAILED) when decoded with the wrong secret', () => {
    const token = encodeAuthToken(payload, TEST_SECRET);
    expect(() => decodeAuthToken(token, 'different-secret-also-long')).toThrow(AuthError);
    try {
      decodeAuthToken(token, 'different-secret-also-long');
    } catch (err) {
      expect(isAuthError(err)).toBe(true);
      if (isAuthError(err)) expect(err.code).toBe('JWT_OPERATION_FAILED');
    }
  });

  it('throws AuthError(AUTH_CONFIG_MISSING) when the secret is too short (<16 chars)', () => {
    expect(() => encodeAuthToken(payload, 'short')).toThrow(AuthError);
    try {
      encodeAuthToken(payload, 'short');
    } catch (err) {
      expect(isAuthError(err)).toBe(true);
      if (isAuthError(err)) expect(err.code).toBe('AUTH_CONFIG_MISSING');
    }
  });

  it('throws AuthError(AUTH_CONFIG_MISSING) when the secret is empty', () => {
    expect(() => encodeAuthToken(payload, '')).toThrow(AuthError);
  });

  it('throws AuthError(JWT_OPERATION_FAILED) on a malformed token', () => {
    expect(() => decodeAuthToken('not-a-jwt', TEST_SECRET)).toThrow(AuthError);
    try {
      decodeAuthToken('not-a-jwt', TEST_SECRET);
    } catch (err) {
      expect(isAuthError(err)).toBe(true);
      if (isAuthError(err)) expect(err.code).toBe('JWT_OPERATION_FAILED');
    }
  });

  it('throws AuthError(JWT_OPERATION_FAILED) on a token missing required fields', () => {
    // Sign a token with a partial payload (missing workspaceId + tier)
    // using jsonwebtoken directly to bypass our own validation.
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const jwtLib = require('jsonwebtoken') as typeof import('jsonwebtoken');
    const partial = jwtLib.sign({ userId: 'u1', email: 'a@b.com' }, TEST_SECRET, {
      issuer: 'zchat',
      audience: 'zchat-user',
    });
    expect(() => decodeAuthToken(partial, TEST_SECRET)).toThrow(AuthError);
    try {
      decodeAuthToken(partial, TEST_SECRET);
    } catch (err) {
      expect(isAuthError(err)).toBe(true);
      if (isAuthError(err)) expect(err.code).toBe('JWT_OPERATION_FAILED');
    }
  });
});

// ─── lookupWorkspaceId ─────────────────────────────────────────────────────

describe('lookupWorkspaceId', () => {
  beforeEach(() => {
    vi.mocked(db.workspace.findFirst).mockReset();
  });

  it('returns the workspace id when one exists', async () => {
    vi.mocked(db.workspace.findFirst).mockResolvedValueOnce({ id: 'ws-1' });
    const result = await lookupWorkspaceId('user-1');
    expect(result).toBe('ws-1');
    expect(db.workspace.findFirst).toHaveBeenCalledWith({
      where: { userId: 'user-1' },
      orderBy: { createdAt: 'asc' },
      select: { id: true },
    });
  });

  it('throws AuthError(NO_WORKSPACE) when no workspace exists for the user', async () => {
    vi.mocked(db.workspace.findFirst).mockResolvedValueOnce(null);
    try {
      await lookupWorkspaceId('user-without-ws');
      expect.fail('Expected lookupWorkspaceId to throw');
    } catch (err) {
      expect(isAuthError(err)).toBe(true);
      if (isAuthError(err)) expect(err.code).toBe('NO_WORKSPACE');
    }
  });
});

// ─── authorizeUser ─────────────────────────────────────────────────────────

describe('authorizeUser', () => {
  beforeEach(() => {
    vi.mocked(db.user.findUnique).mockReset();
  });

  it('throws AuthError(VALIDATION_FAILED) on an invalid email', async () => {
    try {
      await authorizeUser({ email: 'not-an-email', password: TEST_PASSWORD });
      expect.fail('Expected authorizeUser to throw');
    } catch (err) {
      expect(isAuthError(err)).toBe(true);
      if (isAuthError(err)) expect(err.code).toBe('VALIDATION_FAILED');
    }
    expect(db.user.findUnique).not.toHaveBeenCalled();
  });

  it('throws AuthError(VALIDATION_FAILED) on a missing password', async () => {
    try {
      await authorizeUser({ email: TEST_EMAIL, password: '' });
      expect.fail('Expected authorizeUser to throw');
    } catch (err) {
      expect(isAuthError(err)).toBe(true);
      if (isAuthError(err)) expect(err.code).toBe('VALIDATION_FAILED');
    }
  });

  it('throws AuthError(USER_NOT_FOUND) when email is unknown', async () => {
    vi.mocked(db.user.findUnique).mockResolvedValueOnce(null);
    try {
      await authorizeUser({ email: 'unknown@example.com', password: TEST_PASSWORD });
      expect.fail('Expected authorizeUser to throw');
    } catch (err) {
      expect(isAuthError(err)).toBe(true);
      if (isAuthError(err)) expect(err.code).toBe('USER_NOT_FOUND');
    }
  });

  it('throws AuthError(PASSWORD_MISMATCH) when password is wrong', async () => {
    const hash = await hashPassword(TEST_PASSWORD);
    vi.mocked(db.user.findUnique).mockResolvedValueOnce({
      id: 'u1',
      email: TEST_EMAIL,
      name: 'Test User',
      passwordHash: hash,
      tier: 'free',
    });
    try {
      await authorizeUser({ email: TEST_EMAIL, password: 'definitely-wrong' });
      expect.fail('Expected authorizeUser to throw');
    } catch (err) {
      expect(isAuthError(err)).toBe(true);
      if (isAuthError(err)) expect(err.code).toBe('PASSWORD_MISMATCH');
    }
  });

  it('returns the AuthUser when credentials are correct', async () => {
    const hash = await hashPassword(TEST_PASSWORD);
    vi.mocked(db.user.findUnique).mockResolvedValueOnce({
      id: 'u1',
      email: TEST_EMAIL,
      name: 'Test User',
      passwordHash: hash,
      tier: 'pro',
    });
    const user = await authorizeUser({ email: TEST_EMAIL, password: TEST_PASSWORD });
    expect(user).toEqual({
      id: 'u1',
      email: TEST_EMAIL,
      name: 'Test User',
      tier: 'pro',
    });
  });

  it('throws AuthError(INVALID_CREDENTIALS) when user has no passwordHash (OAuth-only)', async () => {
    vi.mocked(db.user.findUnique).mockResolvedValueOnce({
      id: 'u2',
      email: 'oauth@example.com',
      name: null,
      passwordHash: null,
      tier: 'free',
    });
    try {
      await authorizeUser({ email: 'oauth@example.com', password: 'anything-12' });
      expect.fail('Expected authorizeUser to throw');
    } catch (err) {
      expect(isAuthError(err)).toBe(true);
      if (isAuthError(err)) expect(err.code).toBe('INVALID_CREDENTIALS');
    }
  });

  it('queries by email and selects only the required fields', async () => {
    const hash = await hashPassword(TEST_PASSWORD);
    vi.mocked(db.user.findUnique).mockResolvedValueOnce({
      id: 'u1',
      email: TEST_EMAIL,
      name: 'Test',
      passwordHash: hash,
      tier: 'free',
    });
    await authorizeUser({ email: TEST_EMAIL, password: TEST_PASSWORD });
    expect(db.user.findUnique).toHaveBeenCalledWith({
      where: { email: TEST_EMAIL },
      select: {
        id: true,
        email: true,
        name: true,
        passwordHash: true,
        tier: true,
      },
    });
  });
});

// ─── assertAuthConfigured / getAuthOptions ─────────────────────────────────

describe('assertAuthConfigured', () => {
  const originalSecret = process.env.NEXTAUTH_SECRET;

  afterEach(() => {
    if (originalSecret === undefined) delete process.env.NEXTAUTH_SECRET;
    else process.env.NEXTAUTH_SECRET = originalSecret;
  });

  it('throws AuthError(AUTH_CONFIG_MISSING) when NEXTAUTH_SECRET is unset', () => {
    delete process.env.NEXTAUTH_SECRET;
    expect(() => assertAuthConfigured()).toThrow(AuthError);
    try {
      assertAuthConfigured();
    } catch (err) {
      expect(isAuthError(err)).toBe(true);
      if (isAuthError(err)) expect(err.code).toBe('AUTH_CONFIG_MISSING');
    }
  });

  it('throws when NEXTAUTH_SECRET is shorter than 16 characters', () => {
    process.env.NEXTAUTH_SECRET = 'short';
    expect(() => assertAuthConfigured()).toThrow(AuthError);
  });

  it('passes when NEXTAUTH_SECRET is at least 16 characters', () => {
    process.env.NEXTAUTH_SECRET = TEST_SECRET;
    expect(() => assertAuthConfigured()).not.toThrow();
  });
});

describe('getAuthOptions', () => {
  const originalSecret = process.env.NEXTAUTH_SECRET;

  beforeEach(() => {
    _resetAuthOptionsCacheForTests();
    vi.mocked(db.workspace.findFirst).mockReset();
  });

  afterEach(() => {
    if (originalSecret === undefined) delete process.env.NEXTAUTH_SECRET;
    else process.env.NEXTAUTH_SECRET = originalSecret;
  });

  it('throws AuthError when NEXTAUTH_SECRET is missing', () => {
    delete process.env.NEXTAUTH_SECRET;
    expect(() => getAuthOptions()).toThrow(AuthError);
  });

  it('returns a fully-formed NextAuthOptions object when configured', () => {
    process.env.NEXTAUTH_SECRET = TEST_SECRET;
    const opts: NextAuthOptions = getAuthOptions();
    expect(opts.session?.strategy).toBe('jwt');
    expect(opts.session?.maxAge).toBe(60 * 60 * 24);
    expect(Array.isArray(opts.providers)).toBe(true);
    expect(opts.providers).toHaveLength(1);
    expect(opts.callbacks?.jwt).toBeTypeOf('function');
    expect(opts.callbacks?.session).toBeTypeOf('function');
    expect(opts.pages?.signIn).toBe('/login');
    expect(opts.pages?.error).toBe('/login');
  });

  it('caches the options on subsequent calls (same reference)', () => {
    process.env.NEXTAUTH_SECRET = TEST_SECRET;
    const a = getAuthOptions();
    const b = getAuthOptions();
    expect(b).toBe(a);
  });

  it('jwt callback injects userId, workspaceId, tier from user on sign-in', async () => {
    process.env.NEXTAUTH_SECRET = TEST_SECRET;
    const opts = getAuthOptions();
    const jwtCb = opts.callbacks!.jwt!;
    vi.mocked(db.workspace.findFirst).mockResolvedValueOnce({ id: 'ws-1' });

    // Use Parameters<typeof fn> to construct a type-safe arg shape — no `any`.
    type JwtArgs = Parameters<typeof jwtCb>[0];
    const args: JwtArgs = {
      token: {},
      user: { id: 'u1', email: TEST_EMAIL, name: 'T', tier: 'pro' },
    } as JwtArgs;

    const token = await jwtCb(args);

    expect(token.userId).toBe('u1');
    expect(token.workspaceId).toBe('ws-1');
    expect(token.tier).toBe('pro');
  });

  it('jwt callback leaves token unchanged when no user is present (subsequent calls)', async () => {
    process.env.NEXTAUTH_SECRET = TEST_SECRET;
    const opts = getAuthOptions();
    const jwtCb = opts.callbacks!.jwt!;

    type JwtArgs = Parameters<typeof jwtCb>[0];
    const args: JwtArgs = {
      token: { userId: 'u1', workspaceId: 'ws-1', tier: 'pro' },
    } as JwtArgs;

    const token = await jwtCb(args);
    expect(token.userId).toBe('u1');
    expect(token.workspaceId).toBe('ws-1');
    expect(token.tier).toBe('pro');
    expect(db.workspace.findFirst).not.toHaveBeenCalled();
  });

  it('session callback injects workspaceId from token into session.user', async () => {
    process.env.NEXTAUTH_SECRET = TEST_SECRET;
    const opts = getAuthOptions();
    const sessionCb = opts.callbacks!.session!;

    type SessionArgs = Parameters<typeof sessionCb>[0];
    const session = {
      user: { id: '', email: TEST_EMAIL, name: 'T' },
      expires: new Date().toISOString(),
    };
    const args: SessionArgs = {
      session,
      token: {
        userId: 'u1',
        workspaceId: 'ws-1',
        tier: 'pro',
      },
    } as SessionArgs;

    const result = await sessionCb(args);
    expect(result.user.id).toBe('u1');
    expect(result.user.workspaceId).toBe('ws-1');
    expect(result.user.tier).toBe('pro');
  });
});

// ─── AuthError + isAuthError ───────────────────────────────────────────────

describe('AuthError', () => {
  it('preserves code, message, and cause', () => {
    const cause = new Error('root cause');
    const err = new AuthError('PASSWORD_MISMATCH', 'wrong pw', cause);
    expect(err.code).toBe('PASSWORD_MISMATCH');
    expect(err.message).toBe('wrong pw');
    expect(err.cause).toBe(cause);
    expect(err.name).toBe('AuthError');
  });

  it('is an instance of Error', () => {
    const err = new AuthError('USER_NOT_FOUND', 'x');
    expect(err).toBeInstanceOf(Error);
  });

  it('survives instanceof AuthError after subclassing Error (prototype chain)', () => {
    const err = new AuthError('VALIDATION_FAILED', 'x');
    expect(err).toBeInstanceOf(AuthError);
    try {
      throw err;
    } catch (caught) {
      expect(caught).toBeInstanceOf(AuthError);
    }
  });

  it('exposes every AuthErrorCode value', () => {
    const codes: ReadonlyArray<AuthError['code']> = [
      'INVALID_CREDENTIALS',
      'USER_NOT_FOUND',
      'PASSWORD_MISMATCH',
      'VALIDATION_FAILED',
      'NO_WORKSPACE',
      'JWT_OPERATION_FAILED',
      'AUTH_CONFIG_MISSING',
    ];
    for (const code of codes) {
      const err = new AuthError(code, `message for ${code}`);
      expect(err.code).toBe(code);
    }
  });

  it('supports an undefined cause', () => {
    const err = new AuthError('NO_WORKSPACE', 'bye');
    expect(err.cause).toBeUndefined();
  });
});

describe('isAuthError', () => {
  it('returns false for primitives', () => {
    expect(isAuthError(0)).toBe(false);
    expect(isAuthError('')).toBe(false);
    expect(isAuthError(false)).toBe(false);
    expect(isAuthError(null)).toBe(false);
    expect(isAuthError(undefined)).toBe(false);
  });

  it('returns false for plain objects lacking the brand symbol', () => {
    expect(isAuthError({ code: 'VALIDATION_FAILED', message: 'fake' })).toBe(false);
    expect(isAuthError(new Error('plain'))).toBe(false);
    expect(isAuthError({})).toBe(false);
  });

  it('returns true for AuthError instances', () => {
    const err = new AuthError('USER_NOT_FOUND', 'real');
    expect(isAuthError(err)).toBe(true);
  });

  it('does not confuse AuthError with DbError from src/lib/db.ts (different brand symbol)', () => {
    // Simulate a DbError-shaped object: same fields, but no AuthError brand.
    const fakeDbError = Object.assign(new Error('db failed'), {
      code: 'QUERY_FAILED',
      cause: undefined,
    });
    expect(isAuthError(fakeDbError)).toBe(false);
  });
});

// ─── Sanity: env-var isolation helper (paranoid check) ─────────────────────

describe('withEnv helper isolation', () => {
  it('restores the original env var value after the wrapped function runs', async () => {
    const before = process.env.NEXTAUTH_SECRET;
    const run = withEnv('NEXTAUTH_SECRET', 'temp-value-16-chars', () => {
      expect(process.env.NEXTAUTH_SECRET).toBe('temp-value-16-chars');
    });
    await run();
    expect(process.env.NEXTAUTH_SECRET).toBe(before);
  });
});
