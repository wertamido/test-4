/** Advanced Features Tests — Blueprint §22 Phase 5 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  setMemory, getMemory, listMemory,
  getDashboardData,
  uploadFile, MAX_FILE_SIZE_BYTES,
  type MemoryLayer,
} from '@/lib/advanced';
import { LocalStorageAdapter } from '@/lib/storage/local';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import os from 'node:os';

vi.mock('@/lib/db', () => ({
  db: {
    agentMemory: { create: vi.fn(), findFirst: vi.fn(), findMany: vi.fn() },
    workspace: { findMany: vi.fn() },
    session: { findMany: vi.fn() },
    message: { findMany: vi.fn() },
  },
}));
vi.mock('@/lib/sessions/repository', () => ({
  getSession: vi.fn(async () => ({ id: 'sess-1', workspaceId: 'ws-1' })),
}));
vi.mock('@/lib/logger', () => ({
  logger: { trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
    child: vi.fn(() => ({ trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(), child: vi.fn(), level: 'debug' })) },
}));

import { db } from '@/lib/db';

const WS_1 = 'ws-1';
const SESS_1 = 'sess-1';

let tmpRoot: string;
beforeEach(async () => {
  tmpRoot = path.join(os.tmpdir(), `zchat-adv-test-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  await fs.mkdir(tmpRoot, { recursive: true });
  for (const model of Object.values(db) as Array<Record<string, ReturnType<typeof vi.fn>>>) {
    for (const fn of Object.values(model)) fn.mockReset();
  }
});
afterEach(async () => {
  try { await fs.rm(tmpRoot, { recursive: true, force: true }); } catch { /* ignore */ }
});

// ─── Memory System ─────────────────────────────────────────────────────────

describe('Memory System (3-layer)', () => {
  it('setMemory session layer requires sessionId', async () => {
    try {
      await setMemory({ workspaceId: WS_1, layer: 'session', key: 'k', value: 'v' });
      expect.fail('throw');
    } catch (err) {
      expect(err).toBeInstanceOf(Error);
    }
  });

  it('setMemory session layer creates an AgentMemory record', async () => {
    (db.agentMemory.create as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'mem-1', sessionId: SESS_1, key: 'k', value: 'v', scope: 'session', createdAt: new Date(),
    });
    const entry = await setMemory({ workspaceId: WS_1, sessionId: SESS_1, layer: 'session', key: 'k', value: 'v' });
    expect(entry.layer).toBe('session');
    expect(entry.sessionId).toBe(SESS_1);
    expect(entry.key).toBe('k');
  });

  it('setMemory workspace layer uses synthetic sessionId', async () => {
    (db.agentMemory.create as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'mem-1', sessionId: '__ws__:ws-1', key: 'k', value: 'v', scope: 'workspace', createdAt: new Date(),
    });
    const entry = await setMemory({ workspaceId: WS_1, layer: 'workspace', key: 'k', value: 'v' });
    expect(entry.layer).toBe('workspace');
    expect(entry.workspaceId).toBe(WS_1);
  });

  it('setMemory global layer uses __global__ sessionId', async () => {
    (db.agentMemory.create as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'mem-1', sessionId: '__global__', key: 'k', value: 'v', scope: 'global', createdAt: new Date(),
    });
    const entry = await setMemory({ workspaceId: WS_1, layer: 'global', key: 'k', value: 'v' });
    expect(entry.layer).toBe('global');
  });

  it('getMemory returns the latest entry for a key', async () => {
    (db.agentMemory.findFirst as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'mem-1', sessionId: SESS_1, key: 'k', value: 'v', scope: 'session', createdAt: new Date(),
    });
    const entry = await getMemory({ workspaceId: WS_1, sessionId: SESS_1, layer: 'session', key: 'k' });
    expect(entry).not.toBeNull();
    expect(entry!.value).toBe('v');
  });

  it('getMemory returns null when key not found', async () => {
    (db.agentMemory.findFirst as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);
    const entry = await getMemory({ workspaceId: WS_1, sessionId: SESS_1, layer: 'session', key: 'nope' });
    expect(entry).toBeNull();
  });

  it('listMemory returns all entries for a layer', async () => {
    (db.agentMemory.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { id: 'm1', sessionId: SESS_1, key: 'k1', value: 'v1', scope: 'session', createdAt: new Date() },
      { id: 'm2', sessionId: SESS_1, key: 'k2', value: 'v2', scope: 'session', createdAt: new Date() },
    ]);
    const entries = await listMemory({ workspaceId: WS_1, sessionId: SESS_1, layer: 'session' });
    expect(entries).toHaveLength(2);
  });

  it('MemoryLayer type includes session, workspace, global', () => {
    const layers: MemoryLayer[] = ['session', 'workspace', 'global'];
    expect(layers).toHaveLength(3);
  });
});

// ─── Token Dashboard ───────────────────────────────────────────────────────

describe('Token Dashboard', () => {
  it('aggregates usage data by day, provider, and model', async () => {
    (db.workspace.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([{ id: WS_1 }]);
    (db.session.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([{ id: SESS_1 }]);
    const today = new Date();
    (db.message.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { tokens: 100, costUsd: 0.01, providerId: 'openai', model: 'gpt-4o', createdAt: today, sessionId: SESS_1 },
      { tokens: 200, costUsd: 0.02, providerId: 'mistral', model: 'mistral-large-latest', createdAt: today, sessionId: SESS_1 },
    ]);

    const dashboard = await getDashboardData('user-1', 30);

    expect(dashboard.totalTokens).toBe(300);
    expect(dashboard.totalCostUsd).toBeCloseTo(0.03, 4);
    expect(dashboard.totalMessages).toBe(2);
    expect(dashboard.totalSessions).toBe(1);
    expect(dashboard.byDay).toHaveLength(1);
    expect(dashboard.byProvider).toHaveLength(2);
    expect(dashboard.byModel).toHaveLength(2);
  });

  it('returns empty arrays when no messages', async () => {
    (db.workspace.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([]);
    (db.session.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([]);
    (db.message.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([]);

    const dashboard = await getDashboardData('user-1');
    expect(dashboard.totalTokens).toBe(0);
    expect(dashboard.byDay).toEqual([]);
    expect(dashboard.byProvider).toEqual([]);
  });
});

// ─── File Upload ───────────────────────────────────────────────────────────

describe('File Upload', () => {
  it('MAX_FILE_SIZE_BYTES is 10MB', () => {
    expect(MAX_FILE_SIZE_BYTES).toBe(10 * 1024 * 1024);
  });

  it('uploads a file under the size limit', async () => {
    const storage = new LocalStorageAdapter(tmpRoot);
    const content = Buffer.from('hello, file upload');

    const result = await uploadFile({
      workspaceId: WS_1,
      sessionId: SESS_1,
      filename: 'test.txt',
      content,
      contentType: 'text/plain',
      storage,
    });

    expect(result.filename).toBe('test.txt');
    expect(result.size).toBe(content.length);
    expect(result.contentType).toBe('text/plain');
    expect(result.path).toContain('uploads');
    expect(result.path).toContain(WS_1);
    expect(result.path).toContain(SESS_1);
  });

  it('rejects files over the 10MB limit', async () => {
    const storage = new LocalStorageAdapter(tmpRoot);
    const bigContent = Buffer.alloc(MAX_FILE_SIZE_BYTES + 1, 0);

    try {
      await uploadFile({
        workspaceId: WS_1,
        filename: 'big.bin',
        content: bigContent,
        storage,
      });
      expect.fail('throw');
    } catch (err) {
      expect(err).toBeInstanceOf(Error);
      expect((err as Error).message).toContain('10MB');
    }
  });

  it('rejects path-traversal filenames', async () => {
    const storage = new LocalStorageAdapter(tmpRoot);

    try {
      await uploadFile({
        workspaceId: WS_1,
        filename: '../../../etc/passwd',
        content: Buffer.from('x'),
        storage,
      });
      expect.fail('throw');
    } catch (err) {
      // validatePath throws a StorageError
      expect(err).toBeDefined();
    }
  });

  it('works without a sessionId (workspace-level upload)', async () => {
    const storage = new LocalStorageAdapter(tmpRoot);
    const result = await uploadFile({
      workspaceId: WS_1,
      filename: 'ws-file.txt',
      content: Buffer.from('workspace file'),
      storage,
    });
    expect(result.path).toContain(WS_1);
    expect(result.path).not.toContain(SESS_1);
  });
});
