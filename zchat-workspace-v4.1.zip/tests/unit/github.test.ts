/**
 * GitHub Integration Tests
 *
 * Blueprint v4.1 §14 (GitHub Integration), §22 Phase 1 Step 1.8
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  GithubError,
  isGithubError,
  searchGithubRepos,
  importGithubRepo,
  getImportedRepos,
  pinReposToSession,
  buildRepoContext,
  MAX_PINNED_REPOS,
  README_CHAR_CAP,
  type GithubSearchResult,
} from '@/lib/github';

vi.mock('@/lib/db', () => ({
  db: {
    githubRepo: { findUnique: vi.fn(), findFirst: vi.fn(), findMany: vi.fn(), create: vi.fn(), update: vi.fn() },
    session: { update: vi.fn(), findUnique: vi.fn() },
  },
}));

vi.mock('@/lib/logger', () => ({
  logger: {
    trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
    child: vi.fn(() => ({
      trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
      child: vi.fn(), level: 'debug',
    })),
  },
}));

import { db } from '@/lib/db';

const WS_1 = 'ws-1';

function makeSearchResult(overrides: Partial<GithubSearchResult> = {}): GithubSearchResult {
  return {
    id: 1,
    fullName: 'vercel/next.js',
    description: 'The React Framework',
    url: 'https://github.com/vercel/next.js',
    stars: 100000,
    language: 'TypeScript',
    owner: 'vercel',
    ...overrides,
  };
}

beforeEach(() => {
  (db.githubRepo.findUnique as ReturnType<typeof vi.fn>).mockReset();
  (db.githubRepo.findFirst as ReturnType<typeof vi.fn>).mockReset();
  (db.githubRepo.findMany as ReturnType<typeof vi.fn>).mockReset();
  (db.githubRepo.create as ReturnType<typeof vi.fn>).mockReset();
  (db.githubRepo.update as ReturnType<typeof vi.fn>).mockReset();
  (db.session.update as ReturnType<typeof vi.fn>).mockReset();
});

// ─── GithubError + isGithubError ───────────────────────────────────────────

describe('GithubError', () => {
  it('preserves code, message, cause', () => {
    const cause = new Error('root');
    const err = new GithubError('SEARCH_FAILED', 'search broke', cause);
    expect(err.code).toBe('SEARCH_FAILED');
    expect(err.message).toBe('search broke');
    expect(err.cause).toBe(cause);
    expect(err.name).toBe('GithubError');
  });

  it('is an instance of Error', () => {
    expect(new GithubError('IMPORT_FAILED', 'x')).toBeInstanceOf(Error);
  });

  it('exposes every GithubErrorCode', () => {
    const codes: ReadonlyArray<GithubError['code']> = [
      'SEARCH_FAILED', 'IMPORT_FAILED', 'REPO_NOT_FOUND', 'README_FETCH_FAILED', 'PIN_LIMIT_EXCEEDED',
    ];
    for (const code of codes) {
      expect(new GithubError(code, `msg for ${code}`).code).toBe(code);
    }
  });
});

describe('isGithubError', () => {
  it('returns false for primitives + plain objects', () => {
    expect(isGithubError(0)).toBe(false);
    expect(isGithubError(null)).toBe(false);
    expect(isGithubError({})).toBe(false);
  });

  it('returns true for GithubError instances', () => {
    expect(isGithubError(new GithubError('SEARCH_FAILED', 'x'))).toBe(true);
  });
});

// ─── Constants ─────────────────────────────────────────────────────────────

describe('constants', () => {
  it('MAX_PINNED_REPOS is 3 (Blueprint §14)', () => {
    expect(MAX_PINNED_REPOS).toBe(3);
  });

  it('README_CHAR_CAP is 6000 (Blueprint §14)', () => {
    expect(README_CHAR_CAP).toBe(6000);
  });
});

// ─── searchGithubRepos ─────────────────────────────────────────────────────

describe('searchGithubRepos', () => {
  it('returns parsed search results', async () => {
    const mockResponse = {
      items: [
        { id: 1, full_name: 'vercel/next.js', description: 'The React Framework', html_url: 'https://github.com/vercel/next.js', stargazers_count: 100000, language: 'TypeScript', owner: { login: 'vercel' } },
        { id: 2, full_name: 'facebook/react', description: 'The library for web UIs', html_url: 'https://github.com/facebook/react', stargazers_count: 200000, language: 'JavaScript', owner: { login: 'facebook' } },
      ],
    };
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response(JSON.stringify(mockResponse), { status: 200 }),
    );

    const results = await searchGithubRepos({ query: 'react framework' });

    expect(results).toHaveLength(2);
    expect(results[0]!.fullName).toBe('vercel/next.js');
    expect(results[0]!.owner).toBe('vercel');
    expect(results[1]!.fullName).toBe('facebook/react');

    // Verify the URL + headers
    const [url, init] = fetchSpy.mock.calls[0]!;
    expect(url).toContain('https://api.github.com/search/repositories');
    expect(url).toContain('q=react+framework');
    expect((init!.headers as Record<string, string>)['accept']).toContain('application/vnd.github');

    fetchSpy.mockRestore();
  });

  it('includes language filter when provided', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response(JSON.stringify({ items: [] }), { status: 200 }),
    );

    await searchGithubRepos({ query: 'web framework', language: 'TypeScript' });

    const [url] = fetchSpy.mock.calls[0]!;
    expect(url).toContain('language%3ATypeScript');

    fetchSpy.mockRestore();
  });

  it('throws SEARCH_FAILED on HTTP error', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response('rate limited', { status: 403 }),
    );

    try {
      await searchGithubRepos({ query: 'test' });
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isGithubError(err)).toBe(true);
      if (isGithubError(err)) expect(err.code).toBe('SEARCH_FAILED');
    }

    fetchSpy.mockRestore();
  });

  it('throws SEARCH_FAILED on network error', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockRejectedValueOnce(new Error('ECONNREFUSED'));

    try {
      await searchGithubRepos({ query: 'test' });
      expect.fail('Expected to throw');
    } catch (err) {
      if (isGithubError(err)) expect(err.code).toBe('SEARCH_FAILED');
    }

    fetchSpy.mockRestore();
  });
});

// ─── importGithubRepo ──────────────────────────────────────────────────────

describe('importGithubRepo', () => {
  it('fetches README and creates a DB record when not already imported', async () => {
    const searchResult = makeSearchResult();
    const readmeContent = '# Next.js\n\nThe React Framework.';

    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response(readmeContent, { status: 200 }),
    );
    (db.githubRepo.findFirst as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);
    (db.githubRepo.create as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'repo-1', workspaceId: WS_1, fullName: 'vercel/next.js', description: 'The React Framework',
      url: 'https://github.com/vercel/next.js', stars: 100000, language: 'TypeScript', owner: 'vercel',
      readmeCache: readmeContent, createdAt: new Date(),
    });

    const record = await importGithubRepo(WS_1, searchResult);

    expect(record.id).toBe('repo-1');
    expect(record.readmeCache).toBe(readmeContent);
    expect(db.githubRepo.create).toHaveBeenCalledTimes(1);

    fetchSpy.mockRestore();
  });

  it('updates the existing record when already imported', async () => {
    const searchResult = makeSearchResult({ stars: 110000 });
    const readmeContent = '# Next.js\n\nUpdated.';

    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response(readmeContent, { status: 200 }),
    );
    (db.githubRepo.findFirst as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'repo-1', workspaceId: WS_1, fullName: 'vercel/next.js',
    });
    (db.githubRepo.update as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'repo-1', workspaceId: WS_1, fullName: 'vercel/next.js', description: 'The React Framework',
      url: 'https://github.com/vercel/next.js', stars: 110000, language: 'TypeScript', owner: 'vercel',
      readmeCache: readmeContent, createdAt: new Date(),
    });

    const record = await importGithubRepo(WS_1, searchResult);

    expect(record.id).toBe('repo-1');
    expect(record.stars).toBe(110000);
    expect(db.githubRepo.update).toHaveBeenCalledTimes(1);
    expect(db.githubRepo.create).not.toHaveBeenCalled();

    fetchSpy.mockRestore();
  });

  it('imports without README when fetch fails', async () => {
    const searchResult = makeSearchResult();
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response('not found', { status: 404 }),
    );
    (db.githubRepo.findFirst as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);
    (db.githubRepo.create as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'repo-1', workspaceId: WS_1, fullName: 'vercel/next.js', description: 'x',
      url: 'x', stars: 0, language: null, owner: 'vercel',
      readmeCache: null, createdAt: new Date(),
    });

    const record = await importGithubRepo(WS_1, searchResult);

    expect(record.readmeCache).toBeNull();

    fetchSpy.mockRestore();
  });
});

// ─── getImportedRepos ──────────────────────────────────────────────────────

describe('getImportedRepos', () => {
  it('returns repos for the workspace', async () => {
    (db.githubRepo.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { id: 'r1', workspaceId: WS_1, fullName: 'a/b', description: null, url: 'u', stars: 0, language: null, owner: 'a', readmeCache: null, createdAt: new Date() },
    ]);

    const repos = await getImportedRepos(WS_1);
    expect(repos).toHaveLength(1);
    expect(repos[0]!.id).toBe('r1');
  });
});

// ─── pinReposToSession ─────────────────────────────────────────────────────

describe('pinReposToSession', () => {
  it('throws PIN_LIMIT_EXCEEDED when more than 3 repos', async () => {
    try {
      await pinReposToSession('sess-1', WS_1, ['r1', 'r2', 'r3', 'r4']);
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isGithubError(err)).toBe(true);
      if (isGithubError(err)) expect(err.code).toBe('PIN_LIMIT_EXCEEDED');
    }
  });

  it('accepts exactly 3 repos (boundary)', async () => {
    (db.githubRepo.findUnique as ReturnType<typeof vi.fn>)
      .mockResolvedValueOnce({ id: 'r1', workspaceId: WS_1 })
      .mockResolvedValueOnce({ id: 'r2', workspaceId: WS_1 })
      .mockResolvedValueOnce({ id: 'r3', workspaceId: WS_1 });
    (db.session.update as ReturnType<typeof vi.fn>).mockResolvedValueOnce({});

    await pinReposToSession('sess-1', WS_1, ['r1', 'r2', 'r3']);

    expect(db.session.update).toHaveBeenCalledTimes(1);
  });

  it('throws REPO_NOT_FOUND when a repo does not exist in the workspace', async () => {
    (db.githubRepo.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);

    try {
      await pinReposToSession('sess-1', WS_1, ['nonexistent']);
      expect.fail('Expected to throw');
    } catch (err) {
      if (isGithubError(err)) expect(err.code).toBe('REPO_NOT_FOUND');
    }
  });

  it('throws REPO_NOT_FOUND when the repo belongs to a different workspace', async () => {
    (db.githubRepo.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'r1', workspaceId: 'ws-other',
    });

    try {
      await pinReposToSession('sess-1', WS_1, ['r1']);
      expect.fail('Expected to throw');
    } catch (err) {
      if (isGithubError(err)) expect(err.code).toBe('REPO_NOT_FOUND');
    }
  });

  it('updates the session repoIds with JSON-stringified array', async () => {
    (db.githubRepo.findUnique as ReturnType<typeof vi.fn>)
      .mockResolvedValueOnce({ id: 'r1', workspaceId: WS_1 });
    (db.session.update as ReturnType<typeof vi.fn>).mockResolvedValueOnce({});

    await pinReposToSession('sess-1', WS_1, ['r1']);

    const updateArgs = (db.session.update as ReturnType<typeof vi.fn>).mock.calls[0]![0];
    expect(updateArgs.data.repoIds).toBe(JSON.stringify(['r1']));
  });
});

// ─── buildRepoContext ──────────────────────────────────────────────────────

describe('buildRepoContext', () => {
  it('returns empty string when no repoIds', async () => {
    const result = await buildRepoContext(WS_1, []);
    expect(result).toBe('');
  });

  it('returns empty string when no repos are found', async () => {
    (db.githubRepo.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);

    const result = await buildRepoContext(WS_1, ['nonexistent']);
    expect(result).toBe('');
  });

  it('includes repo name, URL, and README in the context', async () => {
    (db.githubRepo.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'r1', workspaceId: WS_1, fullName: 'vercel/next.js', description: 'x',
      url: 'https://github.com/vercel/next.js', stars: 100, language: 'TS', owner: 'vercel',
      readmeCache: '# Next.js\n\nThe React Framework.', createdAt: new Date(),
    });

    const result = await buildRepoContext(WS_1, ['r1']);
    expect(result).toContain('vercel/next.js');
    expect(result).toContain('https://github.com/vercel/next.js');
    expect(result).toContain('# Next.js');
    expect(result).toContain('The React Framework.');
  });

  it('includes the 5 citation rules', async () => {
    (db.githubRepo.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'r1', workspaceId: WS_1, fullName: 'a/b', description: null,
      url: 'u', stars: 0, language: null, owner: 'a',
      readmeCache: 'readme', createdAt: new Date(),
    });

    const result = await buildRepoContext(WS_1, ['r1']);
    expect(result).toContain('Citation Rules');
    expect(result).toContain('Cite the repo by name');
    expect(result).toContain('file path');
    expect(result).toContain('Quote the relevant snippet');
    expect(result).toContain('Distinguish between');
    expect(result).toContain('do not fabricate');
  });

  it('truncates long READMEs to fit the char cap', async () => {
    const longReadme = 'x'.repeat(10000);
    (db.githubRepo.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'r1', workspaceId: WS_1, fullName: 'a/b', description: null,
      url: 'u', stars: 0, language: null, owner: 'a',
      readmeCache: longReadme, createdAt: new Date(),
    });

    const result = await buildRepoContext(WS_1, ['r1']);
    // Should be truncated (well under the 10000 char original)
    expect(result.length).toBeLessThan(10000);
    expect(result).toContain('truncated');
  });
});
