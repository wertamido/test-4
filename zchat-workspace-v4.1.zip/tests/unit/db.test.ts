/**
 * Unit tests for src/lib/db.ts
 *
 * Blueprint v4.1 §6 (Database), §23 (Testing Strategy)
 *
 * Covers:
 *  - Singleton identity (one PrismaClient per process via globalThis)
 *  - Connection lifecycle (connect / disconnect / reconnect)
 *  - Health check semantics (assertDbHealthy throws, isDbHealthy returns bool)
 *  - Error mapping (Prisma errors → DbError)
 *  - Transaction wrapper (commit on success, DbError on body throw)
 *  - DbError static behavior (no live DB required)
 *
 * Prerequisites:
 *  - `DATABASE_URL` must be set (pointing to a writable SQLite file)
 *  - `prisma db push` must have been run to materialize the schema
 *  - Vitest must be configured (Phase 0, Step 0.8)
 *
 * If `DATABASE_URL` is not set, the DB-dependent suite is SKIPPED (not
 * failed) so this file can still be type-checked and the static suite can
 * run in CI environments that don't have a live DB.
 */

import { describe, it, expect, afterAll } from 'vitest';
import {
  db,
  DbError,
  isDbError,
  assertDbHealthy,
  isDbHealthy,
  runInTransaction,
  disconnectDb,
} from '@/lib/db';

const hasDatabase =
  typeof process.env.DATABASE_URL === 'string' &&
  process.env.DATABASE_URL.trim().length > 0;

const describeIfDb = hasDatabase ? describe : describe.skip;

// ─── DB-dependent suite ────────────────────────────────────────────────────

describeIfDb('db client (Prisma singleton) — live DB', () => {
  afterAll(async () => {
    // Leave the process clean for subsequent test files
    await disconnectDb().catch(() => undefined);
  });

  describe('singleton identity', () => {
    it('exports a non-null PrismaClient instance with the expected surface', () => {
      expect(db).toBeDefined();
      expect(typeof db.$connect).toBe('function');
      expect(typeof db.$disconnect).toBe('function');
      expect(typeof db.$queryRaw).toBe('function');
      expect(typeof db.$transaction).toBe('function');
    });

    it('holds a stable reference across imports (singleton via globalThis)', async () => {
      // Re-importing should yield the same instance, not a fresh one
      const reimported = await import('@/lib/db');
      expect(reimported.db).toBe(db);
    });
  });

  describe('connection lifecycle', () => {
    it('can connect, run a trivial query, and disconnect', async () => {
      await db.$connect();
      const rows = await db.$queryRaw<Array<Record<string, unknown>>>`SELECT 1 AS "1"`;
      expect(Array.isArray(rows)).toBe(true);
      expect(rows.length).toBe(1);
      // SQLite returns the literal as a number; PostgreSQL may return bigint.
      // Coerce to Number so the assertion is portable across providers.
      const value = rows[0]!['1'];
      expect(Number(value)).toBe(1);
      await db.$disconnect();
    });

    it('reconnects automatically after disconnect on the next operation', async () => {
      await db.$disconnect();
      // The next raw query should trigger Prisma's internal reconnection
      const rows = await db.$queryRaw<Array<Record<string, unknown>>>`SELECT 1 AS "1"`;
      expect(rows.length).toBe(1);
    });
  });

  describe('health checks', () => {
    it('assertDbHealthy() resolves when the DB is reachable', async () => {
      await expect(assertDbHealthy()).resolves.toBeUndefined();
    });

    it('isDbHealthy() returns true when the DB is reachable', async () => {
      expect(await isDbHealthy()).toBe(true);
    });
  });

  describe('error mapping', () => {
    it('throws DbError when given invalid SQL', async () => {
      try {
        // Intentionally invalid SQL — table does not exist in the v4.1 schema
        await db.$queryRaw`SELECT * FROM __table_that_does_not_exist__`;
        expect.fail('Expected $queryRaw to throw on invalid SQL');
      } catch (error) {
        expect(isDbError(error)).toBe(true);
        if (isDbError(error)) {
          // Prisma may map missing-table errors to CONNECTION_FAILED (init)
          // or QUERY_FAILED (known/unknown request) depending on the engine
          // state and provider; accept either here.
          expect(['QUERY_FAILED', 'CONNECTION_FAILED']).toContain(error.code);
        }
      }
    });
  });

  describe('runInTransaction', () => {
    it('commits a successful transaction and returns its value', async () => {
      const result = await runInTransaction(async (tx) => {
        const rows =
          await tx.$queryRaw<Array<Record<string, unknown>>>`SELECT 1 AS "1"`;
        return rows.length;
      });
      expect(result).toBe(1);
    });

    it('rolls back and throws DbError(code=TRANSACTION_FAILED) when the body throws a non-DbError', async () => {
      const sentinel = new Error('boom');
      try {
        await runInTransaction(async () => {
          throw sentinel;
        });
        expect.fail('Expected runInTransaction to throw');
      } catch (error) {
        expect(isDbError(error)).toBe(true);
        if (isDbError(error)) {
          expect(error.code).toBe('TRANSACTION_FAILED');
          expect(error.cause).toBe(sentinel);
        }
      }
    });

    it('preserves an existing DbError thrown inside the body unchanged', async () => {
      const inner = new DbError('QUERY_FAILED', 'inner failure');
      try {
        await runInTransaction(async () => {
          throw inner;
        });
        expect.fail('Expected runInTransaction to throw');
      } catch (error) {
        expect(error).toBe(inner);
        expect(isDbError(error)).toBe(true);
        if (isDbError(error)) {
          expect(error.code).toBe('QUERY_FAILED');
        }
      }
    });
  });
});

// ─── Static suite (no live DB required) ────────────────────────────────────

describe('db client — static behavior (no DB required)', () => {
  describe('DbError', () => {
    it('preserves code, message, and cause', () => {
      const cause = new Error('root cause');
      const err = new DbError('CLIENT_NOT_INITIALIZED', 'no url', cause);
      expect(err.code).toBe('CLIENT_NOT_INITIALIZED');
      expect(err.message).toBe('no url');
      expect(err.cause).toBe(cause);
      expect(err.name).toBe('DbError');
    });

    it('is an instance of Error', () => {
      const err = new DbError('QUERY_FAILED', 'x');
      expect(err).toBeInstanceOf(Error);
    });

    it('survives instanceof DbError after subclassing Error', () => {
      const err = new DbError('QUERY_FAILED', 'x');
      expect(err).toBeInstanceOf(DbError);
      // Re-throw and re-catch to simulate propagation through a call stack
      try {
        throw err;
      } catch (caught) {
        expect(caught).toBeInstanceOf(DbError);
      }
    });

    it('supports an undefined cause', () => {
      const err = new DbError('SHUTDOWN_IN_PROGRESS', 'bye');
      expect(err.cause).toBeUndefined();
    });

    it('exposes every DbErrorCode value', () => {
      const codes: ReadonlyArray<DbError['code']> = [
        'CONNECTION_FAILED',
        'QUERY_FAILED',
        'TRANSACTION_FAILED',
        'CLIENT_NOT_INITIALIZED',
        'SHUTDOWN_IN_PROGRESS',
      ];
      for (const code of codes) {
        const err = new DbError(code, `message for ${code}`);
        expect(err.code).toBe(code);
      }
    });
  });

  describe('isDbError', () => {
    it('returns false for primitives', () => {
      expect(isDbError(0)).toBe(false);
      expect(isDbError('')).toBe(false);
      expect(isDbError(false)).toBe(false);
      expect(isDbError(null)).toBe(false);
      expect(isDbError(undefined)).toBe(false);
    });

    it('returns false for plain objects lacking the brand symbol', () => {
      expect(isDbError({ code: 'QUERY_FAILED', message: 'fake' })).toBe(false);
      expect(isDbError(new Error('plain'))).toBe(false);
      expect(isDbError({})).toBe(false);
    });

    it('returns true for DbError instances', () => {
      const err = new DbError('CONNECTION_FAILED', 'real');
      expect(isDbError(err)).toBe(true);
    });
  });
});
