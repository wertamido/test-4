/**
 * Unit tests for ErrorBoundary + ApiErrorBoundary
 *
 * Blueprint v4.1 §22 Phase 0 Step 0.5, §23 (Testing Strategy), §12 (Mistake #12)
 *
 * Coverage:
 *  - ErrorBoundary (React class component):
 *      • Renders children normally when no error
 *      • Catches render-time errors and shows fallback
 *      • Shows default fallback UI with message + buttons
 *      • "Try Again" resets internal state, children re-render
 *      • "Reload Page" calls window.location.reload
 *      • resetKey change auto-recovers from error state
 *      • Custom `fallback` prop replaces default UI
 *      • `renderFallback` render-prop takes precedence + receives reset
 *      • `onError` callback fires with error + ErrorInfo
 *      • Logs JSON-structured error to console.error
 *  - ApiErrorBoundary (server-side HOF):
 *      • Success path returns 200 + { data }
 *      • DbError → 500
 *      • AuthError → 401
 *      • ValidationError → 400 with issues[]
 *      • Unknown Error → 500 with generic message (no leak)
 *      • Dev mode includes stack trace in body
 *      • Production mode omits stack trace
 *      • withValidatedBody: parses + delegates, throws ValidationError on bad JSON
 *
 * Mocking strategy:
 *  - React boundary tests use @testing-library/react + a "Bomb" component that
 *    throws on render. The DOM is real (jsdom).
 *  - console.error is spied because ErrorBoundary logs to it. We assert the
 *    JSON-structured log line is emitted.
 *  - window.location.reload is stubbed because jsdom throws on calls to it.
 *  - process.env.NODE_ENV is captured/restored around dev-mode tests.
 *
 * No DB mocking needed — the ApiErrorBoundary tests use buildApiResponse()
 * directly with thrown errors, not real DB calls.
 */

import React from 'react';
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';

import { ErrorBoundary } from '@/components/layout/ErrorBoundary';
import {
  withApiErrorHandler,
  buildApiResponse,
  withValidatedBody,
} from '@/components/layout/ApiErrorBoundary';
import { DbError } from '@/lib/db';
import { AuthError } from '@/lib/auth';
import { ValidationError } from '@/lib/validation/schemas';
import { z } from 'zod';

// ─── Helpers ───────────────────────────────────────────────────────────────

/** Component that throws on render. */
function Bomb({ message }: { message: string }): React.ReactElement {
  throw new Error(message);
}

/** Component that throws only when `shouldThrow` is true. */
function ConditionalBomb({ shouldThrow }: { shouldThrow: boolean }): React.ReactElement {
  if (shouldThrow) throw new Error('Conditional explosion');
  return <div data-testid="ok">ok</div>;
}

// ─── React ErrorBoundary ───────────────────────────────────────────────────

describe('ErrorBoundary (React class component)', () => {
  let consoleErrorSpy: ReturnType<typeof vi.spyOn>;
  let reloadSpy: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => undefined);
    reloadSpy = vi.fn();
    // jsdom's window.location.reload throws — replace it
    Object.defineProperty(window, 'location', {
      value: { ...window.location, reload: reloadSpy },
      writable: true,
    });
  });

  afterEach(() => {
    consoleErrorSpy.mockRestore();
    cleanup();
  });

  it('renders children normally when no error is thrown', () => {
    render(
      <ErrorBoundary>
        <div data-testid="child">hello</div>
      </ErrorBoundary>,
    );
    expect(screen.getByTestId('child')).toBeDefined();
    expect(screen.queryByText('Something went wrong')).toBeNull();
  });

  it('catches render-time errors and shows the default fallback', () => {
    render(
      <ErrorBoundary>
        <Bomb message="kaboom" />
      </ErrorBoundary>,
    );
    expect(screen.getByText('Something went wrong')).toBeDefined();
    expect(screen.getByText('kaboom')).toBeDefined();
  });

  it('renders "Try Again" and "Reload Page" buttons', () => {
    render(
      <ErrorBoundary>
        <Bomb message="boom" />
      </ErrorBoundary>,
    );
    expect(screen.getByRole('button', { name: /Try Again/i })).toBeDefined();
    expect(screen.getByRole('button', { name: /Reload Page/i })).toBeDefined();
  });

  it('"Try Again" resets error state and re-renders children when they no longer throw', () => {
    const { rerender } = render(
      <ErrorBoundary>
        <ConditionalBomb shouldThrow={true} />
      </ErrorBoundary>,
    );
    expect(screen.getByText('Something went wrong')).toBeDefined();

    // Click "Try Again" while the child STILL throws — fallback should re-render
    fireEvent.click(screen.getByRole('button', { name: /Try Again/i }));
    expect(screen.getByText('Something went wrong')).toBeDefined();

    // Now fix the child + click "Try Again" — children should render
    rerender(
      <ErrorBoundary>
        <ConditionalBomb shouldThrow={false} />
      </ErrorBoundary>,
    );
    fireEvent.click(screen.getByRole('button', { name: /Try Again/i }));
    expect(screen.getByTestId('ok')).toBeDefined();
  });

  it('"Reload Page" calls window.location.reload', () => {
    render(
      <ErrorBoundary>
        <Bomb message="boom" />
      </ErrorBoundary>,
    );
    fireEvent.click(screen.getByRole('button', { name: /Reload Page/i }));
    expect(reloadSpy).toHaveBeenCalledTimes(1);
  });

  it('resetKey change auto-recovers from error state', () => {
    const { rerender } = render(
      <ErrorBoundary resetKey="/page-a">
        <Bomb message="boom on page a" />
      </ErrorBoundary>,
    );
    expect(screen.getByText('boom on page a')).toBeDefined();

    // Change resetKey → simulate route change. ErrorBoundary should clear
    // error state and try to render children. We swap in a non-throwing child
    // at the same time so the test doesn't loop back into the fallback.
    rerender(
      <ErrorBoundary resetKey="/page-b">
        <div data-testid="next-page">page b</div>
      </ErrorBoundary>,
    );
    expect(screen.getByTestId('next-page')).toBeDefined();
    expect(screen.queryByText('Something went wrong')).toBeNull();
  });

  it('does NOT auto-recover when resetKey is unchanged', () => {
    const { rerender } = render(
      <ErrorBoundary resetKey="/same">
        <Bomb message="boom" />
      </ErrorBoundary>,
    );
    expect(screen.getByText('Something went wrong')).toBeDefined();

    // Re-render with the same resetKey — error state should persist
    rerender(
      <ErrorBoundary resetKey="/same">
        <div data-testid="never-rendered">should not render</div>
      </ErrorBoundary>,
    );
    expect(screen.queryByTestId('never-rendered')).toBeNull();
    expect(screen.getByText('Something went wrong')).toBeDefined();
  });

  it('uses the custom `fallback` prop when provided', () => {
    render(
      <ErrorBoundary fallback={<div data-testid="custom-fallback">custom UI</div>}>
        <Bomb message="boom" />
      </ErrorBoundary>,
    );
    expect(screen.getByTestId('custom-fallback')).toBeDefined();
    expect(screen.queryByText('Something went wrong')).toBeNull();
  });

  it('uses `renderFallback` (render-prop) when provided, and the reset callback works', () => {
    function CustomRender({ error, reset }: { error: Error; reset: () => void }) {
      return (
        <div>
          <span data-testid="custom-error">{error.message}</span>
          <button type="button" onClick={reset} data-testid="custom-reset">
            recover
          </button>
        </div>
      );
    }

    const { rerender } = render(
      <ErrorBoundary renderFallback={(e, reset) => <CustomRender error={e} reset={reset} />}>
        <ConditionalBomb shouldThrow={true} />
      </ErrorBoundary>,
    );
    expect(screen.getByTestId('custom-error').textContent).toBe('Conditional explosion');

    // Click custom reset, then swap to non-throwing child
    fireEvent.click(screen.getByTestId('custom-reset'));
    rerender(
      <ErrorBoundary renderFallback={(e, reset) => <CustomRender error={e} reset={reset} />}>
        <ConditionalBomb shouldThrow={false} />
      </ErrorBoundary>,
    );
    expect(screen.getByTestId('ok')).toBeDefined();
  });

  it('`renderFallback` takes precedence over `fallback`', () => {
    render(
      <ErrorBoundary
        fallback={<div data-testid="static-fallback">static</div>}
        renderFallback={() => <div data-testid="render-prop-fallback">render-prop</div>}
      >
        <Bomb message="boom" />
      </ErrorBoundary>,
    );
    expect(screen.getByTestId('render-prop-fallback')).toBeDefined();
    expect(screen.queryByTestId('static-fallback')).toBeNull();
  });

  it('fires the onError callback exactly once per caught error', () => {
    const onError = vi.fn();
    render(
      <ErrorBoundary onError={onError}>
        <Bomb message="boom" />
      </ErrorBoundary>,
    );
    expect(onError).toHaveBeenCalledTimes(1);
    const [errorArg, infoArg] = onError.mock.calls[0]!;
    expect(errorArg).toBeInstanceOf(Error);
    expect((errorArg as Error).message).toBe('boom');
    // React.ErrorInfo has a `componentStack` field (string, possibly empty)
    expect(typeof infoArg.componentStack).toBe('string');
  });

  it('logs a JSON-structured line to console.error', () => {
    render(
      <ErrorBoundary resetKey="/test-route">
        <Bomb message="logged boom" />
      </ErrorBoundary>,
    );
    expect(consoleErrorSpy).toHaveBeenCalled();
    const logLine = consoleErrorSpy.mock.calls[0]![0] as string;
    const parsed = JSON.parse(logLine);
    expect(parsed.level).toBe('error');
    expect(parsed.msg).toContain('logged boom');
    expect(parsed.err.type).toBe('Error');
    expect(parsed.err.message).toBe('logged boom');
    expect(parsed.boundary.resetKey).toBe('/test-route');
  });

  it('marks the fallback container with role="alert" for accessibility', () => {
    render(
      <ErrorBoundary>
        <Bomb message="boom" />
      </ErrorBoundary>,
    );
    const alert = screen.getByRole('alert');
    expect(alert).toBeDefined();
  });
});

// ─── ApiErrorBoundary — buildApiResponse ───────────────────────────────────

describe('buildApiResponse', () => {
  const originalEnv = process.env.NODE_ENV;

  afterEach(() => {
    process.env.NODE_ENV = originalEnv;
  });

  it('maps DbError → 500', () => {
    const err = new DbError('CONNECTION_FAILED', 'db unreachable');
    const result = buildApiResponse(err);
    expect(result.success).toBe(false);
    expect(result.status).toBe(500);
    if (!result.success) {
      expect(result.body.error.code).toBe('CONNECTION_FAILED');
    }
  });

  it('maps AuthError → 401', () => {
    const err = new AuthError('USER_NOT_FOUND', 'no user');
    const result = buildApiResponse(err);
    expect(result.success).toBe(false);
    expect(result.status).toBe(401);
    if (!result.success) {
      expect(result.body.error.code).toBe('USER_NOT_FOUND');
    }
  });

  it('maps ValidationError → 400 with issues[]', () => {
    const issues = [
      { path: 'email', message: 'Invalid email', code: 'invalid_input' },
      { path: 'password', message: 'Too short', code: 'invalid_input' },
    ];
    const err = new ValidationError('VALIDATION_FAILED', 'bad input', undefined, issues);
    const result = buildApiResponse(err);
    expect(result.success).toBe(false);
    expect(result.status).toBe(400);
    if (!result.success) {
      expect(result.body.error.code).toBe('VALIDATION_FAILED');
      expect(result.body.error.issues).toEqual(issues);
    }
  });

  it('omits issues[] when ValidationError has zero issues', () => {
    const err = new ValidationError('VALIDATION_FAILED', 'no issues');
    const result = buildApiResponse(err);
    if (!result.success) {
      expect(result.body.error.issues).toBeUndefined();
    }
  });

  it('maps unknown Error → 500 with generic message (no internal leak)', () => {
    process.env.NODE_ENV = 'production';
    const err = new Error('some internal secret: db password is hunter2');
    const result = buildApiResponse(err);
    expect(result.success).toBe(false);
    expect(result.status).toBe(500);
    if (!result.success) {
      expect(result.body.error.code).toBe('INTERNAL_ERROR');
      expect(result.body.error.message).toBe('Internal server error.');
      // Production must NOT leak the original message
      expect(result.body.error.message).not.toContain('hunter2');
      expect(result.body.error.stack).toBeUndefined();
    }
  });

  it('includes stack trace in dev mode for unknown errors', () => {
    process.env.NODE_ENV = 'development';
    const err = new Error('dev boom');
    const result = buildApiResponse(err);
    if (!result.success) {
      expect(result.body.error.stack).toContain('dev boom');
    }
  });

  it('includes stack trace in dev mode for DbError', () => {
    process.env.NODE_ENV = 'development';
    const err = new DbError('QUERY_FAILED', 'query failed');
    const result = buildApiResponse(err);
    if (!result.success) {
      expect(result.body.error.stack).toBeDefined();
    }
  });

  it('includes stack trace in dev mode for AuthError', () => {
    process.env.NODE_ENV = 'development';
    const err = new AuthError('PASSWORD_MISMATCH', 'wrong pw');
    const result = buildApiResponse(err);
    if (!result.success) {
      expect(result.body.error.stack).toBeDefined();
    }
  });

  it('includes stack trace in dev mode for ValidationError', () => {
    process.env.NODE_ENV = 'development';
    const err = new ValidationError('VALIDATION_FAILED', 'bad');
    const result = buildApiResponse(err);
    if (!result.success) {
      expect(result.body.error.stack).toBeDefined();
    }
  });

  it('omits stack trace in production for all error types', () => {
    process.env.NODE_ENV = 'production';
    expect(buildApiResponse(new DbError('QUERY_FAILED', 'x')).success ? null : buildApiResponse(new DbError('QUERY_FAILED', 'x')).body.error.stack).toBeUndefined();
    expect(buildApiResponse(new AuthError('USER_NOT_FOUND', 'x')).success ? null : buildApiResponse(new AuthError('USER_NOT_FOUND', 'x')).body.error.stack).toBeUndefined();
    expect(buildApiResponse(new ValidationError('VALIDATION_FAILED', 'x')).success ? null : buildApiResponse(new ValidationError('VALIDATION_FAILED', 'x')).body.error.stack).toBeUndefined();
  });

  it('maps non-Error throwables (e.g., string) → 500', () => {
    process.env.NODE_ENV = 'production';
    const result = buildApiResponse('just a string');
    expect(result.success).toBe(false);
    expect(result.status).toBe(500);
    if (!result.success) {
      expect(result.body.error.code).toBe('INTERNAL_ERROR');
    }
  });

  it('maps null throws → 500', () => {
    const result = buildApiResponse(null);
    expect(result.success).toBe(false);
    expect(result.status).toBe(500);
  });
});

// ─── ApiErrorBoundary — withApiErrorHandler (HOF) ──────────────────────────

describe('withApiErrorHandler', () => {
  const originalEnv = process.env.NODE_ENV;
  afterEach(() => {
    process.env.NODE_ENV = originalEnv;
  });

  it('returns 200 + { data } on success', async () => {
    const handler = withApiErrorHandler(async () => ({ ok: true, value: 42 }));
    const res = await handler(new Request('http://localhost/'));
    expect(res.status).toBe(200);
    const body = (await res.json()) as { data: { ok: boolean; value: number } };
    expect(body.data).toEqual({ ok: true, value: 42 });
  });

  it('passes the Request through to the handler', async () => {
    const handler = withApiErrorHandler(async (req) => ({ url: req.url }));
    const res = await handler(new Request('http://localhost/foo'));
    const body = (await res.json()) as { data: { url: string } };
    expect(body.data.url).toBe('http://localhost/foo');
  });

  it('maps DbError thrown inside handler → 500 response', async () => {
    const handler = withApiErrorHandler(async () => {
      throw new DbError('CONNECTION_FAILED', 'db down');
    });
    const res = await handler(new Request('http://localhost/'));
    expect(res.status).toBe(500);
    const body = (await res.json()) as { error: { code: string; message: string } };
    expect(body.error.code).toBe('CONNECTION_FAILED');
  });

  it('maps AuthError thrown inside handler → 401 response', async () => {
    const handler = withApiErrorHandler(async () => {
      throw new AuthError('PASSWORD_MISMATCH', 'wrong pw');
    });
    const res = await handler(new Request('http://localhost/'));
    expect(res.status).toBe(401);
    const body = (await res.json()) as { error: { code: string } };
    expect(body.error.code).toBe('PASSWORD_MISMATCH');
  });

  it('maps ValidationError thrown inside handler → 400 response with issues', async () => {
    const issues = [{ path: 'email', message: 'Invalid', code: 'invalid_input' }];
    const handler = withApiErrorHandler(async () => {
      throw new ValidationError('VALIDATION_FAILED', 'bad', undefined, issues);
    });
    const res = await handler(new Request('http://localhost/'));
    expect(res.status).toBe(400);
    const body = (await res.json()) as {
      error: { code: string; issues: Array<{ path: string }> };
    };
    expect(body.error.code).toBe('VALIDATION_FAILED');
    expect(body.error.issues).toEqual(issues);
  });

  it('maps unknown Error → 500 with generic message in production', async () => {
    process.env.NODE_ENV = 'production';
    const handler = withApiErrorHandler(async () => {
      throw new Error('internal secret');
    });
    const res = await handler(new Request('http://localhost/'));
    expect(res.status).toBe(500);
    const body = (await res.json()) as { error: { code: string; message: string; stack?: string } };
    expect(body.error.code).toBe('INTERNAL_ERROR');
    expect(body.error.message).toBe('Internal server error.');
    expect(body.error.stack).toBeUndefined();
  });

  it('includes stack trace in dev mode for unknown errors', async () => {
    process.env.NODE_ENV = 'development';
    const handler = withApiErrorHandler(async () => {
      throw new Error('dev boom');
    });
    const res = await handler(new Request('http://localhost/'));
    expect(res.status).toBe(500);
    const body = (await res.json()) as { error: { stack?: string } };
    expect(body.error.stack).toContain('dev boom');
  });

  it('returns JSON content-type on every response', async () => {
    const handler = withApiErrorHandler(async () => ({ ok: true }));
    const res = await handler(new Request('http://localhost/'));
    expect(res.headers.get('content-type')).toBe('application/json; charset=utf-8');
  });
});

// ─── ApiErrorBoundary — withValidatedBody ──────────────────────────────────

describe('withValidatedBody', () => {
  const schema = z.object({ name: z.string().min(1) });

  it('parses a valid body and delegates to the handler', async () => {
    const inner = vi.fn(async (body: { name: string }) => ({ echoed: body.name }));
    const wrapped = withApiErrorHandler(withValidatedBody(schema, inner));

    const req = new Request('http://localhost/', {
      method: 'POST',
      body: JSON.stringify({ name: 'Alice' }),
      headers: { 'content-type': 'application/json' },
    });
    const res = await wrapped(req);
    expect(res.status).toBe(200);
    expect(inner).toHaveBeenCalledWith({ name: 'Alice' }, req);
  });

  it('throws ValidationError → 400 when body fails schema', async () => {
    const inner = vi.fn(async () => ({ never: 'called' }));
    const wrapped = withApiErrorHandler(withValidatedBody(schema, inner));

    const req = new Request('http://localhost/', {
      method: 'POST',
      body: JSON.stringify({ name: '' }),
      headers: { 'content-type': 'application/json' },
    });
    const res = await wrapped(req);
    expect(res.status).toBe(400);
    expect(inner).not.toHaveBeenCalled();
  });

  it('throws ValidationError → 400 when body is not valid JSON', async () => {
    const inner = vi.fn(async () => ({ never: 'called' }));
    const wrapped = withApiErrorHandler(withValidatedBody(schema, inner));

    const req = new Request('http://localhost/', {
      method: 'POST',
      body: 'not json at all',
      headers: { 'content-type': 'application/json' },
    });
    const res = await wrapped(req);
    expect(res.status).toBe(400);
    const body = (await res.json()) as { error: { code: string; message: string } };
    expect(body.error.code).toBe('VALIDATION_FAILED');
    expect(body.error.message).toContain('not valid JSON');
  });
});
