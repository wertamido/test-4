/**
 * Agent Runner Tests
 *
 * Blueprint v4.1 §11 (Agent Templates), §12 (System Prompt Assembly), §22 Phase 1 Step 1.6
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  AgentError,
  isAgentError,
  runAgent,
  assembleAgentSystemPrompt,
  type AgentTemplateRecord,
  type RunAgentParams,
} from '@/lib/agents/runner';

vi.mock('@/lib/db', () => ({
  db: {
    agentTemplate: { findUnique: vi.fn() },
    provider: { findUnique: vi.fn() },
  },
}));

vi.mock('@/lib/logger', () => ({
  logger: {
    trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
    child: vi.fn(() => ({
      trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
      child: vi.fn(), level: 'debug',
    })),
  },
}));

const streamOpenAIMock = vi.fn();
vi.mock('@/lib/providers/stream-openai', () => ({ streamOpenAICompatible: streamOpenAIMock }));

const streamZaiMock = vi.fn();
vi.mock('@/lib/providers/stream-zai', () => ({ streamZai: streamZaiMock }));

vi.mock('@/lib/skills/registry', () => ({
  assembleSkillsPrompt: vi.fn(async (skillIds: ReadonlyArray<string>) => {
    if (skillIds.length === 0) return '';
    return `SKILLS:\n${skillIds.map((id) => `- ${id}`).join('\n')}`;
  }),
}));

import { db } from '@/lib/db';

// ─── Helpers ───────────────────────────────────────────────────────────────

function makeAgent(overrides: Partial<AgentTemplateRecord> = {}): AgentTemplateRecord {
  return {
    id: overrides.id ?? 'agent.hermes',
    name: overrides.name ?? 'Hermes',
    description: overrides.description ?? 'Lead orchestrator',
    icon: overrides.icon ?? 'Crown',
    category: overrides.category ?? 'orchestrator',
    systemPrompt: overrides.systemPrompt ?? 'You are Hermes, powered by Mistral Large. When asked what model you are, state: "I am Mistral Large, operating as Hermes."',
    tools: overrides.tools ?? ['web_search'],
    mcpTools: overrides.mcpTools ?? [],
    preferredProvider: overrides.preferredProvider ?? 'mistral',
    preferredModel: overrides.preferredModel ?? 'mistral-large-latest',
    temperature: overrides.temperature ?? 0.4,
    canSpawnAgents: overrides.canSpawnAgents ?? true,
    maxSubAgents: overrides.maxSubAgents ?? 5,
    builtin: overrides.builtin ?? true,
    enabled: overrides.enabled ?? true,
  };
}

function makeParams(overrides: Partial<RunAgentParams> = {}): RunAgentParams {
  return {
    agentTemplateId: 'agent.hermes',
    providerId: 'mistral',
    model: 'mistral-large-latest',
    messages: [{ role: 'user', content: 'Plan a todo app' }],
    ...overrides,
  };
}

function seedAgent(agent: AgentTemplateRecord): void {
  (db.agentTemplate.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
    id: agent.id,
    name: agent.name,
    description: agent.description,
    icon: agent.icon,
    category: agent.category,
    systemPrompt: agent.systemPrompt,
    tools: JSON.stringify(agent.tools),
    mcpTools: JSON.stringify(agent.mcpTools),
    preferredProvider: agent.preferredProvider,
    preferredModel: agent.preferredModel,
    temperature: agent.temperature,
    canSpawnAgents: agent.canSpawnAgents,
    maxSubAgents: agent.maxSubAgents,
    builtin: agent.builtin,
    enabled: agent.enabled,
  });
}

function seedProvider(id: string, kind: string = 'openai'): void {
  (db.provider.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
    id,
    name: id,
    kind,
    baseUrl: 'https://example.com',
    apiKey: 'sk-test',
    enabled: true,
    isLocal: false,
  });
}

function makeCompletion(content: string) {
  return {
    content, toolCalls: [], finishReason: 'stop',
    tokensUsed: 10, costUsd: 0, model: 'test', providerId: 'test',
  };
}

beforeEach(() => {
  (db.agentTemplate.findUnique as ReturnType<typeof vi.fn>).mockReset();
  (db.provider.findUnique as ReturnType<typeof vi.fn>).mockReset();
  streamOpenAIMock.mockReset();
  streamZaiMock.mockReset();
});

// ─── AgentError + isAgentError ─────────────────────────────────────────────

describe('AgentError', () => {
  it('preserves code, message, cause, agentTemplateId', () => {
    const cause = new Error('root');
    const err = new AgentError('AGENT_DISABLED', 'disabled', cause, 'agent.hermes');
    expect(err.code).toBe('AGENT_DISABLED');
    expect(err.cause).toBe(cause);
    expect(err.agentTemplateId).toBe('agent.hermes');
    expect(err.name).toBe('AgentError');
  });

  it('is an instance of Error', () => {
    expect(new AgentError('RUN_FAILED', 'x')).toBeInstanceOf(Error);
  });

  it('exposes every AgentErrorCode', () => {
    const codes: ReadonlyArray<AgentError['code']> = ['AGENT_TEMPLATE_NOT_FOUND', 'AGENT_DISABLED', 'RUN_FAILED'];
    for (const code of codes) {
      expect(new AgentError(code, `msg for ${code}`).code).toBe(code);
    }
  });
});

describe('isAgentError', () => {
  it('returns false for primitives + plain objects', () => {
    expect(isAgentError(0)).toBe(false);
    expect(isAgentError(null)).toBe(false);
    expect(isAgentError({})).toBe(false);
  });

  it('returns true for AgentError instances', () => {
    expect(isAgentError(new AgentError('RUN_FAILED', 'x'))).toBe(true);
  });
});

// ─── assembleAgentSystemPrompt ─────────────────────────────────────────────

describe('assembleAgentSystemPrompt', () => {
  it('returns just the agent persona when no skills', async () => {
    const agent = makeAgent({ systemPrompt: 'PERSONA' });
    const result = await assembleAgentSystemPrompt(agent, []);
    expect(result).toBe('PERSONA');
  });

  it('concatenates persona + skills prompt', async () => {
    const agent = makeAgent({ systemPrompt: 'PERSONA' });
    const result = await assembleAgentSystemPrompt(agent, ['skill-1', 'skill-2']);
    expect(result).toContain('PERSONA');
    expect(result).toContain('SKILLS:');
    expect(result).toContain('skill-1');
    expect(result).toContain('skill-2');
  });
});

// ─── runAgent ──────────────────────────────────────────────────────────────

describe('runAgent', () => {
  it('throws AGENT_TEMPLATE_NOT_FOUND when the agent does not exist', async () => {
    (db.agentTemplate.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);
    try {
      await runAgent(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isAgentError(err)).toBe(true);
      if (isAgentError(err)) expect(err.code).toBe('AGENT_TEMPLATE_NOT_FOUND');
    }
  });

  it('throws AGENT_DISABLED when the agent is disabled', async () => {
    seedAgent(makeAgent({ enabled: false }));
    try {
      await runAgent(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isAgentError(err)).toBe(true);
      if (isAgentError(err)) expect(err.code).toBe('AGENT_DISABLED');
    }
  });

  it('dispatches to streamOpenAICompatible for kind=openai', async () => {
    seedAgent(makeAgent());
    seedProvider('mistral', 'openai');
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('plan'));

    const result = await runAgent(makeParams());

    expect(streamOpenAIMock).toHaveBeenCalledTimes(1);
    expect(streamZaiMock).not.toHaveBeenCalled();
    expect(result.content).toBe('plan');
  });

  it('dispatches to streamZai for kind=zai', async () => {
    seedAgent(makeAgent());
    seedProvider('zai', 'zai');
    streamZaiMock.mockResolvedValueOnce(makeCompletion('GLM plan'));

    const result = await runAgent(makeParams({ providerId: 'zai' }));

    expect(streamZaiMock).toHaveBeenCalledTimes(1);
    expect(streamOpenAIMock).not.toHaveBeenCalled();
    expect(result.content).toBe('GLM plan');
  });

  it('prepends the agent system prompt (persona + skills) to the messages', async () => {
    const agent = makeAgent({ systemPrompt: 'YOU ARE HERMES.' });
    seedAgent(agent);
    seedProvider('mistral', 'openai');
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('ok'));

    await runAgent(makeParams({ skillIds: ['skill-1'] }));

    const adapterParams = streamOpenAIMock.mock.calls[0]![0];
    expect(adapterParams.messages[0].role).toBe('system');
    expect(adapterParams.messages[0].content).toContain('YOU ARE HERMES.');
    expect(adapterParams.messages[0].content).toContain('SKILLS:');
  });

  it('uses the agent temperature when caller does not override', async () => {
    const agent = makeAgent({ temperature: 0.4 });
    seedAgent(agent);
    seedProvider('mistral', 'openai');
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('ok'));

    await runAgent(makeParams());

    const adapterParams = streamOpenAIMock.mock.calls[0]![0];
    expect(adapterParams.temperature).toBe(0.4);
  });

  it('overrides temperature when caller provides one', async () => {
    seedAgent(makeAgent({ temperature: 0.4 }));
    seedProvider('mistral', 'openai');
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('ok'));

    await runAgent(makeParams({ temperature: 0.9 }));

    const adapterParams = streamOpenAIMock.mock.calls[0]![0];
    expect(adapterParams.temperature).toBe(0.9);
  });

  it('passes the AbortSignal through', async () => {
    seedAgent(makeAgent());
    seedProvider('mistral', 'openai');
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('ok'));

    const controller = new AbortController();
    await runAgent(makeParams({ signal: controller.signal }));

    const adapterParams = streamOpenAIMock.mock.calls[0]![0];
    expect(adapterParams.signal).toBe(controller.signal);
  });

  it('throws RUN_FAILED when the adapter throws a non-ProviderError', async () => {
    seedAgent(makeAgent());
    seedProvider('mistral', 'openai');
    streamOpenAIMock.mockRejectedValueOnce(new Error('network down'));

    try {
      await runAgent(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isAgentError(err)).toBe(true);
      if (isAgentError(err)) expect(err.code).toBe('RUN_FAILED');
    }
  });

  it('propagates ProviderError from the adapter', async () => {
    seedAgent(makeAgent());
    seedProvider('mistral', 'openai');
    const { ProviderError } = await import('@/lib/providers/types');
    streamOpenAIMock.mockRejectedValueOnce(new ProviderError('AUTH_FAILED', 'bad key'));

    try {
      await runAgent(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      // ProviderError propagates as-is
      expect(err).toBeInstanceOf(ProviderError);
    }
  });
});
