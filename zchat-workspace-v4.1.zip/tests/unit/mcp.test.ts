/**
 * MCP Integration Tests
 *
 * Blueprint v4.1 §13 (MCP Integration), §22 Phase 1 Step 1.9
 *
 * The McpClient class spawns real child processes, so we test it with
 * a mock spawn function. The DB-backed functions are tested with mocked db.
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  McpError,
  isMcpError,
  McpClient,
  MCP_PRESETS,
  getMcpServer,
  getEnabledMcpServers,
  getEnabledMcpTools,
  testMcpServer,
  type McpTool,
} from '@/lib/mcp';

vi.mock('@/lib/db', () => ({
  db: {
    mcpServer: { findUnique: vi.fn(), findMany: vi.fn(), update: vi.fn() },
  },
}));

vi.mock('@/lib/logger', () => ({
  logger: {
    trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
    child: vi.fn(() => ({
      trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
      child: vi.fn(), level: 'debug',
    })),
  },
}));

import { db } from '@/lib/db';

const WS_1 = 'ws-1';

function makeMcpServerRow(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    id: 'mcp-1',
    workspaceId: WS_1,
    name: 'Filesystem',
    transport: 'stdio',
    command: 'npx',
    args: JSON.stringify(['-y', '@modelcontextprotocol/server-filesystem']),
    url: null,
    env: '{}',
    enabled: true,
    toolsCache: JSON.stringify([
      { name: 'read_file', description: 'Read a file', inputSchema: { type: 'object' } },
      { name: 'write_file', description: 'Write a file', inputSchema: { type: 'object' } },
    ]),
    ...overrides,
  };
}

beforeEach(() => {
  (db.mcpServer.findUnique as ReturnType<typeof vi.fn>).mockReset();
  (db.mcpServer.findMany as ReturnType<typeof vi.fn>).mockReset();
  (db.mcpServer.update as ReturnType<typeof vi.fn>).mockReset();
});

// ─── McpError + isMcpError ─────────────────────────────────────────────────

describe('McpError', () => {
  it('preserves code, message, cause, mcpServerId', () => {
    const cause = new Error('root');
    const err = new McpError('MCP_SPAWN_FAILED', 'spawn broke', cause, 'mcp-1');
    expect(err.code).toBe('MCP_SPAWN_FAILED');
    expect(err.cause).toBe(cause);
    expect(err.mcpServerId).toBe('mcp-1');
    expect(err.name).toBe('McpError');
  });

  it('is an instance of Error', () => {
    expect(new McpError('MCP_TIMEOUT', 'x')).toBeInstanceOf(Error);
  });

  it('exposes every McpErrorCode', () => {
    const codes: ReadonlyArray<McpError['code']> = [
      'MCP_SERVER_NOT_FOUND', 'MCP_SPAWN_FAILED', 'MCP_DISCOVER_FAILED',
      'MCP_CALL_FAILED', 'MCP_TIMEOUT', 'MCP_NOT_CONFIGURED',
    ];
    for (const code of codes) {
      expect(new McpError(code, `msg for ${code}`).code).toBe(code);
    }
  });
});

describe('isMcpError', () => {
  it('returns false for primitives + plain objects', () => {
    expect(isMcpError(0)).toBe(false);
    expect(isMcpError(null)).toBe(false);
    expect(isMcpError({})).toBe(false);
  });

  it('returns true for McpError instances', () => {
    expect(isMcpError(new McpError('MCP_TIMEOUT', 'x'))).toBe(true);
  });
});

// ─── Presets ───────────────────────────────────────────────────────────────

describe('MCP_PRESETS', () => {
  it('has 2 presets (Filesystem + Memory)', () => {
    expect(MCP_PRESETS).toHaveLength(2);
  });

  it('includes the Filesystem preset', () => {
    const fs = MCP_PRESETS.find((p) => p.id === 'mcp.filesystem');
    expect(fs).toBeDefined();
    expect(fs!.command).toBe('npx');
    expect(fs!.args).toContain('@modelcontextprotocol/server-filesystem');
  });

  it('includes the Memory preset', () => {
    const mem = MCP_PRESETS.find((p) => p.id === 'mcp.memory');
    expect(mem).toBeDefined();
    expect(mem!.command).toBe('npx');
    expect(mem!.args).toContain('@modelcontextprotocol/server-memory');
  });
});

// ─── getMcpServer ──────────────────────────────────────────────────────────

describe('getMcpServer', () => {
  it('returns the server when it exists', async () => {
    (db.mcpServer.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce(makeMcpServerRow());

    const server = await getMcpServer('mcp-1');
    expect(server.id).toBe('mcp-1');
    expect(server.name).toBe('Filesystem');
    expect(server.command).toBe('npx');
    expect(server.args).toEqual(['-y', '@modelcontextprotocol/server-filesystem']);
    expect(server.toolsCache).toHaveLength(2);
    expect(server.toolsCache[0]!.name).toBe('read_file');
  });

  it('throws MCP_SERVER_NOT_FOUND when missing', async () => {
    (db.mcpServer.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);
    try {
      await getMcpServer('nonexistent');
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isMcpError(err)).toBe(true);
      if (isMcpError(err)) expect(err.code).toBe('MCP_SERVER_NOT_FOUND');
    }
  });

  it('parses JSON fields (args, env, toolsCache)', async () => {
    (db.mcpServer.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce(
      makeMcpServerRow({
        args: JSON.stringify(['-y', 'server']),
        env: JSON.stringify({ NODE_PATH: '/usr/lib' }),
        toolsCache: JSON.stringify([{ name: 'tool1', description: 'd', inputSchema: {} }]),
      }),
    );

    const server = await getMcpServer('mcp-1');
    expect(server.args).toEqual(['-y', 'server']);
    expect(server.env).toEqual({ NODE_PATH: '/usr/lib' });
    expect(server.toolsCache).toHaveLength(1);
  });

  it('handles corrupt JSON gracefully (defaults to empty)', async () => {
    (db.mcpServer.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce(
      makeMcpServerRow({
        args: 'not-json',
        env: 'also-not-json',
        toolsCache: 'broken',
      }),
    );

    const server = await getMcpServer('mcp-1');
    expect(server.args).toEqual([]);
    expect(server.env).toEqual({});
    expect(server.toolsCache).toEqual([]);
  });
});

// ─── getEnabledMcpServers ──────────────────────────────────────────────────

describe('getEnabledMcpServers', () => {
  it('returns enabled servers for the workspace + global servers', async () => {
    (db.mcpServer.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      makeMcpServerRow({ id: 'ws-server', workspaceId: WS_1 }),
      makeMcpServerRow({ id: 'global-server', workspaceId: null }),
    ]);

    const servers = await getEnabledMcpServers(WS_1);
    expect(servers).toHaveLength(2);
    expect(servers.map((s) => s.id)).toContain('ws-server');
    expect(servers.map((s) => s.id)).toContain('global-server');
  });
});

// ─── getEnabledMcpTools ────────────────────────────────────────────────────

describe('getEnabledMcpTools', () => {
  it('returns all tools from all enabled servers', async () => {
    (db.mcpServer.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      makeMcpServerRow({
        id: 's1',
        toolsCache: JSON.stringify([
          { name: 'read_file', description: 'Read', inputSchema: {} },
          { name: 'write_file', description: 'Write', inputSchema: {} },
        ]),
      }),
      makeMcpServerRow({
        id: 's2',
        toolsCache: JSON.stringify([
          { name: 'create_entity', description: 'Memory', inputSchema: {} },
        ]),
      }),
    ]);

    const tools = await getEnabledMcpTools(WS_1);
    expect(tools).toHaveLength(3);
    expect(tools.map((t) => t.name)).toContain('read_file');
    expect(tools.map((t) => t.name)).toContain('create_entity');
  });

  it('returns empty array when no servers are enabled', async () => {
    (db.mcpServer.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([]);

    const tools = await getEnabledMcpTools(WS_1);
    expect(tools).toEqual([]);
  });
});

// ─── McpClient (mocked spawn) ──────────────────────────────────────────────

describe('McpClient', () => {
  it('throws MCP_SPAWN_FAILED when spawn fails', async () => {
    // Mock child_process.spawn to throw
    vi.doMock('node:child_process', () => ({
      spawn: vi.fn(() => {
        throw new Error('ENOENT');
      }),
    }));

    // We need to re-import after doMock
    const { McpClient: MockedClient } = await import('@/lib/mcp');
    const client = new MockedClient({ command: 'nonexistent', args: [] });
    try {
      await client.connect();
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isMcpError(err)).toBe(true);
      if (isMcpError(err)) expect(err.code).toBe('MCP_SPAWN_FAILED');
    }
    vi.doUnmock('node:child_process');
  });
});

// ─── testMcpServer ─────────────────────────────────────────────────────────

describe('testMcpServer', () => {
  it('throws MCP_NOT_CONFIGURED for non-stdio servers', async () => {
    (db.mcpServer.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce(
      makeMcpServerRow({ transport: 'sse', command: null, url: 'https://example.com' }),
    );

    try {
      await testMcpServer('mcp-1');
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isMcpError(err)).toBe(true);
      if (isMcpError(err)) expect(err.code).toBe('MCP_NOT_CONFIGURED');
    }
  });
});

// ─── Type-level checks ─────────────────────────────────────────────────────

describe('type-level checks', () => {
  it('McpTool has name, description, inputSchema', () => {
    const tool: McpTool = {
      name: 'read_file',
      description: 'Read a file',
      inputSchema: { type: 'object', properties: { path: { type: 'string' } } },
    };
    expect(tool.name).toBe('read_file');
  });
});
