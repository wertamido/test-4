/**
 * Unit tests for src/lib/sessions/types.ts + repository.ts
 *
 * Blueprint v4.1 §6 (Session model), §4 (NO pending state), §22 Phase 1 Step 1.3,
 * §24 (Security Model), §23 (Testing Strategy)
 *
 * Coverage:
 *  - SessionError + isSessionError: construction, brand, type guard (pos + neg)
 *  - isValidStatusTransition: every valid + invalid transition
 *  - encodeCursor / decodeCursor: round-trip + error cases
 *  - createSession: creates with status='idle', default model='glm-4.6',
 *    empty JSON arrays, goal=null when omitted
 *  - getSession: returns the session; SESSION_NOT_FOUND when missing;
 *    WORKSPACE_MISMATCH when workspace doesn't match
 *  - updateSession: updates fields; JSON-stringifies arrays; validates
 *    status transitions (valid + invalid); rejects empty input
 *  - deleteSession: deletes; subsequent getSession throws SESSION_NOT_FOUND
 *  - listSessions: cursor pagination; filters by status + pinned;
 *    orders by createdAt DESC + id DESC; respects limit (max 100)
 *  - pinSession: toggles pinned
 *  - RBAC: every method enforces workspace-scoped access
 *
 * Mocking strategy:
 *  - @/lib/db is mocked with an in-memory session store. The mock implements
 *    findUnique, findMany, create, update, delete with cursor pagination
 *    support (matching Prisma's query semantics).
 *  - @/lib/logger is mocked to suppress noise.
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';

// ─── Mock setup ────────────────────────────────────────────────────────────

type StoredSession = {
  id: string;
  workspaceId: string;
  title: string;
  goal: string | null;
  status: string;
  providerId: string | null;
  model: string;
  agentId: string | null;
  skillIds: string;
  repoIds: string;
  mcpServerIds: string;
  pinned: boolean;
  createdAt: Date;
  updatedAt: Date;
};

const sessionStore = new Map<string, StoredSession>();
let idCounter = 0;

const dbMock = {
  session: {
    findUnique: vi.fn(async (args: { where: { id: string } }) => {
      return sessionStore.get(args.where.id) ?? null;
    }),

    findMany: vi.fn(async (args: {
      where?: Record<string, unknown>;
      orderBy?: Array<Record<string, 'asc' | 'desc'>>;
      take?: number;
    }) => {
      let entries = Array.from(sessionStore.values());

      // Apply where clause
      const where = args.where ?? {};
      entries = applyWhere(entries, where);

      // Apply orderBy (createdAt desc, id desc)
      if (args.orderBy) {
        for (const ob of [...args.orderBy].reverse()) {
          for (const [field, dir] of Object.entries(ob)) {
            entries.sort((a, b) => {
              const av = (a as Record<string, unknown>)[field];
              const bv = (b as Record<string, unknown>)[field];
              let cmp = 0;
              if (av instanceof Date && bv instanceof Date) {
                cmp = av.getTime() - bv.getTime();
              } else if (typeof av === 'string' && typeof bv === 'string') {
                cmp = av < bv ? -1 : av > bv ? 1 : 0;
              } else if (typeof av === 'boolean' && typeof bv === 'boolean') {
                cmp = av === bv ? 0 : av ? 1 : -1;
              }
              return dir === 'asc' ? cmp : -cmp;
            });
          }
        }
      }

      // Apply take
      if (args.take !== undefined) {
        entries = entries.slice(0, args.take);
      }

      return entries;
    }),

    create: vi.fn(async (args: { data: Partial<StoredSession> }) => {
      const id = `sess-${++idCounter}`;
      const now = new Date();
      const session: StoredSession = {
        id,
        workspaceId: args.data.workspaceId!,
        title: args.data.title ?? 'New session',
        goal: args.data.goal ?? null,
        status: args.data.status ?? 'idle',
        providerId: args.data.providerId ?? null,
        model: args.data.model ?? 'glm-4.6',
        agentId: args.data.agentId ?? null,
        skillIds: args.data.skillIds ?? '[]',
        repoIds: args.data.repoIds ?? '[]',
        mcpServerIds: args.data.mcpServerIds ?? '[]',
        pinned: args.data.pinned ?? false,
        createdAt: now,
        updatedAt: now,
      };
      sessionStore.set(id, session);
      return session;
    }),

    update: vi.fn(async (args: { where: { id: string }; data: Partial<StoredSession> }) => {
      const existing = sessionStore.get(args.where.id);
      if (!existing) {
        throw new Error(`Record not found for id ${args.where.id}`);
      }
      const updated: StoredSession = {
        ...existing,
        ...(args.data as Partial<StoredSession>),
        updatedAt: new Date(),
      };
      sessionStore.set(args.where.id, updated);
      return updated;
    }),

    delete: vi.fn(async (args: { where: { id: string } }) => {
      const existing = sessionStore.get(args.where.id);
      if (!existing) {
        throw new Error(`Record not found for id ${args.where.id}`);
      }
      sessionStore.delete(args.where.id);
      return existing;
    }),
  },
};

/** Recursively apply a Prisma-style where clause to filter entries. */
function applyWhere(
  entries: StoredSession[],
  where: Record<string, unknown>,
): StoredSession[] {
  let result = entries;
  for (const [key, value] of Object.entries(where)) {
    if (key === 'AND') {
      for (const subWhere of value as Array<Record<string, unknown>>) {
        result = applyWhere(result, subWhere);
      }
    } else if (key === 'OR') {
      const subWheres = value as Array<Record<string, unknown>>;
      result = result.filter((entry) =>
        subWheres.some((subWhere) => applyWhere([entry], subWhere).length > 0),
      );
    } else if (key === 'workspaceId') {
      result = result.filter((e) => e.workspaceId === value);
    } else if (key === 'status') {
      result = result.filter((e) => e.status === value);
    } else if (key === 'pinned') {
      result = result.filter((e) => e.pinned === value);
    } else if (key === 'id') {
      const idFilter = value as { lt?: string };
      if (idFilter.lt !== undefined) {
        result = result.filter((e) => e.id < idFilter.lt!);
      }
    } else if (key === 'createdAt') {
      const dateFilter = value as { lt?: Date };
      if (dateFilter.lt !== undefined) {
        result = result.filter((e) => e.createdAt < dateFilter.lt!);
      }
    }
  }
  return result;
}

vi.mock('@/lib/db', () => ({ db: dbMock }));

vi.mock('@/lib/logger', () => ({
  logger: {
    trace: vi.fn(),
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    fatal: vi.fn(),
    child: vi.fn(() => ({
      trace: vi.fn(),
      debug: vi.fn(),
      info: vi.fn(),
      warn: vi.fn(),
      error: vi.fn(),
      fatal: vi.fn(),
      child: vi.fn(),
      level: 'debug',
    })),
  },
}));

// ─── Imports (after mocks) ─────────────────────────────────────────────────

import {
  createSession,
  getSession,
  updateSession,
  deleteSession,
  listSessions,
  pinSession,
} from '@/lib/sessions/repository';
import {
  SessionError,
  isSessionError,
  isValidStatusTransition,
  encodeCursor,
  decodeCursor,
  type CreateSessionInput,
  type SessionRecord,
  type SessionStatus,
} from '@/lib/sessions/types';

// ─── Test helpers ──────────────────────────────────────────────────────────

const WS_1 = 'ws-1';
const WS_2 = 'ws-2';

function resetStore(): void {
  sessionStore.clear();
  idCounter = 0;
  for (const fn of Object.values(dbMock.session)) {
    (fn as ReturnType<typeof vi.fn>).mockClear();
  }
}

async function seedSession(
  overrides: Partial<StoredSession> = {},
): Promise<StoredSession> {
  const id = overrides.id ?? `sess-${++idCounter}`;
  const now = new Date();
  const session: StoredSession = {
    id,
    workspaceId: overrides.workspaceId ?? WS_1,
    title: overrides.title ?? 'Test Session',
    goal: overrides.goal ?? null,
    status: overrides.status ?? 'idle',
    providerId: overrides.providerId ?? null,
    model: overrides.model ?? 'glm-4.6',
    agentId: overrides.agentId ?? null,
    skillIds: overrides.skillIds ?? '[]',
    repoIds: overrides.repoIds ?? '[]',
    mcpServerIds: overrides.mcpServerIds ?? '[]',
    pinned: overrides.pinned ?? false,
    createdAt: overrides.createdAt ?? now,
    updatedAt: overrides.updatedAt ?? now,
  };
  sessionStore.set(id, session);
  return session;
}

// ─── SessionError + isSessionError ─────────────────────────────────────────

describe('SessionError', () => {
  it('preserves code, message, cause, sessionId, workspaceId', () => {
    const cause = new Error('root');
    const err = new SessionError('SESSION_NOT_FOUND', 'missing', cause, 'sess-1', 'ws-1');
    expect(err.code).toBe('SESSION_NOT_FOUND');
    expect(err.message).toBe('missing');
    expect(err.cause).toBe(cause);
    expect(err.sessionId).toBe('sess-1');
    expect(err.workspaceId).toBe('ws-1');
    expect(err.name).toBe('SessionError');
  });

  it('is an instance of Error', () => {
    expect(new SessionError('CREATE_FAILED', 'x')).toBeInstanceOf(Error);
  });

  it('survives instanceof SessionError after subclassing Error', () => {
    const err = new SessionError('UPDATE_FAILED', 'x');
    expect(err).toBeInstanceOf(SessionError);
    try {
      throw err;
    } catch (caught) {
      expect(caught).toBeInstanceOf(SessionError);
    }
  });

  it('exposes every SessionErrorCode value', () => {
    const codes: ReadonlyArray<SessionError['code']> = [
      'SESSION_NOT_FOUND',
      'WORKSPACE_MISMATCH',
      'INVALID_STATUS_TRANSITION',
      'CREATE_FAILED',
      'UPDATE_FAILED',
      'DELETE_FAILED',
      'LIST_FAILED',
    ];
    for (const code of codes) {
      expect(new SessionError(code, `msg for ${code}`).code).toBe(code);
    }
  });
});

describe('isSessionError', () => {
  it('returns false for primitives', () => {
    expect(isSessionError(0)).toBe(false);
    expect(isSessionError('')).toBe(false);
    expect(isSessionError(null)).toBe(false);
    expect(isSessionError(undefined)).toBe(false);
  });

  it('returns false for plain objects lacking the brand', () => {
    expect(isSessionError({ code: 'SESSION_NOT_FOUND' })).toBe(false);
    expect(isSessionError(new Error('plain'))).toBe(false);
  });

  it('returns true for SessionError instances', () => {
    expect(isSessionError(new SessionError('SESSION_NOT_FOUND', 'x'))).toBe(true);
  });
});

// ─── isValidStatusTransition ───────────────────────────────────────────────

describe('isValidStatusTransition', () => {
  describe('valid forward transitions', () => {
    it('idle → planning is valid', () => {
      expect(isValidStatusTransition('idle', 'planning')).toBe(true);
    });
    it('idle → executing is valid (skip planning)', () => {
      expect(isValidStatusTransition('idle', 'executing')).toBe(true);
    });
    it('idle → verifying is valid (skip planning + executing)', () => {
      expect(isValidStatusTransition('idle', 'verifying')).toBe(true);
    });
    it('idle → done is valid (instant mode)', () => {
      expect(isValidStatusTransition('idle', 'done')).toBe(true);
    });
    it('planning → executing is valid', () => {
      expect(isValidStatusTransition('planning', 'executing')).toBe(true);
    });
    it('planning → verifying is valid (skip executing)', () => {
      expect(isValidStatusTransition('planning', 'verifying')).toBe(true);
    });
    it('planning → done is valid', () => {
      expect(isValidStatusTransition('planning', 'done')).toBe(true);
    });
    it('executing → verifying is valid', () => {
      expect(isValidStatusTransition('executing', 'verifying')).toBe(true);
    });
    it('executing → done is valid', () => {
      expect(isValidStatusTransition('executing', 'done')).toBe(true);
    });
    it('verifying → done is valid', () => {
      expect(isValidStatusTransition('verifying', 'done')).toBe(true);
    });
  });

  describe('error transitions', () => {
    it('idle → error is valid', () => {
      expect(isValidStatusTransition('idle', 'error')).toBe(true);
    });
    it('planning → error is valid', () => {
      expect(isValidStatusTransition('planning', 'error')).toBe(true);
    });
    it('executing → error is valid', () => {
      expect(isValidStatusTransition('executing', 'error')).toBe(true);
    });
    it('verifying → error is valid', () => {
      expect(isValidStatusTransition('verifying', 'error')).toBe(true);
    });
  });

  describe('invalid backward transitions', () => {
    it('planning → idle is invalid', () => {
      expect(isValidStatusTransition('planning', 'idle')).toBe(false);
    });
    it('executing → planning is invalid', () => {
      expect(isValidStatusTransition('executing', 'planning')).toBe(false);
    });
    it('executing → idle is invalid', () => {
      expect(isValidStatusTransition('executing', 'idle')).toBe(false);
    });
    it('verifying → executing is invalid', () => {
      expect(isValidStatusTransition('verifying', 'executing')).toBe(false);
    });
    it('verifying → planning is invalid', () => {
      expect(isValidStatusTransition('verifying', 'planning')).toBe(false);
    });
  });

  describe('terminal states (done, error)', () => {
    it('done → idle is invalid', () => {
      expect(isValidStatusTransition('done', 'idle')).toBe(false);
    });
    it('done → planning is invalid', () => {
      expect(isValidStatusTransition('done', 'planning')).toBe(false);
    });
    it('done → executing is invalid', () => {
      expect(isValidStatusTransition('done', 'executing')).toBe(false);
    });
    it('done → verifying is invalid', () => {
      expect(isValidStatusTransition('done', 'verifying')).toBe(false);
    });
    it('done → error is invalid (done is terminal)', () => {
      expect(isValidStatusTransition('done', 'error')).toBe(false);
    });
    it('error → idle is invalid', () => {
      expect(isValidStatusTransition('error', 'idle')).toBe(false);
    });
    it('error → planning is invalid', () => {
      expect(isValidStatusTransition('error', 'planning')).toBe(false);
    });
    it('error → executing is invalid', () => {
      expect(isValidStatusTransition('error', 'executing')).toBe(false);
    });
    it('error → verifying is invalid', () => {
      expect(isValidStatusTransition('error', 'verifying')).toBe(false);
    });
    it('error → done is invalid', () => {
      expect(isValidStatusTransition('error', 'done')).toBe(false);
    });
  });

  describe('same status (no-op)', () => {
    it('idle → idle is valid (no-op)', () => {
      expect(isValidStatusTransition('idle', 'idle')).toBe(true);
    });
    it('done → done is valid (no-op)', () => {
      expect(isValidStatusTransition('done', 'done')).toBe(true);
    });
    it('error → error is valid (no-op)', () => {
      expect(isValidStatusTransition('error', 'error')).toBe(true);
    });
  });
});

// ─── encodeCursor / decodeCursor ───────────────────────────────────────────

describe('encodeCursor / decodeCursor', () => {
  it('round-trips a cursor', () => {
    const cursor = { createdAt: '2025-01-15T10:00:00.000Z', id: 'sess-1' };
    const encoded = encodeCursor(cursor);
    const decoded = decodeCursor(encoded);
    expect(decoded).toEqual(cursor);
  });

  it('produces a base64url string', () => {
    const encoded = encodeCursor({ createdAt: '2025-01-15T10:00:00.000Z', id: 'sess-1' });
    expect(typeof encoded).toBe('string');
    // base64url uses only URL-safe characters
    expect(encoded).toMatch(/^[A-Za-z0-9_-]+$/);
  });

  it('decodeCursor throws SessionError for invalid base64', () => {
    try {
      decodeCursor('not-valid-base64!!!');
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isSessionError(err)).toBe(true);
      if (isSessionError(err)) expect(err.code).toBe('LIST_FAILED');
    }
  });

  it('decodeCursor throws SessionError for valid base64 but invalid JSON', () => {
    const badJson = Buffer.from('not-json', 'utf8').toString('base64url');
    try {
      decodeCursor(badJson);
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isSessionError(err)).toBe(true);
    }
  });

  it('decodeCursor throws SessionError for JSON missing required fields', () => {
    const missingFields = Buffer.from(JSON.stringify({ createdAt: 'x' }), 'utf8').toString('base64url');
    try {
      decodeCursor(missingFields);
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isSessionError(err)).toBe(true);
    }
  });
});

// ─── createSession ─────────────────────────────────────────────────────────

describe('createSession', () => {
  beforeEach(() => {
    resetStore();
  });

  it('creates a session with status="idle"', async () => {
    const record = await createSession({
      workspaceId: WS_1,
      title: 'My Session',
    });
    expect(record.status).toBe('idle');
    expect(record.title).toBe('My Session');
    expect(record.workspaceId).toBe(WS_1);
  });

  it('defaults model to "glm-4.6"', async () => {
    const record = await createSession({
      workspaceId: WS_1,
      title: 'Test',
    });
    expect(record.model).toBe('glm-4.6');
  });

  it('honors an explicit model', async () => {
    const record = await createSession({
      workspaceId: WS_1,
      title: 'Test',
      model: 'gpt-4o',
    });
    expect(record.model).toBe('gpt-4o');
  });

  it('defaults goal to null when omitted', async () => {
    const record = await createSession({
      workspaceId: WS_1,
      title: 'Test',
    });
    expect(record.goal).toBeNull();
  });

  it('stores goal when provided', async () => {
    const record = await createSession({
      workspaceId: WS_1,
      title: 'Test',
      goal: 'Build a todo app',
    });
    expect(record.goal).toBe('Build a todo app');
  });

  it('initializes skillIds, repoIds, mcpServerIds as empty arrays', async () => {
    const record = await createSession({
      workspaceId: WS_1,
      title: 'Test',
    });
    expect(record.skillIds).toEqual([]);
    expect(record.repoIds).toEqual([]);
    expect(record.mcpServerIds).toEqual([]);
  });

  it('initializes pinned to false', async () => {
    const record = await createSession({
      workspaceId: WS_1,
      title: 'Test',
    });
    expect(record.pinned).toBe(false);
  });

  it('stores providerId when provided', async () => {
    const record = await createSession({
      workspaceId: WS_1,
      title: 'Test',
      providerId: 'openai',
    });
    expect(record.providerId).toBe('openai');
  });

  it('defaults providerId to null when omitted', async () => {
    const record = await createSession({
      workspaceId: WS_1,
      title: 'Test',
    });
    expect(record.providerId).toBeNull();
  });

  it('throws CREATE_FAILED for an empty title', async () => {
    try {
      await createSession({ workspaceId: WS_1, title: '' });
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isSessionError(err)).toBe(true);
      if (isSessionError(err)) expect(err.code).toBe('CREATE_FAILED');
    }
  });
});

// ─── getSession ────────────────────────────────────────────────────────────

describe('getSession', () => {
  beforeEach(() => {
    resetStore();
  });

  it('returns the session when it exists in the workspace', async () => {
    const seeded = await seedSession({ id: 'sess-1', workspaceId: WS_1 });
    const record = await getSession('sess-1', WS_1);
    expect(record.id).toBe('sess-1');
    expect(record.title).toBe(seeded.title);
  });

  it('throws SESSION_NOT_FOUND when the session does not exist', async () => {
    try {
      await getSession('nonexistent', WS_1);
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isSessionError(err)).toBe(true);
      if (isSessionError(err)) expect(err.code).toBe('SESSION_NOT_FOUND');
    }
  });

  it('throws WORKSPACE_MISMATCH when the session belongs to a different workspace', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_2 });
    try {
      await getSession('sess-1', WS_1);
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isSessionError(err)).toBe(true);
      if (isSessionError(err)) expect(err.code).toBe('WORKSPACE_MISMATCH');
    }
  });

  it('parses JSON fields on read', async () => {
    await seedSession({
      id: 'sess-1',
      skillIds: '["skill-1","skill-2"]',
      repoIds: '["repo-1"]',
      mcpServerIds: '["mcp-1"]',
    });
    const record = await getSession('sess-1', WS_1);
    expect(record.skillIds).toEqual(['skill-1', 'skill-2']);
    expect(record.repoIds).toEqual(['repo-1']);
    expect(record.mcpServerIds).toEqual(['mcp-1']);
  });

  it('handles corrupt JSON fields gracefully (defaults to empty array)', async () => {
    await seedSession({
      id: 'sess-1',
      skillIds: 'not-json',
      repoIds: 'also-not-json',
      mcpServerIds: 'broken',
    });
    const record = await getSession('sess-1', WS_1);
    expect(record.skillIds).toEqual([]);
    expect(record.repoIds).toEqual([]);
    expect(record.mcpServerIds).toEqual([]);
  });
});

// ─── updateSession ─────────────────────────────────────────────────────────

describe('updateSession', () => {
  beforeEach(() => {
    resetStore();
  });

  it('updates the title', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, title: 'Old' });
    const record = await updateSession('sess-1', WS_1, { title: 'New' });
    expect(record.title).toBe('New');
  });

  it('updates the goal', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, goal: null });
    const record = await updateSession('sess-1', WS_1, { goal: 'New goal' });
    expect(record.goal).toBe('New goal');
  });

  it('updates pinned', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, pinned: false });
    const record = await updateSession('sess-1', WS_1, { pinned: true });
    expect(record.pinned).toBe(true);
  });

  it('updates skillIds and JSON-stringifies them', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1 });
    const record = await updateSession('sess-1', WS_1, {
      skillIds: ['skill-a', 'skill-b'],
    });
    expect(record.skillIds).toEqual(['skill-a', 'skill-b']);
    // Verify the DB stored the stringified version
    const stored = sessionStore.get('sess-1')!;
    expect(stored.skillIds).toBe(JSON.stringify(['skill-a', 'skill-b']));
  });

  it('updates repoIds and mcpServerIds', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1 });
    const record = await updateSession('sess-1', WS_1, {
      repoIds: ['repo-1'],
      mcpServerIds: ['mcp-1', 'mcp-2'],
    });
    expect(record.repoIds).toEqual(['repo-1']);
    expect(record.mcpServerIds).toEqual(['mcp-1', 'mcp-2']);
  });

  it('updates providerId (including setting to null)', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, providerId: 'openai' });
    const record = await updateSession('sess-1', WS_1, { providerId: null });
    expect(record.providerId).toBeNull();
  });

  it('updates model', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, model: 'glm-4.6' });
    const record = await updateSession('sess-1', WS_1, { model: 'gpt-4o' });
    expect(record.model).toBe('gpt-4o');
  });

  it('updates agentId', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, agentId: null });
    const record = await updateSession('sess-1', WS_1, { agentId: 'hermes' });
    expect(record.agentId).toBe('hermes');
  });

  it('throws UPDATE_FAILED for empty input (no fields to update)', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1 });
    try {
      await updateSession('sess-1', WS_1, {});
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isSessionError(err)).toBe(true);
      if (isSessionError(err)) expect(err.code).toBe('UPDATE_FAILED');
    }
  });

  it('throws SESSION_NOT_FOUND when the session does not exist', async () => {
    try {
      await updateSession('nonexistent', WS_1, { title: 'X' });
      expect.fail('Expected to throw');
    } catch (err) {
      if (isSessionError(err)) expect(err.code).toBe('SESSION_NOT_FOUND');
    }
  });

  it('throws WORKSPACE_MISMATCH when the session belongs to a different workspace', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_2 });
    try {
      await updateSession('sess-1', WS_1, { title: 'X' });
      expect.fail('Expected to throw');
    } catch (err) {
      if (isSessionError(err)) expect(err.code).toBe('WORKSPACE_MISMATCH');
    }
  });
});

// ─── updateSession — status transitions ────────────────────────────────────

describe('updateSession — status transitions', () => {
  beforeEach(() => {
    resetStore();
  });

  it('valid transition: idle → planning', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, status: 'idle' });
    const record = await updateSession('sess-1', WS_1, { status: 'planning' });
    expect(record.status).toBe('planning');
  });

  it('valid transition: planning → executing', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, status: 'planning' });
    const record = await updateSession('sess-1', WS_1, { status: 'executing' });
    expect(record.status).toBe('executing');
  });

  it('valid transition: executing → verifying', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, status: 'executing' });
    const record = await updateSession('sess-1', WS_1, { status: 'verifying' });
    expect(record.status).toBe('verifying');
  });

  it('valid transition: verifying → done', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, status: 'verifying' });
    const record = await updateSession('sess-1', WS_1, { status: 'done' });
    expect(record.status).toBe('done');
  });

  it('valid transition: idle → error (error from any non-terminal state)', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, status: 'idle' });
    const record = await updateSession('sess-1', WS_1, { status: 'error' });
    expect(record.status).toBe('error');
  });

  it('valid transition: executing → error', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, status: 'executing' });
    const record = await updateSession('sess-1', WS_1, { status: 'error' });
    expect(record.status).toBe('error');
  });

  it('valid transition: idle → done (skip all stages — instant mode)', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, status: 'idle' });
    const record = await updateSession('sess-1', WS_1, { status: 'done' });
    expect(record.status).toBe('done');
  });

  it('invalid transition: done → idle (done is terminal)', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, status: 'done' });
    try {
      await updateSession('sess-1', WS_1, { status: 'idle' });
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isSessionError(err)).toBe(true);
      if (isSessionError(err)) expect(err.code).toBe('INVALID_STATUS_TRANSITION');
    }
  });

  it('invalid transition: done → planning', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, status: 'done' });
    try {
      await updateSession('sess-1', WS_1, { status: 'planning' });
      expect.fail('Expected to throw');
    } catch (err) {
      if (isSessionError(err)) expect(err.code).toBe('INVALID_STATUS_TRANSITION');
    }
  });

  it('invalid transition: error → idle (error is terminal)', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, status: 'error' });
    try {
      await updateSession('sess-1', WS_1, { status: 'idle' });
      expect.fail('Expected to throw');
    } catch (err) {
      if (isSessionError(err)) expect(err.code).toBe('INVALID_STATUS_TRANSITION');
    }
  });

  it('invalid transition: planning → idle (backward)', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, status: 'planning' });
    try {
      await updateSession('sess-1', WS_1, { status: 'idle' });
      expect.fail('Expected to throw');
    } catch (err) {
      if (isSessionError(err)) expect(err.code).toBe('INVALID_STATUS_TRANSITION');
    }
  });

  it('same-status update is a no-op (does not throw)', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, status: 'idle' });
    const record = await updateSession('sess-1', WS_1, { status: 'idle' });
    expect(record.status).toBe('idle');
  });
});

// ─── deleteSession ─────────────────────────────────────────────────────────

describe('deleteSession', () => {
  beforeEach(() => {
    resetStore();
  });

  it('deletes the session', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1 });
    await deleteSession('sess-1', WS_1);
    expect(sessionStore.has('sess-1')).toBe(false);
  });

  it('subsequent getSession throws SESSION_NOT_FOUND', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1 });
    await deleteSession('sess-1', WS_1);
    try {
      await getSession('sess-1', WS_1);
      expect.fail('Expected to throw');
    } catch (err) {
      if (isSessionError(err)) expect(err.code).toBe('SESSION_NOT_FOUND');
    }
  });

  it('throws SESSION_NOT_FOUND when deleting a missing session', async () => {
    try {
      await deleteSession('nonexistent', WS_1);
      expect.fail('Expected to throw');
    } catch (err) {
      if (isSessionError(err)) expect(err.code).toBe('SESSION_NOT_FOUND');
    }
  });

  it('throws WORKSPACE_MISMATCH when deleting a session in another workspace', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_2 });
    try {
      await deleteSession('sess-1', WS_1);
      expect.fail('Expected to throw');
    } catch (err) {
      if (isSessionError(err)) expect(err.code).toBe('WORKSPACE_MISMATCH');
    }
  });
});

// ─── listSessions ──────────────────────────────────────────────────────────

describe('listSessions', () => {
  beforeEach(() => {
    resetStore();
  });

  it('returns all sessions in the workspace, ordered by createdAt DESC', async () => {
    const t0 = new Date('2025-01-01T00:00:00Z');
    const t1 = new Date('2025-01-02T00:00:00Z');
    const t2 = new Date('2025-01-03T00:00:00Z');
    await seedSession({ id: 'old', workspaceId: WS_1, createdAt: t0 });
    await seedSession({ id: 'newest', workspaceId: WS_1, createdAt: t2 });
    await seedSession({ id: 'middle', workspaceId: WS_1, createdAt: t1 });

    const result = await listSessions({ workspaceId: WS_1 });
    expect(result.items).toHaveLength(3);
    expect(result.items[0]!.id).toBe('newest');
    expect(result.items[1]!.id).toBe('middle');
    expect(result.items[2]!.id).toBe('old');
  });

  it('only returns sessions in the requested workspace (RBAC)', async () => {
    await seedSession({ id: 's1', workspaceId: WS_1 });
    await seedSession({ id: 's2', workspaceId: WS_2 });
    const result = await listSessions({ workspaceId: WS_1 });
    expect(result.items).toHaveLength(1);
    expect(result.items[0]!.id).toBe('s1');
  });

  it('filters by status', async () => {
    await seedSession({ id: 's1', workspaceId: WS_1, status: 'idle' });
    await seedSession({ id: 's2', workspaceId: WS_1, status: 'done' });
    await seedSession({ id: 's3', workspaceId: WS_1, status: 'idle' });
    const result = await listSessions({ workspaceId: WS_1, status: 'done' });
    expect(result.items).toHaveLength(1);
    expect(result.items[0]!.id).toBe('s2');
  });

  it('filters by pinned=true', async () => {
    await seedSession({ id: 's1', workspaceId: WS_1, pinned: false });
    await seedSession({ id: 's2', workspaceId: WS_1, pinned: true });
    await seedSession({ id: 's3', workspaceId: WS_1, pinned: true });
    const result = await listSessions({ workspaceId: WS_1, pinned: true });
    expect(result.items).toHaveLength(2);
    expect(result.items.map((s) => s.id)).toContain('s2');
    expect(result.items.map((s) => s.id)).toContain('s3');
  });

  it('filters by pinned=false', async () => {
    await seedSession({ id: 's1', workspaceId: WS_1, pinned: false });
    await seedSession({ id: 's2', workspaceId: WS_1, pinned: true });
    const result = await listSessions({ workspaceId: WS_1, pinned: false });
    expect(result.items).toHaveLength(1);
    expect(result.items[0]!.id).toBe('s1');
  });

  it('respects limit (default 20)', async () => {
    for (let i = 0; i < 25; i++) {
      await seedSession({
        id: `s${i}`,
        workspaceId: WS_1,
        createdAt: new Date(2025, 0, 1, 0, i),
      });
    }
    const result = await listSessions({ workspaceId: WS_1 });
    expect(result.items).toHaveLength(20);
    expect(result.nextCursor).not.toBeNull();
  });

  it('respects an explicit limit', async () => {
    for (let i = 0; i < 10; i++) {
      await seedSession({
        id: `s${i}`,
        workspaceId: WS_1,
        createdAt: new Date(2025, 0, 1, 0, i),
      });
    }
    const result = await listSessions({ workspaceId: WS_1, limit: 3 });
    expect(result.items).toHaveLength(3);
    expect(result.nextCursor).not.toBeNull();
  });

  it('caps limit at 100', async () => {
    for (let i = 0; i < 5; i++) {
      await seedSession({
        id: `s${i}`,
        workspaceId: WS_1,
        createdAt: new Date(2025, 0, 1, 0, i),
      });
    }
    const result = await listSessions({ workspaceId: WS_1, limit: 200 });
    // Only 5 items exist; the cap (100) doesn't matter
    expect(result.items).toHaveLength(5);
    expect(result.nextCursor).toBeNull();
  });

  it('returns nextCursor=null when there are no more items', async () => {
    await seedSession({ id: 's1', workspaceId: WS_1 });
    const result = await listSessions({ workspaceId: WS_1 });
    expect(result.items).toHaveLength(1);
    expect(result.nextCursor).toBeNull();
  });

  it('paginates correctly using the cursor', async () => {
    // Create 5 sessions with distinct createdAt
    for (let i = 0; i < 5; i++) {
      await seedSession({
        id: `s${i}`,
        workspaceId: WS_1,
        createdAt: new Date(2025, 0, 1, 0, i),
      });
    }

    // Page 1: limit=2
    const page1 = await listSessions({ workspaceId: WS_1, limit: 2 });
    expect(page1.items).toHaveLength(2);
    expect(page1.items[0]!.id).toBe('s4'); // newest first
    expect(page1.items[1]!.id).toBe('s3');
    expect(page1.nextCursor).not.toBeNull();

    // Page 2: use cursor from page 1
    const page2 = await listSessions({
      workspaceId: WS_1,
      limit: 2,
      cursor: page1.nextCursor!,
    });
    expect(page2.items).toHaveLength(2);
    expect(page2.items[0]!.id).toBe('s2');
    expect(page2.items[1]!.id).toBe('s1');
    expect(page2.nextCursor).not.toBeNull();

    // Page 3: use cursor from page 2 — should be empty
    const page3 = await listSessions({
      workspaceId: WS_1,
      limit: 2,
      cursor: page2.nextCursor!,
    });
    expect(page3.items).toHaveLength(1); // only s0 left
    expect(page3.items[0]!.id).toBe('s0');
    expect(page3.nextCursor).toBeNull();
  });

  it('returns empty array when no sessions exist', async () => {
    const result = await listSessions({ workspaceId: WS_1 });
    expect(result.items).toEqual([]);
    expect(result.nextCursor).toBeNull();
  });

  it('throws LIST_FAILED for an invalid cursor', async () => {
    await seedSession({ id: 's1', workspaceId: WS_1 });
    try {
      await listSessions({ workspaceId: WS_1, cursor: 'invalid-cursor!!!' });
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isSessionError(err)).toBe(true);
      if (isSessionError(err)) expect(err.code).toBe('LIST_FAILED');
    }
  });

  it('handles ties in createdAt deterministically (falls back to id DESC)', async () => {
    const sameTime = new Date('2025-01-01T00:00:00Z');
    await seedSession({ id: 'aaa', workspaceId: WS_1, createdAt: sameTime });
    await seedSession({ id: 'zzz', workspaceId: WS_1, createdAt: sameTime });
    await seedSession({ id: 'mmm', workspaceId: WS_1, createdAt: sameTime });

    const result = await listSessions({ workspaceId: WS_1 });
    expect(result.items).toHaveLength(3);
    // id DESC: zzz > mmm > aaa
    expect(result.items[0]!.id).toBe('zzz');
    expect(result.items[1]!.id).toBe('mmm');
    expect(result.items[2]!.id).toBe('aaa');
  });
});

// ─── pinSession ────────────────────────────────────────────────────────────

describe('pinSession', () => {
  beforeEach(() => {
    resetStore();
  });

  it('sets pinned=true', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, pinned: false });
    const record = await pinSession('sess-1', WS_1, true);
    expect(record.pinned).toBe(true);
  });

  it('sets pinned=false', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_1, pinned: true });
    const record = await pinSession('sess-1', WS_1, false);
    expect(record.pinned).toBe(false);
  });

  it('throws WORKSPACE_MISMATCH for cross-workspace access', async () => {
    await seedSession({ id: 'sess-1', workspaceId: WS_2 });
    try {
      await pinSession('sess-1', WS_1, true);
      expect.fail('Expected to throw');
    } catch (err) {
      if (isSessionError(err)) expect(err.code).toBe('WORKSPACE_MISMATCH');
    }
  });
});

// ─── SessionRecord type (compile-time check) ───────────────────────────────

describe('SessionRecord type (compile-time check)', () => {
  it('has all documented fields with correct types', () => {
    const record: SessionRecord = {
      id: 'sess-1',
      workspaceId: 'ws-1',
      title: 'Test',
      goal: null,
      status: 'idle',
      providerId: null,
      model: 'glm-4.6',
      agentId: null,
      skillIds: [],
      repoIds: [],
      mcpServerIds: [],
      pinned: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    expect(record.id).toBe('sess-1');
    expect(Array.isArray(record.skillIds)).toBe(true);
  });
});

// ─── SessionStatus union (compile-time check) ──────────────────────────────

describe('SessionStatus union', () => {
  it('includes all 6 documented statuses', () => {
    const statuses: SessionStatus[] = [
      'idle', 'planning', 'executing', 'verifying', 'done', 'error',
    ];
    expect(statuses).toHaveLength(6);
  });
});
