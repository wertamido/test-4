/**
 * Agent Identity Tests
 *
 * Blueprint v4.1 §4 (Mistake #7), §11, §22 Phase 1 Step 1.7
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  extractIdentityClaims,
  extractExpectedClaims,
  verifyAgentIdentity,
  type IdentityResult,
} from '@/lib/agents/identity';
import type { AgentTemplateRecord } from '@/lib/agents/runner';

vi.mock('@/lib/logger', () => ({
  logger: {
    trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
    child: vi.fn(() => ({
      trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
      child: vi.fn(), level: 'debug',
    })),
  },
}));

const runAgentMock = vi.fn();
vi.mock('@/lib/agents/runner', () => ({
  runAgent: runAgentMock,
}));

function makeAgent(overrides: Partial<AgentTemplateRecord> = {}): AgentTemplateRecord {
  return {
    id: 'agent.hermes',
    name: 'Hermes',
    description: 'Lead orchestrator',
    icon: 'Crown',
    category: 'orchestrator',
    systemPrompt: overrides.systemPrompt ??
      'You are Hermes, powered by Mistral Large from Mistral. Your underlying model is Mistral Large. When asked what model you are, state: "I am Mistral Large, operating as Hermes."',
    tools: [],
    mcpTools: [],
    preferredProvider: 'mistral',
    preferredModel: 'mistral-large-latest',
    temperature: 0.4,
    canSpawnAgents: true,
    maxSubAgents: 5,
    builtin: true,
    enabled: true,
    ...overrides,
  };
}

beforeEach(() => {
  runAgentMock.mockReset();
});

// ─── extractIdentityClaims ─────────────────────────────────────────────────

describe('extractIdentityClaims', () => {
  it('extracts model + agent from "I am <model>, operating as <agent>."', () => {
    const claims = extractIdentityClaims('I am Mistral Large, operating as Hermes.');
    expect(claims.claimedModel).toBe('Mistral Large');
    expect(claims.claimedAgent).toBe('Hermes');
  });

  it('extracts without trailing period', () => {
    const claims = extractIdentityClaims('I am GPT-4o, operating as Coder');
    expect(claims.claimedModel).toBe('GPT-4o');
    expect(claims.claimedAgent).toBe('Coder');
  });

  it('is case-insensitive on "I am"', () => {
    const claims = extractIdentityClaims('i am GLM-4-Plus, operating as Hermes.');
    expect(claims.claimedModel).toBe('GLM-4-Plus');
    expect(claims.claimedAgent).toBe('Hermes');
  });

  it('handles model names with hyphens + dots (gpt-4o-mini)', () => {
    const claims = extractIdentityClaims('I am gpt-4o-mini, operating as Researcher.');
    expect(claims.claimedModel).toBe('gpt-4o-mini');
    expect(claims.claimedAgent).toBe('Researcher');
  });

  it('falls back to model-only when no "operating as" clause', () => {
    const claims = extractIdentityClaims('I am GPT-4o.');
    expect(claims.claimedModel).toBe('GPT-4o');
    expect(claims.claimedAgent).toBe('');
  });

  it('falls back to whole response when no "I am" pattern', () => {
    const claims = extractIdentityClaims('This is Claude 3.5 Sonnet.');
    expect(claims.claimedModel).toBe('This is Claude 3.5 Sonnet');
    expect(claims.claimedAgent).toBe('');
  });

  it('trims whitespace', () => {
    const claims = extractIdentityClaims('  I am Mistral Large, operating as Hermes.  ');
    expect(claims.claimedModel).toBe('Mistral Large');
    expect(claims.claimedAgent).toBe('Hermes');
  });

  it('returns empty strings for empty input', () => {
    const claims = extractIdentityClaims('');
    expect(claims.claimedModel).toBe('');
    expect(claims.claimedAgent).toBe('');
  });
});

// ─── extractExpectedClaims ─────────────────────────────────────────────────

describe('extractExpectedClaims', () => {
  it('extracts expected model + agent from the system prompt identity clause', () => {
    const agent = makeAgent();
    const { expectedModel, expectedAgent } = extractExpectedClaims(agent);
    expect(expectedModel).toBe('Mistral Large');
    expect(expectedAgent).toBe('Hermes');
  });

  it('falls back to preferredModel + name when no identity clause', () => {
    const agent = makeAgent({
      systemPrompt: 'You are a generic agent with no identity clause.',
      preferredModel: 'gpt-4o',
      name: 'Generic',
    });
    const { expectedModel, expectedAgent } = extractExpectedClaims(agent);
    expect(expectedModel).toBe('gpt-4o');
    expect(expectedAgent).toBe('Generic');
  });

  it('handles agent prompts with single-quoted identity clause', () => {
    const agent = makeAgent({
      systemPrompt: `When asked, state: 'I am GPT-4o, operating as Coder.'`,
    });
    const { expectedModel, expectedAgent } = extractExpectedClaims(agent);
    expect(expectedModel).toBe('GPT-4o');
    expect(expectedAgent).toBe('Coder');
  });
});

// ─── verifyAgentIdentity ───────────────────────────────────────────────────

describe('verifyAgentIdentity', () => {
  it('returns matched=true when the agent correctly identifies itself', async () => {
    const agent = makeAgent();
    runAgentMock.mockResolvedValueOnce({
      content: 'I am Mistral Large, operating as Hermes.',
      toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'mistral-large-latest', providerId: 'mistral',
    });

    const result = await verifyAgentIdentity({
      agent,
      providerId: 'mistral',
      model: 'mistral-large-latest',
    });

    expect(result.matched).toBe(true);
    expect(result.matchedModel).toBe(true);
    expect(result.matchedAgent).toBe(true);
    expect(result.claimedModel).toBe('Mistral Large');
    expect(result.claimedAgent).toBe('Hermes');
  });

  it('returns matched=false when the model is wrong', async () => {
    const agent = makeAgent();
    runAgentMock.mockResolvedValueOnce({
      content: 'I am GPT-4o, operating as Hermes.',
      toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'gpt-4o', providerId: 'openai',
    });

    const result = await verifyAgentIdentity({
      agent,
      providerId: 'mistral',
      model: 'mistral-large-latest',
    });

    expect(result.matchedModel).toBe(false);
    expect(result.matchedAgent).toBe(true);
    expect(result.matched).toBe(false);
  });

  it('returns matched=false when the agent name is wrong', async () => {
    const agent = makeAgent();
    runAgentMock.mockResolvedValueOnce({
      content: 'I am Mistral Large, operating as Coder.',
      toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'mistral-large-latest', providerId: 'mistral',
    });

    const result = await verifyAgentIdentity({
      agent,
      providerId: 'mistral',
      model: 'mistral-large-latest',
    });

    expect(result.matchedModel).toBe(true);
    expect(result.matchedAgent).toBe(false);
    expect(result.matched).toBe(false);
  });

  it('is case-insensitive on matching', async () => {
    const agent = makeAgent();
    runAgentMock.mockResolvedValueOnce({
      content: 'I am mistral large, operating as hermes.',
      toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'mistral-large-latest', providerId: 'mistral',
    });

    const result = await verifyAgentIdentity({
      agent,
      providerId: 'mistral',
      model: 'mistral-large-latest',
    });

    expect(result.matched).toBe(true);
  });

  it('passes the identity prompt via runAgent', async () => {
    const agent = makeAgent();
    runAgentMock.mockResolvedValueOnce({
      content: 'I am Mistral Large, operating as Hermes.',
      toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'mistral-large-latest', providerId: 'mistral',
    });

    await verifyAgentIdentity({
      agent,
      providerId: 'mistral',
      model: 'mistral-large-latest',
    });

    expect(runAgentMock).toHaveBeenCalledTimes(1);
    const callParams = runAgentMock.mock.calls[0]![0];
    expect(callParams.agentTemplateId).toBe('agent.hermes');
    expect(callParams.providerId).toBe('mistral');
    expect(callParams.model).toBe('mistral-large-latest');
    expect(callParams.messages[0].content).toContain('What model are you?');
  });

  it('returns a fully-populated IdentityResult', async () => {
    const agent = makeAgent();
    runAgentMock.mockResolvedValueOnce({
      content: 'I am Mistral Large, operating as Hermes.',
      toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'mistral-large-latest', providerId: 'mistral',
    });

    const result = await verifyAgentIdentity({
      agent,
      providerId: 'mistral',
      model: 'mistral-large-latest',
    });

    expect(result.agentTemplateId).toBe('agent.hermes');
    expect(result.providerId).toBe('mistral');
    expect(result.model).toBe('mistral-large-latest');
    expect(result.agentName).toBe('Hermes');
    expect(result.expectedModel).toBe('Mistral Large');
    expect(result.expectedAgent).toBe('Hermes');
    expect(typeof result.durationMs).toBe('number');
  });
});

// ─── Type-level checks ─────────────────────────────────────────────────────

describe('type-level checks', () => {
  it('IdentityResult has all documented fields', () => {
    const result: IdentityResult = {
      agentTemplateId: 'a1',
      providerId: 'p1',
      model: 'm1',
      agentName: 'A',
      claimedModel: 'M',
      claimedAgent: 'A',
      expectedModel: 'M',
      expectedAgent: 'A',
      matchedModel: true,
      matchedAgent: true,
      matched: true,
      response: 'I am M, operating as A.',
      durationMs: 100,
    };
    expect(result.matched).toBe(true);
  });
});
