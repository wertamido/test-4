/**
 * Unit tests for src/lib/validation/schemas.ts
 *
 * Blueprint v4.1 §0.4 (Zod validation schemas), §23 (Testing Strategy)
 *
 * Coverage strategy:
 *  - ValidationError: construction, brand, type guard (positive + negative)
 *  - validate(): success returns parsed value, failure throws ValidationError
 *  - safeValidate(): discriminated union on success/failure
 *  - Every schema exported by schemas.ts: at least 1 accept + 1 reject
 *  - Boundary tests for every blueprint constraint:
 *      temperature 0..2         (test 0, 2.0, 2.1)
 *      maxAgents 1..20          (test 1, 20, 21, 0)
 *      maxDepth 0..3            (test 0, 3, 4)
 *      maxSubAgents 0..20       (test 0, 20, 21)
 *      strength 1|2|3           (test 1, 3, 4, 0)
 *      repoIds max 3            (test 0, 3, 4)
 *      pagination limit 1..100  (test 1, 100, 101, 0)
 *      olderThanMs 1..86400000  (test 1, 86400000, 86400001, 0)
 *  - Cross-cutting: empty strings, oversized inputs, wrong types, missing
 *    required fields
 *
 * No mocking required — these are pure schema tests.
 */

import { describe, it, expect } from 'vitest';
import {
  ValidationError,
  isValidationError,
  validate,
  safeValidate,
  // Schemas
  createSessionSchema,
  updateSessionSchema,
  listSessionsSchema,
  sendMessageSchema,
  createProviderSchema,
  updateProviderSchema,
  testProviderSchema,
  createSkillSchema,
  updateSkillSchema,
  strengthSchema,
  createAgentTemplateSchema,
  updateAgentTemplateSchema,
  createMcpServerSchema,
  testMcpServerSchema,
  updateMcpServerSchema,
  searchGithubSchema,
  importGithubSchema,
  pinGithubSchema,
  startOrchestrateSchema,
  getJobStatusSchema,
  recoverJobsSchema,
  startReasoningSchema,
  paginationSchema,
  updateWorkspaceSettingsSchema,
  exportProjectSchema,
  // Enums (spot-checked)
  sessionStatusSchema,
  reasoningModeSchema,
  mcpTransportSchema,
} from '@/lib/validation/schemas';

// ─── Helpers ───────────────────────────────────────────────────────────────

/** Assert that a schema accepts the input. Returns parsed data for further checks. */
function expectAccept<T>(schema: { safeParse: (input: unknown) => { success: true; data: T } | { success: false; error: unknown } }, input: unknown): T {
  const result = schema.safeParse(input);
  expect(result.success).toBe(true);
  if (!result.success) throw new Error('unreachable');
  return result.data;
}

/** Assert that a schema rejects the input. */
function expectReject(schema: { safeParse: (input: unknown) => { success: true } | { success: false; error: unknown } }, input: unknown): void {
  const result = schema.safeParse(input);
  expect(result.success).toBe(false);
}

// ─── ValidationError + isValidationError ───────────────────────────────────

describe('ValidationError', () => {
  it('preserves code, message, cause, and issues', () => {
    const issues = [{ path: 'email', message: 'invalid', code: 'invalid_input' }];
    const err = new ValidationError('VALIDATION_FAILED', 'bad input', undefined, issues);
    expect(err.code).toBe('VALIDATION_FAILED');
    expect(err.message).toBe('bad input');
    expect(err.issues).toBe(issues);
    expect(err.name).toBe('ValidationError');
  });

  it('defaults issues to empty array when not provided', () => {
    const err = new ValidationError('SCHEMA_MISSING', 'no schema');
    expect(err.issues).toEqual([]);
    expect(err.cause).toBeUndefined();
  });

  it('is an instance of Error', () => {
    const err = new ValidationError('VALIDATION_FAILED', 'x');
    expect(err).toBeInstanceOf(Error);
  });

  it('survives instanceof after subclassing Error (prototype chain restored)', () => {
    const err = new ValidationError('VALIDATION_FAILED', 'x');
    expect(err).toBeInstanceOf(ValidationError);
    try {
      throw err;
    } catch (caught) {
      expect(caught).toBeInstanceOf(ValidationError);
    }
  });

  it('exposes every ValidationErrorCode value', () => {
    const codes: ReadonlyArray<ValidationError['code']> = [
      'VALIDATION_FAILED',
      'SCHEMA_MISSING',
    ];
    for (const code of codes) {
      const err = new ValidationError(code, `message for ${code}`);
      expect(err.code).toBe(code);
    }
  });
});

describe('isValidationError', () => {
  it('returns false for primitives', () => {
    expect(isValidationError(0)).toBe(false);
    expect(isValidationError('')).toBe(false);
    expect(isValidationError(false)).toBe(false);
    expect(isValidationError(null)).toBe(false);
    expect(isValidationError(undefined)).toBe(false);
  });

  it('returns false for plain objects lacking the brand symbol', () => {
    expect(isValidationError({ code: 'VALIDATION_FAILED', message: 'fake' })).toBe(false);
    expect(isValidationError(new Error('plain'))).toBe(false);
    expect(isValidationError({})).toBe(false);
  });

  it('returns true for ValidationError instances', () => {
    const err = new ValidationError('VALIDATION_FAILED', 'real');
    expect(isValidationError(err)).toBe(true);
  });

  it('does not confuse ValidationError with DbError or AuthError (different brand symbol)', () => {
    // Simulate a DbError-shaped object: same fields, but no ValidationError brand.
    const fakeDbError = Object.assign(new Error('db failed'), {
      code: 'QUERY_FAILED',
      cause: undefined,
    });
    expect(isValidationError(fakeDbError)).toBe(false);
  });
});

// ─── validate() helper ─────────────────────────────────────────────────────

describe('validate()', () => {
  it('returns the parsed value on success', () => {
    const data = validate(createSessionSchema, { title: 'My Session' });
    expect(data).toEqual({ title: 'My Session' });
  });

  it('applies defaults from the schema on success', () => {
    const data = validate(paginationSchema, {});
    expect(data).toEqual({ limit: 20 });
  });

  it('throws ValidationError(code=VALIDATION_FAILED) on failure', () => {
    try {
      validate(createSessionSchema, { title: '' });
      expect.fail('Expected validate to throw');
    } catch (err) {
      expect(isValidationError(err)).toBe(true);
      if (isValidationError(err)) {
        expect(err.code).toBe('VALIDATION_FAILED');
        expect(err.issues.length).toBeGreaterThan(0);
      }
    }
  });

  it('attaches the Zod error as cause', () => {
    try {
      validate(createSessionSchema, null);
      expect.fail('Expected validate to throw');
    } catch (err) {
      expect(isValidationError(err)).toBe(true);
      if (isValidationError(err)) {
        expect(err.cause).toBeDefined();
      }
    }
  });

  it('throws on null input', () => {
    expect(() => validate(createSessionSchema, null)).toThrow(ValidationError);
  });

  it('throws on undefined input', () => {
    expect(() => validate(createSessionSchema, undefined)).toThrow(ValidationError);
  });

  it('throws on wrong type', () => {
    expect(() => validate(createSessionSchema, 'not-an-object')).toThrow(ValidationError);
  });
});

// ─── safeValidate() helper ─────────────────────────────────────────────────

describe('safeValidate()', () => {
  it('returns { success: true, data } on success', () => {
    const result = safeValidate(createSessionSchema, { title: 'X' });
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data).toEqual({ title: 'X' });
    }
  });

  it('returns { success: false, error: ValidationError } on failure', () => {
    const result = safeValidate(createSessionSchema, { title: '' });
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(isValidationError(result.error)).toBe(true);
      expect(result.error.code).toBe('VALIDATION_FAILED');
    }
  });
});

// ─── Session ───────────────────────────────────────────────────────────────

describe('createSessionSchema', () => {
  it('accepts a title with optional goal', () => {
    expectAccept(createSessionSchema, { title: 'My Session', goal: 'Build X' });
    expectAccept(createSessionSchema, { title: 'Just a title' });
  });

  it('rejects an empty title', () => {
    expectReject(createSessionSchema, { title: '' });
  });

  it('rejects a missing title', () => {
    expectReject(createSessionSchema, { goal: 'no title' });
  });

  it('rejects an oversized title (>200 chars)', () => {
    expectReject(createSessionSchema, { title: 'a'.repeat(201) });
  });

  it('rejects an oversized goal (>10000 chars)', () => {
    expectReject(createSessionSchema, { title: 'ok', goal: 'a'.repeat(10001) });
  });
});

describe('updateSessionSchema', () => {
  it('accepts a partial update with at least one field', () => {
    expectAccept(updateSessionSchema, { title: 'New' });
    expectAccept(updateSessionSchema, { pinned: true });
    expectAccept(updateSessionSchema, { status: 'done' });
  });

  it('rejects an empty object (refine: at least one field)', () => {
    expectReject(updateSessionSchema, {});
  });

  it('rejects an invalid status value', () => {
    expectReject(updateSessionSchema, { status: 'bogus' });
  });

  it('rejects an empty title when provided', () => {
    expectReject(updateSessionSchema, { title: '' });
  });
});

describe('listSessionsSchema', () => {
  it('accepts workspaceId with optional cursor and applies default limit', () => {
    const data = expectAccept(listSessionsSchema, { workspaceId: 'ws-1' });
    expect(data.limit).toBe(20);
  });

  it('accepts an explicit limit within 1..100', () => {
    expectAccept(listSessionsSchema, { workspaceId: 'ws-1', limit: 50 });
  });

  it('rejects a missing workspaceId', () => {
    expectReject(listSessionsSchema, { limit: 10 });
  });

  it('rejects a limit of 0', () => {
    expectReject(listSessionsSchema, { workspaceId: 'ws-1', limit: 0 });
  });

  it('rejects a limit > 100', () => {
    expectReject(listSessionsSchema, { workspaceId: 'ws-1', limit: 101 });
  });

  it('rejects a non-integer limit', () => {
    expectReject(listSessionsSchema, { workspaceId: 'ws-1', limit: 1.5 });
  });
});

// ─── Message ───────────────────────────────────────────────────────────────

describe('sendMessageSchema', () => {
  it('accepts sessionId + content, defaults role to user', () => {
    const data = expectAccept(sendMessageSchema, {
      sessionId: 's1',
      content: 'Hello',
    });
    expect(data.role).toBe('user');
  });

  it('accepts optional skillIds, repoIds (≤3), mcpServerIds', () => {
    expectAccept(sendMessageSchema, {
      sessionId: 's1',
      content: 'Hi',
      skillIds: ['sk1', 'sk2'],
      repoIds: ['r1', 'r2', 'r3'],
      mcpServerIds: ['m1'],
    });
  });

  it('rejects an empty content', () => {
    expectReject(sendMessageSchema, { sessionId: 's1', content: '' });
  });

  it('rejects content > 32000 chars', () => {
    expectReject(sendMessageSchema, { sessionId: 's1', content: 'a'.repeat(32001) });
  });

  it('rejects repoIds with more than 3 entries (§14 boundary)', () => {
    expectReject(sendMessageSchema, {
      sessionId: 's1',
      content: 'Hi',
      repoIds: ['r1', 'r2', 'r3', 'r4'],
    });
  });

  it('rejects role="assistant" (clients can only send user messages)', () => {
    expectReject(sendMessageSchema, {
      sessionId: 's1',
      content: 'Hi',
      role: 'assistant',
    });
  });

  it('accepts exactly 3 repoIds (§14 boundary)', () => {
    expectAccept(sendMessageSchema, {
      sessionId: 's1',
      content: 'Hi',
      repoIds: ['r1', 'r2', 'r3'],
    });
  });
});

// ─── Provider ──────────────────────────────────────────────────────────────

describe('createProviderSchema', () => {
  it('accepts a valid OpenAI-style provider', () => {
    expectAccept(createProviderSchema, {
      id: 'openai',
      name: 'OpenAI',
      kind: 'openai',
      baseUrl: 'https://api.openai.com/v1/chat/completions',
      apiKey: 'sk-xxx',
      models: ['gpt-4o', 'gpt-4o-mini'],
      enabled: true,
      isLocal: false,
    });
  });

  it('accepts a Z.ai provider without baseUrl', () => {
    expectAccept(createProviderSchema, {
      id: 'zai',
      name: 'Z.ai',
      kind: 'zai',
      enabled: true,
      isLocal: false,
    });
  });

  it('rejects an invalid kind', () => {
    expectReject(createProviderSchema, {
      id: 'x',
      name: 'X',
      kind: 'bogus',
      enabled: true,
      isLocal: false,
    });
  });

  it('rejects an invalid baseUrl', () => {
    expectReject(createProviderSchema, {
      id: 'x',
      name: 'X',
      kind: 'openai',
      baseUrl: 'not-a-url',
      enabled: true,
      isLocal: false,
    });
  });

  it('rejects a missing required field (enabled)', () => {
    expectReject(createProviderSchema, {
      id: 'x',
      name: 'X',
      kind: 'openai',
      isLocal: false,
    });
  });
});

describe('updateProviderSchema', () => {
  it('accepts a partial update with at least one field', () => {
    expectAccept(updateProviderSchema, { enabled: false });
    expectAccept(updateProviderSchema, { apiKey: 'new-key' });
  });

  it('rejects an empty object', () => {
    expectReject(updateProviderSchema, {});
  });
});

describe('testProviderSchema', () => {
  it('accepts an id', () => {
    expectAccept(testProviderSchema, { id: 'openai' });
  });

  it('rejects a missing id', () => {
    expectReject(testProviderSchema, {});
  });

  it('rejects an empty id', () => {
    expectReject(testProviderSchema, { id: '' });
  });
});

// ─── Skill ─────────────────────────────────────────────────────────────────

describe('strengthSchema', () => {
  it('accepts 1, 2, 3 (§12)', () => {
    expect(strengthSchema.safeParse(1).success).toBe(true);
    expect(strengthSchema.safeParse(2).success).toBe(true);
    expect(strengthSchema.safeParse(3).success).toBe(true);
  });

  it('rejects 0 (§12 boundary)', () => {
    expect(strengthSchema.safeParse(0).success).toBe(false);
  });

  it('rejects 4 (§12 boundary)', () => {
    expect(strengthSchema.safeParse(4).success).toBe(false);
  });

  it('rejects non-integer values', () => {
    expect(strengthSchema.safeParse(1.5).success).toBe(false);
    expect(strengthSchema.safeParse('1').success).toBe(false);
  });
});

describe('createSkillSchema', () => {
  it('accepts a valid skill with strength=3', () => {
    expectAccept(createSkillSchema, {
      id: 'code-reviewer',
      name: 'Code Reviewer',
      description: 'Reviews code',
      systemPrompt: 'You are a code reviewer.',
      category: 'Coding',
      strength: 3,
    });
  });

  it('rejects strength=4 (§12 boundary)', () => {
    expectReject(createSkillSchema, {
      id: 'x',
      name: 'X',
      description: 'd',
      systemPrompt: 'p',
      category: 'General',
      strength: 4,
    });
  });

  it('rejects an empty systemPrompt', () => {
    expectReject(createSkillSchema, {
      id: 'x',
      name: 'X',
      description: 'd',
      systemPrompt: '',
      category: 'General',
      strength: 1,
    });
  });
});

describe('updateSkillSchema', () => {
  it('accepts enabled and/or strength', () => {
    expectAccept(updateSkillSchema, { enabled: true });
    expectAccept(updateSkillSchema, { strength: 2 });
    expectAccept(updateSkillSchema, { enabled: false, strength: 1 });
  });

  it('rejects an empty object', () => {
    expectReject(updateSkillSchema, {});
  });

  it('rejects strength=4', () => {
    expectReject(updateSkillSchema, { strength: 4 });
  });
});

// ─── AgentTemplate ─────────────────────────────────────────────────────────

describe('createAgentTemplateSchema', () => {
  const validBase = {
    name: 'Hermes',
    description: 'Lead orchestrator',
    systemPrompt: 'You are Hermes.',
    category: 'orchestrator',
    temperature: 0.7,
    canSpawnAgents: true,
    maxSubAgents: 5,
  };

  it('accepts a valid orchestrator template', () => {
    expectAccept(createAgentTemplateSchema, validBase);
  });

  it('accepts temperature at the lower boundary (0)', () => {
    expectAccept(createAgentTemplateSchema, { ...validBase, temperature: 0 });
  });

  it('accepts temperature at the upper boundary (2.0) (§11)', () => {
    expectAccept(createAgentTemplateSchema, { ...validBase, temperature: 2.0 });
  });

  it('rejects temperature > 2.0 (§11 boundary)', () => {
    expectReject(createAgentTemplateSchema, { ...validBase, temperature: 2.1 });
  });

  it('rejects temperature < 0', () => {
    expectReject(createAgentTemplateSchema, { ...validBase, temperature: -0.1 });
  });

  it('accepts maxSubAgents at the upper boundary (20) (§10)', () => {
    expectAccept(createAgentTemplateSchema, { ...validBase, maxSubAgents: 20 });
  });

  it('rejects maxSubAgents > 20 (§10 boundary)', () => {
    expectReject(createAgentTemplateSchema, { ...validBase, maxSubAgents: 21 });
  });

  it('accepts maxSubAgents at the lower boundary (0)', () => {
    expectAccept(createAgentTemplateSchema, { ...validBase, maxSubAgents: 0 });
  });

  it('rejects a non-integer maxSubAgents', () => {
    expectReject(createAgentTemplateSchema, { ...validBase, maxSubAgents: 1.5 });
  });

  it('rejects an invalid category', () => {
    expectReject(createAgentTemplateSchema, { ...validBase, category: 'bogus' });
  });
});

describe('updateAgentTemplateSchema', () => {
  it('accepts a partial update', () => {
    expectAccept(updateAgentTemplateSchema, { enabled: false });
    expectAccept(updateAgentTemplateSchema, { temperature: 1.5 });
    expectAccept(updateAgentTemplateSchema, { maxSubAgents: 10 });
  });

  it('rejects an empty object', () => {
    expectReject(updateAgentTemplateSchema, {});
  });

  it('rejects temperature > 2 (§11 boundary)', () => {
    expectReject(updateAgentTemplateSchema, { temperature: 2.5 });
  });

  it('rejects maxSubAgents > 20 (§10 boundary)', () => {
    expectReject(updateAgentTemplateSchema, { maxSubAgents: 21 });
  });
});

// ─── McpServer ─────────────────────────────────────────────────────────────

describe('createMcpServerSchema', () => {
  it('accepts a stdio server with command', () => {
    expectAccept(createMcpServerSchema, {
      name: 'filesystem',
      transport: 'stdio',
      command: 'npx',
      args: ['@modelcontextprotocol/server-filesystem'],
    });
  });

  it('accepts an sse server with url', () => {
    expectAccept(createMcpServerSchema, {
      name: 'remote',
      transport: 'sse',
      url: 'https://example.com/mcp',
    });
  });

  it('rejects a stdio server without command (refine)', () => {
    expectReject(createMcpServerSchema, {
      name: 'broken',
      transport: 'stdio',
    });
  });

  it('rejects an sse server without url (refine)', () => {
    expectReject(createMcpServerSchema, {
      name: 'broken',
      transport: 'sse',
    });
  });

  it('rejects an invalid transport', () => {
    expectReject(createMcpServerSchema, {
      name: 'x',
      transport: 'websocket',
    });
  });

  it('accepts env as a string→string record', () => {
    expectAccept(createMcpServerSchema, {
      name: 'fs',
      transport: 'stdio',
      command: 'npx',
      env: { NODE_PATH: '/usr/lib/node_modules' },
    });
  });

  it('rejects env with non-string values', () => {
    expectReject(createMcpServerSchema, {
      name: 'fs',
      transport: 'stdio',
      command: 'npx',
      env: { PORT: 3000 },
    });
  });
});

describe('testMcpServerSchema', () => {
  it('accepts an id', () => {
    expectAccept(testMcpServerSchema, { id: 'mcp-1' });
  });

  it('rejects a missing id', () => {
    expectReject(testMcpServerSchema, {});
  });
});

describe('updateMcpServerSchema', () => {
  it('accepts enabled and/or toolsCache', () => {
    expectAccept(updateMcpServerSchema, { enabled: true });
    expectAccept(updateMcpServerSchema, { toolsCache: ['read_file', 'write_file'] });
  });

  it('rejects an empty object', () => {
    expectReject(updateMcpServerSchema, {});
  });
});

// ─── GithubRepo ────────────────────────────────────────────────────────────

describe('searchGithubSchema', () => {
  it('accepts a query', () => {
    expectAccept(searchGithubSchema, { query: 'next.js' });
  });

  it('accepts query + language + sort', () => {
    expectAccept(searchGithubSchema, {
      query: 'next.js',
      language: 'TypeScript',
      sort: 'stars',
    });
  });

  it('rejects an empty query', () => {
    expectReject(searchGithubSchema, { query: '' });
  });

  it('rejects an invalid sort', () => {
    expectReject(searchGithubSchema, { query: 'x', sort: 'relevance' });
  });
});

describe('importGithubSchema', () => {
  it('accepts fullName + url + owner', () => {
    expectAccept(importGithubSchema, {
      fullName: 'vercel/next.js',
      url: 'https://github.com/vercel/next.js',
      owner: 'vercel',
    });
  });

  it('rejects an invalid url', () => {
    expectReject(importGithubSchema, {
      fullName: 'vercel/next.js',
      url: 'not-a-url',
      owner: 'vercel',
    });
  });

  it('rejects a missing owner', () => {
    expectReject(importGithubSchema, {
      fullName: 'vercel/next.js',
      url: 'https://github.com/vercel/next.js',
    });
  });
});

describe('pinGithubSchema', () => {
  it('accepts an empty array (unpin all)', () => {
    expectAccept(pinGithubSchema, { repoIds: [] });
  });

  it('accepts exactly 3 repoIds (§14 boundary)', () => {
    expectAccept(pinGithubSchema, { repoIds: ['r1', 'r2', 'r3'] });
  });

  it('rejects 4 repoIds (§14 boundary)', () => {
    expectReject(pinGithubSchema, { repoIds: ['r1', 'r2', 'r3', 'r4'] });
  });
});

// ─── Orchestrate ───────────────────────────────────────────────────────────

describe('startOrchestrateSchema', () => {
  const validBase = {
    sessionId: 's1',
    goal: 'Build a todo app',
    leadAgentId: 'hermes',
    providerId: 'mistral',
    model: 'mistral-large-latest',
    maxDepth: 3,
    maxAgents: 20,
    mode: 'auto' as const,
  };

  it('accepts a valid orchestration request', () => {
    expectAccept(startOrchestrateSchema, validBase);
  });

  it('accepts maxDepth at the lower boundary (0)', () => {
    expectAccept(startOrchestrateSchema, { ...validBase, maxDepth: 0 });
  });

  it('accepts maxDepth at the upper boundary (3) (§10)', () => {
    expectAccept(startOrchestrateSchema, { ...validBase, maxDepth: 3 });
  });

  it('rejects maxDepth > 3 (§10 boundary)', () => {
    expectReject(startOrchestrateSchema, { ...validBase, maxDepth: 4 });
  });

  it('accepts maxAgents at the lower boundary (1)', () => {
    expectAccept(startOrchestrateSchema, { ...validBase, maxAgents: 1 });
  });

  it('accepts maxAgents at the upper boundary (20) (§10)', () => {
    expectAccept(startOrchestrateSchema, { ...validBase, maxAgents: 20 });
  });

  it('rejects maxAgents > 20 (§10 boundary)', () => {
    expectReject(startOrchestrateSchema, { ...validBase, maxAgents: 21 });
  });

  it('rejects maxAgents = 0 (must be ≥1)', () => {
    expectReject(startOrchestrateSchema, { ...validBase, maxAgents: 0 });
  });

  it('rejects an invalid mode', () => {
    expectReject(startOrchestrateSchema, { ...validBase, mode: 'bogus' });
  });

  it('rejects a missing goal', () => {
    expectReject(startOrchestrateSchema, { ...validBase, goal: undefined });
  });
});

// ─── Job ───────────────────────────────────────────────────────────────────

describe('getJobStatusSchema', () => {
  it('accepts an id', () => {
    expectAccept(getJobStatusSchema, { id: 'job-1' });
  });

  it('rejects a missing id', () => {
    expectReject(getJobStatusSchema, {});
  });

  it('rejects an empty id', () => {
    expectReject(getJobStatusSchema, { id: '' });
  });
});

describe('recoverJobsSchema', () => {
  it('accepts a positive olderThanMs', () => {
    expectAccept(recoverJobsSchema, { olderThanMs: 5 * 60 * 1000 }); // 5 min
  });

  it('accepts the upper boundary (24h) (§17)', () => {
    expectAccept(recoverJobsSchema, { olderThanMs: 24 * 60 * 60 * 1000 });
  });

  it('rejects olderThanMs = 0', () => {
    expectReject(recoverJobsSchema, { olderThanMs: 0 });
  });

  it('rejects olderThanMs > 24h (§17 boundary)', () => {
    expectReject(recoverJobsSchema, { olderThanMs: 24 * 60 * 60 * 1000 + 1 });
  });

  it('rejects a non-integer olderThanMs', () => {
    expectReject(recoverJobsSchema, { olderThanMs: 1.5 });
  });

  it('rejects a negative olderThanMs', () => {
    expectReject(recoverJobsSchema, { olderThanMs: -100 });
  });
});

// ─── Reasoning ─────────────────────────────────────────────────────────────

describe('startReasoningSchema', () => {
  it('accepts a valid reasoning request', () => {
    expectAccept(startReasoningSchema, {
      sessionId: 's1',
      goal: 'Analyze this',
      mode: 'deep',
    });
  });

  it('accepts all 5 modes', () => {
    for (const mode of ['instant', 'standard', 'reasoning', 'deep', 'autonomous'] as const) {
      expectAccept(startReasoningSchema, {
        sessionId: 's1',
        goal: 'g',
        mode,
      });
    }
  });

  it('rejects an invalid mode', () => {
    expectReject(startReasoningSchema, {
      sessionId: 's1',
      goal: 'g',
      mode: 'bogus',
    });
  });

  it('rejects an empty goal', () => {
    expectReject(startReasoningSchema, {
      sessionId: 's1',
      goal: '',
      mode: 'standard',
    });
  });
});

// ─── Pagination ────────────────────────────────────────────────────────────

describe('paginationSchema', () => {
  it('applies default limit=20 when omitted', () => {
    const data = expectAccept(paginationSchema, {});
    expect(data.limit).toBe(20);
  });

  it('accepts limit at the lower boundary (1)', () => {
    expectAccept(paginationSchema, { limit: 1 });
  });

  it('accepts limit at the upper boundary (100)', () => {
    expectAccept(paginationSchema, { limit: 100 });
  });

  it('rejects limit > 100 (§22 boundary)', () => {
    expectReject(paginationSchema, { limit: 101 });
  });

  it('rejects limit = 0', () => {
    expectReject(paginationSchema, { limit: 0 });
  });

  it('rejects a non-integer limit', () => {
    expectReject(paginationSchema, { limit: 1.5 });
  });

  it('accepts an optional cursor', () => {
    expectAccept(paginationSchema, { cursor: 'abc123', limit: 50 });
  });
});

// ─── Workspace settings ────────────────────────────────────────────────────

describe('updateWorkspaceSettingsSchema', () => {
  it('accepts a valid JSON string', () => {
    expectAccept(updateWorkspaceSettingsSchema, {
      settings: '{"theme":"dark","density":"compact"}',
    });
  });

  it('accepts an empty JSON object', () => {
    expectAccept(updateWorkspaceSettingsSchema, { settings: '{}' });
  });

  it('rejects a non-JSON string (refine)', () => {
    expectReject(updateWorkspaceSettingsSchema, { settings: 'not-json' });
  });

  it('rejects a JSON string that is just a number', () => {
    expectReject(updateWorkspaceSettingsSchema, { settings: '123' });
  });

  it('rejects an empty string', () => {
    expectReject(updateWorkspaceSettingsSchema, { settings: '' });
  });
});

// ─── Export ────────────────────────────────────────────────────────────────

describe('exportProjectSchema', () => {
  it('accepts zip format', () => {
    expectAccept(exportProjectSchema, { sessionId: 's1', format: 'zip' });
  });

  it('accepts tar format', () => {
    expectAccept(exportProjectSchema, { sessionId: 's1', format: 'tar' });
  });

  it('rejects an invalid format', () => {
    expectReject(exportProjectSchema, { sessionId: 's1', format: 'rar' });
  });

  it('rejects a missing sessionId', () => {
    expectReject(exportProjectSchema, { format: 'zip' });
  });
});

// ─── Enums (spot-checks) ───────────────────────────────────────────────────

describe('enums', () => {
  it('sessionStatusSchema accepts all 6 values', () => {
    for (const s of ['idle', 'planning', 'executing', 'verifying', 'done', 'error']) {
      expect(sessionStatusSchema.safeParse(s).success).toBe(true);
    }
    expect(sessionStatusSchema.safeParse('bogus').success).toBe(false);
  });

  it('reasoningModeSchema accepts all 5 values', () => {
    for (const m of ['instant', 'standard', 'reasoning', 'deep', 'autonomous']) {
      expect(reasoningModeSchema.safeParse(m).success).toBe(true);
    }
    expect(reasoningModeSchema.safeParse('bogus').success).toBe(false);
  });

  it('mcpTransportSchema accepts stdio + sse', () => {
    expect(mcpTransportSchema.safeParse('stdio').success).toBe(true);
    expect(mcpTransportSchema.safeParse('sse').success).toBe(true);
    expect(mcpTransportSchema.safeParse('websocket').success).toBe(false);
  });
});

// ─── Cross-cutting: wrong types ────────────────────────────────────────────

describe('cross-cutting: wrong input types', () => {
  it('rejects null for object schemas', () => {
    expectReject(createSessionSchema, null);
    expectReject(sendMessageSchema, null);
    expectReject(startOrchestrateSchema, null);
  });

  it('rejects undefined for object schemas', () => {
    expectReject(createSessionSchema, undefined);
    expectReject(sendMessageSchema, undefined);
  });

  it('rejects arrays for object schemas', () => {
    expectReject(createSessionSchema, []);
    expectReject(sendMessageSchema, []);
  });

  it('rejects primitives for object schemas', () => {
    expectReject(createSessionSchema, 'not-an-object');
    expectReject(createSessionSchema, 42);
    expectReject(createSessionSchema, true);
  });
});
