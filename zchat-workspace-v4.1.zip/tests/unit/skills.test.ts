/**
 * Skills System — Tests
 *
 * Blueprint v4.1 §12 (Skills System), §22 Phase 1 Step 1.5
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  SkillError,
  isSkillError,
  getSkill,
  getAllSkills,
  getEnabledSkills,
  getSkillsByCategory,
  assembleSkillsPrompt,
  refreshSkillCatalog,
  _setCatalogForTests,
  _resetCatalogForTests,
  type SkillRecord,
} from '@/lib/skills/registry';

vi.mock('@/lib/db', () => ({
  db: {
    skill: {
      findMany: vi.fn(),
    },
  },
}));

vi.mock('@/lib/logger', () => ({
  logger: {
    trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
    child: vi.fn(() => ({
      trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
      child: vi.fn(), level: 'debug',
    })),
  },
}));

import { db } from '@/lib/db';

// ─── Helpers ───────────────────────────────────────────────────────────────

function makeSkill(overrides: Partial<SkillRecord> = {}): SkillRecord {
  return {
    id: overrides.id ?? 'general.agent-mode',
    name: overrides.name ?? 'Agent Mode',
    description: overrides.description ?? 'Never ask. Always act.',
    icon: overrides.icon ?? 'Bot',
    category: overrides.category ?? 'General',
    systemPrompt: overrides.systemPrompt ?? 'You operate in Agent Mode...',
    strength: overrides.strength ?? 3,
    enabled: overrides.enabled ?? true,
    builtin: overrides.builtin ?? true,
  };
}

function setCatalog(skills: SkillRecord[]): void {
  _setCatalogForTests(skills);
}

beforeEach(() => {
  _resetCatalogForTests();
  (db.skill.findMany as ReturnType<typeof vi.fn>).mockReset();
});

// ─── SkillError + isSkillError ─────────────────────────────────────────────

describe('SkillError', () => {
  it('preserves code, message, cause, skillId', () => {
    const cause = new Error('root');
    const err = new SkillError('SKILL_NOT_FOUND', 'missing', cause, 'skill-1');
    expect(err.code).toBe('SKILL_NOT_FOUND');
    expect(err.message).toBe('missing');
    expect(err.cause).toBe(cause);
    expect(err.skillId).toBe('skill-1');
    expect(err.name).toBe('SkillError');
  });

  it('is an instance of Error', () => {
    expect(new SkillError('LOAD_FAILED', 'x')).toBeInstanceOf(Error);
  });

  it('exposes every SkillErrorCode', () => {
    const codes: ReadonlyArray<SkillError['code']> = ['SKILL_NOT_FOUND', 'LOAD_FAILED', 'ASSEMBLE_FAILED'];
    for (const code of codes) {
      expect(new SkillError(code, `msg for ${code}`).code).toBe(code);
    }
  });
});

describe('isSkillError', () => {
  it('returns false for primitives + plain objects', () => {
    expect(isSkillError(0)).toBe(false);
    expect(isSkillError(null)).toBe(false);
    expect(isSkillError({})).toBe(false);
  });

  it('returns true for SkillError instances', () => {
    expect(isSkillError(new SkillError('SKILL_NOT_FOUND', 'x'))).toBe(true);
  });
});

// ─── refreshSkillCatalog ───────────────────────────────────────────────────

describe('refreshSkillCatalog', () => {
  it('loads skills from the DB into the catalog', async () => {
    const dbSkills = [
      { id: 's1', name: 'A', description: 'd', icon: 'Bot', category: 'General', systemPrompt: 'p', strength: 1, enabled: true, builtin: true },
      { id: 's2', name: 'B', description: 'd', icon: 'Bot', category: 'Coding', systemPrompt: 'p', strength: 2, enabled: false, builtin: true },
    ];
    (db.skill.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce(dbSkills);

    await refreshSkillCatalog();

    const all = await getAllSkills();
    expect(all).toHaveLength(2);
    expect(all.map((s) => s.id)).toContain('s1');
    expect(all.map((s) => s.id)).toContain('s2');
  });

  it('throws LOAD_FAILED when the DB query fails', async () => {
    (db.skill.findMany as ReturnType<typeof vi.fn>).mockRejectedValueOnce(new Error('DB down'));
    try {
      await refreshSkillCatalog();
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isSkillError(err)).toBe(true);
      if (isSkillError(err)) expect(err.code).toBe('LOAD_FAILED');
    }
  });
});

// ─── getSkill ──────────────────────────────────────────────────────────────

describe('getSkill', () => {
  it('returns the skill when it exists in the catalog', async () => {
    setCatalog([makeSkill({ id: 's1', name: 'My Skill' })]);
    const skill = await getSkill('s1');
    expect(skill.name).toBe('My Skill');
  });

  it('throws SKILL_NOT_FOUND when the skill does not exist', async () => {
    setCatalog([]);
    try {
      await getSkill('nonexistent');
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isSkillError(err)).toBe(true);
      if (isSkillError(err)) expect(err.code).toBe('SKILL_NOT_FOUND');
    }
  });
});

// ─── getEnabledSkills ──────────────────────────────────────────────────────

describe('getEnabledSkills', () => {
  it('returns only enabled skills', async () => {
    setCatalog([
      makeSkill({ id: 's1', enabled: true }),
      makeSkill({ id: 's2', enabled: false }),
      makeSkill({ id: 's3', enabled: true }),
    ]);
    const enabled = await getEnabledSkills();
    expect(enabled).toHaveLength(2);
    expect(enabled.map((s) => s.id)).toContain('s1');
    expect(enabled.map((s) => s.id)).toContain('s3');
  });
});

// ─── getSkillsByCategory ───────────────────────────────────────────────────

describe('getSkillsByCategory', () => {
  it('returns only skills in the specified category', async () => {
    setCatalog([
      makeSkill({ id: 's1', category: 'General' }),
      makeSkill({ id: 's2', category: 'Coding' }),
      makeSkill({ id: 's3', category: 'General' }),
    ]);
    const general = await getSkillsByCategory('General');
    expect(general).toHaveLength(2);
    expect(general.map((s) => s.id)).toContain('s1');
    expect(general.map((s) => s.id)).toContain('s3');
  });
});

// ─── assembleSkillsPrompt ──────────────────────────────────────────────────

describe('assembleSkillsPrompt', () => {
  it('returns empty string for empty skillIds', async () => {
    const result = await assembleSkillsPrompt([]);
    expect(result).toBe('');
  });

  it('assembles skills in strength ASCENDING order (Light → Medium → Strict)', async () => {
    setCatalog([
      makeSkill({ id: 'strict', name: 'Strict Skill', strength: 3, systemPrompt: 'STRICT PROMPT' }),
      makeSkill({ id: 'light', name: 'Light Skill', strength: 1, systemPrompt: 'LIGHT PROMPT' }),
      makeSkill({ id: 'medium', name: 'Medium Skill', strength: 2, systemPrompt: 'MEDIUM PROMPT' }),
    ]);
    const result = await assembleSkillsPrompt(['strict', 'light', 'medium']);
    // Light (1) should come before Medium (2) before Strict (3)
    const lightIdx = result.indexOf('LIGHT PROMPT');
    const mediumIdx = result.indexOf('MEDIUM PROMPT');
    const strictIdx = result.indexOf('STRICT PROMPT');
    expect(lightIdx).toBeLessThan(mediumIdx);
    expect(mediumIdx).toBeLessThan(strictIdx);
  });

  it('includes the skill name + strength + system prompt for each skill', async () => {
    setCatalog([makeSkill({ id: 's1', name: 'Agent Mode', strength: 3, systemPrompt: 'You operate in Agent Mode.' })]);
    const result = await assembleSkillsPrompt(['s1']);
    expect(result).toContain('Agent Mode');
    expect(result).toContain('strength 3');
    expect(result).toContain('You operate in Agent Mode.');
  });

  it('skips unknown skills (logs warning)', async () => {
    setCatalog([makeSkill({ id: 's1', name: 'Real Skill' })]);
    const result = await assembleSkillsPrompt(['s1', 'nonexistent']);
    expect(result).toContain('Real Skill');
    expect(result).not.toContain('nonexistent');
  });

  it('skips disabled skills', async () => {
    setCatalog([
      makeSkill({ id: 's1', name: 'Enabled', enabled: true }),
      makeSkill({ id: 's2', name: 'Disabled', enabled: false }),
    ]);
    const result = await assembleSkillsPrompt(['s1', 's2']);
    expect(result).toContain('Enabled');
    expect(result).not.toContain('Disabled');
  });

  it('returns empty string when all skills are disabled', async () => {
    setCatalog([
      makeSkill({ id: 's1', enabled: false }),
      makeSkill({ id: 's2', enabled: false }),
    ]);
    const result = await assembleSkillsPrompt(['s1', 's2']);
    expect(result).toBe('');
  });

  it('returns empty string when all skill IDs are unknown', async () => {
    setCatalog([makeSkill({ id: 's1' })]);
    const result = await assembleSkillsPrompt(['nonexistent-1', 'nonexistent-2']);
    expect(result).toBe('');
  });
});

// ─── Type-level checks ─────────────────────────────────────────────────────

describe('type-level checks', () => {
  it('SkillStrength is 1 | 2 | 3', () => {
    const strengths: SkillRecord['strength'][] = [1, 2, 3];
    expect(strengths).toHaveLength(3);
  });

  it('SkillRecord has all documented fields', () => {
    const skill: SkillRecord = {
      id: 's1',
      name: 'Test',
      description: 'd',
      icon: 'Bot',
      category: 'General',
      systemPrompt: 'p',
      strength: 1,
      enabled: true,
      builtin: true,
    };
    expect(skill.id).toBe('s1');
  });
});
