/**
 * Unit tests for prisma/seed-data.ts
 *
 * Blueprint v4.1 §22 Phase 0 Step 0.9, §23 (Testing Strategy), §7 (Providers),
 * §11 (Agent Templates), §12 (Skills), §8 (Z.ai Policy)
 *
 * These tests verify the SHAPE of the seed data — they do NOT execute the
 * seed script (that needs a live DB and is an integration test). The seed
 * script itself is exercised by `npm run db:seed` against a real SQLite DB.
 *
 * Coverage:
 *  - Providers: 10 total, correct kinds, Z.ai enabled-by-default + others disabled
 *  - Skills: 42 total, 10 categories with correct counts, every systemPrompt
 *    is non-empty + production-grade (>100 chars), every strength is 1|2|3
 *  - Agent templates: 10 total (3 orchestrators, 7 workers), every systemPrompt
 *    contains the §11 identity-preservation phrase
 *  - Demo user: email is correct, password is the documented plaintext
 *
 * No mocking required — these are pure data-shape assertions against static
 * arrays. No DB, no logger, no Prisma.
 */

import { describe, it, expect } from 'vitest';
import bcrypt from 'bcryptjs';
import {
  demoUser,
  providers,
  skills,
  agentTemplates,
  SKILL_CATEGORY_COUNTS,
  EXPECTED_PROVIDER_COUNT,
  EXPECTED_AGENT_TEMPLATE_COUNT,
  EXPECTED_ORCHESTRATOR_COUNT,
  EXPECTED_WORKER_COUNT,
  type ProviderSeed,
  type SkillSeed,
  type AgentTemplateSeed,
} from '@/../prisma/seed-data';

// ─── Helpers ───────────────────────────────────────────────────────────────

/** Provider IDs that should be in the seed array. */
const EXPECTED_PROVIDER_IDS = [
  'zai',
  'mistral',
  'openai',
  'anthropic',
  'groq',
  'together',
  'openrouter',
  'cloudflare',
  'ollama',
  'lmstudio',
] as const;

/** Skill categories that should be in the seed array, with their counts. */
const EXPECTED_CATEGORIES = Object.keys(SKILL_CATEGORY_COUNTS);

// ─── Providers ─────────────────────────────────────────────────────────────

describe('providers seed data', () => {
  it('has exactly 10 providers', () => {
    expect(providers).toHaveLength(EXPECTED_PROVIDER_COUNT);
  });

  it('has all 10 expected provider IDs', () => {
    const ids = providers.map((p) => p.id);
    for (const expectedId of EXPECTED_PROVIDER_IDS) {
      expect(ids).toContain(expectedId);
    }
  });

  it('every provider has a non-empty name', () => {
    for (const p of providers) {
      expect(p.name.length).toBeGreaterThan(0);
    }
  });

  it('every provider has a valid kind (openai | anthropic | zai | custom)', () => {
    const validKinds = ['openai', 'anthropic', 'zai', 'custom'];
    for (const p of providers) {
      expect(validKinds).toContain(p.kind);
    }
  });

  it('Z.ai has kind=zai', () => {
    const zai = providers.find((p) => p.id === 'zai');
    expect(zai).toBeDefined();
    expect(zai!.kind).toBe('zai');
  });

  it('Mistral, OpenAI, Groq, Together, OpenRouter, Cloudflare, Ollama, LM Studio all have kind=openai', () => {
    const openAiCompatibleIds = ['mistral', 'openai', 'groq', 'together', 'openrouter', 'cloudflare', 'ollama', 'lmstudio'];
    for (const id of openAiCompatibleIds) {
      const p = providers.find((x) => x.id === id);
      expect(p).toBeDefined();
      expect(p!.kind).toBe('openai');
    }
  });

  it('Anthropic has kind=anthropic', () => {
    const anthropic = providers.find((p) => p.id === 'anthropic');
    expect(anthropic).toBeDefined();
    expect(anthropic!.kind).toBe('anthropic');
  });

  it('Z.ai is enabled by default (Blueprint §8)', () => {
    const zai = providers.find((p) => p.id === 'zai');
    expect(zai).toBeDefined();
    expect(zai!.enabled).toBe(true);
  });

  it('every non-Z.ai provider is disabled by default (user must enable after adding API key)', () => {
    for (const p of providers) {
      if (p.id === 'zai') continue;
      expect(p.enabled).toBe(false);
    }
  });

  it('Ollama and LM Studio are marked isLocal=true', () => {
    const ollama = providers.find((p) => p.id === 'ollama');
    const lmstudio = providers.find((p) => p.id === 'lmstudio');
    expect(ollama!.isLocal).toBe(true);
    expect(lmstudio!.isLocal).toBe(true);
  });

  it('every non-local provider has isLocal=false', () => {
    for (const p of providers) {
      if (p.id === 'ollama' || p.id === 'lmstudio') continue;
      expect(p.isLocal).toBe(false);
    }
  });

  it('every provider has workspaceId=null (global built-ins)', () => {
    for (const p of providers) {
      expect(p.workspaceId).toBeNull();
    }
  });

  it('every provider has a non-empty models JSON array', () => {
    for (const p of providers) {
      expect(p.models).toBeDefined();
      const parsed = JSON.parse(p.models) as unknown[];
      expect(Array.isArray(parsed)).toBe(true);
      expect(parsed.length).toBeGreaterThan(0);
    }
  });

  it('every non-Z.ai, non-local provider has a non-null baseUrl', () => {
    for (const p of providers) {
      if (p.id === 'zai') continue; // Z.ai uses SDK, no baseUrl
      expect(p.baseUrl).not.toBeNull();
      // Basic URL sanity check
      expect(p.baseUrl).toMatch(/^https?:\/\//);
    }
  });

  it('Z.ai has baseUrl=null (SDK internal)', () => {
    const zai = providers.find((p) => p.id === 'zai');
    expect(zai!.baseUrl).toBeNull();
  });

  it('every provider has apiKey=null in seed (user adds their own)', () => {
    for (const p of providers) {
      expect(p.apiKey).toBeNull();
    }
  });
});

// ─── Skills ────────────────────────────────────────────────────────────────

describe('skills seed data', () => {
  it('has exactly 42 skills', () => {
    expect(skills).toHaveLength(42);
  });

  it('has exactly 10 categories', () => {
    const categories = new Set(skills.map((s) => s.category));
    expect(categories.size).toBe(10);
  });

  it('every category has the expected count (Blueprint §12)', () => {
    const counts: Record<string, number> = {};
    for (const s of skills) {
      counts[s.category] = (counts[s.category] ?? 0) + 1;
    }
    for (const [category, expectedCount] of Object.entries(SKILL_CATEGORY_COUNTS)) {
      expect(counts[category]).toBe(expectedCount);
    }
  });

  it('includes all 10 expected categories', () => {
    const categories = new Set(skills.map((s) => s.category));
    for (const expected of EXPECTED_CATEGORIES) {
      expect(categories.has(expected)).toBe(true);
    }
  });

  it('every skill has a non-empty systemPrompt with length > 100 chars (production-grade)', () => {
    for (const s of skills) {
      expect(s.systemPrompt.length).toBeGreaterThan(100);
    }
  });

  it('no skill systemPrompt contains "TODO" (no placeholder prompts)', () => {
    for (const s of skills) {
      expect(s.systemPrompt).not.toMatch(/\bTODO\b/);
    }
  });

  it('no skill systemPrompt contains "implement here" placeholder', () => {
    for (const s of skills) {
      expect(s.systemPrompt.toLowerCase()).not.toContain('implement here');
    }
  });

  it('no skill systemPrompt is just "You are a helpful assistant" filler', () => {
    for (const s of skills) {
      expect(s.systemPrompt.trim()).not.toBe('You are a helpful assistant.');
      expect(s.systemPrompt.trim()).not.toBe('You are a helpful assistant');
    }
  });

  it('every skill has a valid strength (1 | 2 | 3)', () => {
    for (const s of skills) {
      expect([1, 2, 3]).toContain(s.strength);
    }
  });

  it('every skill has builtin=true', () => {
    for (const s of skills) {
      expect(s.builtin).toBe(true);
    }
  });

  it('every skill has enabled=false by default (user opts in)', () => {
    for (const s of skills) {
      expect(s.enabled).toBe(false);
    }
  });

  it('every skill has a non-empty id, name, description, icon, category', () => {
    for (const s of skills) {
      expect(s.id.length).toBeGreaterThan(0);
      expect(s.name.length).toBeGreaterThan(0);
      expect(s.description.length).toBeGreaterThan(0);
      expect(s.icon.length).toBeGreaterThan(0);
      expect(s.category.length).toBeGreaterThan(0);
    }
  });

  it('skill IDs are unique', () => {
    const ids = skills.map((s) => s.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('has at least one STRICT skill (strength=3) — Agent Mode and Type Safety Enforcer per §12', () => {
    const strictSkills = skills.filter((s) => s.strength === 3);
    expect(strictSkills.length).toBeGreaterThanOrEqual(2);
    const strictNames = strictSkills.map((s) => s.name);
    expect(strictNames).toContain('Agent Mode');
    expect(strictNames).toContain('Type Safety Enforcer');
  });

  it('has at least one MEDIUM skill (strength=2)', () => {
    const mediumSkills = skills.filter((s) => s.strength === 2);
    expect(mediumSkills.length).toBeGreaterThanOrEqual(1);
  });

  it('has at least one LIGHT skill (strength=1)', () => {
    const lightSkills = skills.filter((s) => s.strength === 1);
    expect(lightSkills.length).toBeGreaterThanOrEqual(1);
  });
});

// ─── Agent templates ───────────────────────────────────────────────────────

describe('agentTemplates seed data', () => {
  it('has exactly 10 agent templates', () => {
    expect(agentTemplates).toHaveLength(EXPECTED_AGENT_TEMPLATE_COUNT);
  });

  it('has exactly 3 orchestrators', () => {
    const orchestrators = agentTemplates.filter((a) => a.category === 'orchestrator');
    expect(orchestrators).toHaveLength(EXPECTED_ORCHESTRATOR_COUNT);
  });

  it('has exactly 7 workers', () => {
    const workers = agentTemplates.filter((a) => a.category === 'worker');
    expect(workers).toHaveLength(EXPECTED_WORKER_COUNT);
  });

  it('includes Hermes, Odysseus, OpenClaw as orchestrators (Blueprint §11)', () => {
    const orchestratorNames = agentTemplates
      .filter((a) => a.category === 'orchestrator')
      .map((a) => a.name);
    expect(orchestratorNames).toContain('Hermes');
    expect(orchestratorNames).toContain('Odysseus');
    expect(orchestratorNames).toContain('OpenClaw');
  });

  it('includes Researcher, Coder, Tester, Reviewer, Bug Hunter, Deployer, Scribe as workers (Blueprint §11)', () => {
    const workerNames = agentTemplates
      .filter((a) => a.category === 'worker')
      .map((a) => a.name);
    expect(workerNames).toContain('Researcher');
    expect(workerNames).toContain('Coder');
    expect(workerNames).toContain('Tester');
    expect(workerNames).toContain('Reviewer');
    expect(workerNames).toContain('Bug Hunter');
    expect(workerNames).toContain('Deployer');
    expect(workerNames).toContain('Scribe');
  });

  it('every agent template systemPrompt contains the §11 identity-preservation phrase', () => {
    // Blueprint §11: "When asked what model you are, state: 'I am [Model], operating as [Name].'"
    for (const a of agentTemplates) {
      expect(a.systemPrompt).toContain('I am ');
      expect(a.systemPrompt).toContain('operating as');
      // Combine the pattern: must contain a phrase like
      // "I am [Model], operating as [Name]"
      expect(a.systemPrompt).toMatch(/I am [A-Z][\w .-]+, operating as \w+/);
    }
  });

  it('every agent template systemPrompt starts with the identity statement', () => {
    // Blueprint §11: the first line should be the identity statement
    for (const a of agentTemplates) {
      const firstLine = a.systemPrompt.split('\n')[0]!;
      expect(firstLine).toContain('You are ');
      expect(firstLine).toContain('powered by');
      expect(firstLine).toContain('from');
    }
  });

  it('orchestrators have canSpawnAgents=true and maxSubAgents > 0', () => {
    for (const a of agentTemplates) {
      if (a.category === 'orchestrator') {
        expect(a.canSpawnAgents).toBe(true);
        expect(a.maxSubAgents).toBeGreaterThan(0);
      }
    }
  });

  it('workers have canSpawnAgents=false and maxSubAgents=0', () => {
    for (const a of agentTemplates) {
      if (a.category === 'worker') {
        expect(a.canSpawnAgents).toBe(false);
        expect(a.maxSubAgents).toBe(0);
      }
    }
  });

  it('orchestrators have maxSubAgents within Blueprint §10 limits (1..20)', () => {
    for (const a of agentTemplates) {
      if (a.category === 'orchestrator') {
        expect(a.maxSubAgents).toBeGreaterThanOrEqual(1);
        expect(a.maxSubAgents).toBeLessThanOrEqual(20);
      }
    }
  });

  it('every agent template has a valid temperature (0..2) per Blueprint §11', () => {
    for (const a of agentTemplates) {
      expect(a.temperature).toBeGreaterThanOrEqual(0);
      expect(a.temperature).toBeLessThanOrEqual(2);
    }
  });

  it('every agent template has builtin=true', () => {
    for (const a of agentTemplates) {
      expect(a.builtin).toBe(true);
    }
  });

  it('every agent template has enabled=true (agents are usable out of the box)', () => {
    for (const a of agentTemplates) {
      expect(a.enabled).toBe(true);
    }
  });

  it('every agent template has a non-empty tools JSON array (stringified)', () => {
    for (const a of agentTemplates) {
      const parsed = JSON.parse(a.tools) as unknown[];
      expect(Array.isArray(parsed)).toBe(true);
      expect(parsed.length).toBeGreaterThan(0);
    }
  });

  it('every agent template has a mcpTools JSON array (stringified, may be empty)', () => {
    for (const a of agentTemplates) {
      const parsed = JSON.parse(a.mcpTools) as unknown[];
      expect(Array.isArray(parsed)).toBe(true);
    }
  });

  it('every agent template has a non-empty systemPrompt with length > 200 chars (production-grade)', () => {
    for (const a of agentTemplates) {
      expect(a.systemPrompt.length).toBeGreaterThan(200);
    }
  });

  it('no agent template systemPrompt contains "TODO"', () => {
    for (const a of agentTemplates) {
      expect(a.systemPrompt).not.toMatch(/\bTODO\b/);
    }
  });

  it('every agent template has a unique id', () => {
    const ids = agentTemplates.map((a) => a.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('every agent template has a preferredProvider and preferredModel (so orchestrators know who to call)', () => {
    for (const a of agentTemplates) {
      expect(a.preferredProvider).not.toBeNull();
      expect(a.preferredModel).not.toBeNull();
    }
  });

  it('Hermes prefers Mistral Large (Blueprint §11)', () => {
    const hermes = agentTemplates.find((a) => a.name === 'Hermes');
    expect(hermes!.preferredProvider).toBe('mistral');
    expect(hermes!.preferredModel).toBe('mistral-large-latest');
  });

  it('Odysseus prefers GPT-4o (Blueprint §11)', () => {
    const odysseus = agentTemplates.find((a) => a.name === 'Odysseus');
    expect(odysseus!.preferredProvider).toBe('openai');
    expect(odysseus!.preferredModel).toBe('gpt-4o');
  });

  it('OpenClaw prefers GPT-4o (Blueprint §11)', () => {
    const openclaw = agentTemplates.find((a) => a.name === 'OpenClaw');
    expect(openclaw!.preferredProvider).toBe('openai');
    expect(openclaw!.preferredModel).toBe('gpt-4o');
  });

  it('Reviewer prefers Claude (Blueprint §11 — Reviewer uses Claude)', () => {
    const reviewer = agentTemplates.find((a) => a.name === 'Reviewer');
    expect(reviewer!.preferredProvider).toBe('anthropic');
    expect(reviewer!.preferredModel).toBe('claude-3-5-sonnet-latest');
  });
});

// ─── Demo user ─────────────────────────────────────────────────────────────

describe('demoUser seed data', () => {
  it('has the documented email', () => {
    expect(demoUser.email).toBe('demo@zchat.dev');
  });

  it('has the documented plaintext password (hashed at seed runtime)', () => {
    // Per the seed-data.ts comment: the demo user's password is
    // 'demo-password-123'. This is intentional for sandbox access.
    expect(demoUser.passwordPlain).toBe('demo-password-123');
  });

  it('has a non-empty name', () => {
    expect(demoUser.name.length).toBeGreaterThan(0);
  });

  it('has tier=free', () => {
    expect(demoUser.tier).toBe('free');
  });

  it('hashPassword produces a bcrypt hash of the demo password in the expected format', async () => {
    // This is the actual contract the seed script relies on. We test it here
    // against bcryptjs directly (the same library src/lib/auth.ts uses) so
    // the test does NOT import auth.ts (which would trigger the logger/db
    // singletons).
    const hash = await bcrypt.hash(demoUser.passwordPlain, 12);
    expect(hash).toMatch(/^\$2[ab]\$\d{2}\$/);
    expect(await bcrypt.compare(demoUser.passwordPlain, hash)).toBe(true);
  });

  it('the bcrypt hash format starts with $2a$ or $2b$', async () => {
    const hash = await bcrypt.hash(demoUser.passwordPlain, 12);
    expect(hash.startsWith('$2a$') || hash.startsWith('$2b$')).toBe(true);
  });
});

// ─── Cross-cutting ─────────────────────────────────────────────────────────

describe('cross-cutting seed data sanity', () => {
  it('EXPECTED_PROVIDER_COUNT is 10', () => {
    expect(EXPECTED_PROVIDER_COUNT).toBe(10);
  });

  it('EXPECTED_AGENT_TEMPLATE_COUNT is 10', () => {
    expect(EXPECTED_AGENT_TEMPLATE_COUNT).toBe(10);
  });

  it('EXPECTED_ORCHESTRATOR_COUNT is 3', () => {
    expect(EXPECTED_ORCHESTRATOR_COUNT).toBe(3);
  });

  it('EXPECTED_WORKER_COUNT is 7', () => {
    expect(EXPECTED_WORKER_COUNT).toBe(7);
  });

  it('SKILL_CATEGORY_COUNTS sums to 42', () => {
    const total = Object.values(SKILL_CATEGORY_COUNTS).reduce((a, b) => a + b, 0);
    expect(total).toBe(42);
  });

  it('no skill references a provider that does not exist in the providers array', () => {
    // Sanity: if a skill prompt mentions a provider by ID, that ID must exist.
    // (Not strictly required — skills may reference any provider conceptually —
    // but useful to catch typos.)
    const providerIds = new Set(providers.map((p) => p.id));
    for (const s of skills) {
      // Extract provider-id-like tokens from the prompt
      const matches = s.systemPrompt.match(/\b(mistral|openai|anthropic|groq|together|openrouter|cloudflare|ollama|lmstudio|zai)\b/gi);
      if (matches) {
        for (const m of matches) {
          expect(providerIds.has(m.toLowerCase())).toBe(true);
        }
      }
    }
  });

  it('every agent template preferredProvider exists in the providers array', () => {
    const providerIds = new Set(providers.map((p) => p.id));
    for (const a of agentTemplates) {
      if (a.preferredProvider) {
        expect(providerIds.has(a.preferredProvider)).toBe(true);
      }
    }
  });
});
