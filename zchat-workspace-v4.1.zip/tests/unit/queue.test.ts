/**
 * Unit tests for src/lib/queue/db-queue.ts + types.ts
 *
 * Blueprint v4.1 §17 (Job Queue), §23 (Testing Strategy)
 *
 * Coverage:
 *  - QueueError + isQueueError: construction, brand, type guard (pos + neg)
 *  - enqueue: inserts row with status='queued', returns jobId, payload JSON-stringified,
 *    rejects payload.type mismatch, rejects un-serializable payloads
 *  - claimNext: returns null on empty queue, claims oldest queued job, increments
 *    attempts, sets startedAt, status='running'; atomicity (two sequential claims
 *    can't get the same job)
 *  - complete: sets status='done', finishedAt is set, result is JSON-stringified,
 *    clears error
 *  - fail: terminal failure (attempts >= maxAttempts) sets status='failed' +
 *    finishedAt; retry failure resets status='queued' + startedAt=null
 *  - recoverStaleJobs: resets old 'running' jobs to 'queued', returns count,
 *    leaves fresh 'running' jobs alone, leaves non-running jobs alone
 *  - getJob / getJobsBySession: basic CRUD
 *  - registerHandler + processNext: handler is called, returns true; empty queue
 *    returns false; unhandled type → terminal fail + NO_HANDLER throw; handler
 *    error → retry path (attempts < maxAttempts); handler error on last attempt
 *    → terminal fail; MAX_ATTEMPTS_EXCEEDED via repeated failures
 *  - parseJobPayload / parseJobResult: round-trip + error cases
 *
 * Mocking strategy:
 *  - `@/lib/db` is mocked with vi.mock. The mock provides an in-memory job store
 *    backed by a Map<string, JobRecord-like>. The mock implements `findFirst`,
 *    `findUnique`, `findMany`, `create`, `update`, `updateMany`, and a `$transaction`
 *    that runs its callback synchronously with the same mock client.
 *  - `@/lib/logger` is mocked to no-op functions so test output stays clean.
 *  - Between tests, the in-memory store and the handler registry are cleared.
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';

// ─── Mock setup ────────────────────────────────────────────────────────────
//
// vi.mock is hoisted. The mock factory must return an object shaped like the
// `db` export of src/lib/db.ts. We expose an in-memory store via a closure
// that the test helpers can reset.

type StoredJob = {
  id: string;
  sessionId: string;
  type: string;
  status: string;
  payload: string;
  result: string | null;
  error: string | null;
  attempts: number;
  maxAttempts: number;
  startedAt: Date | null;
  finishedAt: Date | null;
  createdAt: Date;
};

const jobStore = new Map<string, StoredJob>();
let idCounter = 0;

const dbMock = {
  job: {
    findFirst: vi.fn(async (args?: {
      where?: Record<string, unknown>;
      orderBy?: Record<string, 'asc' | 'desc'>;
      take?: number;
    }) => {
      let entries = Array.from(jobStore.values());
      const where = args?.where ?? {};
      if (where['status'] !== undefined) {
        entries = entries.filter((e) => e.status === where['status']);
      }
      if (where['sessionId'] !== undefined) {
        entries = entries.filter((e) => e.sessionId === where['sessionId']);
      }
      if (where['startedAt'] !== undefined) {
        const startedAtFilter = where['startedAt'] as { lt?: Date; gt?: Date };
        if (startedAtFilter.lt) {
          entries = entries.filter((e) => e.startedAt !== null && e.startedAt < startedAtFilter.lt!);
        }
        if (startedAtFilter.gt) {
          entries = entries.filter((e) => e.startedAt !== null && e.startedAt > startedAtFilter.gt!);
        }
      }
      // orderBy
      if (args?.orderBy && args.orderBy['createdAt']) {
        const dir = args.orderBy['createdAt'];
        entries.sort((a, b) => {
          const cmp = a.createdAt.getTime() - b.createdAt.getTime();
          return dir === 'asc' ? cmp : -cmp;
        });
      }
      if (args?.take === 1) {
        return entries[0] ?? null;
      }
      return entries[0] ?? null;
    }),

    findUnique: vi.fn(async (args: { where: { id: string } }) => {
      return jobStore.get(args.where.id) ?? null;
    }),

    findMany: vi.fn(async (args: {
      where?: Record<string, unknown>;
      orderBy?: Record<string, 'asc' | 'desc'>;
    }) => {
      let entries = Array.from(jobStore.values());
      const where = args?.where ?? {};
      if (where['sessionId'] !== undefined) {
        entries = entries.filter((e) => e.sessionId === where['sessionId']);
      }
      if (args?.orderBy && args.orderBy['createdAt']) {
        const dir = args.orderBy['createdAt'];
        entries.sort((a, b) => {
          const cmp = a.createdAt.getTime() - b.createdAt.getTime();
          return dir === 'asc' ? cmp : -cmp;
        });
      }
      return entries;
    }),

    create: vi.fn(async (args: { data: Partial<StoredJob> & { sessionId: string; type: string } }) => {
      const id = `job-${++idCounter}`;
      const now = new Date();
      const job: StoredJob = {
        id,
        sessionId: args.data.sessionId!,
        type: args.data.type!,
        status: args.data.status ?? 'queued',
        payload: args.data.payload ?? '{}',
        result: args.data.result ?? null,
        error: args.data.error ?? null,
        attempts: args.data.attempts ?? 0,
        maxAttempts: args.data.maxAttempts ?? 3,
        startedAt: args.data.startedAt ?? null,
        finishedAt: args.data.finishedAt ?? null,
        createdAt: now,
      };
      jobStore.set(id, job);
      return job;
    }),

    update: vi.fn(async (args: { where: { id: string }; data: Partial<StoredJob> }) => {
      const existing = jobStore.get(args.where.id);
      if (!existing) {
        // Prisma would throw P2025; for tests we throw a generic error the
        // queue code catches + rewraps.
        throw new Error(`Record not found for id ${args.where.id}`);
      }
      const updated: StoredJob = { ...existing };
      for (const [key, value] of Object.entries(args.data)) {
        if (key === 'attempts' && typeof value === 'object' && value !== null && 'increment' in value) {
          const inc = (value as { increment: number }).increment;
          updated.attempts = existing.attempts + inc;
        } else {
          (updated as Record<string, unknown>)[key] = value;
        }
      }
      jobStore.set(args.where.id, updated);
      return updated;
    }),

    updateMany: vi.fn(async (args: {
      where: Record<string, unknown>;
      data: Partial<StoredJob>;
    }) => {
      let count = 0;
      const where = args.where;
      for (const job of jobStore.values()) {
        let match = true;
        if (where['status'] !== undefined && job.status !== where['status']) match = false;
        if (match && where['startedAt'] !== undefined) {
          const f = where['startedAt'] as { lt?: Date; gt?: Date };
          if (f.lt && (job.startedAt === null || job.startedAt >= f.lt)) match = false;
          if (f.gt && (job.startedAt === null || job.startedAt <= f.gt)) match = false;
        }
        if (match) {
          const updated: StoredJob = { ...job, ...args.data } as StoredJob;
          jobStore.set(job.id, updated);
          count++;
        }
      }
      return { count };
    }),
  },
};

vi.mock('@/lib/db', () => ({
  db: dbMock,
  runInTransaction: async <T,>(
    fn: (tx: typeof dbMock) => Promise<T>,
    _options?: { timeoutMs?: number; maxWaitMs?: number },
  ): Promise<T> => {
    // Synchronous-ish: just run the callback with the same mock client.
    // This is sufficient for the atomicity tests — real SQLite serializes
    // transactions, but the in-memory mock doesn't need to.
    return fn(dbMock);
  },
}));

vi.mock('@/lib/logger', () => ({
  logger: {
    trace: vi.fn(),
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    fatal: vi.fn(),
    child: vi.fn(() => ({
      trace: vi.fn(),
      debug: vi.fn(),
      info: vi.fn(),
      warn: vi.fn(),
      error: vi.fn(),
      fatal: vi.fn(),
      child: vi.fn(),
      level: 'debug',
    })),
  },
  withRequestContext: vi.fn(),
  logReactError: vi.fn(),
  moduleLogger: vi.fn(() => ({
    trace: vi.fn(),
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    fatal: vi.fn(),
    child: vi.fn(),
    level: 'debug',
  })),
}));

// ─── Imports (after mocks) ─────────────────────────────────────────────────

import {
  enqueue,
  claimNext,
  complete,
  fail,
  recoverStaleJobs,
  getJob,
  getJobsBySession,
  registerHandler,
  processNext,
  _clearHandlersForTests,
  DEFAULT_MAX_ATTEMPTS,
  DEFAULT_STALE_THRESHOLD_MS,
} from '@/lib/queue/db-queue';
import {
  QueueError,
  isQueueError,
  parseJobPayload,
  parseJobResult,
  type JobPayload,
  type JobRecord,
  type JobResult,
  type JobType,
} from '@/lib/queue/types';

// ─── Test helpers ──────────────────────────────────────────────────────────

function resetStore(): void {
  jobStore.clear();
  idCounter = 0;
  for (const fn of Object.values(dbMock.job)) {
    (fn as ReturnType<typeof vi.fn>).mockClear();
  }
}

function makeChatPayload(sessionId = 'sess-1'): JobPayload {
  return {
    type: 'chat',
    sessionId,
    messageContent: 'Hello',
    providerId: 'openai',
    model: 'gpt-4o',
  };
}

function makeChatResult(): JobResult {
  return {
    type: 'chat',
    message: 'Hi there',
    tokens: 10,
    costUsd: 0.001,
  };
}

function storeJob(overrides: Partial<StoredJob> = {}): StoredJob {
  const id = overrides.id ?? `job-${++idCounter}`;
  const job: StoredJob = {
    id,
    sessionId: overrides.sessionId ?? 'sess-1',
    type: overrides.type ?? 'chat',
    status: overrides.status ?? 'queued',
    payload: overrides.payload ?? JSON.stringify(makeChatPayload()),
    result: overrides.result ?? null,
    error: overrides.error ?? null,
    attempts: overrides.attempts ?? 0,
    maxAttempts: overrides.maxAttempts ?? 3,
    startedAt: overrides.startedAt ?? null,
    finishedAt: overrides.finishedAt ?? null,
    createdAt: overrides.createdAt ?? new Date(),
  };
  jobStore.set(id, job);
  return job;
}

// ─── QueueError + isQueueError ─────────────────────────────────────────────

describe('QueueError', () => {
  it('preserves code, message, cause, and jobId', () => {
    const cause = new Error('root');
    const err = new QueueError('CLAIM_FAILED', 'claim broke', cause, 'job-1');
    expect(err.code).toBe('CLAIM_FAILED');
    expect(err.message).toBe('claim broke');
    expect(err.cause).toBe(cause);
    expect(err.jobId).toBe('job-1');
    expect(err.name).toBe('QueueError');
  });

  it('is an instance of Error', () => {
    const err = new QueueError('NO_HANDLER', 'x');
    expect(err).toBeInstanceOf(Error);
  });

  it('survives instanceof QueueError after subclassing Error (prototype chain)', () => {
    const err = new QueueError('CLAIM_FAILED', 'x');
    expect(err).toBeInstanceOf(QueueError);
    try {
      throw err;
    } catch (caught) {
      expect(caught).toBeInstanceOf(QueueError);
    }
  });

  it('exposes every QueueErrorCode value', () => {
    const codes: ReadonlyArray<QueueError['code']> = [
      'ENQUEUE_FAILED',
      'CLAIM_FAILED',
      'COMPLETE_FAILED',
      'FAIL_FAILED',
      'RECOVER_FAILED',
      'NO_HANDLER',
      'MAX_ATTEMPTS_EXCEEDED',
      'JOB_NOT_FOUND',
    ];
    for (const code of codes) {
      const err = new QueueError(code, `message for ${code}`);
      expect(err.code).toBe(code);
    }
  });

  it('supports an undefined cause + jobId', () => {
    const err = new QueueError('JOB_NOT_FOUND', 'nope');
    expect(err.cause).toBeUndefined();
    expect(err.jobId).toBeUndefined();
  });
});

describe('isQueueError', () => {
  it('returns false for primitives', () => {
    expect(isQueueError(0)).toBe(false);
    expect(isQueueError('')).toBe(false);
    expect(isQueueError(false)).toBe(false);
    expect(isQueueError(null)).toBe(false);
    expect(isQueueError(undefined)).toBe(false);
  });

  it('returns false for plain objects lacking the brand symbol', () => {
    expect(isQueueError({ code: 'CLAIM_FAILED', message: 'fake' })).toBe(false);
    expect(isQueueError(new Error('plain'))).toBe(false);
    expect(isQueueError({})).toBe(false);
  });

  it('returns true for QueueError instances', () => {
    const err = new QueueError('CLAIM_FAILED', 'real');
    expect(isQueueError(err)).toBe(true);
  });

  it('does not confuse QueueError with DbError / AuthError / ValidationError (different brand symbol)', () => {
    const fakeDbError = Object.assign(new Error('db failed'), {
      code: 'QUERY_FAILED',
      cause: undefined,
    });
    expect(isQueueError(fakeDbError)).toBe(false);
  });
});

// ─── enqueue ───────────────────────────────────────────────────────────────

describe('enqueue', () => {
  beforeEach(() => {
    resetStore();
  });

  it('inserts a job row with status="queued" and returns the jobId', async () => {
    const jobId = await enqueue('sess-1', 'chat', makeChatPayload());
    expect(typeof jobId).toBe('string');
    expect(jobId.length).toBeGreaterThan(0);
    const stored = jobStore.get(jobId);
    expect(stored).toBeDefined();
    expect(stored!.status).toBe('queued');
  });

  it('JSON-stringifies the payload', async () => {
    const payload = makeChatPayload('sess-1');
    const jobId = await enqueue('sess-1', 'chat', payload);
    const stored = jobStore.get(jobId);
    expect(stored!.payload).toBe(JSON.stringify(payload));
    // Payload must be parseable back to the original
    expect(JSON.parse(stored!.payload)).toEqual(payload);
  });

  it('defaults maxAttempts to DEFAULT_MAX_ATTEMPTS (3)', async () => {
    const jobId = await enqueue('sess-1', 'chat', makeChatPayload());
    expect(jobStore.get(jobId)!.maxAttempts).toBe(DEFAULT_MAX_ATTEMPTS);
  });

  it('honors an explicit maxAttempts option', async () => {
    const jobId = await enqueue('sess-1', 'chat', makeChatPayload(), { maxAttempts: 5 });
    expect(jobStore.get(jobId)!.maxAttempts).toBe(5);
  });

  it('initializes attempts=0, startedAt=null, finishedAt=null', async () => {
    const jobId = await enqueue('sess-1', 'chat', makeChatPayload());
    const stored = jobStore.get(jobId)!;
    expect(stored.attempts).toBe(0);
    expect(stored.startedAt).toBeNull();
    expect(stored.finishedAt).toBeNull();
  });

  it('throws QueueError(ENQUEUE_FAILED) when payload.type does not match declared type', async () => {
    const wrongPayload: JobPayload = {
      type: 'reasoning',
      sessionId: 's1',
      goal: 'x',
      mode: 'standard',
      providerId: 'p',
      model: 'm',
    };
    try {
      await enqueue('s1', 'chat', wrongPayload);
      expect.fail('Expected enqueue to throw');
    } catch (err) {
      expect(isQueueError(err)).toBe(true);
      if (isQueueError(err)) expect(err.code).toBe('ENQUEUE_FAILED');
    }
  });

  it('throws QueueError(ENQUEUE_FAILED) when payload cannot be serialized (circular ref)', async () => {
    const circular: unknown = { type: 'chat', sessionId: 's1', messageContent: 'x', providerId: 'p', model: 'm' };
    (circular as Record<string, unknown>).self = circular;
    try {
      await enqueue('s1', 'chat', circular as JobPayload);
      expect.fail('Expected enqueue to throw');
    } catch (err) {
      expect(isQueueError(err)).toBe(true);
      if (isQueueError(err)) expect(err.code).toBe('ENQUEUE_FAILED');
    }
  });

  it('sets createdAt to a Date', async () => {
    const jobId = await enqueue('sess-1', 'chat', makeChatPayload());
    expect(jobStore.get(jobId)!.createdAt).toBeInstanceOf(Date);
  });
});

// ─── claimNext ─────────────────────────────────────────────────────────────

describe('claimNext', () => {
  beforeEach(() => {
    resetStore();
  });

  it('returns null when the queue is empty', async () => {
    const result = await claimNext();
    expect(result).toBeNull();
  });

  it('claims the oldest queued job and marks it running', async () => {
    const older = storeJob({ id: 'job-old', createdAt: new Date(Date.now() - 1000) });
    const newer = storeJob({ id: 'job-new', createdAt: new Date() });
    void newer;

    const claimed = await claimNext();
    expect(claimed).not.toBeNull();
    expect(claimed!.id).toBe('job-old');
    expect(claimed!.status).toBe('running');
    expect(claimed!.startedAt).not.toBeNull();
    expect(claimed!.attempts).toBe(1); // 0 + 1
  });

  it('does NOT claim a job that is already running', async () => {
    storeJob({ id: 'job-running', status: 'running', startedAt: new Date() });
    const claimed = await claimNext();
    expect(claimed).toBeNull();
  });

  it('does NOT claim a job that is done', async () => {
    storeJob({ id: 'job-done', status: 'done', finishedAt: new Date() });
    const claimed = await claimNext();
    expect(claimed).toBeNull();
  });

  it('does NOT claim a job that is failed', async () => {
    storeJob({ id: 'job-failed', status: 'failed', finishedAt: new Date() });
    const claimed = await claimNext();
    expect(claimed).toBeNull();
  });

  it('atomic: two sequential claims cannot get the same job', async () => {
    storeJob({ id: 'only-job' });
    const first = await claimNext();
    const second = await claimNext();
    expect(first!.id).toBe('only-job');
    expect(second).toBeNull();
  });

  it('atomic: claims two distinct jobs when both are queued', async () => {
    storeJob({ id: 'job-a', createdAt: new Date(Date.now() - 2000) });
    storeJob({ id: 'job-b', createdAt: new Date(Date.now() - 1000) });
    const first = await claimNext();
    const second = await claimNext();
    expect(first!.id).toBe('job-a');
    expect(second!.id).toBe('job-b');
    expect(first!.id).not.toBe(second!.id);
  });

  it('increments attempts on each claim', async () => {
    storeJob({ id: 'job-retry', attempts: 2 });
    const claimed = await claimNext();
    expect(claimed!.attempts).toBe(3);
  });
});

// ─── complete ──────────────────────────────────────────────────────────────

describe('complete', () => {
  beforeEach(() => {
    resetStore();
  });

  it('sets status="done", finishedAt is set, result is JSON-stringified', async () => {
    storeJob({ id: 'job-1', status: 'running', attempts: 1 });
    const result = makeChatResult();
    await complete('job-1', result);
    const stored = jobStore.get('job-1')!;
    expect(stored.status).toBe('done');
    expect(stored.finishedAt).not.toBeNull();
    expect(stored.finishedAt).toBeInstanceOf(Date);
    expect(JSON.parse(stored.result!)).toEqual(result);
  });

  it('clears the error field on completion', async () => {
    storeJob({ id: 'job-1', status: 'running', error: 'previous attempt failed' });
    await complete('job-1', makeChatResult());
    expect(jobStore.get('job-1')!.error).toBeNull();
  });

  it('throws QueueError(COMPLETE_FAILED) when result cannot be serialized', async () => {
    storeJob({ id: 'job-1', status: 'running' });
    const circular: unknown = { type: 'chat', message: 'x', tokens: 1, costUsd: 0 };
    (circular as Record<string, unknown>).self = circular;
    try {
      await complete('job-1', circular as JobResult);
      expect.fail('Expected complete to throw');
    } catch (err) {
      expect(isQueueError(err)).toBe(true);
      if (isQueueError(err)) expect(err.code).toBe('COMPLETE_FAILED');
    }
  });

  it('throws QueueError(JOB_NOT_FOUND) when the job does not exist', async () => {
    try {
      await complete('nonexistent', makeChatResult());
      expect.fail('Expected complete to throw');
    } catch (err) {
      expect(isQueueError(err)).toBe(true);
      if (isQueueError(err)) expect(err.code).toBe('JOB_NOT_FOUND');
    }
  });
});

// ─── fail ──────────────────────────────────────────────────────────────────

describe('fail', () => {
  beforeEach(() => {
    resetStore();
  });

  it('terminal failure: attempts >= maxAttempts sets status="failed" + finishedAt', async () => {
    storeJob({ id: 'job-1', status: 'running', attempts: 3, maxAttempts: 3 });
    await fail('job-1', new Error('boom'), 3, 3);
    const stored = jobStore.get('job-1')!;
    expect(stored.status).toBe('failed');
    expect(stored.finishedAt).toBeInstanceOf(Date);
    expect(stored.error).toBe('boom');
  });

  it('terminal failure accepts a string error', async () => {
    storeJob({ id: 'job-1', status: 'running', attempts: 3, maxAttempts: 3 });
    await fail('job-1', 'string error', 3, 3);
    expect(jobStore.get('job-1')!.error).toBe('string error');
  });

  it('retry: attempts < maxAttempts resets status="queued" + startedAt=null', async () => {
    storeJob({
      id: 'job-1',
      status: 'running',
      attempts: 1,
      maxAttempts: 3,
      startedAt: new Date(),
    });
    await fail('job-1', new Error('transient'), 1, 3);
    const stored = jobStore.get('job-1')!;
    expect(stored.status).toBe('queued');
    expect(stored.startedAt).toBeNull();
    // finishedAt stays null because the job is not done
    expect(stored.finishedAt).toBeNull();
    expect(stored.error).toBe('transient');
  });

  it('retry does NOT increment attempts (counter only changes on claimNext)', async () => {
    storeJob({ id: 'job-1', status: 'running', attempts: 1, maxAttempts: 3 });
    await fail('job-1', new Error('x'), 1, 3);
    expect(jobStore.get('job-1')!.attempts).toBe(1);
  });

  it('boundary: attempts == maxAttempts is terminal (>=)', async () => {
    storeJob({ id: 'job-1', status: 'running', attempts: 3, maxAttempts: 3 });
    await fail('job-1', new Error('x'), 3, 3);
    expect(jobStore.get('job-1')!.status).toBe('failed');
  });

  it('boundary: attempts == maxAttempts - 1 is retry', async () => {
    storeJob({ id: 'job-1', status: 'running', attempts: 2, maxAttempts: 3 });
    await fail('job-1', new Error('x'), 2, 3);
    expect(jobStore.get('job-1')!.status).toBe('queued');
  });

  it('throws QueueError(FAIL_FAILED) when the job does not exist', async () => {
    try {
      await fail('nonexistent', new Error('x'), 1, 3);
      expect.fail('Expected fail to throw');
    } catch (err) {
      expect(isQueueError(err)).toBe(true);
      if (isQueueError(err)) expect(err.code).toBe('FAIL_FAILED');
    }
  });
});

// ─── recoverStaleJobs ──────────────────────────────────────────────────────

describe('recoverStaleJobs', () => {
  beforeEach(() => {
    resetStore();
  });

  it('resets old "running" jobs to "queued" and returns the count', async () => {
    const staleTime = new Date(Date.now() - 10 * 60 * 1000); // 10 min ago
    storeJob({ id: 'stale-1', status: 'running', startedAt: staleTime });
    storeJob({ id: 'stale-2', status: 'running', startedAt: staleTime });

    const count = await recoverStaleJobs(5 * 60 * 1000); // 5 min threshold
    expect(count).toBe(2);
    expect(jobStore.get('stale-1')!.status).toBe('queued');
    expect(jobStore.get('stale-1')!.startedAt).toBeNull();
    expect(jobStore.get('stale-2')!.status).toBe('queued');
    expect(jobStore.get('stale-2')!.startedAt).toBeNull();
  });

  it('leaves fresh "running" jobs alone', async () => {
    const freshTime = new Date(Date.now() - 60 * 1000); // 1 min ago
    storeJob({ id: 'fresh-1', status: 'running', startedAt: freshTime });

    const count = await recoverStaleJobs(5 * 60 * 1000); // 5 min threshold
    expect(count).toBe(0);
    expect(jobStore.get('fresh-1')!.status).toBe('running');
    expect(jobStore.get('fresh-1')!.startedAt).toEqual(freshTime);
  });

  it('leaves non-running jobs alone', async () => {
    const staleTime = new Date(Date.now() - 10 * 60 * 1000);
    storeJob({ id: 'queued-1', status: 'queued', startedAt: null });
    storeJob({ id: 'done-1', status: 'done', finishedAt: staleTime });
    storeJob({ id: 'failed-1', status: 'failed', finishedAt: staleTime });

    const count = await recoverStaleJobs(5 * 60 * 1000);
    expect(count).toBe(0);
    expect(jobStore.get('queued-1')!.status).toBe('queued');
    expect(jobStore.get('done-1')!.status).toBe('done');
    expect(jobStore.get('failed-1')!.status).toBe('failed');
  });

  it('does NOT increment attempts during recovery', async () => {
    storeJob({
      id: 'stale-1',
      status: 'running',
      attempts: 1,
      startedAt: new Date(Date.now() - 10 * 60 * 1000),
    });
    await recoverStaleJobs(5 * 60 * 1000);
    expect(jobStore.get('stale-1')!.attempts).toBe(1);
  });

  it('returns 0 when no jobs are recoverable', async () => {
    const count = await recoverStaleJobs(5 * 60 * 1000);
    expect(count).toBe(0);
  });

  it('uses DEFAULT_STALE_THRESHOLD_MS (5 min) when olderThanMs is omitted', async () => {
    expect(DEFAULT_STALE_THRESHOLD_MS).toBe(5 * 60 * 1000);
    // 4-min-old running job should NOT be recovered at default threshold
    storeJob({
      id: 'fresh',
      status: 'running',
      startedAt: new Date(Date.now() - 4 * 60 * 1000),
    });
    const count = await recoverStaleJobs();
    expect(count).toBe(0);
    // 6-min-old running job SHOULD be recovered at default threshold
    storeJob({
      id: 'stale',
      status: 'running',
      startedAt: new Date(Date.now() - 6 * 60 * 1000),
    });
    const count2 = await recoverStaleJobs();
    expect(count2).toBe(1);
  });

  it('boundary: a job exactly at the threshold is NOT recovered (lt, not lte)', async () => {
    // startedAt exactly `olderThanMs` ago — should NOT match (lt is strict)
    const exactly = new Date(Date.now() - 5 * 60 * 1000);
    storeJob({ id: 'boundary', status: 'running', startedAt: exactly });
    const count = await recoverStaleJobs(5 * 60 * 1000);
    expect(count).toBe(0);
  });
});

// ─── getJob / getJobsBySession ─────────────────────────────────────────────

describe('getJob / getJobsBySession', () => {
  beforeEach(() => {
    resetStore();
  });

  it('getJob returns the job when it exists', async () => {
    storeJob({ id: 'job-1' });
    const job = await getJob('job-1');
    expect(job).not.toBeNull();
    expect(job!.id).toBe('job-1');
  });

  it('getJob returns null when the job does not exist', async () => {
    const job = await getJob('nonexistent');
    expect(job).toBeNull();
  });

  it('getJobsBySession returns all jobs for a session ordered by createdAt asc', async () => {
    storeJob({ id: 'b', sessionId: 's1', createdAt: new Date(Date.now() - 1000) });
    storeJob({ id: 'a', sessionId: 's1', createdAt: new Date(Date.now() - 2000) });
    storeJob({ id: 'c', sessionId: 's2', createdAt: new Date() });
    const jobs = await getJobsBySession('s1');
    expect(jobs).toHaveLength(2);
    expect(jobs[0]!.id).toBe('a'); // oldest first
    expect(jobs[1]!.id).toBe('b');
  });

  it('getJobsBySession returns empty array when the session has no jobs', async () => {
    const jobs = await getJobsBySession('empty-sess');
    expect(jobs).toEqual([]);
  });
});

// ─── registerHandler + processNext ─────────────────────────────────────────

describe('registerHandler + processNext', () => {
  beforeEach(() => {
    resetStore();
    _clearHandlersForTests();
  });

  it('processNext returns false when the queue is empty', async () => {
    const result = await processNext();
    expect(result).toBe(false);
  });

  it('processNext calls the registered handler and completes the job', async () => {
    const handler = vi.fn(async (_job: JobRecord) => makeChatResult());
    registerHandler('chat', handler);

    storeJob({ id: 'job-1', type: 'chat', status: 'queued' });
    const processed = await processNext();
    expect(processed).toBe(true);
    expect(handler).toHaveBeenCalledTimes(1);

    const stored = jobStore.get('job-1')!;
    expect(stored.status).toBe('done');
    expect(stored.finishedAt).toBeInstanceOf(Date);
    expect(JSON.parse(stored.result!)).toEqual(makeChatResult());
  });

  it('processNext passes the claimed JobRecord (with status=running, attempts incremented) to the handler', async () => {
    const handler = vi.fn(async (job: JobRecord) => {
      expect(job.status).toBe('running');
      expect(job.attempts).toBe(1);
      return makeChatResult();
    });
    registerHandler('chat', handler);
    storeJob({ id: 'job-1', type: 'chat', status: 'queued', attempts: 0 });
    await processNext();
    expect(handler).toHaveBeenCalledTimes(1);
  });

  it('processNext throws QueueError(NO_HANDLER) when no handler is registered for the type', async () => {
    storeJob({ id: 'job-1', type: 'reasoning', status: 'queued' });
    try {
      await processNext();
      expect.fail('Expected processNext to throw');
    } catch (err) {
      expect(isQueueError(err)).toBe(true);
      if (isQueueError(err)) expect(err.code).toBe('NO_HANDLER');
    }
    // The job should be marked terminal failure (status=failed)
    const stored = jobStore.get('job-1')!;
    expect(stored.status).toBe('failed');
    expect(stored.finishedAt).toBeInstanceOf(Date);
  });

  it('processNext retries the job when the handler throws and attempts < maxAttempts', async () => {
    const handler = vi.fn(async (): Promise<JobResult> => {
      throw new Error('transient');
    });
    registerHandler('chat', handler);
    storeJob({ id: 'job-1', type: 'chat', status: 'queued', attempts: 0, maxAttempts: 3 });

    const processed = await processNext();
    expect(processed).toBe(true);

    const stored = jobStore.get('job-1')!;
    expect(stored.status).toBe('queued'); // re-enqueued
    expect(stored.startedAt).toBeNull();
    expect(stored.finishedAt).toBeNull(); // not done
    expect(stored.error).toBe('transient');
    expect(stored.attempts).toBe(1); // incremented by claimNext
  });

  it('processNext marks the job as failed when the handler throws on the last attempt', async () => {
    const handler = vi.fn(async (): Promise<JobResult> => {
      throw new Error('final');
    });
    registerHandler('chat', handler);
    storeJob({ id: 'job-1', type: 'chat', status: 'queued', attempts: 2, maxAttempts: 3 });

    const processed = await processNext();
    expect(processed).toBe(true);

    const stored = jobStore.get('job-1')!;
    expect(stored.status).toBe('failed');
    expect(stored.finishedAt).toBeInstanceOf(Date);
    expect(stored.error).toBe('final');
    expect(stored.attempts).toBe(3); // 2 + 1 from claimNext
  });

  it('MAX_ATTEMPTS_EXCEEDED path: 3 failed processNext calls land the job in failed state', async () => {
    const handler = vi.fn(async (): Promise<JobResult> => {
      throw new Error('always');
    });
    registerHandler('chat', handler);

    const jobId = await enqueue('sess-1', 'chat', makeChatPayload(), { maxAttempts: 3 });

    // First attempt → re-enqueued
    await processNext();
    expect(jobStore.get(jobId)!.status).toBe('queued');
    expect(jobStore.get(jobId)!.attempts).toBe(1);

    // Second attempt → re-enqueued
    await processNext();
    expect(jobStore.get(jobId)!.status).toBe('queued');
    expect(jobStore.get(jobId)!.attempts).toBe(2);

    // Third attempt → terminal failure
    await processNext();
    expect(jobStore.get(jobId)!.status).toBe('failed');
    expect(jobStore.get(jobId)!.attempts).toBe(3);
    expect(jobStore.get(jobId)!.finishedAt).toBeInstanceOf(Date);
  });

  it('registerHandler replaces the previous handler for the same type', async () => {
    const handler1 = vi.fn(async () => makeChatResult());
    const handler2 = vi.fn(async () => makeChatResult());
    registerHandler('chat', handler1);
    registerHandler('chat', handler2);
    storeJob({ id: 'job-1', type: 'chat', status: 'queued' });
    await processNext();
    expect(handler1).not.toHaveBeenCalled();
    expect(handler2).toHaveBeenCalledTimes(1);
  });
});

// ─── parseJobPayload / parseJobResult ──────────────────────────────────────

describe('parseJobPayload', () => {
  it('round-trips a chat payload', () => {
    const original: JobPayload = makeChatPayload();
    const json = JSON.stringify(original);
    const parsed = parseJobPayload(json);
    expect(parsed).toEqual(original);
    expect(parsed.type).toBe('chat');
  });

  it('throws QueueError when the payload is not valid JSON', () => {
    try {
      parseJobPayload('not-json');
      expect.fail('Expected parseJobPayload to throw');
    } catch (err) {
      expect(isQueueError(err)).toBe(true);
    }
  });

  it('throws QueueError when the payload has no `type` field', () => {
    try {
      parseJobPayload(JSON.stringify({ sessionId: 's1' }));
      expect.fail('Expected parseJobPayload to throw');
    } catch (err) {
      expect(isQueueError(err)).toBe(true);
    }
  });

  it('throws QueueError when the payload is not an object', () => {
    try {
      parseJobPayload(JSON.stringify('string'));
      expect.fail('Expected parseJobPayload to throw');
    } catch (err) {
      expect(isQueueError(err)).toBe(true);
    }
  });
});

describe('parseJobResult', () => {
  it('round-trips a chat result', () => {
    const original: JobResult = makeChatResult();
    const json = JSON.stringify(original);
    const parsed = parseJobResult(json);
    expect(parsed).toEqual(original);
    expect(parsed.type).toBe('chat');
  });

  it('throws QueueError when the result is not valid JSON', () => {
    try {
      parseJobResult('not-json');
      expect.fail('Expected parseJobResult to throw');
    } catch (err) {
      expect(isQueueError(err)).toBe(true);
    }
  });

  it('throws QueueError when the result has no `type` field', () => {
    try {
      parseJobResult(JSON.stringify({ message: 'x' }));
      expect.fail('Expected parseJobResult to throw');
    } catch (err) {
      expect(isQueueError(err)).toBe(true);
    }
  });
});

// ─── Constants ─────────────────────────────────────────────────────────────

describe('constants', () => {
  it('DEFAULT_MAX_ATTEMPTS is 3', () => {
    expect(DEFAULT_MAX_ATTEMPTS).toBe(3);
  });

  it('DEFAULT_STALE_THRESHOLD_MS is 5 minutes (Blueprint §17)', () => {
    expect(DEFAULT_STALE_THRESHOLD_MS).toBe(5 * 60 * 1000);
  });
});

// ─── Type-level sanity ─────────────────────────────────────────────────────

describe('type-level sanity (compile-time checks)', () => {
  it('JobType includes all 5 documented types', () => {
    const types: JobType[] = ['chat', 'reasoning', 'agent_run', 'title_gen', 'mcp_discover'];
    expect(types).toHaveLength(5);
  });
});
