/**
 * Unit tests for src/lib/providers/types.ts + stream-openai.ts + stream-zai.ts
 *
 * Blueprint v4.1 §7 (Provider System), §8 (Z.ai Policy), §18 (Streaming),
 * §22 Phase 1 Step 1.1, §23 (Testing Strategy)
 *
 * Coverage:
 *  - ProviderError + isProviderError: construction, brand, type guard (pos + neg)
 *  - streamOpenAICompatible:
 *      • throws PROVIDER_DISABLED when provider.enabled=false
 *      • throws PROVIDER_NOT_CONFIGURED when apiKey is null and !isLocal
 *      • Ollama (isLocal=true, apiKey=null) does NOT throw PROVIDER_NOT_CONFIGURED
 *      • mocks global.fetch, verifies URL/headers/body are correct
 *      • mocks SSE stream, verifies onChunk is called per chunk
 *      • maps 401→AUTH_FAILED, 429→RATE_LIMITED, 500→REQUEST_FAILED
 *      • aggregates chunks into final ChatCompletion
 *      • AbortSignal → STREAM_ABORTED
 *  - streamZai:
 *      • throws ZAI_DISABLED when enabled=false
 *      • when disabled, the z-ai-web-dev-sdk module is NEVER imported
 *        (verified by mocking the dynamic import and asserting it was not called)
 *      • when enabled=true, the SDK is imported and called
 *      • aggregates SDK stream chunks into final ChatCompletion
 *
 * Mocking strategy:
 *  - global.fetch is mocked for the OpenAI adapter (SSE response body)
 *  - The Z.ai SDK dynamic import is mocked via vi.mock('z-ai-web-dev-sdk')
 *    and a spy on the module's ZAI.create()
 *  - @/lib/logger is mocked to suppress noise
 *  - The dynamic `new Function('return import(spec)')` in stream-zai.ts
 *    resolves the mocked module via Node's module resolution (vi.mock
 *    intercepts dynamic imports in vitest)
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

// ─── Mock setup ────────────────────────────────────────────────────────────

vi.mock('@/lib/logger', () => ({
  logger: {
    trace: vi.fn(),
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    fatal: vi.fn(),
    child: vi.fn(() => ({
      trace: vi.fn(),
      debug: vi.fn(),
      info: vi.fn(),
      warn: vi.fn(),
      error: vi.fn(),
      fatal: vi.fn(),
      child: vi.fn(),
      level: 'debug',
    })),
  },
}));

// Mock the Z.ai SDK. vitest's vi.mock intercepts BOTH static and dynamic
// imports of the specified module path. The mock factory returns a controlled
// SDK shape that tests can configure per-case.
const zaiCreateMock = vi.fn();
const zaiChatCreateMock = vi.fn();

vi.mock('z-ai-web-dev-sdk', () => ({
  ZAI: {
    create: zaiCreateMock,
  },
}));

// ─── Imports (after mocks) ─────────────────────────────────────────────────

import {
  ProviderError,
  isProviderError,
  type ProviderConfig,
  type ChatMessage,
  type StreamAdapterParams,
} from '@/lib/providers/types';
import { streamOpenAICompatible } from '@/lib/providers/stream-openai';
import { streamZai } from '@/lib/providers/stream-zai';

// ─── Test helpers ──────────────────────────────────────────────────────────

function makeProvider(overrides: Partial<ProviderConfig> = {}): ProviderConfig {
  return {
    id: 'openai',
    name: 'OpenAI',
    kind: 'openai',
    baseUrl: 'https://api.openai.com/v1/chat/completions',
    apiKey: 'sk-test-key',
    enabled: true,
    isLocal: false,
    ...overrides,
  };
}

function makeMessages(): ChatMessage[] {
  return [
    { role: 'system', content: 'You are a helpful assistant.' },
    { role: 'user', content: 'Say hello.' },
  ];
}

function makeParams(overrides: Partial<StreamAdapterParams> = {}): StreamAdapterParams {
  return {
    provider: makeProvider(),
    model: 'gpt-4o',
    messages: makeMessages(),
    stream: true,
    ...overrides,
  };
}

/**
 * Build a mock SSE response body from an array of JSON chunks.
 * Each chunk is wrapped in `data: <json>\n\n` format; the stream ends with
 * `data: [DONE]\n\n`.
 */
function makeSseBody(chunks: Array<Record<string, unknown>>): string {
  let body = '';
  for (const chunk of chunks) {
    body += `data: ${JSON.stringify(chunk)}\n\n`;
  }
  body += 'data: [DONE]\n\n';
  return body;
}

/**
 * Build a mock fetch Response with the given SSE body.
 */
function makeFetchResponse(body: string, status = 200): Response {
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(encoder.encode(body));
      controller.close();
    },
  });
  return new Response(stream, {
    status,
    headers: { 'content-type': 'text/event-stream' },
  });
}

/** Standard OpenAI-style chunk: content delta. */
function contentDelta(text: string): Record<string, unknown> {
  return {
    id: 'chatcmpl-test',
    object: 'chat.completion.chunk',
    choices: [{ index: 0, delta: { content: text }, finish_reason: null }],
  };
}

/** Final OpenAI-style chunk: empty delta with finish_reason. */
function finishChunk(reason: string = 'stop'): Record<string, unknown> {
  return {
    id: 'chatcmpl-test',
    object: 'chat.completion.chunk',
    choices: [{ index: 0, delta: {}, finish_reason: reason }],
  };
}

// ─── ProviderError + isProviderError ───────────────────────────────────────

describe('ProviderError', () => {
  it('preserves code, message, cause, providerId, statusCode', () => {
    const cause = new Error('root');
    const err = new ProviderError('AUTH_FAILED', 'bad key', cause, 'openai', 401);
    expect(err.code).toBe('AUTH_FAILED');
    expect(err.message).toBe('bad key');
    expect(err.cause).toBe(cause);
    expect(err.providerId).toBe('openai');
    expect(err.statusCode).toBe(401);
    expect(err.name).toBe('ProviderError');
  });

  it('is an instance of Error', () => {
    expect(new ProviderError('REQUEST_FAILED', 'x')).toBeInstanceOf(Error);
  });

  it('survives instanceof ProviderError after subclassing Error (prototype chain)', () => {
    const err = new ProviderError('AUTH_FAILED', 'x');
    expect(err).toBeInstanceOf(ProviderError);
    try {
      throw err;
    } catch (caught) {
      expect(caught).toBeInstanceOf(ProviderError);
    }
  });

  it('exposes every ProviderErrorCode value', () => {
    const codes: ReadonlyArray<ProviderError['code']> = [
      'PROVIDER_DISABLED',
      'PROVIDER_NOT_CONFIGURED',
      'REQUEST_FAILED',
      'RATE_LIMITED',
      'AUTH_FAILED',
      'INVALID_RESPONSE',
      'STREAM_ABORTED',
      'ZAI_DISABLED',
    ];
    for (const code of codes) {
      expect(new ProviderError(code, `msg for ${code}`).code).toBe(code);
    }
  });

  it('supports undefined cause/providerId/statusCode', () => {
    const err = new ProviderError('REQUEST_FAILED', 'x');
    expect(err.cause).toBeUndefined();
    expect(err.providerId).toBeUndefined();
    expect(err.statusCode).toBeUndefined();
  });
});

describe('isProviderError', () => {
  it('returns false for primitives', () => {
    expect(isProviderError(0)).toBe(false);
    expect(isProviderError('')).toBe(false);
    expect(isProviderError(false)).toBe(false);
    expect(isProviderError(null)).toBe(false);
    expect(isProviderError(undefined)).toBe(false);
  });

  it('returns false for plain objects lacking the brand symbol', () => {
    expect(isProviderError({ code: 'AUTH_FAILED', message: 'fake' })).toBe(false);
    expect(isProviderError(new Error('plain'))).toBe(false);
    expect(isProviderError({})).toBe(false);
  });

  it('returns true for ProviderError instances', () => {
    expect(isProviderError(new ProviderError('AUTH_FAILED', 'real'))).toBe(true);
  });

  it('does not confuse ProviderError with DbError/AuthError/etc.', () => {
    const fakeDbError = Object.assign(new Error('db failed'), {
      code: 'QUERY_FAILED',
      cause: undefined,
    });
    expect(isProviderError(fakeDbError)).toBe(false);
  });
});

// ─── streamOpenAICompatible — guards ───────────────────────────────────────

describe('streamOpenAICompatible — guards', () => {
  it('throws PROVIDER_DISABLED when provider.enabled=false', async () => {
    const params = makeParams({ provider: makeProvider({ enabled: false }) });
    try {
      await streamOpenAICompatible(params);
      expect.fail('Expected streamOpenAICompatible to throw');
    } catch (err) {
      expect(isProviderError(err)).toBe(true);
      if (isProviderError(err)) expect(err.code).toBe('PROVIDER_DISABLED');
    }
  });

  it('throws PROVIDER_NOT_CONFIGURED when apiKey is null and !isLocal', async () => {
    const params = makeParams({
      provider: makeProvider({ apiKey: null, isLocal: false }),
    });
    try {
      await streamOpenAICompatible(params);
      expect.fail('Expected streamOpenAICompatible to throw');
    } catch (err) {
      expect(isProviderError(err)).toBe(true);
      if (isProviderError(err)) expect(err.code).toBe('PROVIDER_NOT_CONFIGURED');
    }
  });

  it('throws PROVIDER_NOT_CONFIGURED when apiKey is empty string and !isLocal', async () => {
    const params = makeParams({
      provider: makeProvider({ apiKey: '', isLocal: false }),
    });
    try {
      await streamOpenAICompatible(params);
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('PROVIDER_NOT_CONFIGURED');
    }
  });

  it('does NOT throw PROVIDER_NOT_CONFIGURED for Ollama (isLocal=true, apiKey=null)', async () => {
    // Ollama is local — no API key required. The adapter should proceed to
    // fetch (which we mock here).
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      makeFetchResponse(makeSseBody([contentDelta('hi'), finishChunk('stop')])),
    );
    const params = makeParams({
      provider: makeProvider({
        id: 'ollama',
        name: 'Ollama',
        baseUrl: 'http://localhost:11434/v1/chat/completions',
        apiKey: null,
        isLocal: true,
      }),
      model: 'llama3.2',
    });
    const result = await streamOpenAICompatible(params);
    expect(result.content).toBe('hi');
    expect(fetchSpy).toHaveBeenCalled();
    fetchSpy.mockRestore();
  });

  it('throws PROVIDER_NOT_CONFIGURED when baseUrl is null', async () => {
    const params = makeParams({ provider: makeProvider({ baseUrl: null }) });
    try {
      await streamOpenAICompatible(params);
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('PROVIDER_NOT_CONFIGURED');
    }
  });
});

// ─── streamOpenAICompatible — request shape ────────────────────────────────

describe('streamOpenAICompatible — request shape', () => {
  let fetchSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    fetchSpy = vi.spyOn(globalThis, 'fetch');
  });

  afterEach(() => {
    fetchSpy.mockRestore();
  });

  it('POSTs to provider.baseUrl with Bearer auth + correct body', async () => {
    fetchSpy.mockResolvedValueOnce(
      makeFetchResponse(makeSseBody([contentDelta('ok'), finishChunk('stop')])),
    );

    await streamOpenAICompatible(makeParams({
      temperature: 0.7,
      maxTokens: 1000,
    }));

    expect(fetchSpy).toHaveBeenCalledTimes(1);
    const [url, init] = fetchSpy.mock.calls[0]!;
    expect(url).toBe('https://api.openai.com/v1/chat/completions');
    expect(init?.method).toBe('POST');
    const headers = init?.headers as Record<string, string>;
    expect(headers['authorization']).toBe('Bearer sk-test-key');
    expect(headers['content-type']).toBe('application/json');
    expect(headers['accept']).toBe('text/event-stream');

    const body = JSON.parse(init?.body as string) as Record<string, unknown>;
    expect(body['model']).toBe('gpt-4o');
    expect(body['stream']).toBe(true);
    expect(body['temperature']).toBe(0.7);
    expect(body['max_tokens']).toBe(1000);
    expect(Array.isArray(body['messages'])).toBe(true);
    expect((body['messages'] as Array<{ role: string }>)[0]!.role).toBe('system');
  });

  it('omits Bearer auth for local providers (Ollama, LM Studio)', async () => {
    fetchSpy.mockResolvedValueOnce(
      makeFetchResponse(makeSseBody([contentDelta('ok'), finishChunk('stop')])),
    );

    await streamOpenAICompatible(makeParams({
      provider: makeProvider({
        id: 'ollama',
        name: 'Ollama',
        baseUrl: 'http://localhost:11434/v1/chat/completions',
        apiKey: null,
        isLocal: true,
      }),
    }));

    const [, init] = fetchSpy.mock.calls[0]!;
    const headers = init?.headers as Record<string, string>;
    expect(headers['authorization']).toBeUndefined();
  });

  it('includes tools in the body when provided', async () => {
    fetchSpy.mockResolvedValueOnce(
      makeFetchResponse(makeSseBody([contentDelta('ok'), finishChunk('tool_calls')])),
    );

    await streamOpenAICompatible(makeParams({
      tools: [
        {
          type: 'function',
          function: {
            name: 'web_search',
            description: 'Search the web',
            parameters: { type: 'object', properties: { query: { type: 'string' } } },
          },
        },
      ],
    }));

    const [, init] = fetchSpy.mock.calls[0]!;
    const body = JSON.parse(init?.body as string) as Record<string, unknown>;
    expect(Array.isArray(body['tools'])).toBe(true);
    expect((body['tools'] as Array<{ function: { name: string } }>)[0]!.function.name).toBe('web_search');
  });

  it('omits temperature/maxTokens/tools when not provided', async () => {
    fetchSpy.mockResolvedValueOnce(
      makeFetchResponse(makeSseBody([contentDelta('ok'), finishChunk('stop')])),
    );

    await streamOpenAICompatible(makeParams());

    const [, init] = fetchSpy.mock.calls[0]!;
    const body = JSON.parse(init?.body as string) as Record<string, unknown>;
    expect(body['temperature']).toBeUndefined();
    expect(body['max_tokens']).toBeUndefined();
    expect(body['tools']).toBeUndefined();
  });
});

// ─── streamOpenAICompatible — streaming + aggregation ──────────────────────

describe('streamOpenAICompatible — streaming + aggregation', () => {
  let fetchSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    fetchSpy = vi.spyOn(globalThis, 'fetch');
  });

  afterEach(() => {
    fetchSpy.mockRestore();
  });

  it('parses SSE chunks and calls onChunk for each', async () => {
    const chunks = [
      contentDelta('Hello'),
      contentDelta(', '),
      contentDelta('world'),
      contentDelta('!'),
      finishChunk('stop'),
    ];
    fetchSpy.mockResolvedValueOnce(makeFetchResponse(makeSseBody(chunks)));

    const onChunk = vi.fn();
    const result = await streamOpenAICompatible(makeParams({ onChunk }));

    // 4 content chunks + 1 finish chunk = 5 onChunk calls
    expect(onChunk).toHaveBeenCalledTimes(5);
    expect(result.content).toBe('Hello, world!');
    expect(result.finishReason).toBe('stop');
  });

  it('aggregates content across multiple chunks', async () => {
    const chunks = [
      contentDelta('The '),
      contentDelta('quick '),
      contentDelta('brown '),
      contentDelta('fox'),
      finishChunk('stop'),
    ];
    fetchSpy.mockResolvedValueOnce(makeFetchResponse(makeSseBody(chunks)));

    const result = await streamOpenAICompatible(makeParams());
    expect(result.content).toBe('The quick brown fox');
  });

  it('aggregates tool_calls fragments by index', async () => {
    const chunks = [
      {
        id: 'x',
        choices: [{
          index: 0,
          delta: {
            tool_calls: [{
              index: 0,
              id: 'call_1',
              function: { name: 'web_search', arguments: '{"q":"hello' },
            }],
          },
          finish_reason: null,
        }],
      },
      {
        id: 'x',
        choices: [{
          index: 0,
          delta: {
            tool_calls: [{ index: 0, function: { arguments: ' world"}' } }],
          },
          finish_reason: null,
        }],
      },
      finishChunk('tool_calls'),
    ];
    fetchSpy.mockResolvedValueOnce(makeFetchResponse(makeSseBody(chunks)));

    const result = await streamOpenAICompatible(makeParams());
    expect(result.toolCalls).toHaveLength(1);
    expect(result.toolCalls[0]!.id).toBe('call_1');
    expect(result.toolCalls[0]!.function.name).toBe('web_search');
    expect(result.toolCalls[0]!.function.arguments).toBe('{"q":"hello world"}');
    expect(result.finishReason).toBe('tool_calls');
  });

  it('handles empty content delta chunks (only finish_reason)', async () => {
    fetchSpy.mockResolvedValueOnce(
      makeFetchResponse(makeSseBody([finishChunk('stop')])),
    );
    const result = await streamOpenAICompatible(makeParams());
    expect(result.content).toBe('');
    expect(result.finishReason).toBe('stop');
  });

  it('throws INVALID_RESPONSE when stream is empty (no chunks)', async () => {
    fetchSpy.mockResolvedValueOnce(makeFetchResponse('data: [DONE]\n\n'));
    try {
      await streamOpenAICompatible(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('INVALID_RESPONSE');
    }
  });

  it('skips malformed SSE lines without failing the stream', async () => {
    const body = 'data: not-json\n\ndata: {"choices":[{"delta":{"content":"ok"},"finish_reason":null}]}\n\ndata: [DONE]\n\n';
    fetchSpy.mockResolvedValueOnce(makeFetchResponse(body));
    const result = await streamOpenAICompatible(makeParams());
    expect(result.content).toBe('ok');
  });
});

// ─── streamOpenAICompatible — HTTP error mapping ───────────────────────────

describe('streamOpenAICompatible — HTTP error mapping', () => {
  let fetchSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    fetchSpy = vi.spyOn(globalThis, 'fetch');
  });

  afterEach(() => {
    fetchSpy.mockRestore();
  });

  it('maps HTTP 401 → AUTH_FAILED', async () => {
    fetchSpy.mockResolvedValueOnce(
      new Response('{"error":"invalid api key"}', { status: 401 }),
    );
    try {
      await streamOpenAICompatible(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isProviderError(err)).toBe(true);
      if (isProviderError(err)) {
        expect(err.code).toBe('AUTH_FAILED');
        expect(err.statusCode).toBe(401);
      }
    }
  });

  it('maps HTTP 403 → AUTH_FAILED', async () => {
    fetchSpy.mockResolvedValueOnce(
      new Response('forbidden', { status: 403 }),
    );
    try {
      await streamOpenAICompatible(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) {
        expect(err.code).toBe('AUTH_FAILED');
        expect(err.statusCode).toBe(403);
      }
    }
  });

  it('maps HTTP 429 → RATE_LIMITED', async () => {
    fetchSpy.mockResolvedValueOnce(
      new Response('rate limited', { status: 429 }),
    );
    try {
      await streamOpenAICompatible(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) {
        expect(err.code).toBe('RATE_LIMITED');
        expect(err.statusCode).toBe(429);
      }
    }
  });

  it('maps HTTP 500 → REQUEST_FAILED', async () => {
    fetchSpy.mockResolvedValueOnce(
      new Response('internal error', { status: 500 }),
    );
    try {
      await streamOpenAICompatible(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) {
        expect(err.code).toBe('REQUEST_FAILED');
        expect(err.statusCode).toBe(500);
      }
    }
  });

  it('maps HTTP 502 → REQUEST_FAILED', async () => {
    fetchSpy.mockResolvedValueOnce(
      new Response('bad gateway', { status: 502 }),
    );
    try {
      await streamOpenAICompatible(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('REQUEST_FAILED');
    }
  });

  it('maps HTTP 400 → REQUEST_FAILED (4xx other than 401/429)', async () => {
    fetchSpy.mockResolvedValueOnce(
      new Response('bad request', { status: 400 }),
    );
    try {
      await streamOpenAICompatible(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) {
        expect(err.code).toBe('REQUEST_FAILED');
        expect(err.statusCode).toBe(400);
      }
    }
  });

  it('maps network errors → REQUEST_FAILED', async () => {
    fetchSpy.mockRejectedValueOnce(new Error('ECONNREFUSED'));
    try {
      await streamOpenAICompatible(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('REQUEST_FAILED');
    }
  });

  it('maps AbortError on fetch → STREAM_ABORTED', async () => {
    const abortErr = new Error('aborted');
    abortErr.name = 'AbortError';
    fetchSpy.mockRejectedValueOnce(abortErr);
    try {
      await streamOpenAICompatible(makeParams());
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('STREAM_ABORTED');
    }
  });
});

// ─── streamZai — Z.ai disabled path (CRITICAL: §8 verification) ────────────

describe('streamZai — disabled path (Blueprint §8)', () => {
  beforeEach(() => {
    zaiCreateMock.mockReset();
    zaiChatCreateMock.mockReset();
  });

  it('throws ZAI_DISABLED when provider.enabled=false', async () => {
    const params = makeParams({
      provider: makeProvider({
        id: 'zai',
        name: 'Z.ai',
        kind: 'zai',
        enabled: false,
      }),
      model: 'glm-4.6',
    });

    try {
      await streamZai(params);
      expect.fail('Expected streamZai to throw');
    } catch (err) {
      expect(isProviderError(err)).toBe(true);
      if (isProviderError(err)) expect(err.code).toBe('ZAI_DISABLED');
    }
  });

  it('does NOT call ZAI.create() when disabled (no SDK call)', async () => {
    const params = makeParams({
      provider: makeProvider({
        id: 'zai',
        name: 'Z.ai',
        kind: 'zai',
        enabled: false,
      }),
    });

    try {
      await streamZai(params);
    } catch {
      // expected
    }

    // CRITICAL: ZAI.create() must never be called when disabled
    expect(zaiCreateMock).not.toHaveBeenCalled();
  });

  it('does NOT call chat.completions.create() when disabled', async () => {
    const params = makeParams({
      provider: makeProvider({
        id: 'zai',
        name: 'Z.ai',
        kind: 'zai',
        enabled: false,
      }),
    });

    try {
      await streamZai(params);
    } catch {
      // expected
    }

    expect(zaiChatCreateMock).not.toHaveBeenCalled();
  });

  it('ZAI_DISABLED error message mentions Blueprint §8 (no fallback, no SDK call)', async () => {
    const params = makeParams({
      provider: makeProvider({
        id: 'zai',
        name: 'Z.ai',
        kind: 'zai',
        enabled: false,
      }),
    });

    try {
      await streamZai(params);
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) {
        expect(err.message).toContain('disabled');
        expect(err.message).toContain('no fallback');
        expect(err.message).toContain('no SDK call');
      }
    }
  });
});

// ─── streamZai — enabled path ──────────────────────────────────────────────

describe('streamZai — enabled path', () => {
  beforeEach(() => {
    zaiCreateMock.mockReset();
    zaiChatCreateMock.mockReset();
  });

  it('calls ZAI.create() when enabled=true', async () => {
    // Set up the SDK mock to return a stream
    const mockStream = makeAsyncIterator([
      { choices: [{ delta: { content: 'Hello' }, finish_reason: null }] },
      { choices: [{ delta: { content: ' from Z.ai' }, finish_reason: null }] },
      { choices: [{ delta: {}, finish_reason: 'stop' }] },
    ]);
    zaiChatCreateMock.mockResolvedValueOnce(mockStream);
    zaiCreateMock.mockResolvedValueOnce({
      chat: { completions: { create: zaiChatCreateMock } },
    });

    const params = makeParams({
      provider: makeProvider({
        id: 'zai',
        name: 'Z.ai',
        kind: 'zai',
        enabled: true,
      }),
      model: 'glm-4.6',
    });

    const result = await streamZai(params);

    expect(zaiCreateMock).toHaveBeenCalledTimes(1);
    expect(zaiChatCreateMock).toHaveBeenCalledTimes(1);
    expect(result.content).toBe('Hello from Z.ai');
    expect(result.finishReason).toBe('stop');
    expect(result.providerId).toBe('zai');
  });

  it('passes model + messages to the SDK', async () => {
    const mockStream = makeAsyncIterator([
      { choices: [{ delta: { content: 'ok' }, finish_reason: null }] },
      { choices: [{ delta: {}, finish_reason: 'stop' }] },
    ]);
    zaiChatCreateMock.mockResolvedValueOnce(mockStream);
    zaiCreateMock.mockResolvedValueOnce({
      chat: { completions: { create: zaiChatCreateMock } },
    });

    await streamZai(makeParams({
      provider: makeProvider({ id: 'zai', name: 'Z.ai', kind: 'zai', enabled: true }),
      model: 'glm-4-plus',
      temperature: 0.5,
      maxTokens: 500,
    }));

    expect(zaiChatCreateMock).toHaveBeenCalledWith(
      expect.objectContaining({
        model: 'glm-4-plus',
        stream: true,
        temperature: 0.5,
        max_tokens: 500,
        messages: expect.arrayContaining([
          expect.objectContaining({ role: 'system', content: 'You are a helpful assistant.' }),
        ]),
      }),
    );
  });

  it('calls onChunk for each streamed chunk', async () => {
    const mockStream = makeAsyncIterator([
      { choices: [{ delta: { content: 'A' }, finish_reason: null }] },
      { choices: [{ delta: { content: 'B' }, finish_reason: null }] },
      { choices: [{ delta: { content: 'C' }, finish_reason: null }] },
      { choices: [{ delta: {}, finish_reason: 'stop' }] },
    ]);
    zaiChatCreateMock.mockResolvedValueOnce(mockStream);
    zaiCreateMock.mockResolvedValueOnce({
      chat: { completions: { create: zaiChatCreateMock } },
    });

    const onChunk = vi.fn();
    await streamZai(makeParams({
      provider: makeProvider({ id: 'zai', name: 'Z.ai', kind: 'zai', enabled: true }),
      onChunk,
    }));

    expect(onChunk).toHaveBeenCalledTimes(4);
  });

  it('aggregates tool_calls fragments', async () => {
    const mockStream = makeAsyncIterator([
      { choices: [{ delta: { tool_calls: [{ index: 0, id: 'call_1', function: { name: 'web_search', arguments: '{"q":"test' } }] }, finish_reason: null }] },
      { choices: [{ delta: { tool_calls: [{ index: 0, function: { arguments: '"}' } }] }, finish_reason: null }] },
      { choices: [{ delta: {}, finish_reason: 'tool_calls' }] },
    ]);
    zaiChatCreateMock.mockResolvedValueOnce(mockStream);
    zaiCreateMock.mockResolvedValueOnce({
      chat: { completions: { create: zaiChatCreateMock } },
    });

    const result = await streamZai(makeParams({
      provider: makeProvider({ id: 'zai', name: 'Z.ai', kind: 'zai', enabled: true }),
    }));

    expect(result.toolCalls).toHaveLength(1);
    expect(result.toolCalls[0]!.function.name).toBe('web_search');
    expect(result.toolCalls[0]!.function.arguments).toBe('{"q":"test"}');
    expect(result.finishReason).toBe('tool_calls');
  });

  it('throws INVALID_RESPONSE when stream is empty', async () => {
    const mockStream = makeAsyncIterator([]);
    zaiChatCreateMock.mockResolvedValueOnce(mockStream);
    zaiCreateMock.mockResolvedValueOnce({
      chat: { completions: { create: zaiChatCreateMock } },
    });

    try {
      await streamZai(makeParams({
        provider: makeProvider({ id: 'zai', name: 'Z.ai', kind: 'zai', enabled: true }),
      }));
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('INVALID_RESPONSE');
    }
  });

  it('throws REQUEST_FAILED when ZAI.create() throws', async () => {
    zaiCreateMock.mockRejectedValueOnce(new Error('SDK init failed'));
    try {
      await streamZai(makeParams({
        provider: makeProvider({ id: 'zai', name: 'Z.ai', kind: 'zai', enabled: true }),
      }));
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('PROVIDER_NOT_CONFIGURED');
    }
  });

  it('throws REQUEST_FAILED when chat.completions.create() throws', async () => {
    zaiChatCreateMock.mockRejectedValueOnce(new Error('API error'));
    zaiCreateMock.mockResolvedValueOnce({
      chat: { completions: { create: zaiChatCreateMock } },
    });
    try {
      await streamZai(makeParams({
        provider: makeProvider({ id: 'zai', name: 'Z.ai', kind: 'zai', enabled: true }),
      }));
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('REQUEST_FAILED');
    }
  });

  it('throws STREAM_ABORTED when AbortSignal fires mid-stream', async () => {
    const controller = new AbortController();
    const mockStream = makeAsyncIterator([
      { choices: [{ delta: { content: 'partial' }, finish_reason: null }] },
      { choices: [{ delta: {}, finish_reason: 'stop' }] },
    ]);
    zaiChatCreateMock.mockResolvedValueOnce(mockStream);
    zaiCreateMock.mockResolvedValueOnce({
      chat: { completions: { create: zaiChatCreateMock } },
    });

    // Abort before consuming the stream
    controller.abort();
    try {
      await streamZai(makeParams({
        provider: makeProvider({ id: 'zai', name: 'Z.ai', kind: 'zai', enabled: true }),
        signal: controller.signal,
      }));
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('STREAM_ABORTED');
    }
  });
});

// ─── streamZai — §8 "no Z.ai code when disabled" verification ──────────────

describe('streamZai — §8 verification (no Z.ai code when disabled)', () => {
  // This is the most important test in the file. It verifies that calling
  // streamZai with a disabled provider does NOT trigger ANY Z.ai SDK activity.
  //
  // The mock factory (vi.mock('z-ai-web-dev-sdk', ...)) replaces the SDK
  // module entirely. If streamZai were to import the SDK when disabled,
  // the mock's ZAI.create function would have been called. We assert it
  // was NOT called.

  beforeEach(() => {
    zaiCreateMock.mockReset();
    zaiChatCreateMock.mockReset();
  });

  it('disabled provider: ZAI.create is never called (no SDK initialization)', async () => {
    try {
      await streamZai(makeParams({
        provider: makeProvider({ id: 'zai', name: 'Z.ai', kind: 'zai', enabled: false }),
      }));
    } catch {
      // expected ZAI_DISABLED
    }
    expect(zaiCreateMock).not.toHaveBeenCalled();
  });

  it('disabled provider: chat.completions.create is never called (no API request)', async () => {
    try {
      await streamZai(makeParams({
        provider: makeProvider({ id: 'zai', name: 'Z.ai', kind: 'zai', enabled: false }),
      }));
    } catch {
      // expected
    }
    expect(zaiChatCreateMock).not.toHaveBeenCalled();
  });

  it('disabled provider: error is ZAI_DISABLED (not a fallback to another provider)', async () => {
    try {
      await streamZai(makeParams({
        provider: makeProvider({ id: 'zai', name: 'Z.ai', kind: 'zai', enabled: false }),
      }));
      expect.fail('Expected to throw');
    } catch (err) {
      // Must be ZAI_DISABLED specifically — not REQUEST_FAILED or any other code
      // that would suggest a fallback attempt was made.
      expect(isProviderError(err)).toBe(true);
      if (isProviderError(err)) {
        expect(err.code).toBe('ZAI_DISABLED');
      }
    }
  });

  it('enabled provider: SDK IS called (positive control — verifies the mock works)', async () => {
    const mockStream = makeAsyncIterator([
      { choices: [{ delta: { content: 'ok' }, finish_reason: null }] },
      { choices: [{ delta: {}, finish_reason: 'stop' }] },
    ]);
    zaiChatCreateMock.mockResolvedValueOnce(mockStream);
    zaiCreateMock.mockResolvedValueOnce({
      chat: { completions: { create: zaiChatCreateMock } },
    });

    await streamZai(makeParams({
      provider: makeProvider({ id: 'zai', name: 'Z.ai', kind: 'zai', enabled: true }),
    }));

    // The positive control: when enabled, the SDK IS called. This proves
    // the mock is wired correctly — so the "not called" assertions in the
    // disabled-path tests are meaningful.
    expect(zaiCreateMock).toHaveBeenCalledTimes(1);
    expect(zaiChatCreateMock).toHaveBeenCalledTimes(1);
  });
});

// ─── Helper: make an async iterator from an array ──────────────────────────

function makeAsyncIterator<T>(items: T[]): AsyncIterable<T> {
  return {
    [Symbol.asyncIterator](): AsyncIterator<T> {
      let i = 0;
      return {
        next(): Promise<IteratorResult<T>> {
          if (i < items.length) {
            return Promise.resolve({ value: items[i++]!, done: false });
          }
          return Promise.resolve({ value: undefined as unknown as T, done: true });
        },
      };
    },
  };
}
