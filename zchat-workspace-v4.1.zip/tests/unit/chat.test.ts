/**
 * Unit tests for src/lib/chat/messages.ts + stream.ts
 *
 * Blueprint v4.1 §18 (SSE), §4 (NO pending state), §22 Phase 1 Step 1.4
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';

// ─── Mock setup ────────────────────────────────────────────────────────────

type StoredMessage = {
  id: string;
  sessionId: string;
  role: string;
  content: string;
  toolCalls: string;
  tokens: number;
  costUsd: number;
  providerId: string | null;
  model: string | null;
  agentRunId: string | null;
  createdAt: Date;
};

type StoredSession = {
  id: string;
  workspaceId: string;
  title: string;
  status: string;
  createdAt: Date;
  updatedAt: Date;
};

type StoredProvider = {
  id: string;
  name: string;
  kind: string;
  baseUrl: string | null;
  apiKey: string | null;
  enabled: boolean;
  isLocal: boolean;
};

type StoredSkill = {
  id: string;
  name: string;
  systemPrompt: string;
  strength: number;
  enabled: boolean;
};

const messageStore = new Map<string, StoredMessage>();
const sessionStore = new Map<string, StoredSession>();
const providerStore = new Map<string, StoredProvider>();
const skillStore = new Map<string, StoredSkill>();
let msgIdCounter = 0;

const dbMock = {
  message: {
    findUnique: vi.fn(async (args: { where: { id: string } }) => messageStore.get(args.where.id) ?? null),
    findMany: vi.fn(async (args: {
      where?: Record<string, unknown>;
      orderBy?: Array<Record<string, 'asc' | 'desc'>>;
      take?: number;
    }) => {
      let entries = Array.from(messageStore.values());
      const where = args.where ?? {};
      if (where['sessionId'] !== undefined) {
        entries = entries.filter((e) => e.sessionId === where['sessionId']);
      }
      if (where['OR'] !== undefined) {
        const orClauses = where['OR'] as Array<Record<string, unknown>>;
        entries = entries.filter((entry) =>
          orClauses.some((clause) => {
            if (clause['createdAt']) {
              const f = clause['createdAt'] as { gt?: Date };
              if (f.gt && entry.createdAt <= f.gt) return false;
            }
            return true;
          }),
        );
      }
      if (args.orderBy) {
        for (const ob of [...args.orderBy].reverse()) {
          for (const [field, dir] of Object.entries(ob)) {
            entries.sort((a, b) => {
              const av = (a as Record<string, unknown>)[field];
              const bv = (b as Record<string, unknown>)[field];
              let cmp = 0;
              if (av instanceof Date && bv instanceof Date) cmp = av.getTime() - bv.getTime();
              else if (typeof av === 'string' && typeof bv === 'string') cmp = av < bv ? -1 : av > bv ? 1 : 0;
              return dir === 'asc' ? cmp : -cmp;
            });
          }
        }
      }
      if (args.take !== undefined) entries = entries.slice(0, args.take);
      return entries;
    }),
    create: vi.fn(async (args: { data: Partial<StoredMessage> }) => {
      const id = `msg-${++msgIdCounter}`;
      const msg: StoredMessage = {
        id,
        sessionId: args.data.sessionId!,
        role: args.data.role ?? 'user',
        content: args.data.content ?? '',
        toolCalls: args.data.toolCalls ?? '[]',
        tokens: args.data.tokens ?? 0,
        costUsd: args.data.costUsd ?? 0,
        providerId: args.data.providerId ?? null,
        model: args.data.model ?? null,
        agentRunId: args.data.agentRunId ?? null,
        createdAt: new Date(),
      };
      messageStore.set(id, msg);
      return msg;
    }),
  },
  session: {
    findUnique: vi.fn(async (args: { where: { id: string } }) => sessionStore.get(args.where.id) ?? null),
  },
  provider: {
    findUnique: vi.fn(async (args: { where: { id: string } }) => providerStore.get(args.where.id) ?? null),
  },
  skill: {
    findMany: vi.fn(async (args: { where?: Record<string, unknown>; orderBy?: Record<string, 'asc' | 'desc'> }) => {
      let entries = Array.from(skillStore.values());
      const where = args.where ?? {};
      if (where['id']) {
        const idFilter = where['id'] as { in?: string[] };
        if (idFilter.in) entries = entries.filter((e) => idFilter.in!.includes(e.id));
      }
      if (where['enabled'] !== undefined) {
        entries = entries.filter((e) => e.enabled === where['enabled']);
      }
      if (args.orderBy && args.orderBy['strength']) {
        entries.sort((a, b) => args.orderBy!['strength'] === 'asc' ? a.strength - b.strength : b.strength - a.strength);
      }
      return entries;
    }),
  },
};

vi.mock('@/lib/db', () => ({ db: dbMock }));

vi.mock('@/lib/logger', () => ({
  logger: {
    trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
    child: vi.fn(() => ({
      trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
      child: vi.fn(), level: 'debug',
    })),
  },
}));

const streamOpenAIMock = vi.fn();
vi.mock('@/lib/providers/stream-openai', () => ({ streamOpenAICompatible: streamOpenAIMock }));

const streamZaiMock = vi.fn();
vi.mock('@/lib/providers/stream-zai', () => ({ streamZai: streamZaiMock }));

// ─── Imports ───────────────────────────────────────────────────────────────

import {
  createMessage,
  getMessages,
  getMessage,
  MessageError,
  isMessageError,
  type MessageRecord,
} from '@/lib/chat/messages';
import { streamChat, streamChatToSse, type StreamChatParams } from '@/lib/chat/stream';

// ─── Helpers ───────────────────────────────────────────────────────────────

const WS_1 = 'ws-1';
const WS_2 = 'ws-2';
const SESS_1 = 'sess-1';
const PROVIDER_OPENAI = 'openai';
const PROVIDER_ZAI = 'zai';

function resetStores(): void {
  messageStore.clear();
  sessionStore.clear();
  providerStore.clear();
  skillStore.clear();
  msgIdCounter = 0;
  for (const fn of Object.values(dbMock.message)) (fn as ReturnType<typeof vi.fn>).mockClear();
  dbMock.session.findUnique.mockClear();
  dbMock.provider.findUnique.mockClear();
  dbMock.skill.findMany.mockClear();
  streamOpenAIMock.mockReset();
  streamZaiMock.mockReset();
}

function seedSession(overrides: Partial<StoredSession> = {}): StoredSession {
  const s: StoredSession = {
    id: overrides.id ?? SESS_1,
    workspaceId: overrides.workspaceId ?? WS_1,
    title: overrides.title ?? 'Test',
    status: overrides.status ?? 'idle',
    createdAt: overrides.createdAt ?? new Date(),
    updatedAt: overrides.updatedAt ?? new Date(),
  };
  sessionStore.set(s.id, s);
  return s;
}

function seedProvider(overrides: Partial<StoredProvider> = {}): StoredProvider {
  const p: StoredProvider = {
    id: overrides.id ?? PROVIDER_OPENAI,
    name: overrides.name ?? 'OpenAI',
    kind: overrides.kind ?? 'openai',
    baseUrl: overrides.baseUrl ?? 'https://api.openai.com/v1/chat/completions',
    apiKey: overrides.apiKey ?? 'sk-test',
    enabled: overrides.enabled ?? true,
    isLocal: overrides.isLocal ?? false,
  };
  providerStore.set(p.id, p);
  return p;
}

function seedMessage(overrides: Partial<StoredMessage> = {}): StoredMessage {
  const id = overrides.id ?? `msg-${++msgIdCounter}`;
  const m: StoredMessage = {
    id,
    sessionId: overrides.sessionId ?? SESS_1,
    role: overrides.role ?? 'user',
    content: overrides.content ?? 'hello',
    toolCalls: overrides.toolCalls ?? '[]',
    tokens: overrides.tokens ?? 0,
    costUsd: overrides.costUsd ?? 0,
    providerId: overrides.providerId ?? null,
    model: overrides.model ?? null,
    agentRunId: overrides.agentRunId ?? null,
    createdAt: overrides.createdAt ?? new Date(),
  };
  messageStore.set(id, m);
  return m;
}

function makeCompletion(content: string) {
  return {
    content,
    toolCalls: [],
    finishReason: 'stop',
    tokensUsed: Math.ceil(content.length / 4),
    costUsd: 0,
    model: 'test',
    providerId: 'test',
  };
}

function makeParams(overrides: Partial<StreamChatParams> = {}): StreamChatParams {
  return {
    sessionId: SESS_1,
    workspaceId: WS_1,
    userId: 'user-1',
    content: 'Hello, how are you?',
    providerId: PROVIDER_OPENAI,
    model: 'gpt-4o',
    ...overrides,
  };
}

// ─── MessageError + isMessageError ─────────────────────────────────────────

describe('MessageError', () => {
  it('preserves code, message, cause, messageId', () => {
    const cause = new Error('root');
    const err = new MessageError('MESSAGE_NOT_FOUND', 'missing', cause, 'msg-1');
    expect(err.code).toBe('MESSAGE_NOT_FOUND');
    expect(err.message).toBe('missing');
    expect(err.cause).toBe(cause);
    expect(err.messageId).toBe('msg-1');
    expect(err.name).toBe('MessageError');
  });

  it('is an instance of Error', () => {
    expect(new MessageError('CREATE_FAILED', 'x')).toBeInstanceOf(Error);
  });

  it('survives instanceof after subclassing Error', () => {
    const err = new MessageError('LIST_FAILED', 'x');
    expect(err).toBeInstanceOf(MessageError);
  });

  it('exposes every MessageErrorCode', () => {
    const codes: ReadonlyArray<MessageError['code']> = ['MESSAGE_NOT_FOUND', 'CREATE_FAILED', 'LIST_FAILED'];
    for (const code of codes) {
      expect(new MessageError(code, `msg for ${code}`).code).toBe(code);
    }
  });
});

describe('isMessageError', () => {
  it('returns false for primitives + plain objects', () => {
    expect(isMessageError(0)).toBe(false);
    expect(isMessageError(null)).toBe(false);
    expect(isMessageError({})).toBe(false);
    expect(isMessageError(new Error('plain'))).toBe(false);
  });

  it('returns true for MessageError instances', () => {
    expect(isMessageError(new MessageError('CREATE_FAILED', 'x'))).toBe(true);
  });
});

// ─── createMessage ─────────────────────────────────────────────────────────

describe('createMessage', () => {
  beforeEach(() => resetStores());

  it('creates a user message with default values', async () => {
    const msg = await createMessage(SESS_1, 'user', 'hello');
    expect(msg.role).toBe('user');
    expect(msg.content).toBe('hello');
    expect(msg.tokens).toBe(0);
    expect(msg.costUsd).toBe(0);
    expect(msg.toolCalls).toEqual([]);
    expect(msg.providerId).toBeNull();
    expect(msg.model).toBeNull();
  });

  it('creates an assistant message with tokens + cost + toolCalls', async () => {
    const toolCalls = [{ id: 'tc-1', type: 'function' as const, function: { name: 'web_search', arguments: '{}' } }];
    const msg = await createMessage(SESS_1, 'assistant', 'response', {
      providerId: 'openai',
      model: 'gpt-4o',
      tokens: 42,
      costUsd: 0.001,
      toolCalls,
    });
    expect(msg.role).toBe('assistant');
    expect(msg.tokens).toBe(42);
    expect(msg.costUsd).toBe(0.001);
    expect(msg.providerId).toBe('openai');
    expect(msg.model).toBe('gpt-4o');
    expect(msg.toolCalls).toEqual(toolCalls);
  });

  it('parses toolCalls JSON on the returned record', async () => {
    const msg = await createMessage(SESS_1, 'assistant', 'x', {
      toolCalls: [{ id: 'tc-1', type: 'function' as const, function: { name: 'search', arguments: '{}' } }],
    });
    expect(Array.isArray(msg.toolCalls)).toBe(true);
    expect(msg.toolCalls[0]!.function.name).toBe('search');
  });
});

// ─── getMessages ───────────────────────────────────────────────────────────

describe('getMessages', () => {
  beforeEach(() => resetStores());

  it('returns messages ordered by createdAt ASC', async () => {
    seedSession();
    const t0 = new Date('2025-01-01T00:00:00Z');
    const t1 = new Date('2025-01-02T00:00:00Z');
    seedMessage({ id: 'm2', createdAt: t1, content: 'second' });
    seedMessage({ id: 'm1', createdAt: t0, content: 'first' });
    const msgs = await getMessages(SESS_1, WS_1);
    expect(msgs).toHaveLength(2);
    expect(msgs[0]!.id).toBe('m1');
    expect(msgs[1]!.id).toBe('m2');
  });

  it('throws WORKSPACE_MISMATCH when session belongs to a different workspace', async () => {
    seedSession({ workspaceId: WS_2 });
    try {
      await getMessages(SESS_1, WS_1);
      expect.fail('Expected to throw');
    } catch (err) {
      // getSession throws SessionError, not MessageError — but getMessages re-throws it
      expect(err).toBeDefined();
    }
  });

  it('respects the limit parameter', async () => {
    seedSession();
    for (let i = 0; i < 10; i++) {
      seedMessage({ id: `m${i}`, createdAt: new Date(2025, 0, 1, 0, i) });
    }
    const msgs = await getMessages(SESS_1, WS_1, { limit: 3 });
    expect(msgs).toHaveLength(3);
  });

  it('caps limit at 200', async () => {
    seedSession();
    const msgs = await getMessages(SESS_1, WS_1, { limit: 500 });
    expect(msgs).toHaveLength(0); // no messages seeded
  });
});

// ─── getMessage ────────────────────────────────────────────────────────────

describe('getMessage', () => {
  beforeEach(() => resetStores());

  it('returns the message when it exists in the workspace', async () => {
    seedSession();
    seedMessage({ id: 'm1', content: 'hello' });
    const msg = await getMessage('m1', WS_1);
    expect(msg.id).toBe('m1');
    expect(msg.content).toBe('hello');
  });

  it('throws MESSAGE_NOT_FOUND when the message does not exist', async () => {
    try {
      await getMessage('nonexistent', WS_1);
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isMessageError(err)).toBe(true);
      if (isMessageError(err)) expect(err.code).toBe('MESSAGE_NOT_FOUND');
    }
  });
});

// ─── streamChat — event sequence ───────────────────────────────────────────

describe('streamChat — event sequence', () => {
  beforeEach(() => resetStores());

  it('yields user_message_saved → token → assistant_message_saved', async () => {
    seedSession();
    seedProvider();
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('I am fine, thank you!'));

    const events: Awaited<ReturnType<typeof streamChat.next>>[] = [];
    const gen = streamChat(makeParams());
    let result = await gen.next();
    while (!result.done) {
      events.push(result as Awaited<ReturnType<typeof streamChat>>);
      result = await gen.next();
    }

    const types = events.map((e) => e.value.type);
    expect(types).toEqual(['user_message_saved', 'token', 'assistant_message_saved']);
  });

  it('persists the user message BEFORE streaming starts', async () => {
    seedSession();
    seedProvider();
    streamOpenAIMock.mockImplementationOnce(async () => {
      // Verify the user message was already persisted before the adapter is called
      expect(messageStore.size).toBe(1);
      const userMsg = Array.from(messageStore.values())[0]!;
      expect(userMsg.role).toBe('user');
      return makeCompletion('response');
    });

    const gen = streamChat(makeParams());
    await gen.next(); // user_message_saved
    await gen.next(); // token
    await gen.next(); // assistant_message_saved
  });

  it('persists the assistant message AFTER streaming completes', async () => {
    seedSession();
    seedProvider();
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('assistant response'));

    const gen = streamChat(makeParams());
    await gen.next(); // user_message_saved
    await gen.next(); // token

    // At this point, only the user message should be persisted
    expect(messageStore.size).toBe(1);

    await gen.next(); // assistant_message_saved

    // Now both messages should be persisted
    expect(messageStore.size).toBe(2);
    const assistantMsg = Array.from(messageStore.values()).find((m) => m.role === 'assistant');
    expect(assistantMsg).toBeDefined();
    expect(assistantMsg!.content).toBe('assistant response');
  });

  it('RBAC: throws if session does not belong to workspace', async () => {
    seedSession({ workspaceId: WS_2 });
    try {
      const gen = streamChat(makeParams({ workspaceId: WS_1 }));
      await gen.next();
      expect.fail('Expected to throw');
    } catch (err) {
      expect(err).toBeDefined();
    }
  });

  it('dispatches to streamOpenAICompatible for kind=openai', async () => {
    seedSession();
    seedProvider({ id: PROVIDER_OPENAI, kind: 'openai' });
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('ok'));

    const gen = streamChat(makeParams({ providerId: PROVIDER_OPENAI }));
    await gen.next(); // user_message_saved
    await gen.next(); // token
    await gen.next(); // assistant_message_saved

    expect(streamOpenAIMock).toHaveBeenCalledTimes(1);
    expect(streamZaiMock).not.toHaveBeenCalled();
  });

  it('dispatches to streamZai for kind=zai', async () => {
    seedSession();
    seedProvider({ id: PROVIDER_ZAI, kind: 'zai', baseUrl: null });
    streamZaiMock.mockResolvedValueOnce(makeCompletion('GLM response'));

    const gen = streamChat(makeParams({ providerId: PROVIDER_ZAI }));
    await gen.next();
    await gen.next();
    await gen.next();

    expect(streamZaiMock).toHaveBeenCalledTimes(1);
    expect(streamOpenAIMock).not.toHaveBeenCalled();
  });

  it('yields error event + persists error message when adapter throws', async () => {
    seedSession();
    seedProvider();
    const { ProviderError } = await import('@/lib/providers/types');
    streamOpenAIMock.mockRejectedValueOnce(new ProviderError('AUTH_FAILED', 'bad key'));

    const gen = streamChat(makeParams());
    const events: ChatStreamEvent[] = [];
    let result = await gen.next();
    while (!result.done) {
      events.push(result.value);
      result = await gen.next();
    }

    const types = events.map((e) => e.type);
    expect(types).toContain('error');
    expect(types).toContain('assistant_message_saved');

    const errorEvent = events.find((e) => e.type === 'error');
    expect(errorEvent!.type === 'error' && errorEvent.code).toBe('AUTH_FAILED');

    // An assistant message with the error text should be persisted
    const assistantMsg = Array.from(messageStore.values()).find((m) => m.role === 'assistant');
    expect(assistantMsg).toBeDefined();
    expect(assistantMsg!.content).toContain('bad key');
  });

  it('passes the AbortSignal to the adapter', async () => {
    seedSession();
    seedProvider();
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('ok'));

    const controller = new AbortController();
    const gen = streamChat(makeParams({ signal: controller.signal }));
    await gen.next();
    await gen.next();
    await gen.next();

    const adapterParams = streamOpenAIMock.mock.calls[0]![0];
    expect(adapterParams.signal).toBe(controller.signal);
  });
});

// ─── streamChatToSse ───────────────────────────────────────────────────────

describe('streamChatToSse', () => {
  beforeEach(() => resetStores());

  it('produces valid SSE format (data: JSON\\n\\n per event + [DONE])', async () => {
    seedSession();
    seedProvider();
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('hello'));

    const gen = streamChat(makeParams());
    const stream = streamChatToSse(gen);
    const reader = stream.getReader();
    const decoder = new TextDecoder();

    const chunks: string[] = [];
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(decoder.decode(value, { stream: true }));
    }

    const fullOutput = chunks.join('');
    // Should contain data: lines
    expect(fullOutput).toContain('data: ');
    // Should end with [DONE]
    expect(fullOutput).toContain('data: [DONE]');
    // Each event should be JSON-parseable
    const dataLines = fullOutput
      .split('\n')
      .filter((line) => line.startsWith('data: ') && !line.includes('[DONE]'))
      .map((line) => line.slice(6));
    for (const line of dataLines) {
      expect(() => JSON.parse(line)).not.toThrow();
    }
  });

  it('emits user_message_saved, token, assistant_message_saved events', async () => {
    seedSession();
    seedProvider();
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('response'));

    const gen = streamChat(makeParams());
    const stream = streamChatToSse(gen);
    const reader = stream.getReader();
    const decoder = new TextDecoder();

    const fullOutput = await (async () => {
      const chunks: string[] = [];
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(decoder.decode(value, { stream: true }));
      }
      return chunks.join('');
    })();

    const events = fullOutput
      .split('\n\n')
      .filter((block) => block.startsWith('data: ') && !block.includes('[DONE]'))
      .map((block) => JSON.parse(block.slice(6)) as { type: string });

    const types = events.map((e) => e.type);
    expect(types).toContain('user_message_saved');
    expect(types).toContain('token');
    expect(types).toContain('assistant_message_saved');
  });
});

// ─── Type-level check ──────────────────────────────────────────────────────

describe('type-level checks', () => {
  it('MessageRecord has all documented fields', () => {
    const msg: MessageRecord = {
      id: 'm1',
      sessionId: 's1',
      role: 'user',
      content: 'hello',
      toolCalls: [],
      tokens: 0,
      costUsd: 0,
      providerId: null,
      model: null,
      agentRunId: null,
      createdAt: new Date(),
    };
    expect(msg.id).toBe('m1');
  });
});
