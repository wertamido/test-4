/** Project Export Tests — Blueprint §22 Phase 1 Step 1.11 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  ExportError, isExportError, exportProject, type ExportFormat,
} from '@/lib/export';
import { LocalStorageAdapter } from '@/lib/storage/local';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import os from 'node:os';

vi.mock('@/lib/db', () => ({
  db: { artifact: { findMany: vi.fn() } },
}));
vi.mock('@/lib/sessions/repository', () => ({
  getSession: vi.fn(async () => ({ id: 'sess-1', workspaceId: 'ws-1' })),
}));
vi.mock('@/lib/logger', () => ({
  logger: { trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
    child: vi.fn(() => ({ trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(), child: vi.fn(), level: 'debug' })) },
}));

import { db } from '@/lib/db';

let tmpRoot: string;
beforeEach(async () => {
  tmpRoot = path.join(os.tmpdir(), `zchat-export-test-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  await fs.mkdir(tmpRoot, { recursive: true });
  (db.artifact.findMany as ReturnType<typeof vi.fn>).mockReset();
});
afterEach(async () => {
  try { await fs.rm(tmpRoot, { recursive: true, force: true }); } catch { /* ignore */ }
});

describe('ExportError', () => {
  it('preserves code, message, cause', () => {
    const err = new ExportError('NO_ARTIFACTS', 'none');
    expect(err.code).toBe('NO_ARTIFACTS');
    expect(err.name).toBe('ExportError');
  });
  it('is an instance of Error', () => {
    expect(new ExportError('EXPORT_FAILED', 'x')).toBeInstanceOf(Error);
  });
  it('exposes every ExportErrorCode', () => {
    const codes: ReadonlyArray<ExportError['code']> = ['SESSION_NOT_FOUND', 'NO_ARTIFACTS', 'EXPORT_FAILED'];
    for (const code of codes) {
      expect(new ExportError(code, `msg for ${code}`).code).toBe(code);
    }
  });
});

describe('isExportError', () => {
  it('returns true for ExportError instances', () => {
    expect(isExportError(new ExportError('NO_ARTIFACTS', 'x'))).toBe(true);
  });
  it('returns false for plain errors', () => {
    expect(isExportError(new Error('plain'))).toBe(false);
  });
});

describe('exportProject', () => {
  it('throws NO_ARTIFACTS when session has no artifacts', async () => {
    (db.artifact.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([]);
    try {
      await exportProject('sess-1', 'ws-1', 'zip');
      expect.fail('throw');
    } catch (err) {
      if (isExportError(err)) expect(err.code).toBe('NO_ARTIFACTS');
    }
  });

  it('exports artifacts with inline content as ZIP', async () => {
    (db.artifact.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { id: 'a1', filename: 'hello.txt', content: 'Hello, World!', storageUrl: null, createdAt: new Date() },
    ]);

    const result = await exportProject('sess-1', 'ws-1', 'zip');
    expect(result.format).toBe('zip');
    expect(result.filename).toBe('session-sess-1.zip');
    expect(result.fileCount).toBe(2); // hello.txt + manifest.json
    expect(result.buffer.length).toBeGreaterThan(0);
    // ZIP files start with the PK signature
    expect(result.buffer.readUInt32LE(0)).toBe(0x04034b50);
  });

  it('exports artifacts with inline content as TAR', async () => {
    (db.artifact.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { id: 'a1', filename: 'hello.txt', content: 'Hello, World!', storageUrl: null, createdAt: new Date() },
    ]);

    const result = await exportProject('sess-1', 'ws-1', 'tar');
    expect(result.format).toBe('tar');
    expect(result.filename).toBe('session-sess-1.tar');
    expect(result.fileCount).toBe(2);
    // TAR files have the filename at offset 0
    expect(result.buffer.toString('utf8', 0, 9)).toBe('hello.txt');
    // TAR uses ustar magic at offset 257
    expect(result.buffer.toString('utf8', 257, 262)).toBe('ustar');
  });

  it('reads artifact files from storage when storageUrl is set', async () => {
    const storage = new LocalStorageAdapter(tmpRoot);
    await storage.save('artifacts/a1.txt', Buffer.from('file content'));

    (db.artifact.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { id: 'a1', filename: 'a1.txt', content: null, storageUrl: 'artifacts/a1.txt', createdAt: new Date() },
    ]);

    const result = await exportProject('sess-1', 'ws-1', 'zip', storage);
    expect(result.fileCount).toBe(2);
    expect(result.totalBytes).toBeGreaterThan(0);
  });

  it('skips artifacts that cannot be read from storage', async () => {
    const storage = new LocalStorageAdapter(tmpRoot);
    // Don't save the file — storage.read will throw NOT_FOUND

    (db.artifact.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { id: 'a1', filename: 'missing.txt', content: null, storageUrl: 'artifacts/missing.txt', createdAt: new Date() },
      { id: 'a2', filename: 'present.txt', content: 'fallback content', storageUrl: null, createdAt: new Date() },
    ]);

    const result = await exportProject('sess-1', 'ws-1', 'zip', storage);
    // Only present.txt + manifest.json (missing.txt was skipped)
    expect(result.fileCount).toBe(2);
  });

  it('includes a manifest.json with session metadata', async () => {
    (db.artifact.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { id: 'a1', filename: 'hello.txt', content: 'Hello', storageUrl: null, createdAt: new Date() },
    ]);

    const result = await exportProject('sess-1', 'ws-1', 'zip');
    // The manifest is the last file in the ZIP central directory
    // We can't easily parse the ZIP without a library, but we can verify
    // the manifest content is somewhere in the buffer
    const manifestJson = JSON.stringify({
      sessionId: 'sess-1',
      format: 'zip',
      fileCount: 2,
    });
    // The buffer should contain the manifest JSON (with pretty-printing)
    expect(result.buffer.toString('utf8')).toContain('manifest.json');
    expect(result.buffer.toString('utf8')).toContain('"sessionId": "sess-1"');
  });
});
