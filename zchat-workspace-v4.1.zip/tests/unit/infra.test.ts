/** Infrastructure Tests — Blueprint §22 Phase 4 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import {
  checkRateLimit, checkUserRateLimit, checkIpRateLimit, _clearRateLimitsForTests,
  RATE_LIMITS, IP_RATE_LIMIT,
  calculateCost, PROVIDER_PRICING, getSessionUsage, getUserUsage,
  encryptApiKey, decryptApiKey, serializeEncryptedKey, deserializeEncryptedKey,
  recoverJobs,
} from '@/lib/infra';

vi.mock('@/lib/db', () => ({
  db: {
    message: { findMany: vi.fn() },
    workspace: { findMany: vi.fn() },
    session: { findMany: vi.fn() },
    job: { findMany: vi.fn(), update: vi.fn(), count: vi.fn() },
  },
}));
vi.mock('@/lib/logger', () => ({
  logger: { trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
    child: vi.fn(() => ({ trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(), child: vi.fn(), level: 'debug' })) },
}));

import { db } from '@/lib/db';

const ORIGINAL_ENCRYPTION_KEY = process.env.ENCRYPTION_KEY;

beforeEach(() => {
  _clearRateLimitsForTests();
  for (const model of Object.values(db) as Array<Record<string, ReturnType<typeof vi.fn>>>) {
    for (const fn of Object.values(model)) fn.mockReset();
  }
  process.env.ENCRYPTION_KEY = 'test-encryption-key-16-chars-min';
});

afterEach(() => {
  if (ORIGINAL_ENCRYPTION_KEY === undefined) delete process.env.ENCRYPTION_KEY;
  else process.env.ENCRYPTION_KEY = ORIGINAL_ENCRYPTION_KEY;
});

// ─── Rate Limiting ─────────────────────────────────────────────────────────

describe('Rate Limiting', () => {
  it('allows the first request', () => {
    const result = checkRateLimit('test-key', { maxRequests: 5, windowMs: 60000 });
    expect(result.allowed).toBe(true);
    expect(result.remaining).toBe(4);
  });

  it('blocks requests after the limit is reached', () => {
    for (let i = 0; i < 5; i++) {
      checkRateLimit('test-key', { maxRequests: 5, windowMs: 60000 });
    }
    const result = checkRateLimit('test-key', { maxRequests: 5, windowMs: 60000 });
    expect(result.allowed).toBe(false);
    expect(result.remaining).toBe(0);
  });

  it('resets after the window expires', () => {
    // Fill the bucket
    for (let i = 0; i < 5; i++) {
      checkRateLimit('test-key', { maxRequests: 5, windowMs: 100 });
    }
    // Wait for the window to expire
    return new Promise<void>((resolve) => {
      setTimeout(() => {
        const result = checkRateLimit('test-key', { maxRequests: 5, windowMs: 100 });
        expect(result.allowed).toBe(true);
        expect(result.remaining).toBe(4);
        resolve();
      }, 150);
    });
  });

  it('free tier: 100 requests/hour', () => {
    expect(RATE_LIMITS.free.maxRequests).toBe(100);
    expect(RATE_LIMITS.free.windowMs).toBe(60 * 60 * 1000);
  });

  it('pro tier: 1000 requests/hour', () => {
    expect(RATE_LIMITS.pro.maxRequests).toBe(1000);
  });

  it('enterprise tier: 10000 requests/hour', () => {
    expect(RATE_LIMITS.enterprise.maxRequests).toBe(10000);
  });

  it('IP rate limit: 1000 requests/hour', () => {
    expect(IP_RATE_LIMIT.maxRequests).toBe(1000);
  });

  it('checkUserRateLimit uses the tier config', () => {
    const result = checkUserRateLimit('user-1', 'free');
    expect(result.allowed).toBe(true);
    expect(result.remaining).toBe(99);
  });

  it('checkIpRateLimit uses the IP config', () => {
    const result = checkIpRateLimit('127.0.0.1');
    expect(result.allowed).toBe(true);
    expect(result.remaining).toBe(999);
  });

  it('different keys have independent buckets', () => {
    for (let i = 0; i < 5; i++) {
      checkRateLimit('user-a', { maxRequests: 5, windowMs: 60000 });
    }
    const resultB = checkRateLimit('user-b', { maxRequests: 5, windowMs: 60000 });
    expect(resultB.allowed).toBe(true);
    expect(resultB.remaining).toBe(4);
  });
});

// ─── Token / Cost Tracking ─────────────────────────────────────────────────

describe('Token / Cost Tracking', () => {
  it('calculateCost computes cost from tokens + pricing', () => {
    const cost = calculateCost('gpt-4o', 1000, 500);
    // 1000 input × $0.0025/1K = $0.0025
    // 500 output × $0.01/1K = $0.005
    // Total = $0.0075
    expect(cost).toBeCloseTo(0.0075, 4);
  });

  it('calculateCost returns 0 for unknown models', () => {
    expect(calculateCost('unknown-model', 1000, 500)).toBe(0);
  });

  it('PROVIDER_PRICING has entries for common models', () => {
    expect(PROVIDER_PRICING['gpt-4o']).toBeDefined();
    expect(PROVIDER_PRICING['mistral-large-latest']).toBeDefined();
    expect(PROVIDER_PRICING['claude-3-5-sonnet-latest']).toBeDefined();
    expect(PROVIDER_PRICING['glm-4.6']).toBeDefined();
  });

  it('getSessionUsage sums tokens + cost across messages', async () => {
    (db.message.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { tokens: 100, costUsd: 0.01 },
      { tokens: 200, costUsd: 0.02 },
    ]);
    const usage = await getSessionUsage('sess-1');
    expect(usage.totalTokens).toBe(300);
    expect(usage.totalCostUsd).toBeCloseTo(0.03, 4);
    expect(usage.messageCount).toBe(2);
  });

  it('getUserUsage sums across all user workspaces + sessions', async () => {
    (db.workspace.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([{ id: 'ws-1' }, { id: 'ws-2' }]);
    (db.session.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([{ id: 's1' }, { id: 's2' }]);
    (db.message.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { tokens: 500, costUsd: 0.05 },
    ]);
    const usage = await getUserUsage('user-1');
    expect(usage.totalTokens).toBe(500);
    expect(usage.messageCount).toBe(1);
  });
});

// ─── API Key Encryption ────────────────────────────────────────────────────

describe('API Key Encryption (AES-256-GCM)', () => {
  it('encrypts + decrypts a plaintext API key round-trip', () => {
    const plaintext = 'sk-test-api-key-12345';
    const encrypted = encryptApiKey(plaintext);
    expect(encrypted.iv).not.toBe(plaintext);
    expect(encrypted.ciphertext).not.toBe(plaintext);
    const decrypted = decryptApiKey(encrypted);
    expect(decrypted).toBe(plaintext);
  });

  it('produces different IVs for the same plaintext (randomness)', () => {
    const plaintext = 'sk-test-key';
    const enc1 = encryptApiKey(plaintext);
    const enc2 = encryptApiKey(plaintext);
    expect(enc1.iv).not.toBe(enc2.iv);
    expect(enc1.ciphertext).not.toBe(enc2.ciphertext);
  });

  it('serialize + deserialize round-trips EncryptedKey', () => {
    const encrypted = encryptApiKey('sk-test');
    const json = serializeEncryptedKey(encrypted);
    const deserialized = deserializeEncryptedKey(json);
    expect(deserialized).toEqual(encrypted);
  });

  it('deserialize returns null for invalid JSON', () => {
    expect(deserializeEncryptedKey('not-json')).toBeNull();
  });

  it('deserialize returns null for missing fields', () => {
    expect(deserializeEncryptedKey(JSON.stringify({ iv: 'x' }))).toBeNull();
  });

  it('throws if ENCRYPTION_KEY is not set', () => {
    delete process.env.ENCRYPTION_KEY;
    expect(() => encryptApiKey('test')).toThrow('ENCRYPTION_KEY');
  });

  it('throws if ENCRYPTION_KEY is too short', () => {
    process.env.ENCRYPTION_KEY = 'short';
    expect(() => encryptApiKey('test')).toThrow('ENCRYPTION_KEY');
  });

  it('decryption fails with wrong key (auth tag mismatch)', () => {
    process.env.ENCRYPTION_KEY = 'first-encryption-key-16';
    const encrypted = encryptApiKey('sk-secret');

    // Switch to a different key
    process.env.ENCRYPTION_KEY = 'second-encryption-key-16';
    expect(() => decryptApiKey(encrypted)).toThrow();
  });
});

// ─── Job Recovery ──────────────────────────────────────────────────────────

describe('Job Recovery', () => {
  it('re-enqueues stale running jobs that have retries left', async () => {
    (db.job.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { id: 'job-1', type: 'chat', attempts: 1, maxAttempts: 3 },
    ]);
    (db.job.count as ReturnType<typeof vi.fn>).mockResolvedValueOnce(0);

    const stats = await recoverJobs(5 * 60 * 1000);

    expect(stats.recoveredCount).toBe(1);
    expect(stats.failedCount).toBe(0);
    expect(db.job.update).toHaveBeenCalledWith({
      where: { id: 'job-1' },
      data: expect.objectContaining({ status: 'queued', startedAt: null }),
    });
  });

  it('fails stale jobs that have exhausted max attempts', async () => {
    (db.job.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { id: 'job-1', type: 'chat', attempts: 3, maxAttempts: 3 },
    ]);
    (db.job.count as ReturnType<typeof vi.fn>).mockResolvedValueOnce(0);

    const stats = await recoverJobs();

    expect(stats.recoveredCount).toBe(0);
    expect(stats.failedCount).toBe(1);
    expect(db.job.update).toHaveBeenCalledWith({
      where: { id: 'job-1' },
      data: expect.objectContaining({ status: 'failed', error: expect.any(String) }),
    });
  });

  it('returns 0 counts when no stale jobs', async () => {
    (db.job.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([]);
    (db.job.count as ReturnType<typeof vi.fn>).mockResolvedValueOnce(0);

    const stats = await recoverJobs();
    expect(stats.recoveredCount).toBe(0);
    expect(stats.failedCount).toBe(0);
    expect(stats.stillRunningCount).toBe(0);
  });

  it('reports still-running count', async () => {
    (db.job.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([]);
    (db.job.count as ReturnType<typeof vi.fn>).mockResolvedValueOnce(3);

    const stats = await recoverJobs();
    expect(stats.stillRunningCount).toBe(3);
  });
});
