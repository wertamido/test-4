/** Settings Tests — Blueprint §22 Phase 1 Step 1.10 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  SettingsError, isSettingsError, getSettings, updateSettings, resetSettings,
  DEFAULT_SETTINGS, workspaceSettingsSchema, type WorkspaceSettings,
} from '@/lib/settings';

vi.mock('@/lib/db', () => ({
  db: { workspace: { findUnique: vi.fn(), update: vi.fn() } },
}));
vi.mock('@/lib/logger', () => ({
  logger: { trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
    child: vi.fn(() => ({ trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(), child: vi.fn(), level: 'debug' })) },
}));

import { db } from '@/lib/db';

beforeEach(() => {
  (db.workspace.findUnique as ReturnType<typeof vi.fn>).mockReset();
  (db.workspace.update as ReturnType<typeof vi.fn>).mockReset();
});

describe('SettingsError', () => {
  it('preserves code, message, cause', () => {
    const err = new SettingsError('SETTINGS_INVALID', 'bad');
    expect(err.code).toBe('SETTINGS_INVALID');
    expect(err.name).toBe('SettingsError');
  });
  it('is an instance of Error', () => {
    expect(new SettingsError('SETTINGS_INVALID', 'x')).toBeInstanceOf(Error);
  });
});

describe('isSettingsError', () => {
  it('returns true for SettingsError instances', () => {
    expect(isSettingsError(new SettingsError('SETTINGS_INVALID', 'x'))).toBe(true);
  });
  it('returns false for plain errors', () => {
    expect(isSettingsError(new Error('plain'))).toBe(false);
  });
});

describe('DEFAULT_SETTINGS', () => {
  it('has theme=black (Blueprint §26)', () => { expect(DEFAULT_SETTINGS.theme).toBe('black'); });
  it('has default model glm-4.6', () => { expect(DEFAULT_SETTINGS.defaultModel).toBe('glm-4.6'); });
  it('has default temperature 0.7', () => { expect(DEFAULT_SETTINGS.defaultTemperature).toBe(0.7); });
});

describe('getSettings', () => {
  it('returns parsed settings from DB', async () => {
    (db.workspace.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      settings: JSON.stringify({ ...DEFAULT_SETTINGS, theme: 'zinc' }),
    });
    const s = await getSettings('ws-1');
    expect(s.theme).toBe('zinc');
  });
  it('returns defaults when DB settings are corrupt', async () => {
    (db.workspace.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({ settings: 'not-json' });
    const s = await getSettings('ws-1');
    expect(s.theme).toBe('black');
  });
  it('throws WORKSPACE_NOT_FOUND when workspace missing', async () => {
    (db.workspace.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);
    try { await getSettings('ws-1'); expect.fail('throw'); } catch (err) {
      if (isSettingsError(err)) expect(err.code).toBe('WORKSPACE_NOT_FOUND');
    }
  });
});

describe('updateSettings', () => {
  it('merges + persists updates', async () => {
    (db.workspace.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      settings: JSON.stringify(DEFAULT_SETTINGS),
    });
    (db.workspace.update as ReturnType<typeof vi.fn>).mockResolvedValueOnce({});
    const s = await updateSettings('ws-1', { theme: 'zinc' });
    expect(s.theme).toBe('zinc');
    expect(s.density).toBe(DEFAULT_SETTINGS.density); // unchanged
  });
  it('throws SETTINGS_INVALID for invalid temperature', async () => {
    (db.workspace.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      settings: JSON.stringify(DEFAULT_SETTINGS),
    });
    try { await updateSettings('ws-1', { defaultTemperature: 3 }); expect.fail('throw'); } catch (err) {
      if (isSettingsError(err)) expect(err.code).toBe('SETTINGS_INVALID');
    }
  });
});

describe('resetSettings', () => {
  it('persists DEFAULT_SETTINGS', async () => {
    (db.workspace.update as ReturnType<typeof vi.fn>).mockResolvedValueOnce({});
    const s = await resetSettings('ws-1');
    expect(s).toEqual(DEFAULT_SETTINGS);
  });
});

describe('workspaceSettingsSchema validation', () => {
  it('accepts valid settings', () => {
    const result = workspaceSettingsSchema.safeParse({ theme: 'black', density: 'compact' });
    expect(result.success).toBe(true);
  });
  it('rejects invalid theme (no violet)', () => {
    const result = workspaceSettingsSchema.safeParse({ theme: 'violet' });
    expect(result.success).toBe(false);
  });
  it('rejects temperature > 2', () => {
    const result = workspaceSettingsSchema.safeParse({ defaultTemperature: 2.5 });
    expect(result.success).toBe(false);
  });
});
