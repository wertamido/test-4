/** Reasoning Loop + Summarizer Tests — Blueprint §15, §22 Phase 3 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  summarizeContext, estimateTokens, buildPhaseContext,
  MAX_PHASE_OUTPUT_TOKENS, MAX_TOTAL_CONTEXT_TOKENS, TOKEN_ESTIMATE_CHARS_PER_TOKEN,
} from '@/lib/reasoning/summarizer';
import {
  runReasoningLoop, type ReasoningParams, type ReasoningMode,
} from '@/lib/reasoning/loop';

vi.mock('@/lib/db', () => ({
  db: {
    reasoningRun: { create: vi.fn(), update: vi.fn() },
  },
}));
vi.mock('@/lib/logger', () => ({
  logger: { trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
    child: vi.fn(() => ({ trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(), child: vi.fn(), level: 'debug' })) },
}));
const runAgentMock = vi.fn();
vi.mock('@/lib/agents/runner', () => ({ runAgent: runAgentMock }));

import { db } from '@/lib/db';

beforeEach(() => {
  (db.reasoningRun.create as ReturnType<typeof vi.fn>).mockReset();
  (db.reasoningRun.update as ReturnType<typeof vi.fn>).mockReset();
  runAgentMock.mockReset();
  (db.reasoningRun.create as ReturnType<typeof vi.fn>).mockResolvedValue({ id: 'rr-1' });
});

// ─── Token estimation ──────────────────────────────────────────────────────

describe('estimateTokens', () => {
  it('estimates ~4 chars per token', () => {
    expect(estimateTokens('hello')).toBe(2); // 5 chars / 4 = 1.25 → ceil = 2
    expect(estimateTokens('hello world')).toBe(3); // 11 chars / 4 = 2.75 → ceil = 3
  });
  it('returns 0 for empty string', () => {
    expect(estimateTokens('')).toBe(0);
  });
});

describe('constants', () => {
  it('MAX_PHASE_OUTPUT_TOKENS is 500 (Blueprint §15)', () => {
    expect(MAX_PHASE_OUTPUT_TOKENS).toBe(500);
  });
  it('MAX_TOTAL_CONTEXT_TOKENS is 10_000 (Blueprint §15)', () => {
    expect(MAX_TOTAL_CONTEXT_TOKENS).toBe(10_000);
  });
  it('TOKEN_ESTIMATE_CHARS_PER_TOKEN is 4', () => {
    expect(TOKEN_ESTIMATE_CHARS_PER_TOKEN).toBe(4);
  });
});

// ─── summarizeContext ──────────────────────────────────────────────────────

describe('summarizeContext', () => {
  it('returns text as-is when under the token limit', () => {
    const text = 'This is a short text.';
    expect(summarizeContext(text, 500)).toBe(text);
  });

  it('truncates text that exceeds the token limit', () => {
    const longText = 'This is a sentence. '.repeat(200); // ~4400 chars, ~1100 tokens
    const result = summarizeContext(longText, 100); // 100 tokens = 400 chars
    expect(result.length).toBeLessThan(longText.length);
    expect(result).toContain('summarized');
  });

  it('preserves sentence boundaries when possible', () => {
    const text = 'First sentence. Second sentence. Third sentence. Fourth sentence.';
    const result = summarizeContext(text, 5); // 5 tokens = 20 chars
    // Should keep at least the first sentence (15 chars)
    expect(result).toContain('First sentence.');
  });

  it('hard-truncates when even one sentence exceeds the limit', () => {
    const text = 'This is a very long sentence that goes on and on and does not stop until it exceeds the token limit.';
    const result = summarizeContext(text, 3); // 3 tokens = 12 chars
    expect(result.length).toBeLessThan(text.length);
  });

  it('includes a summarization footer with token counts', () => {
    const longText = 'A. '.repeat(1000); // 3000 chars, 750 tokens
    const result = summarizeContext(longText, 50);
    expect(result).toMatch(/\[... summarized: \d+ tokens → \d+ tokens\]/);
  });
});

// ─── buildPhaseContext ─────────────────────────────────────────────────────

describe('buildPhaseContext', () => {
  it('assembles context with truncated components', () => {
    const ctx = buildPhaseContext(
      'System prompt '.repeat(200), // long
      'Previous summary '.repeat(200), // long
      'Current output', // short
    );
    expect(ctx.systemPrompt.length).toBeLessThan(5000);
    expect(ctx.previousSummary.length).toBeLessThan(2500);
    expect(ctx.currentOutput).toBe('Current output');
    expect(ctx.totalEstimatedTokens).toBeLessThanOrEqual(10_000);
  });

  it('preserves short inputs without truncation', () => {
    const ctx = buildPhaseContext('short system', 'short prev', 'short current');
    expect(ctx.systemPrompt).toBe('short system');
    expect(ctx.previousSummary).toBe('short prev');
    expect(ctx.currentOutput).toBe('short current');
  });
});

// ─── runReasoningLoop ──────────────────────────────────────────────────────

function makeParams(overrides: Partial<ReasoningParams> = {}): ReasoningParams {
  return {
    sessionId: 'sess-1',
    workspaceId: 'ws-1',
    goal: 'Build a todo app',
    mode: 'standard',
    providerId: 'mistral',
    model: 'mistral-large-latest',
    ...overrides,
  };
}

describe('runReasoningLoop', () => {
  it('instant mode: no phases, returns direct answer', async () => {
    runAgentMock.mockResolvedValueOnce({
      content: 'Here is your answer.', toolCalls: [], finishReason: 'stop',
      tokensUsed: 50, costUsd: 0.001, model: 'm', providerId: 'p',
    });

    const result = await runReasoningLoop(makeParams({ mode: 'instant' }));

    expect(result.mode).toBe('instant');
    expect(result.phases).toHaveLength(0);
    expect(result.finalAnswer).toBe('Here is your answer.');
    expect(result.decision).toBeNull();
  });

  it('standard mode: runs 4 phases (GOAL, THINK, PLAN, EXECUTE)', async () => {
    runAgentMock
      .mockResolvedValueOnce({ content: 'Goal restated', toolCalls: [], finishReason: 'stop', tokensUsed: 100, costUsd: 0.01, model: 'm', providerId: 'p' })
      .mockResolvedValueOnce({ content: 'Thinking done', toolCalls: [], finishReason: 'stop', tokensUsed: 150, costUsd: 0.02, model: 'm', providerId: 'p' })
      .mockResolvedValueOnce({ content: 'Plan created', toolCalls: [], finishReason: 'stop', tokensUsed: 200, costUsd: 0.03, model: 'm', providerId: 'p' })
      .mockResolvedValueOnce({ content: 'Executed', toolCalls: [], finishReason: 'stop', tokensUsed: 300, costUsd: 0.04, model: 'm', providerId: 'p' });

    const result = await runReasoningLoop(makeParams({ mode: 'standard' }));

    expect(result.phases).toHaveLength(4);
    expect(result.phases[0]!.phaseName).toBe('GOAL');
    expect(result.phases[1]!.phaseName).toBe('THINK');
    expect(result.phases[2]!.phaseName).toBe('PLAN');
    expect(result.phases[3]!.phaseName).toBe('EXECUTE');
    expect(result.totalTokens).toBe(750);
    expect(result.totalCostUsd).toBeCloseTo(0.10, 4);
  });

  it('reasoning mode: runs all 13 phases', async () => {
    runAgentMock.mockResolvedValue({
      content: 'phase output', toolCalls: [], finishReason: 'stop',
      tokensUsed: 50, costUsd: 0.005, model: 'm', providerId: 'p',
    });

    const result = await runReasoningLoop(makeParams({ mode: 'reasoning' }));

    expect(result.phases).toHaveLength(13);
    expect(result.phases[0]!.phaseName).toBe('GOAL');
    expect(result.phases[12]!.phaseName).toBe('DECIDE');
  });

  it('calls onPhaseComplete after each phase', async () => {
    runAgentMock.mockResolvedValue({
      content: 'output', toolCalls: [], finishReason: 'stop',
      tokensUsed: 10, costUsd: 0, model: 'm', providerId: 'p',
    });

    const onPhaseComplete = vi.fn();
    await runReasoningLoop(makeParams({ mode: 'standard', onPhaseComplete }));

    expect(onPhaseComplete).toHaveBeenCalledTimes(4);
  });

  it('passes the previous phase summary to the next phase', async () => {
    runAgentMock
      .mockResolvedValueOnce({ content: 'GOAL OUTPUT', toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'm', providerId: 'p' })
      .mockResolvedValueOnce({ content: 'THINK OUTPUT', toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'm', providerId: 'p' })
      .mockResolvedValueOnce({ content: 'PLAN OUTPUT', toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'm', providerId: 'p' })
      .mockResolvedValueOnce({ content: 'EXECUTE OUTPUT', toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'm', providerId: 'p' });

    await runReasoningLoop(makeParams({ mode: 'standard' }));

    // The second call (THINK) should have received the GOAL summary
    const thinkCallMessages = runAgentMock.mock.calls[1]![0].messages as Array<{ content: string }>;
    expect(thinkCallMessages[0].content).toContain('GOAL OUTPUT');
  });

  it('extracts SHIP decision from the final phase output', async () => {
    runAgentMock.mockResolvedValue({
      content: 'I decide to SHIP this.', toolCalls: [], finishReason: 'stop',
      tokensUsed: 10, costUsd: 0, model: 'm', providerId: 'p',
    });

    const result = await runReasoningLoop(makeParams({ mode: 'standard' }));
    expect(result.decision).toBe('SHIP');
  });

  it('extracts RETRY decision', async () => {
    runAgentMock.mockResolvedValue({
      content: 'I decide to RETRY.', toolCalls: [], finishReason: 'stop',
      tokensUsed: 10, costUsd: 0, model: 'm', providerId: 'p',
    });

    const result = await runReasoningLoop(makeParams({ mode: 'standard' }));
    expect(result.decision).toBe('RETRY');
  });

  it('extracts SHIP-WITH-CAVEATS decision', async () => {
    runAgentMock.mockResolvedValue({
      content: 'I decide to SHIP-WITH-CAVEATS.', toolCalls: [], finishReason: 'stop',
      tokensUsed: 10, costUsd: 0, model: 'm', providerId: 'p',
    });

    const result = await runReasoningLoop(makeParams({ mode: 'standard' }));
    expect(result.decision).toBe('SHIP-WITH-CAVEATS');
  });

  it('handles phase errors gracefully (continues to next phase)', async () => {
    runAgentMock
      .mockRejectedValueOnce(new Error('phase 1 failed'))
      .mockResolvedValueOnce({ content: 'phase 2 ok', toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'm', providerId: 'p' })
      .mockResolvedValueOnce({ content: 'phase 3 ok', toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'm', providerId: 'p' })
      .mockResolvedValueOnce({ content: 'phase 4 ok', toolCalls: [], finishReason: 'stop', tokensUsed: 10, costUsd: 0, model: 'm', providerId: 'p' });

    const result = await runReasoningLoop(makeParams({ mode: 'standard' }));

    expect(result.phases).toHaveLength(4);
    expect(result.phases[0]!.error).toBe('phase 1 failed');
    expect(result.phases[1]!.error).toBeUndefined();
    expect(result.status).toBe('done'); // overall status is done even with a phase error
  });

  it('persists the reasoning run to the DB', async () => {
    runAgentMock.mockResolvedValue({
      content: 'output', toolCalls: [], finishReason: 'stop',
      tokensUsed: 10, costUsd: 0, model: 'm', providerId: 'p',
    });

    await runReasoningLoop(makeParams({ mode: 'standard' }));

    expect(db.reasoningRun.create).toHaveBeenCalledTimes(1);
    expect(db.reasoningRun.update).toHaveBeenCalledTimes(1);
    const updateArgs = (db.reasoningRun.update as ReturnType<typeof vi.fn>).mock.calls[0]![0];
    expect(updateArgs.data.status).toBe('done');
    expect(updateArgs.data.finalAnswer).toBe('output');
  });
});

// ─── ReasoningMode type ────────────────────────────────────────────────────

describe('ReasoningMode', () => {
  it('includes all 5 modes', () => {
    const modes: ReasoningMode[] = ['instant', 'standard', 'reasoning', 'deep', 'autonomous'];
    expect(modes).toHaveLength(5);
  });
});
