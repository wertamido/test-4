/** Agent Orchestration Tests — Blueprint §10, §16, §22 Phase 2 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  createTask, getTask, getTasksBySession, claimTask, completeTask, failTask,
  writeMemory, readMemory, readAllMemory,
  sendAgentMessage, getAgentMessages, markMessageRead,
  type TaskRecord, type AgentMemoryRecord, type AgentMessageRecord,
} from '@/lib/agents/shared-layer';
import {
  createAgentRun, updateAgentRunStatus, getAgentRun, orchestrate,
  DEFAULT_MAX_DEPTH, DEFAULT_MAX_AGENTS,
} from '@/lib/agents/orchestrator';

vi.mock('@/lib/db', () => ({
  db: {
    task: { findUnique: vi.fn(), findMany: vi.fn(), create: vi.fn(), update: vi.fn() },
    agentMemory: { findFirst: vi.fn(), findMany: vi.fn(), create: vi.fn() },
    agentMessage: { findMany: vi.fn(), create: vi.fn(), update: vi.fn() },
    agentRun: { findUnique: vi.fn(), findMany: vi.fn(), create: vi.fn(), update: vi.fn() },
  },
}));
vi.mock('@/lib/sessions/repository', () => ({
  getSession: vi.fn(async () => ({ id: 'sess-1', workspaceId: 'ws-1' })),
}));
vi.mock('@/lib/logger', () => ({
  logger: { trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(),
    child: vi.fn(() => ({ trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), fatal: vi.fn(), child: vi.fn(), level: 'debug' })) },
}));
const runAgentMock = vi.fn();
vi.mock('@/lib/agents/runner', () => ({ runAgent: runAgentMock }));

import { db } from '@/lib/db';

const WS_1 = 'ws-1';
const SESS_1 = 'sess-1';

beforeEach(() => {
  for (const model of Object.values(db) as Array<Record<string, ReturnType<typeof vi.fn>>>) {
    for (const fn of Object.values(model)) {
      fn.mockReset();
    }
  }
  runAgentMock.mockReset();
});

// ─── Task Board ────────────────────────────────────────────────────────────

describe('Task Board', () => {
  it('createTask creates a pending task', async () => {
    (db.task.create as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'task-1', sessionId: SESS_1, createdByAgentRunId: null, assignedToAgentRunId: null,
      title: 'Research', description: 'do research', status: 'pending', priority: 1,
      dependencies: '["task-0"]', result: null, createdAt: new Date(), completedAt: null,
    });
    const task = await createTask({ sessionId: SESS_1, workspaceId: WS_1, title: 'Research', description: 'do research', priority: 1, dependencies: ['task-0'] });
    expect(task.id).toBe('task-1');
    expect(task.status).toBe('pending');
    expect(task.dependencies).toEqual(['task-0']);
  });

  it('getTask returns the task', async () => {
    (db.task.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'task-1', sessionId: SESS_1, createdByAgentRunId: null, assignedToAgentRunId: null,
      title: 'T', description: null, status: 'pending', priority: 0,
      dependencies: '[]', result: null, createdAt: new Date(), completedAt: null,
    });
    const task = await getTask('task-1', WS_1);
    expect(task.id).toBe('task-1');
  });

  it('claimTask sets status=in_progress + assignedToAgentRunId', async () => {
    (db.task.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'task-1', sessionId: SESS_1, createdByAgentRunId: null, assignedToAgentRunId: null,
      title: 'T', description: null, status: 'pending', priority: 0,
      dependencies: '[]', result: null, createdAt: new Date(), completedAt: null,
    });
    (db.task.update as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'task-1', sessionId: SESS_1, createdByAgentRunId: null, assignedToAgentRunId: 'run-1',
      title: 'T', description: null, status: 'in_progress', priority: 0,
      dependencies: '[]', result: null, createdAt: new Date(), completedAt: null,
    });
    const task = await claimTask('task-1', 'run-1', WS_1);
    expect(task.status).toBe('in_progress');
    expect(task.assignedToAgentRunId).toBe('run-1');
  });

  it('claimTask throws if task is not pending', async () => {
    (db.task.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'task-1', sessionId: SESS_1, status: 'done', dependencies: '[]', title: 'T', description: null, priority: 0, result: null, createdByAgentRunId: null, assignedToAgentRunId: null, createdAt: new Date(), completedAt: null,
    });
    try { await claimTask('task-1', 'run-1', WS_1); expect.fail('throw'); } catch (err) {
      expect(err).toBeInstanceOf(Error);
    }
  });

  it('completeTask sets status=done + result + completedAt', async () => {
    (db.task.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'task-1', sessionId: SESS_1, status: 'in_progress', dependencies: '[]', title: 'T', description: null, priority: 0, result: null, createdByAgentRunId: null, assignedToAgentRunId: null, createdAt: new Date(), completedAt: null,
    });
    (db.task.update as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'task-1', sessionId: SESS_1, status: 'done', result: 'done!', dependencies: '[]', title: 'T', description: null, priority: 0, createdByAgentRunId: null, assignedToAgentRunId: null, createdAt: new Date(), completedAt: new Date(),
    });
    const task = await completeTask('task-1', 'done!', WS_1);
    expect(task.status).toBe('done');
    expect(task.result).toBe('done!');
  });

  it('failTask sets status=failed', async () => {
    (db.task.findUnique as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'task-1', sessionId: SESS_1, status: 'in_progress', dependencies: '[]', title: 'T', description: null, priority: 0, result: null, createdByAgentRunId: null, assignedToAgentRunId: null, createdAt: new Date(), completedAt: null,
    });
    (db.task.update as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'task-1', sessionId: SESS_1, status: 'failed', result: 'oops', dependencies: '[]', title: 'T', description: null, priority: 0, createdByAgentRunId: null, assignedToAgentRunId: null, createdAt: new Date(), completedAt: new Date(),
    });
    const task = await failTask('task-1', 'oops', WS_1);
    expect(task.status).toBe('failed');
  });
});

// ─── Shared Memory ─────────────────────────────────────────────────────────

describe('Shared Memory', () => {
  it('writeMemory creates a memory record', async () => {
    (db.agentMemory.create as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'mem-1', sessionId: SESS_1, writtenByAgentRunId: 'run-1',
      key: 'plan', value: '{}', scope: 'session', createdAt: new Date(),
    });
    const mem = await writeMemory({ sessionId: SESS_1, workspaceId: WS_1, key: 'plan', value: '{}', writtenByAgentRunId: 'run-1' });
    expect(mem.id).toBe('mem-1');
    expect(mem.key).toBe('plan');
  });

  it('readMemory returns the latest record for a key', async () => {
    (db.agentMemory.findFirst as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'mem-1', sessionId: SESS_1, writtenByAgentRunId: null,
      key: 'plan', value: '{"tasks":[]}', scope: 'session', createdAt: new Date(),
    });
    const mem = await readMemory(SESS_1, WS_1, 'plan');
    expect(mem).not.toBeNull();
    expect(mem!.value).toBe('{"tasks":[]}');
  });

  it('readMemory returns null when key not found', async () => {
    (db.agentMemory.findFirst as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);
    const mem = await readMemory(SESS_1, WS_1, 'nonexistent');
    expect(mem).toBeNull();
  });
});

// ─── Inter-Agent Messaging ─────────────────────────────────────────────────

describe('Inter-Agent Messaging', () => {
  it('sendAgentMessage creates a message (broadcast when toAgentRunId is null)', async () => {
    (db.agentMessage.create as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'msg-1', sessionId: SESS_1, fromAgentRunId: 'run-1', toAgentRunId: null,
      type: 'finding', content: 'found something', readAt: null, createdAt: new Date(),
    });
    const msg = await sendAgentMessage({ sessionId: SESS_1, workspaceId: WS_1, fromAgentRunId: 'run-1', toAgentRunId: null, type: 'finding', content: 'found something' });
    expect(msg.id).toBe('msg-1');
    expect(msg.toAgentRunId).toBeNull(); // broadcast
  });

  it('getAgentMessages returns messages for a session', async () => {
    (db.agentMessage.findMany as ReturnType<typeof vi.fn>).mockResolvedValueOnce([
      { id: 'msg-1', sessionId: SESS_1, fromAgentRunId: 'run-1', toAgentRunId: null, type: 'finding', content: 'x', readAt: null, createdAt: new Date() },
    ]);
    const msgs = await getAgentMessages(SESS_1, WS_1);
    expect(msgs).toHaveLength(1);
  });
});

// ─── AgentRun persistence ──────────────────────────────────────────────────

describe('AgentRun persistence', () => {
  it('createAgentRun creates a run with depth + status=pending', async () => {
    (db.agentRun.create as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      id: 'run-1', sessionId: SESS_1, parentRunId: null, agentTemplateId: 'agent.hermes',
      providerId: 'mistral', model: 'mistral-large-latest', task: 'plan', taskContext: '{}',
      status: 'pending', depth: 0, result: null, artifacts: '[]', toolCalls: '[]',
      tokensUsed: 0, costUsd: 0, durationMs: null, messagesToParent: '[]', messagesFromParent: '[]',
      startedAt: new Date(), finishedAt: null,
    });
    const run = await createAgentRun({
      sessionId: SESS_1, workspaceId: WS_1, agentTemplateId: 'agent.hermes',
      providerId: 'mistral', model: 'mistral-large-latest', task: 'plan', depth: 0,
    });
    expect(run.id).toBe('run-1');
    expect(run.depth).toBe(0);
    expect(run.status).toBe('pending');
  });

  it('updateAgentRunStatus updates status + finishedAt for terminal states', async () => {
    await updateAgentRunStatus('run-1', 'done', { result: 'complete', tokensUsed: 100 });
    expect(db.agentRun.update).toHaveBeenCalledWith({
      where: { id: 'run-1' },
      data: expect.objectContaining({ status: 'done', result: 'complete', tokensUsed: 100, finishedAt: expect.any(Date) }),
    });
  });
});

// ─── Constants ─────────────────────────────────────────────────────────────

describe('orchestration constants', () => {
  it('DEFAULT_MAX_DEPTH is 3 (Blueprint §10)', () => {
    expect(DEFAULT_MAX_DEPTH).toBe(3);
  });
  it('DEFAULT_MAX_AGENTS is 20 (Blueprint §10)', () => {
    expect(DEFAULT_MAX_AGENTS).toBe(20);
  });
});

// ─── orchestrate (end-to-end) ──────────────────────────────────────────────

describe('orchestrate', () => {
  it('runs a full orchestration: plan → execute tasks → merge', async () => {
    // Mock createAgentRun to return sequential run IDs
    let runCount = 0;
    (db.agentRun.create as ReturnType<typeof vi.fn>).mockImplementation(async () => ({
      id: `run-${++runCount}`, sessionId: SESS_1, parentRunId: null,
      agentTemplateId: 'agent.hermes', providerId: 'mistral', model: 'mistral-large-latest',
      task: 'plan', taskContext: '{}', status: 'pending', depth: 0, result: null,
      artifacts: '[]', toolCalls: '[]', tokensUsed: 0, costUsd: 0, durationMs: null,
      messagesToParent: '[]', messagesFromParent: '[]',
      startedAt: new Date(), finishedAt: null,
    }));
    (db.agentRun.update as ReturnType<typeof vi.fn>).mockResolvedValue({});

    // Mock task creation
    let taskCount = 0;
    (db.task.create as ReturnType<typeof vi.fn>).mockImplementation(async (args: { data: { title: string } }) => ({
      id: `task-${++taskCount}`, sessionId: SESS_1, createdByAgentRunId: 'run-1',
      assignedToAgentRunId: null, title: args.data.title, description: null,
      status: 'pending', priority: 0, dependencies: '[]', result: null,
      createdAt: new Date(), completedAt: null,
    }));
    (db.task.findUnique as ReturnType<typeof vi.fn>).mockImplementation(async (args: { where: { id: string } }) => ({
      id: args.where.id, sessionId: SESS_1, createdByAgentRunId: null, assignedToAgentRunId: null,
      title: 'T', description: null, status: 'pending', priority: 0,
      dependencies: '[]', result: null, createdAt: new Date(), completedAt: null,
    }));
    (db.task.update as ReturnType<typeof vi.fn>).mockResolvedValue({
      id: 'task-1', sessionId: SESS_1, status: 'done', result: 'result', dependencies: '[]',
      title: 'T', description: null, priority: 0, createdByAgentRunId: null, assignedToAgentRunId: null,
      createdAt: new Date(), completedAt: new Date(),
    });
    (db.task.findMany as ReturnType<typeof vi.fn>).mockResolvedValue([
      { id: 'task-1', sessionId: SESS_1, status: 'done', result: 'result', dependencies: '[]', title: 'T1', description: null, priority: 0, createdByAgentRunId: null, assignedToAgentRunId: null, createdAt: new Date(), completedAt: new Date() },
    ]);

    // Mock memory
    (db.agentMemory.create as ReturnType<typeof vi.fn>).mockResolvedValue({
      id: 'mem-1', sessionId: SESS_1, writtenByAgentRunId: 'run-1',
      key: 'plan', value: '{}', scope: 'session', createdAt: new Date(),
    });
    (db.agentMemory.findMany as ReturnType<typeof vi.fn>).mockResolvedValue([]);

    // Mock runAgent: first call returns the plan, subsequent calls return task results, last returns merge
    runAgentMock
      .mockResolvedValueOnce({ content: '{"tasks":[{"title":"Task 1","agentType":"coder","provider":"mistral","model":"mistral-large-latest","dependencies":[],"priority":1,"taskDescription":"do task 1"}]}', toolCalls: [], finishReason: 'stop', tokensUsed: 50, costUsd: 0.01, model: 'mistral-large-latest', providerId: 'mistral' })
      .mockResolvedValueOnce({ content: 'task 1 result', toolCalls: [], finishReason: 'stop', tokensUsed: 100, costUsd: 0.02, model: 'mistral-large-latest', providerId: 'mistral' })
      .mockResolvedValueOnce({ content: 'merged final deliverable', toolCalls: [], finishReason: 'stop', tokensUsed: 200, costUsd: 0.05, model: 'mistral-large-latest', providerId: 'mistral' });

    const result = await orchestrate({
      sessionId: SESS_1,
      workspaceId: WS_1,
      goal: 'Build a todo app',
      leadAgentId: 'agent.hermes',
      providerId: 'mistral',
      model: 'mistral-large-latest',
    });

    expect(result.status).toBe('done');
    expect(result.finalResult).toBe('merged final deliverable');
    expect(result.tasksCreated).toBeGreaterThanOrEqual(1);
    expect(result.subAgentRuns.length).toBeGreaterThanOrEqual(1);
  });
});
