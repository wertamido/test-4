/**
 * Unit tests for src/lib/storage/adapter.ts + local.ts
 *
 * Blueprint v4.1 §20 (StorageAdapter), §22 Phase 0 Step 0.10, §24 (Security Model)
 *
 * Coverage:
 *  - StorageError + isStorageError: construction, brand, type guard (pos + neg)
 *  - validatePath: rejects '..', absolute paths, drive letters, null bytes,
 *    empty strings, non-strings; accepts valid relative paths, strips `.`
 *    segments, normalizes backslashes
 *  - LocalStorageAdapter:
 *      • save + read roundtrip (Buffer contents match)
 *      • save creates parent directories automatically
 *      • exists returns true after save, false before
 *      • delete removes the file; subsequent read throws NOT_FOUND
 *      • delete on missing file throws NOT_FOUND
 *      • list returns all files; with prefix returns only matching files
 *      • list returns empty array when root doesn't exist yet
 *      • metadata returns size, createdAt, contentType
 *      • metadata on missing file throws NOT_FOUND
 *      • metadata on a directory throws NOT_FOUND
 *      • getSignedUrl returns null
 *      • PATH_TRAVERSAL_DETECTED is thrown for every method when path contains '..'
 *      • save returns the full resolved path
 *  - MIME map: known extensions return correct content type; unknown
 *    extensions default to 'application/octet-stream'
 *
 * Test isolation strategy:
 *  - Each test creates a fresh temp directory under os.tmpdir()
 *  - afterEach removes the temp directory recursively
 *  - Tests never touch the project's real ./storage directory
 *
 * No mocking — these are real filesystem tests against os.tmpdir().
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { promises as fs } from 'node:fs';
import { join } from 'node:path';
import os from 'node:os';
import path from 'node:path';

import {
  StorageError,
  isStorageError,
  validatePath,
  getContentType,
  MIME_MAP,
  type StorageAdapter,
  type StorageItem,
} from '@/lib/storage/adapter';
import { LocalStorageAdapter } from '@/lib/storage/local';

// ─── Helpers ───────────────────────────────────────────────────────────────

let tmpRoot: string;

beforeEach(async () => {
  // Each test gets a fresh temp directory. The path is unique per test
  // (uses a counter via Date.now + Math.random to avoid collisions when
  // tests run in parallel).
  tmpRoot = path.join(
    os.tmpdir(),
    `zchat-storage-test-${Date.now()}-${Math.random().toString(36).slice(2)}`,
  );
  await fs.mkdir(tmpRoot, { recursive: true });
});

afterEach(async () => {
  // Best-effort cleanup — don't fail the test if the dir is already gone
  try {
    await fs.rm(tmpRoot, { recursive: true, force: true });
  } catch {
    // ignore
  }
});

function makeAdapter(): LocalStorageAdapter {
  return new LocalStorageAdapter(tmpRoot);
}

// ─── StorageError + isStorageError ─────────────────────────────────────────

describe('StorageError', () => {
  it('preserves code, message, cause, and path', () => {
    const cause = new Error('root');
    const err = new StorageError('NOT_FOUND', 'missing', cause, 'foo/bar.txt');
    expect(err.code).toBe('NOT_FOUND');
    expect(err.message).toBe('missing');
    expect(err.cause).toBe(cause);
    expect(err.path).toBe('foo/bar.txt');
    expect(err.name).toBe('StorageError');
  });

  it('is an instance of Error', () => {
    const err = new StorageError('SAVE_FAILED', 'x');
    expect(err).toBeInstanceOf(Error);
  });

  it('survives instanceof StorageError after subclassing Error (prototype chain)', () => {
    const err = new StorageError('READ_FAILED', 'x');
    expect(err).toBeInstanceOf(StorageError);
    try {
      throw err;
    } catch (caught) {
      expect(caught).toBeInstanceOf(StorageError);
    }
  });

  it('exposes every StorageErrorCode value', () => {
    const codes: ReadonlyArray<StorageError['code']> = [
      'SAVE_FAILED',
      'READ_FAILED',
      'DELETE_FAILED',
      'NOT_FOUND',
      'PATH_TRAVERSAL_DETECTED',
      'INVALID_PATH',
      'EDGE_RUNTIME_UNSUPPORTED',
    ];
    for (const code of codes) {
      const err = new StorageError(code, `message for ${code}`);
      expect(err.code).toBe(code);
    }
  });

  it('supports an undefined cause + path', () => {
    const err = new StorageError('NOT_FOUND', 'nope');
    expect(err.cause).toBeUndefined();
    expect(err.path).toBeUndefined();
  });
});

describe('isStorageError', () => {
  it('returns false for primitives', () => {
    expect(isStorageError(0)).toBe(false);
    expect(isStorageError('')).toBe(false);
    expect(isStorageError(false)).toBe(false);
    expect(isStorageError(null)).toBe(false);
    expect(isStorageError(undefined)).toBe(false);
  });

  it('returns false for plain objects lacking the brand symbol', () => {
    expect(isStorageError({ code: 'NOT_FOUND', message: 'fake' })).toBe(false);
    expect(isStorageError(new Error('plain'))).toBe(false);
    expect(isStorageError({})).toBe(false);
  });

  it('returns true for StorageError instances', () => {
    const err = new StorageError('NOT_FOUND', 'real');
    expect(isStorageError(err)).toBe(true);
  });

  it('does not confuse StorageError with DbError / AuthError / ValidationError / QueueError', () => {
    const fakeDbError = Object.assign(new Error('db failed'), {
      code: 'QUERY_FAILED',
      cause: undefined,
    });
    expect(isStorageError(fakeDbError)).toBe(false);
  });
});

// ─── validatePath ──────────────────────────────────────────────────────────

describe('validatePath', () => {
  it('accepts a simple relative path', () => {
    expect(validatePath('foo.txt')).toBe('foo.txt');
  });

  it('accepts a nested relative path', () => {
    expect(validatePath('artifacts/session-1/code/auth.ts')).toBe(
      'artifacts/session-1/code/auth.ts',
    );
  });

  it('normalizes backslashes to forward slashes', () => {
    expect(validatePath('artifacts\\session-1\\auth.ts')).toBe(
      'artifacts/session-1/auth.ts',
    );
  });

  it('strips "." segments', () => {
    expect(validatePath('./artifacts/./auth.ts')).toBe('artifacts/auth.ts');
  });

  it('strips trailing slash', () => {
    expect(validatePath('artifacts/')).toBe('artifacts');
  });

  it('rejects empty string', () => {
    try {
      validatePath('');
      expect.fail('Expected validatePath to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('INVALID_PATH');
    }
  });

  it('rejects non-string inputs', () => {
    try {
      validatePath(undefined);
      expect.fail('Expected validatePath to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('INVALID_PATH');
    }
    try {
      validatePath(123);
      expect.fail('Expected validatePath to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('INVALID_PATH');
    }
    try {
      validatePath(null);
      expect.fail('Expected validatePath to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('INVALID_PATH');
    }
  });

  it('rejects null bytes', () => {
    try {
      validatePath('foo\0bar');
      expect.fail('Expected validatePath to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('INVALID_PATH');
    }
  });

  it('rejects absolute Unix paths', () => {
    try {
      validatePath('/etc/passwd');
      expect.fail('Expected validatePath to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('PATH_TRAVERSAL_DETECTED');
    }
  });

  it('rejects Windows drive letter paths', () => {
    try {
      validatePath('C:\\Windows\\System32');
      expect.fail('Expected validatePath to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('PATH_TRAVERSAL_DETECTED');
    }
  });

  it('rejects ".." segment at the start', () => {
    try {
      validatePath('../etc/passwd');
      expect.fail('Expected validatePath to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('PATH_TRAVERSAL_DETECTED');
    }
  });

  it('rejects ".." segment in the middle', () => {
    try {
      validatePath('artifacts/../../etc/passwd');
      expect.fail('Expected validatePath to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('PATH_TRAVERSAL_DETECTED');
    }
  });

  it('rejects ".." segment at the end', () => {
    try {
      validatePath('artifacts/..');
      expect.fail('Expected validatePath to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('PATH_TRAVERSAL_DETECTED');
    }
  });

  it('rejects a path that is only ".."', () => {
    try {
      validatePath('..');
      expect.fail('Expected validatePath to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('PATH_TRAVERSAL_DETECTED');
    }
  });

  it('rejects a path that normalizes to empty (only "." segments)', () => {
    try {
      validatePath('.');
      expect.fail('Expected validatePath to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('INVALID_PATH');
    }
  });

  it('allows filenames containing ".." as a substring (not a segment)', () => {
    // "a..b.txt" is a valid filename — only exact ".." segments are dangerous
    expect(validatePath('a..b.txt')).toBe('a..b.txt');
    expect(validatePath('artifacts/my..file.txt')).toBe('artifacts/my..file.txt');
  });
});

// ─── MIME map ──────────────────────────────────────────────────────────────

describe('getContentType', () => {
  it('returns application/json for .json', () => {
    expect(getContentType('data.json')).toBe('application/json');
  });

  it('returns text/plain for .txt', () => {
    expect(getContentType('notes.txt')).toBe('text/plain');
  });

  it('returns text/markdown for .md', () => {
    expect(getContentType('README.md')).toBe('text/markdown');
  });

  it('returns text/html for .html', () => {
    expect(getContentType('index.html')).toBe('text/html');
  });

  it('returns text/css for .css', () => {
    expect(getContentType('styles.css')).toBe('text/css');
  });

  it('returns application/javascript for .js', () => {
    expect(getContentType('app.js')).toBe('application/javascript');
  });

  it('returns application/typescript for .ts', () => {
    expect(getContentType('auth.ts')).toBe('application/typescript');
  });

  it('returns application/typescript for .tsx', () => {
    expect(getContentType('Component.tsx')).toBe('application/typescript');
  });

  it('returns image/png for .png', () => {
    expect(getContentType('screenshot.png')).toBe('image/png');
  });

  it('returns image/jpeg for .jpg', () => {
    expect(getContentType('photo.jpg')).toBe('image/jpeg');
  });

  it('returns image/jpeg for .jpeg', () => {
    expect(getContentType('photo.jpeg')).toBe('image/jpeg');
  });

  it('returns application/octet-stream for unknown extensions', () => {
    expect(getContentType('archive.xyz')).toBe('application/octet-stream');
  });

  it('returns application/octet-stream for files with no extension', () => {
    expect(getContentType('Makefile')).toBe('application/octet-stream');
  });

  it('is case-insensitive on extensions', () => {
    expect(getContentType('data.JSON')).toBe('application/json');
    expect(getContentType('README.MD')).toBe('text/markdown');
  });

  it('MIME_MAP has all 11 expected entries (json, txt, md, html, css, js, ts, tsx, png, jpg, jpeg)', () => {
    expect(Object.keys(MIME_MAP).sort()).toEqual(
      ['css', 'html', 'jpeg', 'jpg', 'js', 'json', 'md', 'png', 'ts', 'tsx', 'txt'].sort(),
    );
  });
});

// ─── LocalStorageAdapter — save + read ─────────────────────────────────────

describe('LocalStorageAdapter — save + read', () => {
  it('writes a Buffer and reads it back with matching contents', async () => {
    const adapter = makeAdapter();
    const data = Buffer.from('hello, storage', 'utf8');
    await adapter.save('test.txt', data);
    const read = await adapter.read('test.txt');
    expect(read).toEqual(data);
    expect(read.toString('utf8')).toBe('hello, storage');
  });

  it('save creates parent directories automatically', async () => {
    const adapter = makeAdapter();
    const data = Buffer.from('nested');
    await adapter.save('artifacts/session-1/code/auth.ts', data);
    // The file should exist
    const exists = await adapter.exists('artifacts/session-1/code/auth.ts');
    expect(exists).toBe(true);
  });

  it('save returns the full resolved path', async () => {
    const adapter = makeAdapter();
    const fullPath = await adapter.save('test.txt', Buffer.from('x'));
    expect(fullPath).toContain('test.txt');
    expect(fullPath.startsWith(tmpRoot)).toBe(true);
  });

  it('can save and read binary data (PNG header bytes)', async () => {
    const adapter = makeAdapter();
    // PNG signature: 89 50 4E 47 0D 0A 1A 0A
    const pngHeader = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
    await adapter.save('image.png', pngHeader);
    const read = await adapter.read('image.png');
    expect(read).toEqual(pngHeader);
  });

  it('save overwrites an existing file', async () => {
    const adapter = makeAdapter();
    await adapter.save('test.txt', Buffer.from('first'));
    await adapter.save('test.txt', Buffer.from('second'));
    const read = await adapter.read('test.txt');
    expect(read.toString('utf8')).toBe('second');
  });

  it('read throws StorageError(NOT_FOUND) when the file does not exist', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.read('nonexistent.txt');
      expect.fail('Expected read to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('NOT_FOUND');
    }
  });
});

// ─── LocalStorageAdapter — exists ──────────────────────────────────────────

describe('LocalStorageAdapter — exists', () => {
  it('returns false before save', async () => {
    const adapter = makeAdapter();
    expect(await adapter.exists('test.txt')).toBe(false);
  });

  it('returns true after save', async () => {
    const adapter = makeAdapter();
    await adapter.save('test.txt', Buffer.from('x'));
    expect(await adapter.exists('test.txt')).toBe(true);
  });

  it('returns false after delete', async () => {
    const adapter = makeAdapter();
    await adapter.save('test.txt', Buffer.from('x'));
    await adapter.delete('test.txt');
    expect(await adapter.exists('test.txt')).toBe(false);
  });

  it('returns true for nested paths', async () => {
    const adapter = makeAdapter();
    await adapter.save('a/b/c/d.txt', Buffer.from('deep'));
    expect(await adapter.exists('a/b/c/d.txt')).toBe(true);
  });
});

// ─── LocalStorageAdapter — delete ──────────────────────────────────────────

describe('LocalStorageAdapter — delete', () => {
  it('removes the file', async () => {
    const adapter = makeAdapter();
    await adapter.save('test.txt', Buffer.from('x'));
    await adapter.delete('test.txt');
    expect(await adapter.exists('test.txt')).toBe(false);
  });

  it('throws StorageError(NOT_FOUND) when deleting a missing file', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.delete('nonexistent.txt');
      expect.fail('Expected delete to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('NOT_FOUND');
    }
  });
});

// ─── LocalStorageAdapter — list ────────────────────────────────────────────

describe('LocalStorageAdapter — list', () => {
  it('returns an empty array when the root does not exist', async () => {
    // Use a non-existent subdirectory as the root
    const adapter = new LocalStorageAdapter(join(tmpRoot, 'does-not-exist'));
    const items = await adapter.list();
    expect(items).toEqual([]);
  });

  it('returns all files in the root (no subdirectories)', async () => {
    const adapter = makeAdapter();
    await adapter.save('a.txt', Buffer.from('a'));
    await adapter.save('b.txt', Buffer.from('b'));
    const items = await adapter.list();
    expect(items).toHaveLength(2);
    const paths = items.map((i) => i.path).sort();
    expect(paths).toEqual(['a.txt', 'b.txt']);
  });

  it('returns all files recursively (nested directories)', async () => {
    const adapter = makeAdapter();
    await adapter.save('a.txt', Buffer.from('a'));
    await adapter.save('dir/b.txt', Buffer.from('b'));
    await adapter.save('dir/sub/c.txt', Buffer.from('c'));
    const items = await adapter.list();
    expect(items).toHaveLength(3);
    const paths = items.map((i) => i.path).sort();
    expect(paths).toEqual(['a.txt', 'dir/b.txt', 'dir/sub/c.txt']);
  });

  it('returns only files matching the prefix', async () => {
    const adapter = makeAdapter();
    await adapter.save('artifacts/a.txt', Buffer.from('a'));
    await adapter.save('artifacts/b.txt', Buffer.from('b'));
    await adapter.save('other/c.txt', Buffer.from('c'));
    const items = await adapter.list('artifacts/');
    expect(items).toHaveLength(2);
    const paths = items.map((i) => i.path).sort();
    expect(paths).toEqual(['artifacts/a.txt', 'artifacts/b.txt']);
  });

  it('returns empty array when prefix matches nothing', async () => {
    const adapter = makeAdapter();
    await adapter.save('a.txt', Buffer.from('a'));
    const items = await adapter.list('nonexistent/');
    expect(items).toEqual([]);
  });

  it('returns StorageItem objects with path, size, createdAt, contentType', async () => {
    const adapter = makeAdapter();
    await adapter.save('data.json', Buffer.from('{"x":1}'));
    const items = await adapter.list();
    expect(items).toHaveLength(1);
    const item = items[0]!;
    expect(item.path).toBe('data.json');
    expect(item.size).toBe(7);
    expect(item.createdAt).toBeInstanceOf(Date);
    expect(item.contentType).toBe('application/json');
  });

  it('list with prefix that is a directory name (no trailing slash) returns files under it', async () => {
    const adapter = makeAdapter();
    await adapter.save('artifacts/a.txt', Buffer.from('a'));
    await adapter.save('artifacts/sub/b.txt', Buffer.from('b'));
    await adapter.save('other/c.txt', Buffer.from('c'));
    const items = await adapter.list('artifacts');
    expect(items).toHaveLength(2);
    const paths = items.map((i) => i.path).sort();
    expect(paths).toEqual(['artifacts/a.txt', 'artifacts/sub/b.txt']);
  });
});

// ─── LocalStorageAdapter — metadata ────────────────────────────────────────

describe('LocalStorageAdapter — metadata', () => {
  it('returns size, createdAt, contentType', async () => {
    const adapter = makeAdapter();
    await adapter.save('data.json', Buffer.from('{"x":1}'));
    const meta = await adapter.metadata('data.json');
    expect(meta.path).toBe('data.json');
    expect(meta.size).toBe(7);
    expect(meta.createdAt).toBeInstanceOf(Date);
    expect(meta.contentType).toBe('application/json');
  });

  it('returns the correct contentType for a .ts file', async () => {
    const adapter = makeAdapter();
    await adapter.save('auth.ts', Buffer.from('export const x = 1;'));
    const meta = await adapter.metadata('auth.ts');
    expect(meta.contentType).toBe('application/typescript');
  });

  it('throws StorageError(NOT_FOUND) for a missing file', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.metadata('nonexistent.txt');
      expect.fail('Expected metadata to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('NOT_FOUND');
    }
  });

  it('throws StorageError(NOT_FOUND) when the path is a directory, not a file', async () => {
    const adapter = makeAdapter();
    await adapter.save('dir/file.txt', Buffer.from('x'));
    try {
      await adapter.metadata('dir');
      expect.fail('Expected metadata to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('NOT_FOUND');
    }
  });
});

// ─── LocalStorageAdapter — getSignedUrl ────────────────────────────────────

describe('LocalStorageAdapter — getSignedUrl', () => {
  it('returns null (local FS has no signing)', async () => {
    const adapter = makeAdapter();
    const url = await adapter.getSignedUrl('test.txt', 3600);
    expect(url).toBeNull();
  });

  it('returns null even when the file does not exist (no need to check FS)', async () => {
    const adapter = makeAdapter();
    const url = await adapter.getSignedUrl('nonexistent.txt', 3600);
    expect(url).toBeNull();
  });
});

// ─── LocalStorageAdapter — PATH_TRAVERSAL_DETECTED enforcement ─────────────
//
// Every method MUST call validatePath before any FS operation. These tests
// verify the enforcement by passing malicious paths to every method.

describe('LocalStorageAdapter — path traversal enforcement', () => {
  it('save throws PATH_TRAVERSAL_DETECTED for ".." path', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.save('../escape.txt', Buffer.from('x'));
      expect.fail('Expected save to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) {
        // Could be PATH_TRAVERSAL_DETECTED (validatePath) or INVALID_PATH
        expect(['PATH_TRAVERSAL_DETECTED', 'INVALID_PATH']).toContain(err.code);
      }
    }
  });

  it('read throws PATH_TRAVERSAL_DETECTED for absolute path', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.read('/etc/passwd');
      expect.fail('Expected read to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('PATH_TRAVERSAL_DETECTED');
    }
  });

  it('exists throws PATH_TRAVERSAL_DETECTED for ".." path', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.exists('../escape.txt');
      expect.fail('Expected exists to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) {
        expect(['PATH_TRAVERSAL_DETECTED', 'INVALID_PATH']).toContain(err.code);
      }
    }
  });

  it('delete throws PATH_TRAVERSAL_DETECTED for ".." path', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.delete('../escape.txt');
      expect.fail('Expected delete to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) {
        expect(['PATH_TRAVERSAL_DETECTED', 'INVALID_PATH']).toContain(err.code);
      }
    }
  });

  it('list throws PATH_TRAVERSAL_DETECTED for ".." prefix', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.list('../');
      expect.fail('Expected list to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) {
        expect(['PATH_TRAVERSAL_DETECTED', 'INVALID_PATH']).toContain(err.code);
      }
    }
  });

  it('metadata throws PATH_TRAVERSAL_DETECTED for absolute path', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.metadata('/etc/passwd');
      expect.fail('Expected metadata to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('PATH_TRAVERSAL_DETECTED');
    }
  });

  it('save rejects null bytes', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.save('foo\0bar', Buffer.from('x'));
      expect.fail('Expected save to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('INVALID_PATH');
    }
  });

  it('read rejects null bytes', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.read('foo\0bar');
      expect.fail('Expected read to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('INVALID_PATH');
    }
  });

  it('save does NOT allow escaping the root via a deep ".." path', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.save('artifacts/../../../escape.txt', Buffer.from('x'));
      expect.fail('Expected save to throw');
    } catch (err) {
      expect(isStorageError(err)).toBe(true);
      if (isStorageError(err)) expect(err.code).toBe('PATH_TRAVERSAL_DETECTED');
    }
  });

  it('the malicious file was NOT created on the filesystem', async () => {
    const adapter = makeAdapter();
    try {
      await adapter.save('../escape.txt', Buffer.from('x'));
    } catch {
      // expected
    }
    const escapePath = join(tmpRoot, '..', 'escape.txt');
    const exists = await fs.access(escapePath).then(() => true).catch(() => false);
    expect(exists).toBe(false);
  });
});

// ─── LocalStorageAdapter — constructor ─────────────────────────────────────

describe('LocalStorageAdapter — constructor', () => {
  it('uses the provided rootPath when given', async () => {
    const adapter = new LocalStorageAdapter(tmpRoot);
    await adapter.save('test.txt', Buffer.from('x'));
    // Verify the file is under tmpRoot, not under ./storage
    const expectedPath = join(tmpRoot, 'test.txt');
    const exists = await fs.access(expectedPath).then(() => true).catch(() => false);
    expect(exists).toBe(true);
  });

  it('falls back to process.env.STORAGE_ROOT when rootPath is omitted', async () => {
    const originalStorageRoot = process.env.STORAGE_ROOT;
    const envRoot = path.join(tmpRoot, 'env-root');
    await fs.mkdir(envRoot, { recursive: true });
    process.env.STORAGE_ROOT = envRoot;
    try {
      const adapter = new LocalStorageAdapter();
      await adapter.save('test.txt', Buffer.from('x'));
      const expectedPath = join(envRoot, 'test.txt');
      const exists = await fs.access(expectedPath).then(() => true).catch(() => false);
      expect(exists).toBe(true);
    } finally {
      if (originalStorageRoot === undefined) delete process.env.STORAGE_ROOT;
      else process.env.STORAGE_ROOT = originalStorageRoot;
    }
  });

  it('falls back to ./storage when neither rootPath nor STORAGE_ROOT is set', () => {
    const originalStorageRoot = process.env.STORAGE_ROOT;
    delete process.env.STORAGE_ROOT;
    try {
      const adapter = new LocalStorageAdapter();
      // We can't easily verify ./storage without polluting the project,
      // but we can verify the adapter is constructed without throwing.
      expect(adapter).toBeDefined();
    } finally {
      if (originalStorageRoot === undefined) delete process.env.STORAGE_ROOT;
      else process.env.STORAGE_ROOT = originalStorageRoot;
    }
  });
});

// ─── StorageAdapter interface conformance ──────────────────────────────────

describe('StorageAdapter interface conformance', () => {
  it('LocalStorageAdapter satisfies the StorageAdapter interface (type-level)', () => {
    const adapter: StorageAdapter = new LocalStorageAdapter(tmpRoot);
    expect(typeof adapter.save).toBe('function');
    expect(typeof adapter.read).toBe('function');
    expect(typeof adapter.exists).toBe('function');
    expect(typeof adapter.delete).toBe('function');
    expect(typeof adapter.list).toBe('function');
    expect(typeof adapter.getSignedUrl).toBe('function');
    expect(typeof adapter.metadata).toBe('function');
  });

  it('StorageItem has the expected shape (type-level)', () => {
    const item: StorageItem = {
      path: 'test.txt',
      size: 100,
      createdAt: new Date(),
      contentType: 'text/plain',
    };
    expect(item.path).toBe('test.txt');
    expect(item.size).toBe(100);
    expect(item.contentType).toBe('text/plain');
  });
});
