/**
 * Unit tests for src/lib/providers/verify.ts + expected-models.ts
 *
 * Blueprint v4.1 §23 (Testing Strategy — verify response matches expected
 * model), §7, §8, §22 Phase 1 Step 1.2
 *
 * Coverage:
 *  - expected-models.ts:
 *      • getExpectedModelClaim: returns the model for echo providers, "GLM"
 *        for Z.ai, "" for LM Studio
 *      • UNVERIFIABLE_PROVIDERS contains lmstudio
 *      • isUnverifiableProvider: true for lmstudio, false for everything else
 *      • PROVIDER_CLAIM_DOCS: 10 entries, one per provider
 *  - verify.ts:
 *      • extractClaimedModel: strips "I am", "I'm", "Model:", "operating as X",
 *        punctuation, whitespace; handles GLM-4-Plus, gpt-4o, llama3.2, etc.
 *      • isClaimMatched: case-insensitive substring; empty expected → false
 *      • verifyProviderModel:
 *          - dispatches to streamOpenAICompatible for kind=openai
 *          - dispatches to streamZai for kind=zai
 *          - throws PROVIDER_NOT_CONFIGURED for kind=anthropic (not yet impl)
 *          - Z.ai special case: expected claim is "GLM", matched=true if
 *            response mentions GLM
 *          - LM Studio special case: returns matched=false, unverifiable=true,
 *            does NOT throw, does NOT call the adapter
 *          - 10s timeout: verification that takes >10s throws STREAM_ABORTED
 *          - passes AbortSignal to the adapter
 *          - returns VerificationResult with all fields populated
 *
 * Mocking strategy:
 *  - streamOpenAICompatible + streamZai are mocked via vi.mock so no real
 *    network calls happen. Tests control the mocked completion.
 *  - @/lib/logger is mocked to suppress noise.
 *  - The 10s timeout is tested with vi.useFakeTimers + advancing 10s.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

// ─── Mock setup ────────────────────────────────────────────────────────────

vi.mock('@/lib/logger', () => ({
  logger: {
    trace: vi.fn(),
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    fatal: vi.fn(),
    child: vi.fn(() => ({
      trace: vi.fn(),
      debug: vi.fn(),
      info: vi.fn(),
      warn: vi.fn(),
      error: vi.fn(),
      fatal: vi.fn(),
      child: vi.fn(),
      level: 'debug',
    })),
  },
}));

// Mock the OpenAI adapter — tests control the returned completion
const streamOpenAIMock = vi.fn();
vi.mock('@/lib/providers/stream-openai', () => ({
  streamOpenAICompatible: streamOpenAIMock,
}));

// Mock the Z.ai adapter — tests control the returned completion
const streamZaiMock = vi.fn();
vi.mock('@/lib/providers/stream-zai', () => ({
  streamZai: streamZaiMock,
}));

// ─── Imports (after mocks) ─────────────────────────────────────────────────

import {
  verifyProviderModel,
  extractClaimedModel,
  isClaimMatched,
  VERIFICATION_TIMEOUT_MS,
  type VerificationResult,
} from '@/lib/providers/verify';
import {
  getExpectedModelClaim,
  isUnverifiableProvider,
  UNVERIFIABLE_PROVIDERS,
  ZAI_EXPECTED_CLAIM,
  PROVIDER_CLAIM_DOCS,
  type BuiltinProviderId,
} from '@/lib/providers/expected-models';
import { isProviderError, type ProviderConfig } from '@/lib/providers/types';

// ─── Test helpers ──────────────────────────────────────────────────────────

function makeProvider(overrides: Partial<ProviderConfig> = {}): ProviderConfig {
  return {
    id: 'openai',
    name: 'OpenAI',
    kind: 'openai',
    baseUrl: 'https://api.openai.com/v1/chat/completions',
    apiKey: 'sk-test',
    enabled: true,
    isLocal: false,
    ...overrides,
  };
}

function makeCompletion(content: string) {
  return {
    content,
    toolCalls: [],
    finishReason: 'stop',
    tokensUsed: Math.ceil(content.length / 4),
    costUsd: 0,
    model: 'test-model',
    providerId: 'test-provider',
  };
}

// ─── expected-models.ts ────────────────────────────────────────────────────

describe('expected-models — getExpectedModelClaim', () => {
  it('returns "GLM" for Z.ai regardless of the requested model', () => {
    expect(getExpectedModelClaim('zai', 'glm-4.6')).toBe('GLM');
    expect(getExpectedModelClaim('zai', 'glm-4-plus')).toBe('GLM');
    expect(getExpectedModelClaim('zai', 'anything-else')).toBe('GLM');
  });

  it('returns "" for LM Studio (unverifiable)', () => {
    expect(getExpectedModelClaim('lmstudio', 'loaded-model')).toBe('');
    expect(getExpectedModelClaim('lmstudio', 'anything')).toBe('');
  });

  it('returns the requested model for OpenAI', () => {
    expect(getExpectedModelClaim('openai', 'gpt-4o')).toBe('gpt-4o');
    expect(getExpectedModelClaim('openai', 'gpt-4o-mini')).toBe('gpt-4o-mini');
    expect(getExpectedModelClaim('openai', 'gpt-4-turbo')).toBe('gpt-4-turbo');
  });

  it('returns the requested model for Mistral', () => {
    expect(getExpectedModelClaim('mistral', 'mistral-large-latest')).toBe('mistral-large-latest');
    expect(getExpectedModelClaim('mistral', 'mistral-small-latest')).toBe('mistral-small-latest');
  });

  it('returns the requested model for Anthropic (forward-looking)', () => {
    expect(getExpectedModelClaim('anthropic', 'claude-3-5-sonnet-latest')).toBe('claude-3-5-sonnet-latest');
  });

  it('returns the requested model for Groq', () => {
    expect(getExpectedModelClaim('groq', 'llama-3.3-70b-versatile')).toBe('llama-3.3-70b-versatile');
  });

  it('returns the requested model for Together', () => {
    expect(getExpectedModelClaim('together', 'meta-llama/Llama-3.3-70B-Instruct-Turbo')).toBe('meta-llama/Llama-3.3-70B-Instruct-Turbo');
  });

  it('returns the requested model for OpenRouter', () => {
    expect(getExpectedModelClaim('openrouter', 'openai/gpt-4o')).toBe('openai/gpt-4o');
  });

  it('returns the requested model for Cloudflare', () => {
    expect(getExpectedModelClaim('cloudflare', '@cf/meta/llama-3.1-8b-instruct')).toBe('@cf/meta/llama-3.1-8b-instruct');
  });

  it('returns the requested model for Ollama', () => {
    expect(getExpectedModelClaim('ollama', 'llama3.2')).toBe('llama3.2');
    expect(getExpectedModelClaim('ollama', 'qwen2.5')).toBe('qwen2.5');
  });

  it('returns the requested model for unknown provider IDs (fallback to echo behavior)', () => {
    expect(getExpectedModelClaim('custom-provider', 'some-model')).toBe('some-model');
  });
});

describe('expected-models — UNVERIFIABLE_PROVIDERS', () => {
  it('contains lmstudio', () => {
    expect(UNVERIFIABLE_PROVIDERS).toContain('lmstudio');
  });

  it('has exactly 1 unverifiable provider (LM Studio)', () => {
    expect(UNVERIFIABLE_PROVIDERS).toHaveLength(1);
  });
});

describe('expected-models — isUnverifiableProvider', () => {
  it('returns true for lmstudio', () => {
    expect(isUnverifiableProvider('lmstudio')).toBe(true);
  });

  it('returns false for every other provider', () => {
    const verifiable: BuiltinProviderId[] = [
      'zai', 'mistral', 'openai', 'anthropic', 'groq',
      'together', 'openrouter', 'cloudflare', 'ollama',
    ];
    for (const id of verifiable) {
      expect(isUnverifiableProvider(id)).toBe(false);
    }
  });

  it('returns false for unknown provider IDs', () => {
    expect(isUnverifiableProvider('custom-provider')).toBe(false);
  });
});

describe('expected-models — ZAI_EXPECTED_CLAIM', () => {
  it('is "GLM"', () => {
    expect(ZAI_EXPECTED_CLAIM).toBe('GLM');
  });
});

describe('expected-models — PROVIDER_CLAIM_DOCS', () => {
  it('has 10 entries (one per provider)', () => {
    expect(PROVIDER_CLAIM_DOCS).toHaveLength(10);
  });

  it('covers all 10 provider IDs', () => {
    const ids = PROVIDER_CLAIM_DOCS.map((d) => d.providerId);
    const expected: BuiltinProviderId[] = [
      'zai', 'mistral', 'openai', 'anthropic', 'groq',
      'together', 'openrouter', 'cloudflare', 'ollama', 'lmstudio',
    ];
    for (const id of expected) {
      expect(ids).toContain(id);
    }
  });

  it('Z.ai entry has behavior=always-zai-glm', () => {
    const zai = PROVIDER_CLAIM_DOCS.find((d) => d.providerId === 'zai');
    expect(zai!.behavior).toBe('always-zai-glm');
  });

  it('LM Studio entry has behavior=unverifiable', () => {
    const lmstudio = PROVIDER_CLAIM_DOCS.find((d) => d.providerId === 'lmstudio');
    expect(lmstudio!.behavior).toBe('unverifiable');
  });
});

// ─── verify.ts — extractClaimedModel ───────────────────────────────────────

describe('extractClaimedModel', () => {
  it('returns the string as-is when already clean', () => {
    expect(extractClaimedModel('gpt-4o')).toBe('gpt-4o');
    expect(extractClaimedModel('mistral-large-latest')).toBe('mistral-large-latest');
    expect(extractClaimedModel('llama3.2')).toBe('llama3.2');
  });

  it('strips "I am " prefix', () => {
    expect(extractClaimedModel('I am GPT-4o')).toBe('GPT-4o');
    expect(extractClaimedModel('I am GLM-4-Plus')).toBe('GLM-4-Plus');
  });

  it('strips "I\'m " prefix', () => {
    expect(extractClaimedModel("I'm Claude 3.5 Sonnet")).toBe('Claude 3.5 Sonnet');
  });

  it('strips "This is " prefix', () => {
    expect(extractClaimedModel('This is Llama 3.2')).toBe('Llama 3.2');
  });

  it('strips "Model: " prefix', () => {
    expect(extractClaimedModel('Model: claude-3-5-sonnet-latest')).toBe('claude-3-5-sonnet-latest');
  });

  it('strips ", operating as X" suffix (Blueprint §11 agent identity)', () => {
    expect(extractClaimedModel('GLM-4-Plus, operating as Hermes')).toBe('GLM-4-Plus');
    expect(extractClaimedModel('GPT-4o, operating as OpenClaw.')).toBe('GPT-4o');
    expect(extractClaimedModel('Mistral Large, operating as Researcher.')).toBe('Mistral Large');
  });

  it('strips trailing period', () => {
    expect(extractClaimedModel('GPT-4o.')).toBe('GPT-4o');
    expect(extractClaimedModel('I am Claude.')).toBe('Claude');
  });

  it('strips surrounding quotes and brackets', () => {
    expect(extractClaimedModel('"gpt-4o"')).toBe('gpt-4o');
    expect(extractClaimedModel('[gpt-4o]')).toBe('gpt-4o');
    expect(extractClaimedModel("'llama3.2'")).toBe('llama3.2');
  });

  it('collapses internal whitespace', () => {
    expect(extractClaimedModel('Llama   3.2   70B')).toBe('Llama 3.2 70B');
  });

  it('trims leading/trailing whitespace', () => {
    expect(extractClaimedModel('  GPT-4o  ')).toBe('GPT-4o');
    expect(extractClaimedModel('\n\nGLM-4-Plus\n')).toBe('GLM-4-Plus');
  });

  it('handles complex combined cases', () => {
    expect(extractClaimedModel('I am GPT-4o, operating as Coder.')).toBe('GPT-4o');
    expect(extractClaimedModel("I'm Claude 3.5 Sonnet, operating as Reviewer.")).toBe('Claude 3.5 Sonnet');
  });

  it('returns empty string for empty input', () => {
    expect(extractClaimedModel('')).toBe('');
    expect(extractClaimedModel('   ')).toBe('');
  });

  it('preserves case (does NOT lowercase)', () => {
    expect(extractClaimedModel('GPT-4o')).toBe('GPT-4o');
    expect(extractClaimedModel('gpt-4o')).toBe('gpt-4o');
    expect(extractClaimedModel('GLM-4-Plus')).toBe('GLM-4-Plus');
  });

  it('handles "GLM-4-Plus" (Z.ai canonical name)', () => {
    expect(extractClaimedModel('GLM-4-Plus')).toBe('GLM-4-Plus');
    expect(extractClaimedModel('I am GLM-4-Plus')).toBe('GLM-4-Plus');
  });
});

// ─── verify.ts — isClaimMatched ────────────────────────────────────────────

describe('isClaimMatched', () => {
  it('returns true when claimed contains expected (case-insensitive substring)', () => {
    expect(isClaimMatched('GPT-4o', 'gpt-4o')).toBe(true);
    expect(isClaimMatched('gpt-4o', 'GPT-4O')).toBe(true);
    expect(isClaimMatched('I am GPT-4o', 'gpt-4o')).toBe(true);
    expect(isClaimMatched('GLM-4-Plus', 'GLM')).toBe(true);
    expect(isClaimMatched('glm-4-plus', 'GLM')).toBe(true);
  });

  it('returns false when claimed does not contain expected', () => {
    expect(isClaimMatched('gpt-4o', 'claude')).toBe(false);
    expect(isClaimMatched('Llama 3.2', 'gpt-4o')).toBe(false);
  });

  it('returns false when expected is empty (unverifiable)', () => {
    expect(isClaimMatched('anything', '')).toBe(false);
    expect(isClaimMatched('', '')).toBe(false);
  });

  it('returns true when claimed is empty but expected is also empty? (no — empty expected is always false)', () => {
    expect(isClaimMatched('', '')).toBe(false);
  });

  it('handles substring matches across word boundaries', () => {
    expect(isClaimMatched('Llama 3.3 70B Versatile', 'llama-3.3-70b-versatile')).toBe(false); // not a substring
    expect(isClaimMatched('llama-3.3-70b-versatile', 'llama')).toBe(true); // substring
  });
});

// ─── verify.ts — verifyProviderModel (OpenAI path) ─────────────────────────

describe('verifyProviderModel — OpenAI path', () => {
  beforeEach(() => {
    streamOpenAIMock.mockReset();
    streamZaiMock.mockReset();
  });

  it('dispatches to streamOpenAICompatible for kind=openai', async () => {
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('gpt-4o'));

    const result = await verifyProviderModel(
      makeProvider({ id: 'openai', kind: 'openai' }),
      'gpt-4o',
    );

    expect(streamOpenAIMock).toHaveBeenCalledTimes(1);
    expect(streamZaiMock).not.toHaveBeenCalled();
    expect(result.matched).toBe(true);
    expect(result.claimedModel).toBe('gpt-4o');
    expect(result.expectedClaim).toBe('gpt-4o');
  });

  it('passes the verification prompt as the message', async () => {
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('gpt-4o'));

    await verifyProviderModel(makeProvider(), 'gpt-4o');

    const params = streamOpenAIMock.mock.calls[0]![0];
    expect(params.messages).toHaveLength(1);
    expect(params.messages[0].role).toBe('user');
    expect(params.messages[0].content).toContain('What model are you?');
    expect(params.messages[0].content).toContain('ONLY your model name');
  });

  it('passes the model + provider through', async () => {
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('gpt-4o'));

    await verifyProviderModel(
      makeProvider({ id: 'openai', name: 'OpenAI' }),
      'gpt-4o-mini',
    );

    const params = streamOpenAIMock.mock.calls[0]![0];
    expect(params.model).toBe('gpt-4o-mini');
    expect(params.provider.id).toBe('openai');
  });

  it('returns matched=true when claimed model matches (case-insensitive)', async () => {
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('I am GPT-4o.'));

    const result = await verifyProviderModel(makeProvider(), 'gpt-4o');

    expect(result.matched).toBe(true);
    expect(result.claimedModel).toBe('GPT-4o');
    expect(result.expectedClaim).toBe('gpt-4o');
  });

  it('returns matched=false when claimed model does NOT match', async () => {
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('I am Claude 3.5 Sonnet.'));

    const result = await verifyProviderModel(makeProvider(), 'gpt-4o');

    expect(result.matched).toBe(false);
    expect(result.claimedModel).toBe('Claude 3.5 Sonnet');
    expect(result.expectedClaim).toBe('gpt-4o');
  });

  it('returns matched=true for substring matches (loose matching)', async () => {
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('I am GPT-4o-mini.'));

    const result = await verifyProviderModel(makeProvider(), 'gpt-4o');

    // "gpt-4o" is a substring of "GPT-4o-mini" → matched
    expect(result.matched).toBe(true);
  });

  it('returns a fully-populated VerificationResult', async () => {
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('gpt-4o'));

    const result = await verifyProviderModel(makeProvider(), 'gpt-4o');

    expect(result.providerId).toBe('openai');
    expect(result.model).toBe('gpt-4o');
    expect(result.claimedModel).toBe('gpt-4o');
    expect(result.expectedClaim).toBe('gpt-4o');
    expect(result.matched).toBe(true);
    expect(result.response).toBe('gpt-4o');
    expect(typeof result.durationMs).toBe('number');
    expect(result.durationMs).toBeGreaterThanOrEqual(0);
    expect(typeof result.verifiedAt).toBe('number');
    expect(result.unverifiable).toBe(false);
  });

  it('works for Mistral (kind=openai)', async () => {
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('mistral-large-latest'));

    const result = await verifyProviderModel(
      makeProvider({ id: 'mistral', name: 'Mistral', kind: 'openai' }),
      'mistral-large-latest',
    );

    expect(result.matched).toBe(true);
    expect(result.expectedClaim).toBe('mistral-large-latest');
  });

  it('works for Ollama (kind=openai, isLocal=true)', async () => {
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('llama3.2'));

    const result = await verifyProviderModel(
      makeProvider({
        id: 'ollama',
        name: 'Ollama',
        kind: 'openai',
        isLocal: true,
        apiKey: null,
      }),
      'llama3.2',
    );

    expect(result.matched).toBe(true);
    expect(result.expectedClaim).toBe('llama3.2');
  });
});

// ─── verify.ts — verifyProviderModel (Z.ai path) ───────────────────────────

describe('verifyProviderModel — Z.ai path', () => {
  beforeEach(() => {
    streamOpenAIMock.mockReset();
    streamZaiMock.mockReset();
  });

  it('dispatches to streamZai for kind=zai', async () => {
    streamZaiMock.mockResolvedValueOnce(makeCompletion('GLM-4-Plus'));

    const result = await verifyProviderModel(
      makeProvider({ id: 'zai', name: 'Z.ai', kind: 'zai' }),
      'glm-4.6',
    );

    expect(streamZaiMock).toHaveBeenCalledTimes(1);
    expect(streamOpenAIMock).not.toHaveBeenCalled();
    expect(result.matched).toBe(true);
  });

  it('Z.ai special case: expected claim is "GLM" regardless of requested model (Blueprint §7/§8)', async () => {
    streamZaiMock.mockResolvedValueOnce(makeCompletion('GLM-4-Plus'));

    const result = await verifyProviderModel(
      makeProvider({ id: 'zai', kind: 'zai' }),
      'glm-4.6', // user requests glm-4.6, but SDK serves GLM-4-Plus per §8
    );

    expect(result.expectedClaim).toBe('GLM');
    expect(result.claimedModel).toBe('GLM-4-Plus');
    expect(result.matched).toBe(true);
  });

  it('Z.ai: matched=true even when response says "I am GLM-4-Plus, operating as Hermes"', async () => {
    streamZaiMock.mockResolvedValueOnce(
      makeCompletion('I am GLM-4-Plus, operating as Hermes.'),
    );

    const result = await verifyProviderModel(
      makeProvider({ id: 'zai', kind: 'zai' }),
      'glm-4.6',
    );

    expect(result.claimedModel).toBe('GLM-4-Plus');
    expect(result.matched).toBe(true);
  });

  it('Z.ai: matched=false if response does NOT mention GLM (SDK serving wrong model — §8 violation)', async () => {
    streamZaiMock.mockResolvedValueOnce(makeCompletion('I am Llama 3.'));

    const result = await verifyProviderModel(
      makeProvider({ id: 'zai', kind: 'zai' }),
      'glm-4.6',
    );

    expect(result.claimedModel).toBe('Llama 3');
    expect(result.matched).toBe(false);
  });

  it('Z.ai: propagates ZAI_DISABLED error when provider is disabled (does NOT catch)', async () => {
    // The adapter throws ZAI_DISABLED; the verifier should propagate it
    const { ProviderError } = await import('@/lib/providers/types');
    streamZaiMock.mockRejectedValueOnce(
      new ProviderError('ZAI_DISABLED', 'Z.ai is disabled'),
    );

    try {
      await verifyProviderModel(
        makeProvider({ id: 'zai', kind: 'zai', enabled: false }),
        'glm-4.6',
      );
      expect.fail('Expected verifyProviderModel to throw');
    } catch (err) {
      expect(isProviderError(err)).toBe(true);
      if (isProviderError(err)) expect(err.code).toBe('ZAI_DISABLED');
    }
  });
});

// ─── verify.ts — verifyProviderModel (LM Studio unverifiable path) ─────────

describe('verifyProviderModel — LM Studio (unverifiable)', () => {
  beforeEach(() => {
    streamOpenAIMock.mockReset();
    streamZaiMock.mockReset();
  });

  it('returns matched=false and unverifiable=true for LM Studio', async () => {
    const result = await verifyProviderModel(
      makeProvider({
        id: 'lmstudio',
        name: 'LM Studio',
        kind: 'openai',
        isLocal: true,
        apiKey: null,
      }),
      'loaded-model',
    );

    expect(result.matched).toBe(false);
    expect(result.unverifiable).toBe(true);
    expect(result.expectedClaim).toBe('');
    expect(result.claimedModel).toBe('');
    expect(result.response).toBe('');
  });

  it('does NOT call the adapter for LM Studio (no network call)', async () => {
    await verifyProviderModel(
      makeProvider({
        id: 'lmstudio',
        kind: 'openai',
        isLocal: true,
      }),
      'loaded-model',
    );

    expect(streamOpenAIMock).not.toHaveBeenCalled();
    expect(streamZaiMock).not.toHaveBeenCalled();
  });

  it('does NOT throw for LM Studio (returns a result)', async () => {
    await expect(
      verifyProviderModel(
        makeProvider({ id: 'lmstudio', kind: 'openai', isLocal: true }),
        'loaded-model',
      ),
    ).resolves.toBeDefined();
  });
});

// ─── verify.ts — verifyProviderModel (unsupported kind) ────────────────────

describe('verifyProviderModel — unsupported provider kind', () => {
  beforeEach(() => {
    streamOpenAIMock.mockReset();
    streamZaiMock.mockReset();
  });

  it('throws PROVIDER_NOT_CONFIGURED for kind=anthropic (not yet implemented)', async () => {
    try {
      await verifyProviderModel(
        makeProvider({ id: 'anthropic', kind: 'anthropic' }),
        'claude-3-5-sonnet-latest',
      );
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isProviderError(err)).toBe(true);
      if (isProviderError(err)) expect(err.code).toBe('PROVIDER_NOT_CONFIGURED');
    }
  });

  it('throws PROVIDER_NOT_CONFIGURED for kind=custom', async () => {
    try {
      await verifyProviderModel(
        makeProvider({ id: 'custom-x', kind: 'custom' }),
        'some-model',
      );
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('PROVIDER_NOT_CONFIGURED');
    }
  });
});

// ─── verify.ts — timeout ───────────────────────────────────────────────────

describe('verifyProviderModel — timeout', () => {
  beforeEach(() => {
    streamOpenAIMock.mockReset();
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('VERIFICATION_TIMEOUT_MS is 10_000 (10 seconds)', () => {
    expect(VERIFICATION_TIMEOUT_MS).toBe(10_000);
  });

  it('aborts with STREAM_ABORTED when the adapter takes > 10s', async () => {
    // Mock the adapter to never resolve (simulating a hung provider)
    streamOpenAIMock.mockImplementationOnce(
      (_params: { signal?: AbortSignal }) =>
        new Promise((_resolve, reject) => {
          // Reject with AbortError when the signal fires
          // The adapter normally does this; here we simulate it
          // Wait — actually the verifier wraps the adapter call. If the
          // adapter doesn't honor the signal, the verifier's setTimeout
          // fires controller.abort(), but the adapter's promise is still
          // pending. The verifier needs to handle this case.
          // For this test, we'll have the adapter reject on abort.
          // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
          _params.signal!.addEventListener('abort', () => {
            const err = new Error('aborted');
            err.name = 'AbortError';
            reject(err);
          });
        }),
    );

    // Start the verification (returns a promise that will reject after timeout)
    const verificationPromise = verifyProviderModel(
      makeProvider(),
      'gpt-4o',
    );

    // Advance fake timers by 10 seconds — this fires the verifier's setTimeout
    vi.advanceTimersByTime(VERIFICATION_TIMEOUT_MS);

    try {
      await verificationPromise;
      expect.fail('Expected verifyProviderModel to throw');
    } catch (err) {
      expect(isProviderError(err)).toBe(true);
      if (isProviderError(err)) expect(err.code).toBe('STREAM_ABORTED');
    }
  });

  it('passes an AbortSignal to the adapter', async () => {
    streamOpenAIMock.mockResolvedValueOnce(makeCompletion('gpt-4o'));

    await verifyProviderModel(makeProvider(), 'gpt-4o');

    const params = streamOpenAIMock.mock.calls[0]![0];
    expect(params.signal).toBeInstanceOf(AbortSignal);
  });
});

// ─── verify.ts — adapter error propagation ─────────────────────────────────

describe('verifyProviderModel — adapter error propagation', () => {
  beforeEach(() => {
    streamOpenAIMock.mockReset();
  });

  it('propagates ProviderError from the adapter (e.g., AUTH_FAILED)', async () => {
    const { ProviderError } = await import('@/lib/providers/types');
    streamOpenAIMock.mockRejectedValueOnce(
      new ProviderError('AUTH_FAILED', 'bad key', undefined, 'openai', 401),
    );

    try {
      await verifyProviderModel(makeProvider(), 'gpt-4o');
      expect.fail('Expected to throw');
    } catch (err) {
      expect(isProviderError(err)).toBe(true);
      if (isProviderError(err)) expect(err.code).toBe('AUTH_FAILED');
    }
  });

  it('propagates ProviderError(RATE_LIMITED) from the adapter', async () => {
    const { ProviderError } = await import('@/lib/providers/types');
    streamOpenAIMock.mockRejectedValueOnce(
      new ProviderError('RATE_LIMITED', 'slow down', undefined, 'openai', 429),
    );

    try {
      await verifyProviderModel(makeProvider(), 'gpt-4o');
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('RATE_LIMITED');
    }
  });

  it('propagates PROVIDER_DISABLED from the adapter', async () => {
    const { ProviderError } = await import('@/lib/providers/types');
    streamOpenAIMock.mockRejectedValueOnce(
      new ProviderError('PROVIDER_DISABLED', 'disabled'),
    );

    try {
      await verifyProviderModel(makeProvider({ enabled: false }), 'gpt-4o');
      expect.fail('Expected to throw');
    } catch (err) {
      if (isProviderError(err)) expect(err.code).toBe('PROVIDER_DISABLED');
    }
  });
});

// ─── verify.ts — VerificationResult type narrowing ─────────────────────────

describe('VerificationResult type (compile-time check)', () => {
  it('has all documented fields', () => {
    const result: VerificationResult = {
      providerId: 'openai',
      model: 'gpt-4o',
      claimedModel: 'gpt-4o',
      expectedClaim: 'gpt-4o',
      matched: true,
      response: 'gpt-4o',
      durationMs: 100,
      verifiedAt: Date.now(),
      unverifiable: false,
    };
    expect(result.matched).toBe(true);
    expect(result.unverifiable).toBe(false);
  });
});
