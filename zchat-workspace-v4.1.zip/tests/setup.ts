/**
 * Global Test Setup — runs once before all test files
 *
 * Blueprint v4.1 §22 Phase 0 Step 0.8, §23 (Testing Strategy)
 *
 * Design goals:
 *  - Set environment variables that the existing test files depend on
 *    (db.ts, auth.ts, logger.ts all read env vars at module load time)
 *  - Use a SEPARATE test database — never pollute the dev DB
 *  - Suppress console.error noise from React's error-boundary internal logging
 *    so test output stays readable. Per-test `vi.spyOn(console, 'error')`
 *    still works on top of this baseline mock.
 *
 * This file is referenced from vitest.config.ts → test.setupFiles.
 * It exports nothing — it's purely for side effects.
 *
 * Strictly typed. No `any`.
 */

import { vi } from 'vitest';

// ─── Environment variables ─────────────────────────────────────────────────
//
// Set BEFORE any test file imports modules that read env vars at load time
// (db.ts, auth.ts, logger.ts). Vitest runs setupFiles before importing test
// files, so these are in place when the test files' top-level imports fire.

// NODE_ENV — 'test' so logger.ts picks the dev (pretty-print) transport and
// db.ts uses dev log levels. Production transport would emit JSON lines that
// are harder to assert against in tests.
process.env.NODE_ENV = 'test';

// DATABASE_URL — separate test DB. The 'file:' scheme is Prisma's SQLite
// adapter format. NEVER point this at the dev DB — tests drop + recreate
// the schema and would destroy development data.
process.env.DATABASE_URL = 'file:./prisma/test.db';

// NEXTAUTH_SECRET — auth.ts requires this to be at least 16 chars or it
// throws AuthError(AUTH_CONFIG_MISSING). The test value is a fixed string
// so JWT encode/decode roundtrips are deterministic.
process.env.NEXTAUTH_SECRET = 'test-secret-at-least-16-chars-long';

// LOG_LEVEL — 'warn' so debug/info logs from logger.ts are suppressed
// during tests. Only warnings + errors surface, keeping test output clean.
// Individual tests that need to assert on log output capture their own
// stream (see tests/unit/logger.test.ts).
process.env.LOG_LEVEL = 'warn';

// NEXT_RUNTIME — explicitly unset so logger.ts's isEdgeRuntime() returns
// false in tests (we want the Node transport, not the Edge fallback).
delete process.env.NEXT_RUNTIME;

// ─── Global console.error suppression ──────────────────────────────────────
//
// React 19 logs caught errors to console.error before the error boundary's
// componentDidCatch fires. This produces noisy output during ErrorBoundary
// tests (every test that throws in a child produces 2-3 console.error lines).
//
// We replace console.error with a no-op baseline. Per-test spies via
// `vi.spyOn(console, 'error')` still work — they layer on top of this mock
// and capture the calls. When a per-test spy is active, the spy receives
// the call; when no spy is active, the call is silently dropped.
//
// We DO NOT suppress console.warn — those are often meaningful test signals
// (e.g., queue.ts logs 'Job failed permanently' at warn level).

const originalConsoleError = console.error;

console.error = (..._args: unknown[]): void => {
  // Intentionally empty. Per-test spies via vi.spyOn(console, 'error') will
  // replace this function and capture calls; when the spy is restored
  // (afterEach), this baseline no-op is restored too.
};

// Allow tests to access the original console.error if they need it.
// Exposed on globalThis so test files can do:
//   const real = (globalThis as any).__originalConsoleError;
// without needing a separate import.
(globalThis as unknown as { __originalConsoleError: typeof console.error }).__originalConsoleError =
  originalConsoleError;

// ─── Vitest global hooks ───────────────────────────────────────────────────
//
// afterEach runs after every test, in every file. We use it to restore
// mocks that test files create via vi.spyOn. Without this, a spy created
// in one test leaks into the next test in the same file.
//
// We intentionally do NOT restore mocks via `afterEach` here for ALL mocks —
// only console.error, because that's the one we replaced globally. Other
// mocks (e.g., db.job.findUnique in queue.test.ts) are scoped per-file and
// cleaned up by the test file's own afterEach.

afterEach(() => {
  // Restore the global console.error baseline. If a per-test spy replaced
  // it, vi.restoreAllMocks() in the test file's own afterEach will fire
  // first (file-level hooks run before global hooks), so by the time we
  // get here, console.error is either the spy (about to be restored) or
  // our baseline no-op. Resetting to the baseline ensures the next test
  // starts clean.
  console.error = (..._args: unknown[]): void => {
    // no-op baseline
  };
});

// ─── Module-level export marker (no actual exports) ────────────────────────
//
// Vitest's setupFiles run as plain scripts — they don't need to export
// anything. The `export {}` below keeps TypeScript happy by treating this
// file as a module rather than a global script.

export {};
