import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/app/**/*.{ts,tsx}',
    './src/components/**/*.{ts,tsx}',
    './src/hooks/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        // Black/zinc only — no violet (Blueprint §26)
        background: '#000000',
        foreground: '#fafafa',
        card: '#0a0a0a',
        border: '#27272a',
        input: '#18181b',
        primary: '#fafafa',
        secondary: '#27272a',
        muted: '#18181b',
        accent: '#3f3f46',
        destructive: '#dc2626',
        ring: '#52525b',
      },
      fontFamily: {
        sans: ['var(--font-inter)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
    },
  },
  plugins: [],
};

export default config;
